import { supabaseUrl, publishableKey } from './live-config.mjs';

export const readActions = new Set(['self', 'phone', 'messenger', 'search', 'profile']);
// Protect against accidentally wiring an old order/AI/Flow transport into this page.
export function guardedFetch(transport = fetch) {
  return (input, options = {}) => {
    const url = new URL(typeof input === 'string' ? input : input.url || String(input));
    if (url.origin !== supabaseUrl) throw new Error('readonly_destination_blocked');
    const method = (options.method || 'GET').toUpperCase();
    const auth = (url.pathname === '/auth/v1/token' && method === 'POST' && ['password', 'refresh_token'].includes(url.searchParams.get('grant_type'))) ||
      (url.pathname === '/auth/v1/user' && method === 'GET') ||
      (url.pathname === '/auth/v1/logout' && method === 'POST' && url.searchParams.get('scope') === 'local');
    let rpc = false;
    if (url.pathname === '/rest/v1/rpc/dwell_ops_sidebar_read' && method === 'POST') {
      let body;
      try { body = JSON.parse(options.body); } catch { throw new Error('readonly_request_invalid'); }
      rpc = readActions.has(body.p_action);
    }
    if (url.pathname === '/rest/v1/rpc/dwell_ops_sidebar_username' && method === 'POST') {
      let body;
      try { body = JSON.parse(options.body); } catch { throw new Error('readonly_request_invalid'); }
      rpc = body && Object.keys(body).length === 1 &&
        typeof body.p_username === 'string' && /^@[a-z0-9._-]{3,64}$/i.test(body.p_username);
    }
    if (url.pathname === '/rest/v1/rpc/dwell_ops_customer_dynamic_tags' && method === 'POST') {
      let body;
      try { body = JSON.parse(options.body); } catch { throw new Error('readonly_request_invalid'); }
      rpc = body && Object.keys(body).length === 1 && typeof body.p_customer_id === 'string' &&
        /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(body.p_customer_id);
    }
    if (!auth && !rpc) throw new Error('readonly_operation_blocked');
    return transport(input, { ...options, redirect: 'error', credentials: 'omit' });
  };
}

export function createReadonlyClient(createClient, transport) {
  return createClient(supabaseUrl, publishableKey, {
    auth: { persistSession: false, autoRefreshToken: true, detectSessionInUrl: false, storageKey: 'dwell-sidebar-readonly-memory' },
    global: { fetch: guardedFetch(transport) }
  });
}

export class ReadonlyCustomers {
  constructor(client) { this.client = client; }
  async read(action, payload = {}) {
    if (!readActions.has(action)) throw new Error('readonly_operation_blocked');
    const { data, error } = await this.client.rpc('dwell_ops_sidebar_read', { p_action: action, p_payload: payload });
    if (error) throw error;
    return data;
  }
  async resolve(context) {
    if (context.platform === 'messenger') return this.read('messenger', { mailbox_id: context.page, uid: context.uid });
    if (context.platform === 'whatsapp' && context.status === 'phone_missing' && /^@[a-z0-9._-]{3,64}$/i.test(context.title || '')) {
      const { data, error } = await this.client.rpc('dwell_ops_sidebar_username', { p_username: context.title });
      if (error) throw error;
      return data;
    }
    if (context.platform === 'whatsapp' && context.status === 'phone_missing') {
      const title = String(context.title || '').normalize('NFKC').trim().replace(/\s+/g, ' ');
      if (title.length < 3 || title.length > 100 || title.startsWith('@')) return { items: [], status: 'phone_missing' };
      const found = await this.read('search', { query: title, search: title });
      if (found.limited) return { items: [], status: 'conflict' };
      const key = value => String(value || '').normalize('NFKC').trim().replace(/\s+/g, ' ').toLocaleLowerCase();
      const exact = (found.items || []).filter(item => key(item.name) === key(title) || key(item.matched_name) === key(title));
      if (exact.length !== 1) return { items: [], status: exact.length ? 'conflict' : 'not_found' };
      return { items: [{ id: exact[0].id }], status: 'found', match_source: 'name' };
    }
    if (!context.phone) return { items: [], status: 'phone_missing' };
    return this.read('phone', { phone: context.phone });
  }
}

export function errorMessage(error) {
  const message = String(error?.message || '');
  if (/Invalid login credentials/.test(message)) return '邮箱或密码不正确。';
  if (/Email not confirmed/.test(message)) return '请先验证登录邮箱。';
  if (/sidebar_access_denied|42501/.test(message + error?.code)) return '此账号没有客户查看权限，或账号已停用。';
  if (/JWT|token.*expired|refresh_token|session_not_found/i.test(message)) return '登录已过期，请重新登录。';
  if (/PGRST202|Could not find the function/.test(message + error?.code)) return '只读接口尚未部署，请稍后重试。';
  if (/sidebar_phone_invalid/.test(message)) return '请输入包含 60 或 65 国家码的电话号码。';
  if (/sidebar_customer_unavailable/.test(message)) return '客户已停用或不存在，请重新查找。';
  if (/sidebar_query_invalid/.test(message)) return '搜索内容需为 2 至 100 个字符。';
  return '请求未完成，请检查网络后重试；未保存任何业务资料。';
}
