import {normalizeAIImage,readAIImage} from './ai-images.mjs';
export const aiEndpoint='https://script.google.com/macros/s/AKfycbzv5J-PSFd3tyRlZcCcSh_kZ1xV7c1wgz8MhHSkhV4RFjRt6h1glnzhPIFdhXRE09FC/exec';
// User approved reusing this service and its AI-record log only. No CRM writes.
export const aiGenerationEnabled=true;
export const canUseAI=context=>context?.status==='ready'||(context?.status==='phone_missing'&&context.platform==='whatsapp'&&!!context.key);
const text=(value,max=4000)=>String(value??'').slice(0,max);
export function safeMediaUrl(value){try{const u=new URL(value);return u.protocol==='https:'&&!u.username&&!u.password?u.href:'';}catch{return '';}}
export function createAIService({transport=fetch,assertCurrent,enabled=aiGenerationEnabled,imageSources=new Set()}){
  return async function command(action,payload={}){
    await assertCurrent();
    if(action==='check')return {generation_enabled:enabled};
    if(action==='image')return readAIImage({url:payload.url,sources:imageSources,assertCurrent,transport});
    const url=new URL(aiEndpoint);
    if(action==='prompts')url.searchParams.set('action','dai_prompts');
    else if(action==='media')url.searchParams.set('action','dai_media');
    else if(action==='listings'){
      if(!['my_cn','my_en','sg_cn','sg_en'].includes(payload.listing_key))throw Error('ai_invalid_request');
      url.searchParams.set('action','dai_listings');url.searchParams.set('listing_key',payload.listing_key);
    }else if(action==='generate'){
      if(!enabled)throw Error('ai_generation_locked');
      const input=String(payload.input_text||'').trim(),key=String(payload.prompt_key||'');
      if(!input||input.length>4000||!/^[-\w]{1,100}$/.test(key)||!['answer_question','polish_translate'].includes(payload.mode))throw Error('ai_invalid_request');
      if(payload.mode==='polish_translate'&&!['zh','en'].includes(payload.target_language))throw Error('ai_invalid_request');
      for(const [k,v] of Object.entries({action:'dai_generate',input_text:input,prompt_key:key,mode:payload.mode,target_language:payload.mode==='polish_translate'?payload.target_language:''}))url.searchParams.set(k,v);
    }else throw Error('ai_action_denied');
    await assertCurrent();
    let data;
    try{
      const response=await transport(url.href,{method:'GET',credentials:'omit',cache:'no-store',redirect:'follow',signal:AbortSignal.timeout(50000)});
      if(!response.ok)throw Error('ai_service_failed');
      if(response.url&&!['script.google.com','script.googleusercontent.com'].includes(new URL(response.url).hostname))throw Error('ai_service_failed');
      const body=await response.text();if(body.length>2000000)throw Error('ai_service_failed');data=JSON.parse(body);
      if(!data||typeof data!=='object'||data.ok===false)throw Error('ai_service_failed');
    }catch(error){if(['TimeoutError','AbortError'].includes(error.name))throw Error('ai_timeout');throw Error('ai_service_failed');}
    await assertCurrent();
    if(action==='generate'){if(typeof data.reply!=='string'||!data.reply.trim())throw Error('ai_empty_reply');return {reply:text(data.reply,16000)};}
    if(action==='prompts')return {prompts:(Array.isArray(data.prompts)?data.prompts:[]).slice(0,100).filter(p=>p.prompt_key).map(p=>({key:text(p.prompt_key,100),name:text(p.prompt_name||p.prompt_key,160)}))};
    const remember=value=>{const url=safeMediaUrl(value),normalized=normalizeAIImage(url);if(normalized){imageSources.add(normalized);if(imageSources.size>600)imageSources.delete(imageSources.values().next().value);}return normalized||url;};
    if(action==='media')return {media:(Array.isArray(data.media)?data.media:[]).slice(0,500).map(p=>({title:text(p.title,160),url:remember(p.url),keywords:text(p.keywords,1000)})).filter(p=>p.url)};
    return {listings:(Array.isArray(data.listings)?data.listings:[]).slice(0,150).map(p=>({title:text(p.title,160),text:text(p.text,20000),extra_text:text(p.extra_text,20000),image_url:remember(p.image_url)}))};
  };
}
