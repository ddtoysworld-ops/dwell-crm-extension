"use strict";
window.DwellDelivery=(()=>{
  let profiles=[],customer=null,record=null,preserveSnapshot=false,selected=null,dirty=false,locked=()=>false,manager=null;
  const safe=escapeHtml;
  const input=(label,name,v='',required=false,max=80)=>inputField(label,name,v,'text',required,`maxlength="${max}"`);
  const addressFields=()=>`${input('收件人','recipient_name','',false)}${input('收货电话（含国家码）','recipient_phone','',false,30)}${input('地址名称','delivery_label','家里',false,40)}<datalist id="delivery-labels"><option value="家里"><option value="公司"><option value="家人家"><option value="其他地址"></datalist>`;
  const normalize=p=>String(p||'').replace(/[+ ()-]/g,'');
  function summary(){
    const el=$('#delivery-current');if(!el)return;
    const parts=[value('recipient_name'),value('recipient_phone'),value('address')].filter(Boolean);
    el.textContent=parts.length?[value('delivery_label')+(selected?.is_default?'（默认）':''),...parts].filter(Boolean).join(' · '):'尚未填写收货资料';
  }
  function populate(p){
    for(const [name,key] of [['recipient_name','recipient_name'],['recipient_phone','recipient_phone'],['address','address'],['delivery_label','label']])field(name).value=p?.[key]||'';
    summary();
  }
  function picker(){
    field('saved_address').innerHTML='<option value="">新增 / 本单收货资料</option>'+profiles.map(p=>`<option value="${safe(p.id)}">${safe(p.label)}${p.is_default?' · 默认':''} · ${safe(p.recipient_name)} · ${safe(p.recipient_phone)} · ${safe(p.address)}</option>`).join('');
    field('saved_address').value=selected?.id||'';
  }
  function mount(r,isLocked=()=>false){
    record=r;preserveSnapshot=Boolean(r);customer=null;profiles=[];selected=null;dirty=false;locked=isLocked;
    const address=field('address').closest('label'),select=field('saved_address').closest('label');
    address.classList.add('full');select.classList.add('full');
    const container=document.createElement('section');container.className='delivery-section field full';
    select.before(container);
    container.innerHTML=`<h3>收货资料</h3><p id="delivery-current" class="delivery-current"></p><details id="delivery-options" class="order-fold"><summary><span>更换 / 修改收货资料</span>${icon('chevron-down')}</summary><div class="form-grid">${addressFields()}<label class="delivery-check full"><input type="checkbox" name="delivery_remember">保存到客户收货资料</label><label class="delivery-check full"><input type="checkbox" name="delivery_default">设为默认收货资料</label></div></details>`;
    const grid=container.querySelector('.form-grid');grid.prepend(select);grid.insertBefore(address,field('delivery_remember').closest('label'));
    field('delivery_label').setAttribute('list','delivery-labels');
    field('saved_address').closest('label').querySelector('span').textContent='选择收货资料';
    populate(r?.delivery_snapshot||{recipient_name:r?.customer_name,recipient_phone:r?.phone,address:r?.address,label:'家里'});
    field('delivery_remember').checked=!r;
    $('#delivery-options').open=!r;
    picker();requirements();icons();
  }
  function requirements(){
    if(dialogKind!=='cloud-order'||!field('recipient_name'))return;
    const walkIn=value('fulfillment_method')==='walk_in';
    const required=value('nature')==='formal'&&!walkIn;
    document.querySelector('.delivery-section').hidden=walkIn;
    for(const name of ['recipient_name','recipient_phone'])field(name).required=required;
    field('delivery_label').required=!walkIn&&field('delivery_remember').checked;
    field('delivery_default').disabled=!field('delivery_remember').checked;
    if(field('delivery_default').disabled)field('delivery_default').checked=false;
  }
  function identityInput(){
    customer=null;profiles=[];selected=null;dirty=false;preserveSnapshot=false;picker();
    populate({label:'家里'});field('delivery_remember').checked=true;field('delivery_default').checked=false;
    $('#delivery-options').open=true;
  }
  function match(c){
    customer=c;profiles=c?.delivery_profiles||[];picker();
    // Opening an existing order must retain its snapshot, even if today's default changed.
    if(preserveSnapshot||dirty)return;
    const def=profiles.find(p=>p.is_default);
    if(def){selected=def;populate(def);field('saved_address').value=def.id;field('delivery_remember').checked=false;$('#delivery-options').open=false;}
    else{
      populate({label:'家里',recipient_name:value('customer_name'),recipient_phone:value('phone'),address:''});
      field('delivery_remember').checked=true;$('#delivery-options').open=true;
    }
    requirements();
  }
  function syncIdentity(){
    if(!preserveSnapshot&&!selected&&!dirty){field('recipient_name').value=value('customer_name');field('recipient_phone').value=value('phone');summary();}
  }
  function change(e){
    if(locked()||!$('#delivery-options'))return;
    const n=e.target.name;
    if(n==='saved_address'){
      const choice=value(n);selected=profiles.find(p=>p.id===choice)||null;dirty=true;
      if(selected){populate(selected);field('delivery_remember').checked=false;}
      else {populate({label:'其他地址',recipient_name:value('customer_name'),recipient_phone:value('phone'),address:''});field('delivery_remember').checked=true;}
      field('delivery_default').checked=false;
    }
    requirements();summary();
  }
  function editInput(e){
    if(locked())return;
    if(['recipient_name','recipient_phone','address','delivery_label'].includes(e.target.name)){
      dirty=true;selected=null;field('saved_address').value='';field('delivery_default').checked=false;
    }
    if(e.target.name==='customer_name')syncIdentity();summary();
  }
  function payload(){
    if(value('fulfillment_method')==='walk_in')return {delivery:{label:'上门购买',recipient_name:'',recipient_phone:'',address:'',remember:false,set_default:false}};
    const complete=Boolean(value('recipient_name')&&value('recipient_phone')&&value('address'));
    return {delivery:{profile_id:selected?.id||null,profile_version:selected?.version,label:value('delivery_label')||'本单收货资料',recipient_name:value('recipient_name'),recipient_phone:normalize(value('recipient_phone')),address:value('address'),remember:field('delivery_remember').checked&&complete,set_default:field('delivery_default').checked&&complete}};
  }
  function markup(c){
    const rows=c.delivery_profiles||[];
    return `<div class="profile-section-head"><h3>${icon('map-pin')}收货资料 <span class="profile-count">${rows.length}</span></h3>${(window.DwellPayments?.canCoreAction?.('orders','delivery_save')??true)?`<button type="button" class="secondary" data-action="cloud-delivery" data-id="${safe(c.id)}">${icon('square-pen')}管理收货资料</button>`:''}</div>${rows.length?`<ul class="delivery-list">${rows.map(p=>`<li><strong>${safe(p.label)}${p.is_default?' <span class="pill success">默认</span>':''}</strong><span>${safe(p.recipient_name)} · ${safe(p.recipient_phone)}</span><span>${safe(p.address)}</span></li>`).join('')}</ul>`:'<p class="profile-empty">尚无配对的收货资料</p>'}`;
  }
  async function openManager(id){
    const p=await window.DwellOperations.rpc('customer',{id});manager={customer:p.customer,selected:null,pending:null,busy:false};
    const c=p.customer;
    showDialog('cloud-delivery',c.id,'管理收货资料',`<p>${safe(c.name)}</p><div class="form-grid">${selectField('收货资料','delivery_edit',[['','新增收货资料'],...(c.delivery_profiles||[]).map(p=>[p.id,p.label+(p.is_default?' · 默认':'')+' · '+p.address])],'')}<div></div>${addressFields()}${input('邮寄地址','address','',true,500)}<label class="delivery-check full"><input name="delivery_default" type="checkbox">设为默认收货资料</label></div>`,'正式资料 · 不修改旧订单');
    field('address').closest('label').classList.add('full');field('delivery_label').setAttribute('list','delivery-labels');
    for(const name of ['recipient_name','recipient_phone','delivery_label'])field(name).required=true;
    managerSelect();
  }
  function managerSelect(){
    if(!manager||manager.pending||manager.busy)return;
    const c=manager.customer,p=(c.delivery_profiles||[]).find(p=>p.id===value('delivery_edit'));manager.selected=p||null;
    populate(p||{label:'家里',recipient_name:c.name,recipient_phone:c.phones?.[0]||''});
    field('delivery_default').checked=p?.is_default||!c.delivery_profiles?.length;field('delivery_default').disabled=Boolean(p?.is_default)||!c.delivery_profiles?.length;
  }
  async function saveManager(){
    if(!manager||manager.busy)return;
    try{
      manager.pending ||= {customer_id:manager.customer.id,profile_id:manager.selected?.id||null,profile_version:manager.selected?.version,recipient_name:value('recipient_name'),recipient_phone:value('recipient_phone'),address:value('address'),label:value('delivery_label'),set_default:field('delivery_default').checked,request_id:crypto.randomUUID()};
      manager.busy=true;$('#save-button').disabled=true;
      await window.DwellOperations.rpc('delivery_save',manager.pending);manager.pending=null;dialog.close();toast('收货资料已保存，旧订单保持不变');
    }catch(e){
      const definite=/^[0-9A-Z]{5}$/.test(e?.code||'')&&!e.code.startsWith('08');if(definite)manager.pending=null;
      if(manager.pending)form.querySelectorAll('#dialog-body input,#dialog-body select').forEach(el=>el.disabled=true);
      $('#form-error').textContent=window.DwellOperations.failure(e)+(manager.pending?' 再点保存会重试同一份内容。':'');
    }finally{manager.busy=false;$('#save-button').disabled=false;}
  }
  form.addEventListener('change',e=>{if(dialogKind==='cloud-delivery'&&e.target.name==='delivery_edit')managerSelect();});
  form.addEventListener('invalid',e=>{if(dialogKind==='cloud-order'&&e.target.closest('#delivery-options'))$('#delivery-options').open=true;},true);
  dialog.addEventListener('cancel',e=>{if(dialogKind==='cloud-delivery'&&manager?.busy)e.preventDefault();});
  document.addEventListener('click',e=>{if(dialogKind==='cloud-delivery'&&manager?.busy&&(e.target===dialog||e.target.closest('[data-close]'))){e.preventDefault();e.stopImmediatePropagation();}},true);
  return {mount,match,identityInput,syncIdentity,change,editInput,payload,requirements,markup,openManager,saveManager};
})();
