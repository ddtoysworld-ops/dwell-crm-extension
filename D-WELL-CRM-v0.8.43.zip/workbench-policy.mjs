const reads = {
  dwell_ops_payments: ['self'],
  dwell_ops_sidebar_read: ['self','phone','messenger','search','profile'],
  dwell_ops_legacy_archive_api: ['profile','search'],
  dwell_ops_legacy_crm_api: ['profile','search'],
  dwell_ops_legacy_customer_history: [null],
  dwell_ops_coupon_wallet: ['list'],
  dwell_ops_orders_api: ['phone','customer','get','list','coupons','consumption_list','audit'],
  dwell_ops_catalog: ['list','audit'],
  dwell_ops_referrals_api: ['list','get','settings'],
  dwell_ops_lucky_api: ['list','settings'],
  dwell_ops_messenger_api: ['lookup','list'],
  dwell_ops_rewards: [null],
  dwell_ops_customer_dynamic_tags: [null],
  dwell_ops_customer_pending_prizes: [null]
};
export function workbenchSender(sender, runtime) {
  if (sender.id !== runtime.id || (sender.frameId && sender.frameId !== 0)) return false;
  try {
    const u = new URL(sender.url), own = new URL(runtime.getURL('/'));
    return u.origin === own.origin && u.host === own.host && u.pathname === '/workbench/index.html';
  } catch { return false; }
}
export function allowedWorkbenchRead(name, args) {
  if (!args || typeof args !== 'object' || Array.isArray(args) || !reads[name]) return false;
  if (!reads[name].includes(args.p_action ?? null)) return false;
  if (name === 'dwell_ops_customer_dynamic_tags' && Object.keys(args).length !== 1) return false;
  if (name === 'dwell_ops_customer_pending_prizes' && Object.keys(args).length !== 1) return false;
  if (name === 'dwell_ops_legacy_customer_history' &&
      (typeof args.p_customer_id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(args.p_customer_id))) return false;
  if (name === 'dwell_ops_customer_dynamic_tags' &&
      (typeof args.p_customer_id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(args.p_customer_id))) return false;
  if (name === 'dwell_ops_customer_pending_prizes' &&
      (typeof args.p_customer_id !== 'string' || !/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(args.p_customer_id))) return false;
  if (name === 'dwell_ops_catalog' && !['pages','products','skus','customers'].includes(args.p_entity)) return false;
  if (name === 'dwell_ops_catalog' && args.p_action === 'audit' && args.p_entity !== 'customers') return false;
  return true;
}
export const workbenchViews = new Set(['orders','customers','tasks','referrals','draws','rewards']);
const writes = {
  dwell_ops_sidebar_crm: ['bind','unbind','save_order'],
  dwell_ops_orders_api: ['save','task','consumption_process','grant_coupon','cancel','refund','delivery_save'],
  dwell_ops_referrals_api: ['approve','delivery','ship','complete'],
  dwell_ops_lucky_api: ['ship']
};
export function allowedWorkbenchOperation(name,args,writesEnabled=false) {
  if(allowedWorkbenchRead(name,args))return true;
  if(!writesEnabled||!args||typeof args!=='object'||Array.isArray(args)||!args.p_payload||typeof args.p_payload!=='object'||Array.isArray(args.p_payload))return false;
  if(writesEnabled!==true)return Boolean(writesEnabled.orders)&&name==='dwell_ops_sidebar_crm'&&args.p_action==='save_order';
  if(name==='dwell_ops_catalog')return args.p_action==='save'&&args.p_entity==='customers';
  if(!writes[name]?.includes(args.p_action))return false;
  // New orders must use the atomic identity-binding RPC. Plain save is only for edits.
  if(name==='dwell_ops_orders_api'&&args.p_action==='save')return typeof args.p_payload.id==='string'&&args.p_payload.id.length>0;
  return true;
}
