(() => {
  const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  const money=n=>(Number(n||0)/100).toFixed(2);
  const normalize=s=>String(s||'').replace(/[+ ()-]/g,'');
  const errors={inline_preview_only:'测试版未开放保存，没有写入订单、发放次数或更新奖励。',inline_order_promotions_disabled:'目前只开放普通订单；优惠券及好友推荐尚未切换，没有保存订单。',inline_customer_required:'当前对话尚未关联客户，请先查询或完成进单。',workbench_context_changed:'顾客已切换，请在新对话重新操作。',sidebar_access_denied:'登录或权限已改变，请重新登录。',lucky_cutover_required:'抽奖尚未正式切换，不能发放真实次数。',core_stale_version:'资料刚被更新，请刷新后重新核对。',sidebar_binding_conflict:'当前对话与所填客户不一致，没有保存订单。',referral_postage_unpaid:'请先确认已收到 RM10 邮费。'};
  const statusText=s=>({qualified:'资格已确认',pending:'待处理',shipped:'已寄出',completed:'已完成',void:'已作废',review:'待核对',active:'有效',available:'可使用',used:'已使用',expired:'已过期',hold:'留待下次',ready:'待寄出',not_selected:'未安排',postage_pending:'待收邮费'}[s]||s||'');
  Object.assign(errors,{inline_messenger_required:'请先打开一个 Messenger 顾客对话。',inline_query_invalid:'请填写至少 3 个字的姓名或电话号码。',inline_phone_invalid:'请输入含国家码的完整电话号码。',inline_phone_ambiguous:'此电话号码匹配多个客户，请先在客户资料核对。',sidebar_binding_conflict:'当前对话存在其他客户关联，请刷新核对，不会覆盖原有关联。'});
  const reasonText=s=>({not_first_order:'不是首次有效购买',referrer_missing:'推荐号码未找到现有客户',self_referral:'不能推荐自己',already_rewarded:'已确认过首购奖励',no_eligible_bundle:'没有符合规则的付费配套',order_closed:'订单已取消或拒收',not_formal:'不是正式订单',below_minimum:'未达金额门槛',malaysia_only:'仅限马来西亚 MYR 订单',outside_dates:'不在活动日期内',paused:'活动暂停',wrong_page:'不属于活动主页'}[s]||s||'待核对');
  function button(text,fn,icon){const b=el('button');b.type='button';b.title=text;b.setAttribute('aria-label',text);if(icon&&globalThis.lucide?.icons?.[icon])b.append(lucide.createElement(lucide.icons[icon],{width:15,height:15,'aria-hidden':'true'}));b.append(el('span',text));b.addEventListener('click',fn);return b;}
  function field(parent,label,name,value='',type='text',options){
    const wrap=el('label',null,'ic-field');wrap.append(el('span',label));const input=el(options?'select':type==='textarea'?'textarea':'input');input.name=name;
    if(options)for(const [v,t] of options){const op=el('option',t);op.value=v;input.append(op);}else if(type!=='textarea')input.type=type;
    input.value=value??'';wrap.append(input);parent.append(wrap);return input;
  }
  function fold(parent,label){const d=el('details',null,'ic-fold');d.append(el('summary',label));const box=el('div',null,'ic-grid');d.append(box);parent.append(d);return box;}
  function check(parent,label,name){const w=el('label',null,'ic-check'),c=el('input');c.type='checkbox';c.name=name;w.append(c,el('span',label));parent.append(w);return c;}
  function detailRow(parent,label,value){if(value===undefined||value===null||value==='')return;const row=el('div',null,'ic-legacy-row');row.append(el('span',label),el('span',String(value)));parent.append(row);}
  function rewardText(items){return (items||[]).map(g=>`${g.name} × ${g.quantity??g.qty??1}`).join('、')||'无';}
  function customerCopyText(customer){
    const profiles=customer?.delivery_profiles||[],defaults=profiles.filter(p=>p.is_default);
    const addresses=[...new Set((customer?.addresses||[]).filter(Boolean))];
    if(defaults.length>1||(!defaults.length&&(profiles.length>1||(!profiles.length&&addresses.length>1))))throw new Error('有多个收货地址，请先设置默认收货资料。');
    const delivery=defaults[0]||(profiles.length===1?profiles[0]:null);
    const name=delivery?.recipient_name||customer?.name,phone=delivery?.recipient_phone||customer?.phones?.[0],address=delivery?.address||(!profiles.length?addresses[0]:null);
    if(!name||!phone||!address)throw new Error('姓名、电话或收货地址不完整，请先补齐收货资料。');
    return [name,phone,address].join('\n');
  }
  function copyControl(customer){
    const box=el('div',null,'customer-copy'),status=el('p',null,'ic-note');let fallback=null;
    status.setAttribute('role','status');box.style.cssText='margin:8px 0 14px';
    const copy=button('一键复制客户资料',async()=>{
      if(!box.isConnected)return;let text;try{text=customerCopyText(customer);}catch(e){status.textContent=e.message;return;}
      copy.disabled=true;if(fallback)fallback.hidden=true;
      try{await navigator.clipboard.writeText(text);if(box.isConnected)status.textContent='已复制姓名、电话和收货地址。';}
      catch{if(box.isConnected){status.textContent='浏览器未允许自动复制，请手动复制下方资料。';if(!fallback){fallback=el('textarea');fallback.readOnly=true;fallback.setAttribute('aria-label','可手动复制的客户资料');fallback.style.cssText='width:100%;min-height:110px;font:inherit';box.append(fallback);}fallback.value=text;fallback.hidden=false;fallback.focus();fallback.select();}}
      finally{copy.disabled=false;}
    },'Copy');copy.style.width='100%';box.append(copy,status);return box;
  }
  const css=`.inline-crm{margin-top:12px;font:12px/1.55 Arial,"Microsoft YaHei",sans-serif;letter-spacing:0}.inline-crm *{box-sizing:border-box}.ic-tabs{display:flex;border-bottom:1px solid #dce5e0;gap:4px;margin-bottom:12px}.ic-tabs button{flex:1;border:0;border-radius:0;padding:8px 2px;font-size:12px;border-bottom:2px solid transparent}.ic-tabs [aria-selected=true]{border-color:#176750;color:#176750;font-weight:bold}.ic-actions{display:flex;flex-wrap:wrap;gap:6px;margin:10px 0}.ic-actions button{font-size:12px;flex:1}.ic-form{border-top:1px solid #dbe4df;margin-top:12px;padding:14px 0 10px;max-height:520px;min-height:180px;overflow:auto;resize:vertical;overscroll-behavior:contain}.ic-form h3{font-size:13px;margin:16px 0 10px}.ic-grid{display:grid;grid-template-columns:1fr;gap:11px}.ic-field{display:flex;flex-direction:column;gap:5px;min-width:0}.ic-field>span{font-size:11px;color:#60766b}.inline-crm input:not([type=checkbox]),.inline-crm select,.inline-crm textarea{width:100%;min-width:0;max-width:100%;min-height:35px;border:1px solid #ccd9d2;background:#fff;color:#203b35;border-radius:4px;padding:7px;font:12px/1.4 Arial,"Microsoft YaHei",sans-serif;letter-spacing:0}.inline-crm textarea{min-height:60px;resize:vertical}.inline-crm [readonly]{background:#f3f6f4!important}.ic-fold{margin:16px 0;border-top:1px solid #dbe4df;padding-top:12px}.ic-fold summary{cursor:pointer;font-weight:bold;margin-bottom:10px}.ic-check{display:flex;gap:8px;align-items:flex-start;margin:10px 0}.ic-check input{margin-top:3px}.ic-line{border-bottom:1px solid #dbe4df;padding:12px 0}.ic-pair{display:grid;grid-template-columns:1fr 1fr;gap:8px}.ic-components{margin:8px 0;font-size:11px;color:#62776e}.ic-footer{display:flex;gap:8px;margin-top:14px}.ic-footer button{flex:1}.ic-primary{background:#21654e!important;color:#fff!important;border-color:#21654e!important}.ic-note{font-size:11px;color:#65776e;margin:10px 0;white-space:pre-line}.ic-error{color:#a3422e}.ic-result{border-top:1px solid #dbe4df;padding:14px 0}.ic-result h4{font-size:13px;margin:0 0 7px}.ic-result p{margin:5px 0;overflow-wrap:anywhere}.ic-result form{margin-top:12px}.ic-total{font-weight:bold;font-size:14px;margin-top:14px}.inline-crm [hidden]{display:none!important}.ic-lookup{margin:12px 0}.ic-lookup button{margin:6px 0}.ic-blank{padding:18px 0;color:#65776e}`;
  function mount({container,profileNode,profile,snapshot,send,onSaved,onBound}){
    let alive=true,customer=profile?.customer||null,catalog=null,orderForm=null,tab='crm',serial=0,campaignId='',selectedProfile=profile,couponReloader=null;
    const listeners=new AbortController();
    const links=new Map();
    const layoutCSS=`
      .inline-crm{font-size:14px;line-height:1.5}.inline-crm button{font:inherit;min-height:42px;padding:9px 10px;display:inline-flex;align-items:center;justify-content:center;gap:7px;cursor:pointer;border:1px solid #ccd9d2;border-radius:5px;background:white;color:#203b35}
      .inline-crm button svg{width:18px;height:18px;flex-shrink:0}.inline-crm button:focus-visible,.ic-fold summary:focus-visible{outline:2px solid #287b66;outline-offset:2px}
      .ic-tabs{flex-shrink:0;margin-bottom:8px;gap:0}.ic-tabs button{font-size:13px;border:0;border-bottom:2px solid transparent;border-radius:0;padding:8px 2px;min-width:0}.ic-tabs [aria-selected=true]{border-bottom-color:#176750}
      .ic-actions{margin:8px 0;flex-shrink:0}.ic-actions button{font-size:14px;padding:8px 5px;min-width:0}.ic-actions button:first-child{background:#21654e;color:white;border-color:#21654e}
      .ic-form{display:flex;flex-direction:column;height:560px;max-height:calc(100dvh - 290px);min-height:0;overflow:hidden;resize:none;margin-top:8px;padding:0;border-top:1px solid #dbe4df}
      .ic-scroll{min-height:0;flex:1;overflow:auto;overscroll-behavior:contain;padding:0 8px 16px 0;scrollbar-gutter:stable}
      .ic-form h3{font-size:15px;margin:24px 0 14px}.ic-form h3:first-child{margin-top:16px}.ic-grid{gap:14px}.ic-field>span{font-size:12px;color:#52695f}.inline-crm input:not([type=checkbox]),.inline-crm select,.inline-crm textarea{font-size:14px;min-height:42px;padding:9px}.inline-crm textarea{min-height:76px}
      .ic-line{padding:14px 0 18px}.ic-line .ic-field{margin-bottom:12px}.ic-line-heading{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;font-size:13px;font-weight:bold}.ic-line-heading button{width:38px;min-height:38px;padding:8px}.ic-line-heading button span{display:none}.ic-line-heading button:disabled{opacity:.35}
      .ic-note,.ic-components{font-size:12px}.ic-note:empty{display:none}.ic-fold{margin:18px 0;padding-top:8px}.ic-fold summary{font-size:14px;min-height:42px;padding:10px 0;margin-bottom:6px}.ic-check{font-size:13px;align-items:center}.ic-check input{width:18px;height:18px;flex-shrink:0}
      .ic-address{white-space:pre-line;overflow-wrap:anywhere;margin:10px 0;font-size:13px;line-height:1.6;color:#52695f}.ic-footer{flex:none;display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:0;padding:12px 0 0;border-top:1px solid #dbe4df;background:white}.ic-footer .ic-total,.ic-footer .ic-note{grid-column:1/-1;margin:0}.ic-footer .ic-note{max-height:64px;overflow:auto}.ic-total{display:flex;justify-content:space-between;align-items:baseline;font-size:18px;gap:8px}.ic-total:before{content:'订单合计';font-size:12px;color:#65776e;font-weight:normal}.ic-footer button{min-height:44px;font-weight:bold}
      .ic-result h4{font-size:15px}.ic-result{padding:18px 0}.ic-result form{display:grid;gap:12px}
      .inline-crm button{min-height:38px;padding:7px 9px;font-size:13px}.ic-actions button{font-size:13px;min-height:38px}.ic-footer button{min-height:40px}.ic-tabs button{font-size:13px;min-height:38px}
      .ic-form h3{margin:20px 0 12px}.ic-scroll{padding:0 10px 18px;background:#f7f9fc;border-radius:5px 5px 0 0}.ic-field>span{font-size:13px}.inline-crm input:not([type=checkbox]),.inline-crm select{min-height:38px;padding:8px}.ic-grid{gap:12px}.ic-fold{border:0;padding:0;margin:16px 0}.ic-fold summary{color:#245f83;min-height:38px}.ic-form{border:1px solid #dbe4eb;border-radius:6px}.ic-footer{padding:10px;background:#fff}.ic-form .ic-fold[open]{padding-bottom:8px}.ic-total{font-size:17px}
      .ic-suggestions{position:fixed;inset:auto;margin:0;padding:0;border:1px solid #b8cbc2;border-radius:5px;background:#fff;max-height:280px;overflow:auto;box-shadow:0 12px 28px #142b2440;font:14px/1.45 Arial,"Microsoft YaHei",sans-serif;color:#203b35}.ic-suggestions button{display:block;width:100%;min-height:42px;text-align:left;border:0;border-radius:0;border-bottom:1px solid #edf1ef;background:#fff}.ic-suggestions button:hover,.ic-suggestions button:focus-visible{background:#eaf5ef}.ic-suggestions small{display:block;color:#65776e}.ic-suggestions .ic-note{padding:8px 10px;margin:0}.inline-crm input.ic-invalid{border-color:#bd3e36!important;background:#fff7f6!important;box-shadow:0 0 0 1px #bd3e36}.ic-field .ic-phone-error{color:#b42318;font-size:12px;font-weight:600}
      .ic-form-top{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 10px;background:#fff}.ic-form-top h3{margin:0;font-size:15px}.ic-form-top button{flex:none}
      .ic-order-dialog{width:min(880px,calc(100vw - 24px));height:min(800px,calc(100dvh - 24px));max-width:none;max-height:none;padding:0;border:1px solid #cbdad4;border-radius:6px;box-shadow:0 18px 55px #0004;background:#fff;color:#203b35}.ic-order-dialog::backdrop{background:#142b24a6}.ic-order-dialog .ic-form{height:100%;max-height:none;margin:0;border:0;border-radius:0}.ic-order-dialog .ic-scroll{padding:0 24px 20px}.ic-order-dialog .ic-footer{padding:12px 24px}.ic-order-dialog .ic-form-top{padding:14px 24px;border-bottom:1px solid #dbe4df}.ic-order-dialog .ic-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.ic-order-dialog .ic-line{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:0 16px}.ic-order-dialog .ic-line-heading,.ic-order-dialog .ic-components{grid-column:1/-1}.ic-order-dialog .ic-line .ic-pair{align-self:end}.ic-order-dialog .ic-footer{grid-template-columns:1fr auto auto}.ic-order-dialog .ic-footer .ic-total{grid-column:1}.ic-order-dialog .ic-footer .ic-note{grid-column:1/-1}@media(max-width:640px){.ic-order-dialog{width:calc(100vw - 12px);height:calc(100dvh - 12px)}.ic-order-dialog .ic-grid,.ic-order-dialog .ic-line{grid-template-columns:1fr}.ic-order-dialog .ic-scroll{padding:0 12px 16px}.ic-order-dialog .ic-footer,.ic-order-dialog .ic-form-top{padding:10px 12px}.ic-order-dialog .ic-footer{grid-template-columns:1fr 1fr}.ic-order-dialog .ic-footer .ic-total{grid-column:1/-1}}
    `;
    const legacyCSS=`
      .inline-crm .ic-tabs{background:#fff;border-bottom-color:#d8dde8}.inline-crm .ic-tabs button{color:#667085;font-weight:700;font-size:12px;padding:5px 1px;line-height:1.2}.inline-crm .ic-tabs button span{white-space:pre-line}.inline-crm .ic-tabs [aria-selected=true]{color:#0f6bff;border-bottom-color:#0f6bff}
      .ic-legacy{font:12px/1.45 Arial,"Microsoft YaHei",sans-serif;color:#1d2433}.ic-legacy-controls{padding:12px;border-bottom:1px solid #d8dde8;background:#fff}.ic-legacy-intro{margin:0 0 10px;color:#667085}.ic-legacy-controls input{min-height:40px!important;border-radius:8px!important}.ic-legacy-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin:10px 0 0}.ic-legacy-actions button{font-size:12px!important;font-weight:700!important;min-height:38px!important;border-radius:8px!important;white-space:nowrap}.ic-legacy-actions button:last-child,.ic-legacy .ic-blue{background:#0f6bff!important;border-color:#0f6bff!important;color:white!important}
      .ic-legacy-status{margin:10px 0 0;color:#667085;min-height:0}.ic-legacy-results{background:#f4f7fb;padding:10px 12px 16px;min-height:90px}.ic-legacy-empty{background:#fff;border:1px dashed #d8dde8;border-radius:8px;padding:16px;color:#667085}.ic-legacy-section{font-size:13px;margin:12px 0 7px}.ic-legacy-section.pending{color:#b42318}.ic-legacy-card{background:#fff;border:1px solid #d8dde8;border-radius:8px;padding:12px;margin-bottom:10px}.ic-legacy-card h3{font-size:15px;margin:0 0 8px}.ic-legacy-card p{margin:6px 0;overflow-wrap:anywhere}.ic-legacy-summary{display:grid!important;grid-template-columns:minmax(0,1fr) 18px;gap:6px;width:100%;min-height:58px!important;padding:10px 12px!important;text-align:left;border:0!important;background:#fff!important;color:#1d2433!important;border-radius:8px!important}.ic-legacy-summary span:first-child{display:flex;flex-direction:column;gap:4px;min-width:0;align-items:flex-start}.ic-legacy-summary strong,.ic-legacy-summary small{max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ic-legacy-summary small{color:#667085;font-size:12px}.ic-legacy-badge{display:inline-block;width:fit-content;border-radius:999px;padding:2px 7px;background:#ecfdf3;color:#067647;font-size:11px;font-weight:700}.ic-legacy-badge.warning{background:#fff8db;color:#9a6700}.ic-legacy-badge.muted{background:#f2f4f7;color:#667085}.ic-legacy-chevron{color:#667085;align-self:center;justify-self:end}.ic-legacy-card.collapsible{padding:0;overflow:hidden}.ic-legacy-body{padding:0 12px 12px;border-top:1px solid #eef1f6}.ic-legacy-row{display:grid;grid-template-columns:92px minmax(0,1fr);gap:8px;padding:5px 0;border-top:1px solid #eef1f6}.ic-legacy-row:first-child{border-top:0}.ic-legacy-row span:first-child{color:#667085}.ic-legacy-row span:last-child{overflow-wrap:anywhere}
      .ic-legacy-form{border-top:1px solid #eef1f6;margin-top:12px;padding-top:10px;display:grid;gap:8px}.ic-legacy-form .ic-field>span{font-size:12px;color:#667085}.ic-legacy-form button{justify-self:start;background:#0f6bff!important;border-color:#0f6bff!important;color:#fff!important;font-weight:700!important;font-size:12px!important}.ic-legacy-form .ic-note{margin:0}.ic-legacy-form .ic-check{font-size:12px}.ic-legacy-form .ic-check span{color:#1d2433}.ic-legacy-extra{display:grid;gap:8px}.ic-legacy-card .ic-legacy-primary{width:100%;background:#0f6bff!important;border-color:#0f6bff!important;color:#fff!important;font-weight:700!important}
      .ic-legacy-campaign{display:inline-block;padding:3px 8px;border-radius:999px;background:#ecfdf3;color:#067647;font-size:11px;font-weight:700}.ic-legacy-campaign.inactive{background:#f2f4f7;color:#667085}.ic-legacy-order-head{display:flex;justify-content:space-between;gap:8px;font-weight:700}.ic-legacy-order-head span:last-child{white-space:nowrap}.ic-legacy-date{color:#667085;font-size:12px}.ic-legacy-eligibility{margin-top:8px;padding:7px 8px;border-radius:8px;background:#f2f4f7;color:#667085}.ic-legacy-eligibility.success{background:#ecfdf3;color:#067647}.ic-legacy-link{margin-top:10px}.ic-legacy-link button{width:100%;margin-top:8px}.ic-legacy-metrics{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin:10px 0}.ic-legacy-metrics span{border:1px solid #d8dde8;border-radius:8px;text-align:center;padding:7px 2px;color:#667085}.ic-legacy-metrics strong{display:block;color:#1d2433;font-size:16px}
    `;
    const root=el('section',null,'inline-crm'),style=el('style',css+layoutCSS+legacyCSS),tabs=el('nav',null,'ic-tabs'),orderDialog=el('dialog',null,'ic-order-dialog'),panes={};root.append(style,tabs,orderDialog);
    orderDialog.setAttribute('aria-label','放大填写订单');orderDialog.addEventListener('cancel',e=>e.preventDefault());
    const expected={documentId:snapshot.documentId,revision:snapshot.revision};
    async function call(action,payload={}){const r=await send({type:'dwell-inline',action,payload,expected});if(!alive)throw new Error('workbench_context_changed');if(!r?.ok)throw Object.assign(new Error(r?.error||'连接未完成，请重试。'),{code:r?.code});return r.value;}
    const error=(node,e)=>{if(alive){node.textContent=errors[e.message]||e.message;node.classList.add('ic-error');}};
    for(const [id,label] of [['crm','客户资料'],['referrals','好友推荐'],['lucky','幸运抽奖\nLucky Draw']]){
      const b=button(label,()=>switchTab(id));b.dataset.crmTab=id;b.setAttribute('role','tab');b.setAttribute('aria-label',id==='lucky'?'幸运抽奖':label);tabs.append(b);panes[id]=el('div',null,'ic-pane'+(id==='crm'?'':' ic-legacy'));panes[id].dataset.pane=id;root.append(panes[id]);
    }
    function switchTab(id){tab=id;serial++;for(const [k,p] of Object.entries(panes))p.hidden=k!==id;for(const b of tabs.children)b.setAttribute('aria-selected',String(b.dataset.crmTab===id));profileNode.hidden=id!=='crm';if(id==='referrals')void referralView();if(id==='lucky')void luckyView();}
    const controls=el('div',null,'ic-actions'),message=el('p',null,'ic-note');
    const orderToggle=button('填写订单',async()=>{
      if(orderForm){orderForm.hidden=!orderForm.hidden;setOrderToggle(!orderForm.hidden);return;}
      orderToggle.disabled=true;
      try{catalog=await call('catalog');await buildOrder();setOrderToggle(true);}catch(e){error(message,e);}finally{orderToggle.disabled=false;}
    },'ShoppingBag');
    function setOrderToggle(open){const text=open?'收起订单':'填写订单';orderToggle.lastChild.textContent=text;orderToggle.setAttribute('aria-label',text);orderToggle.title=text;orderToggle.setAttribute('aria-expanded',String(open));}
    const searchBox=el('div',null,'ic-lookup');searchBox.hidden=true;
    const query=field(searchBox,'电话或姓名','query','','search'),matches=el('div');
    let searchSerial=0;
    async function previewCustomer(id){
      const token=++searchSerial;matches.replaceChildren(el('p','正在读取客户资料…'));
      try{
        const result=await call('select',{id});if(token!==searchSerial)return;
        const candidate=result.customer;if(!candidate)throw new Error('没有找到客户。');
        const card=el('section',null,'ic-result');card.append(el('p','查询结果 · 尚未更改当前对话','ic-note'),el('h4',candidate.name),el('p',(candidate.phones||[]).join(' / ')),copyControl(candidate));
        const delivery=candidate.delivery_profiles?.find(p=>p.is_default);
        card.append(el('p',delivery?.address||(candidate.addresses||[]).join('\n'),'ic-address'));
        card.append(el('p',`有效购买 ${result.summary?.purchase_count??0} 次 · 累计 RM ${money(result.summary?.gmv_myr_minor)}`));
        matches.replaceChildren(card);
        try{
          const old=await call('legacy-crm-profile',{customer_id:candidate.id});if(token!==searchSerial)return;
          for(const item of old.items||[])card.append(el('p',`旧 CRM · 只读：${item.purchase_count_text||'购买次数未记录'} · ${item.total_myr_minor!=null?'累计 RM '+money(item.total_myr_minor):'金额未记录'} · 最近购买 ${item.last_order_on||'未记录'}`,'ic-note'));
        }catch{if(token===searchSerial)card.append(el('p','旧 CRM 摘要暂时无法读取。','ic-note'));}
        if(snapshot.context.platform!=='messenger'){card.append(el('p','WhatsApp 按当前对话电话号码识别客户，无需绑定 Messenger UID。','ic-note'));return;}
        const state=await call('binding-status');if(token!==searchSerial)return;
        if(state.customer_id){card.append(el('p',state.customer_id===candidate.id?'此对话已关联这位客户。':'此对话已关联其他客户，不会覆盖原有关联。','ic-note'));return;}
        const confirmed=check(card,'已核对姓名和电话，确认是当前对话的顾客','confirm_binding');
        const note=el('p',null,'ic-note');note.setAttribute('role','status');
        if(state.preview_only)note.textContent='测试版暂未开放真实绑定，旧系统资料不会改变。';
        const requestId=crypto.randomUUID();
        const bind=button('绑定此对话',async()=>{
          if(!confirmed.checked||token!==searchSerial||!alive)return;bind.disabled=true;
          try{
            await call('bind-customer',{customer_id:candidate.id,version:state.version,request_id:requestId});
            if(token!==searchSerial)return;
            note.textContent='已绑定此对话，下次打开将自动识别。';confirmed.disabled=true;onBound?.();
          }catch(e){if(token===searchSerial){
            if(e.message==='inline_preview_only')note.textContent='此版本尚未开放对话绑定，客户和订单资料没有改变。';
            else error(note,e);
            bind.disabled=!confirmed.checked;
          }}
        },'Link');bind.disabled=true;bind.classList.add('ic-primary');confirmed.addEventListener('change',()=>{bind.disabled=!confirmed.checked;});card.append(bind,note);
      }catch(e){if(token===searchSerial)error(matches,e);}
    }
    searchBox.append(button('查询 CRM',async()=>{
      const token=++searchSerial,term=query.value.trim();matches.replaceChildren();
      if(term.length<3||term.length>100){error(matches,new Error('inline_query_invalid'));return;}
      matches.append(el('p','正在查询客户资料…','ic-note'));
      const [nativeResult,crmResult]=await Promise.allSettled([
        call('lookup',{query:term}),call('legacy-crm-search',{query:term})
      ]);
      if(token!==searchSerial)return;
      const native=nativeResult.status==='fulfilled'?nativeResult.value.items||[]:[];
      const snapshots=crmResult.status==='fulfilled'?crmResult.value.items||[]:[];
      matches.replaceChildren();
      if(nativeResult.status==='rejected')matches.append(el('p','新客户查询未完成。','ic-note ic-error'));
      if(crmResult.status==='rejected')matches.append(el('p','旧 CRM 查询未完成，请确认插件已重新加载。','ic-note ic-error'));
      const nativePhones=new Set(native.flatMap(c=>(c.phones||[]).map(normalize)));
      for(const c of native){
        const hasOld=snapshots.some(s=>!s.review_reasons?.length&&nativePhones.has(normalize(s.phone))&&(c.phones||[]).some(p=>normalize(p)===normalize(s.phone)));
        matches.append(button(c.name+' · '+(c.phones||[]).join(' / ')+(hasOld?' · 含旧 CRM':''),()=>previewCustomer(c.id)));
      }
      for(const item of snapshots){
        if(!item.review_reasons?.length&&nativePhones.has(normalize(item.phone)))continue;
        const card=el('section',null,'ic-result');
        card.append(el('h4',item.customer_name||'旧 CRM 未留姓名'));
        card.append(el('p',[item.phone,item.last_order_on&&`最近购买 ${item.last_order_on}`].filter(Boolean).join(' · ')));
        card.append(el('p',[item.purchase_count_text&&`购买 ${item.purchase_count_text}`,item.total_myr_minor!=null&&`累计 RM ${money(item.total_myr_minor)}`].filter(Boolean).join(' · ')));
        card.append(el('p',item.review_reasons?.length?'旧 CRM · 待核对，不能自动关联':'旧 CRM · 只读，尚未建立新客户','ic-note'));
        matches.append(card);
      }
      if(!matches.children.length)matches.append(el('p','没有找到对应客户。','ic-note'));
    },'Search'),matches);
    query.addEventListener('input',()=>{searchSerial++;matches.replaceChildren();});
    controls.append(orderToggle,button('查询客户',()=>{searchBox.hidden=!searchBox.hidden;},'Search'));panes.crm.append(controls,searchBox,message);
    async function buildOrder(){
      const form=el('form',null,'ic-form');orderForm=form;form.setAttribute('aria-label','填写销售订单');
      form.addEventListener('invalid',e=>{for(let n=e.target.parentElement;n&&n!==form;n=n.parentElement)if(n.tagName==='DETAILS')n.open=true;},true);
      const heading=el('h3','填写销售订单'),grid=el('div',null,'ic-grid');form.append(heading,grid);
      const expand=button('放大填写',()=>setExpanded(!orderDialog.open),'Maximize2');
      function setExpanded(open){
        for(const line of lines)hideSuggestions(line);
        if(open){form.hidden=false;orderDialog.append(form);orderDialog.showModal();expand.lastChild.textContent='收回侧栏';expand.title='收回侧栏';expand.setAttribute('aria-label','收回侧栏');}
        else{if(orderDialog.open)orderDialog.close();panes.crm.append(form);expand.lastChild.textContent='放大填写';expand.title='放大填写';expand.setAttribute('aria-label','放大填写');}
      }
      const fields={};
      const f=(label,name,value='',type='text',options,parent=grid,required=false)=>{const n=field(parent,label,name,value,type,options);n.required=required;fields[name]=n;return n;};
      const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
      f('日期 *','order_date',today,'date',null,grid,true);
      f('订单性质 *','nature','formal','text',[['formal','正式订单'],['inquiry','潜在咨询']]);
      f('所属主页 *','page_id',catalog.pages.find(p=>(p.mailbox_id===snapshot.context.page||p.facebook_page_id===snapshot.context.page)&&snapshot.context.page)?.id||'','text',[['','请选择主页'],...catalog.pages.filter(p=>p.active).map(p=>[p.id,p.name])],grid,true);
      f('送货地区 *','market','MY','text',[['MY','西马'],['EM','东马'],['SG','新加坡']]);
      f('币种 *','currency','MYR','text',[['MYR','MYR'],['SGD','SGD']]);
      const linesBox=el('section');form.append(el('h3','订单商品'),linesBox);const lines=[];let lineSequence=0;
      function addLine(){
        const row=el('div',null,'ic-line'),line={row,choices:{}};
        const rowHeading=el('div',null,'ic-line-heading'),rowTitle=el('span');
        const remove=button('移除商品',()=>{if(lines.length===1)return;hideSuggestions(line);lines.splice(lines.indexOf(line),1);row.remove();numberLines();suggestShipping();calculate();},'Trash2');rowHeading.append(rowTitle,remove);row.append(rowHeading);line.title=rowTitle;line.remove=remove;
        line.kind=field(row,'类型','line_kind','sale','text',[['sale','正常销售'],['gift','赠品（不收费）']]);
        line.skuSearch=field(row,'搜索产品分类、关键词或编号','line_sku_search');line.skuSearch.placeholder='输入分类、关键词或编号';line.skuSearch.autocomplete='off';
        line.skuSearch.setAttribute('role','combobox');line.skuSearch.setAttribute('aria-expanded','false');line.skuSearch.setAttribute('aria-autocomplete','list');
        line.suggestions=el('div',null,'ic-suggestions');line.suggestions.id='ic-suggestions-'+(++lineSequence);line.suggestions.setAttribute('popover','auto');line.skuSearch.setAttribute('aria-controls',line.suggestions.id);line.skuSearch.closest('label').after(line.suggestions);
        line.suggestions.addEventListener('toggle',()=>line.skuSearch.setAttribute('aria-expanded',String(line.suggestions.matches(':popover-open'))));
        line.sku=field(row,'产品 / 配套 *','line_sku','','text',[]);line.sku.required=true;
        const pair=el('div',null,'ic-pair');row.append(pair);
        line.qty=field(pair,'数量 *','line_quantity',1,'number');Object.assign(line.qty,{min:'1',max:'1000',step:'1',required:true});
        line.amount=field(pair,'商品小计 *','line_amount','','number');Object.assign(line.amount,{min:'0',step:'.01',required:true});
        line.components=el('div',null,'ic-components');row.append(line.components);
        lines.push(line);linesBox.append(row);options(line);numberLines();
        line.skuSearch.addEventListener('input',()=>{line.sku.value='';options(line);showSuggestions(line);reprice(line);details(line);suggestShipping();calculate();});
        line.skuSearch.addEventListener('keydown',e=>{const buttons=[...line.suggestions.querySelectorAll('button')];if(e.key==='ArrowDown'&&line.suggestions.matches(':popover-open')&&buttons.length){e.preventDefault();buttons[0].focus();}else if(e.key==='Enter'&&line.suggestions.matches(':popover-open')&&buttons.length===1){e.preventDefault();buttons[0].click();}else if(e.key==='Escape'&&line.suggestions.matches(':popover-open')){e.preventDefault();e.stopPropagation();hideSuggestions(line);}});
        line.suggestions.addEventListener('keydown',e=>{const buttons=[...line.suggestions.querySelectorAll('button')],index=buttons.indexOf(line.suggestions.getRootNode().activeElement);if(e.key==='Escape'){e.preventDefault();e.stopPropagation();hideSuggestions(line);line.skuSearch.focus();}else if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();buttons[Math.max(0,Math.min(buttons.length-1,index+(e.key==='ArrowDown'?1:-1)))]?.focus();}});
        for(const control of [line.kind,line.sku,line.qty])control.addEventListener('change',()=>{if(control===line.kind)options(line);reprice(line);details(line);suggestShipping();calculate();});
        line.amount.addEventListener('input',calculate);
      }
      function numberLines(){lines.forEach((l,i)=>{l.title.textContent='商品 '+(i+1);l.remove.disabled=lines.length===1;});}
      const searchKey=value=>String(value||'').normalize('NFKC').toLowerCase().replace(/[\s\u3000_.\-·]+/g,'');
      const productAliases={
        '蓝藻海参精':['蓝枣','gamat','海参'],
        '巴西莓排毒纤维':['fibre','fiber','detox','排毒纤维'],
        '姜黄素':['turmeric','ginger']
      };
      function matches(line){const term=searchKey(line.skuSearch.value);return catalog.skus.filter(s=>s.active&&s.sku_kind!=='legacy'&&(!s.page_id||s.page_id===fields.page_id.value)&&(line.kind.value==='gift'||(s.sale_markets||['MY','EM','SG']).includes(fields.market.value))&&(!term||searchKey(`${s.code||''} ${s.name||''} ${s.product_name||''}`).includes(term)||Object.entries(productAliases).some(([category,aliases])=>searchKey(s.product_name).includes(searchKey(category))&&aliases.some(alias=>searchKey(alias).includes(term)))));}
      function options(line){const old=line.sku.value;line.sku.replaceChildren(el('option','请选择 SKU'));line.sku.firstChild.value='';
        for(const s of matches(line)){const op=el('option',s.code+' · '+s.name);op.value=s.id;line.sku.append(op);}line.sku.value=old;
      }
      function hideSuggestions(line){if(line.suggestions.matches(':popover-open'))line.suggestions.hidePopover();line.skuSearch.setAttribute('aria-expanded','false');}
      function positionSuggestions(line){
        if(!line.suggestions.matches(':popover-open'))return;
        const anchor=line.skuSearch.getBoundingClientRect(),clip=line.skuSearch.closest('.ic-scroll').getBoundingClientRect();
        if(anchor.bottom<=clip.top||anchor.top>=clip.bottom){hideSuggestions(line);return;}
        const width=Math.min(Math.max(anchor.width,520),window.innerWidth-16),wanted=Math.min(280,line.suggestions.scrollHeight+2);
        const below=window.innerHeight-anchor.bottom-8,above=anchor.top-8,useAbove=below<Math.min(wanted,150)&&above>below;
        const available=Math.max(40,useAbove?above:below);
        Object.assign(line.suggestions.style,{width:width+'px',left:Math.max(8,Math.min(anchor.left,window.innerWidth-width-8))+'px',top:(useAbove?Math.max(8,anchor.top-Math.min(wanted,available)-4):anchor.bottom+4)+'px',maxHeight:Math.min(280,available)+'px'});
      }
      function updateSuggestions(){for(const line of lines)positionSuggestions(line);}
      window.addEventListener('scroll',updateSuggestions,{capture:true,signal:listeners.signal});
      window.addEventListener('resize',updateSuggestions,{signal:listeners.signal});
      function showSuggestions(line){const term=line.skuSearch.value.trim();line.suggestions.replaceChildren();if(!term){hideSuggestions(line);return;}
        const found=matches(line).slice(0,100);if(!found.length)line.suggestions.append(el('p','没有找到对应产品或配套。','ic-note'));
        for(const sku of found){const choice=button(`${sku.name} · ${sku.code}`,()=>{line.skuSearch.value=sku.name;options(line);line.sku.value=sku.id;hideSuggestions(line);line.sku.dispatchEvent(new Event('change',{bubbles:true}));line.skuSearch.focus();});choice.append(el('small',sku.product_name||''));line.suggestions.append(choice);}
        if(!line.suggestions.matches(':popover-open'))line.suggestions.showPopover();
        line.skuSearch.setAttribute('aria-expanded','true');positionSuggestions(line);
      }
      function reprice(line){const s=catalog.skus.find(s=>s.id===line.sku.value),gift=line.kind.value==='gift';const key={MY:'myr_minor',EM:'em_minor',SG:'sgd_minor'}[fields.market.value];const unit=fields.currency.value===(fields.market.value==='SG'?'SGD':'MYR')?s?.[key]:null;line.amount.value=gift?'0.00':unit==null?'':money(unit*Number(line.qty.value));line.amount.readOnly=gift;}
      function details(line){const s=catalog.skus.find(s=>s.id===line.sku.value);line.components.replaceChildren();line.choices={};if(!s)return;const groups=new Map();
        for(const c of s.components||[]){if(c.choice_group){if(!groups.has(c.choice_group))groups.set(c.choice_group,[]);groups.get(c.choice_group).push(c);}
          else line.components.append(el('p',`${c.name} × ${c.quantity*Number(line.qty.value)} · ${line.kind.value==='gift'||c.role==='gift'?'赠品':'主商品'}`));}
        for(const [group,items] of groups){const select=field(line.components,group+' *','choice','','text',[['','请选择赠品'],...items.filter(c=>c.active).map(c=>[c.sku_id,c.name+' × '+c.quantity*Number(line.qty.value)])]);select.required=true;line.choices[group]=select;}
      }
      form.append(button('添加产品 / 配套',()=>{if(lines.length<30){addLine();suggestShipping();}},'Plus'));
      const amounts=el('div',null,'ic-grid');form.append(el('h3','订单金额'),amounts);
      const total=el('p',null,'ic-total');
      f('整单运费（可修改）','shipping_minor','0','number',null,amounts);f('其他折扣','discount_minor','0','number',null,amounts);
      for(const n of ['shipping_minor','discount_minor'])Object.assign(fields[n],{min:'0',step:'.01'});
      let shippingManual=false;
      const shippingHint=el('small',null,'ic-note');fields.shipping_minor.closest('label').append(shippingHint);
      function suggestShipping(){
        if(shippingManual)return;
        const market=fields.market.value,selected=lines.filter(l=>l.kind.value!=='gift').map(l=>({sku:catalog.skus.find(s=>s.id===l.sku.value),quantity:Number(l.qty.value)})).filter(x=>x.sku);
        const fees=selected.map(({sku,quantity})=>{
          const tiers=sku.shipping_tiers?.[market];
          const tier=tiers?.[String(quantity)]??tiers?.default;
          return Number(tier??sku[{MY:'shipping_myr_minor',EM:'shipping_em_minor',SG:'shipping_sgd_minor'}[market]]??0);
        });
        fields.shipping_minor.value=money(Math.max(0,...fees));
        shippingHint.textContent=selected.length>1?'已按最高 SKU 运费建议填写；多件商品请核对。':selected.length?'已按 SKU 运费建议填写，可修改。':'';
      }
      f('支付方式 *','payment','','text',[['','请选择'],...['Bank Transfer','COD','TNG','Cash','credit card','shopee','Installment'].map(v=>[v,v])],amounts,true);
      const clientBox=el('div',null,'ic-grid'),clientHeading=el('h3','客户资料');form.append(clientHeading,clientBox);
      f('客户电话号码（含国家码） *','phone',customer?.phones?.[0]||snapshot.context.phone||'','tel',null,clientBox,true);
      const phoneHint=el('span',null,'ic-phone-error');phoneHint.hidden=true;phoneHint.setAttribute('role','alert');fields.phone.closest('label').append(phoneHint);
      function validatePhone(){const value=normalize(fields.phone.value),invalid=!!value&&!/^(60|65)\d{7,12}$/.test(value),hint='电话号码必须以 60（马来西亚）或 65（新加坡）开头，并填写完整号码。';fields.phone.setCustomValidity(invalid?hint:'');fields.phone.classList.toggle('ic-invalid',invalid);fields.phone.setAttribute('aria-invalid',String(invalid));phoneHint.textContent=invalid?hint:'';phoneHint.hidden=!invalid;return !invalid;}
      fields.phone.addEventListener('input',validatePhone);validatePhone();
      f('客户姓名 *','customer_name',customer?.name||'','text',null,clientBox,true);
      let profiles=customer?.delivery_profiles||[];const def=profiles.find(p=>p.is_default),deliveryBox=fold(form,'收货资料');deliveryBox.parentElement.open=!def;
      const addressSummary=el('p',null,'ic-address');deliveryBox.parentElement.before(addressSummary);
      f('选择收货资料','saved_address',def?.id||'','text',[['','本单填写'],...profiles.map(p=>[p.id,`${p.label}${p.is_default?'（默认）':''} · ${p.recipient_name}`])],deliveryBox);
      const differentRecipient=check(deliveryBox,'寄给其他收件人','different_recipient');
      f('收件人 *','recipient_name',def?.recipient_name||customer?.name||'','text',null,deliveryBox,true);
      f('收货电话 *','recipient_phone',def?.recipient_phone||fields.phone.value,'tel',null,deliveryBox,true);
      f('收货地址 *','address',def?.address||customer?.addresses?.[0]||'','textarea',null,deliveryBox,true);
      f('地址名称','delivery_label',def?.label||'家里','text',null,deliveryBox);
      const remember=check(deliveryBox,'保存到客户收货资料','remember'),setDefault=check(deliveryBox,'设为默认收货资料','set_default');let delivery=def;
      function addressSync(){addressSummary.textContent=[fields.delivery_label.value+' · '+fields.recipient_name.value,fields.recipient_phone.value,fields.address.value].filter(Boolean).join('\n');}
      function syncRecipient(){
        const separate=differentRecipient.checked;
        for(const [recipient,client] of [['recipient_name','customer_name'],['recipient_phone','phone']]){
          if(!separate)fields[recipient].value=fields[client].value;
          fields[recipient].closest('label').hidden=!separate;
          fields[recipient].required=separate&&fields.nature.value==='formal';
        }
        addressSync();
      }
      function useDeliveryRecipient(){
        differentRecipient.checked=!!delivery&&((fields.recipient_name.value.trim()!==fields.customer_name.value.trim())||(normalize(fields.recipient_phone.value)!==normalize(fields.phone.value)));
        syncRecipient();
      }
      differentRecipient.addEventListener('change',()=>{delivery=null;fields.saved_address.value='';syncRecipient();});
      fields.customer_name.addEventListener('input',()=>{if(!differentRecipient.checked){delivery=null;fields.saved_address.value='';syncRecipient();}});
      fields.saved_address.addEventListener('change',()=>{delivery=profiles.find(p=>p.id===fields.saved_address.value);for(const n of ['recipient_name','recipient_phone','address','delivery_label'])fields[n].value=delivery?.[n==='delivery_label'?'label':n]||'';remember.checked=false;setDefault.checked=false;useDeliveryRecipient();});
      for(const n of ['recipient_name','recipient_phone','address','delivery_label'])fields[n].addEventListener('input',()=>{delivery=null;fields.saved_address.value='';addressSync();});useDeliveryRecipient();
      let phoneSerial=0,changedPhone=false;
      fields.phone.addEventListener('input',()=>{phoneSerial++;changedPhone=true;customer=null;delivery=null;profiles=[];fields.saved_address.replaceChildren(el('option','本单填写'));fields.saved_address.firstChild.value='';for(const n of ['recipient_name','recipient_phone','address'])fields[n].value='';differentRecipient.checked=false;syncRecipient();});
      fields.phone.addEventListener('blur',async()=>{if(!changedPhone||!validatePhone()||!fields.phone.value.trim())return;const token=++phoneSerial,ph=normalize(fields.phone.value);try{const results=await call('lookup',{query:ph});const exact=(results.items||[]).filter(c=>(c.phones||[]).some(p=>normalize(p)===ph));if(token!==phoneSerial)return;
        if(exact.length!==1){message.textContent=exact.length?'号码有多个匹配，请核对。':'此号码未找到客户；填写资料并保存时才建立客户。';return;}
        const p=await call('select',{id:exact[0].id});if(token!==phoneSerial)return;customer=p.customer;fields.customer_name.value=customer.name;profiles=customer.delivery_profiles||[];delivery=profiles.find(p=>p.is_default);
        for(const p of profiles){const op=el('option',p.label+' · '+p.recipient_name);op.value=p.id;fields.saved_address.append(op);}fields.saved_address.value=delivery?.id||'';
        fields.recipient_name.value=delivery?.recipient_name||customer.name;fields.recipient_phone.value=delivery?.recipient_phone||ph;fields.address.value=delivery?.address||customer.addresses?.[0]||'';fields.delivery_label.value=delivery?.label||'家里';useDeliveryRecipient();message.textContent='已带入 '+customer.name+'；保存时仍会核对当前对话关联。';changedPhone=false;
      }catch(e){if(token===phoneSerial)error(message,e);}});
      const rest=el('div',null,'ic-grid');form.append(el('h3','订单资料'),rest);
      f('本单下单平台','platform',snapshot.context.platform==='messenger'?'Facebook':'WhatsApp','text',['Facebook','Business Whatsapp','Manychat Whatsapp',"D'WELL 网站",'CALL','Instagram','WhatsApp','网站'].map(v=>[v,v]),rest);
      f('客户来源 *','source','','text',[['','请选择'],...['广告','朋友介绍','自行询问','repeat order'].map(v=>[v,v])],rest,true);
      f('ERP 订单 ID *','erp_id','','text',null,rest,true);f('Tracking Number','tracking_number','','text',null,rest);f('订单备注','note','','textarea',null,rest);
      const promo=fold(form,'好友推荐');const referral=check(promo,'好友推荐订单','referral_enabled');f('推荐人电话（含国家码）','referral_phone','','tel',null,promo);fields.referral_phone.closest('label').hidden=true;
      referral.addEventListener('change',()=>{fields.referral_phone.closest('label').hidden=!referral.checked;fields.referral_phone.required=referral.checked;});
      const couponSection=fold(form,'使用客户优惠券');const coupon=f('使用现有优惠券','coupon_id','','text',[['','不使用优惠券']],couponSection),couponInfo=el('div',null,'ic-note');let coupons=[];
      let couponSerial=0;
      const refreshCoupons=async()=>{
        const token=++couponSerial,phone=fields.phone.value;coupons=[];coupon.value='';coupon.replaceChildren(new Option('不使用优惠券',''));calculate();
        try{const data=await call('coupons',{phone});if(token!==couponSerial||phone!==fields.phone.value)return;coupons=(data.items||[]).filter(c=>!c.read_only&&(!c.status||['available','reserved'].includes(c.status)));
          for(const c of coupons){const source=globalThis.DwellCoupons?.sources?.[c.source]||'客户优惠券';const label=`${c.name} · ${c.currency} ${money(c.amount_minor)} · ${source}${c.status==='reserved'?' · 已安排':''}`;const op=new Option(label,c.id);op.dataset.label=label;coupon.append(op);}
          couponInfo.replaceChildren();for(const c of data.legacy_coupons||[])couponInfo.append(el('p',`旧系统只读 · ${c.name} · ${c.status}`));for(const p of data.legacy_physical_rewards||[])couponInfo.append(el('p',`旧奖品只读 · ${p.prize_name||p.name} · ${{FULFILLED:'已寄出',SHIPPED:'已寄出',PENDING:'未寄出',VOID:'已作废'}[p.status]||p.status}`));
          if(!coupons.length&&!data.legacy_coupons?.length)couponInfo.append(el('p','暂无可用券；已使用、过期或作废的券不会出现在选单。'));calculate();
        }catch(e){if(token===couponSerial)error(couponInfo,e);}
      };
      fields.phone.addEventListener('input',()=>{couponSerial++;coupons=[];coupon.replaceChildren(el('option','不使用优惠券'));coupon.firstChild.value='';couponInfo.replaceChildren();calculate();});
      couponReloader=refreshCoupons;
      couponSection.append(button('刷新优惠券',refreshCoupons,'RefreshCw'),couponInfo);
      const giftSection=fold(form,'本单附送优惠券');const giftCoupon=check(giftSection,'附送优惠券','gift_coupon'),giftBox=el('div',null,'ic-grid');giftSection.append(giftBox);giftBox.hidden=true;
      const giftName=field(giftBox,'赠券名称 *','gift_name'),giftAmount=field(giftBox,'面额（本单币种） *','gift_amount','','number'),giftMinimum=field(giftBox,'最低消费 *','gift_minimum','0','number'),giftExpiry=field(giftBox,'有效期至（留空长期有效）','gift_expiry','','date');Object.assign(giftAmount,{min:'.01',step:'.01'});Object.assign(giftMinimum,{min:'0',step:'.01'});
      giftCoupon.addEventListener('change',()=>{giftBox.hidden=!giftCoupon.checked;for(const n of [giftName,giftAmount,giftMinimum])n.required=giftCoupon.checked;});
      if(!catalog.order_promotions_enabled){promo.parentElement.hidden=true;couponSection.parentElement.hidden=true;giftSection.parentElement.hidden=true;}
      const follow=fold(form,'后续处理');f('跟进日期','due_date','','date',null,follow);f('任务标签','task_tag','潜在客户跟进','text',['潜在客户跟进','延迟寄出','其他'].map(v=>[v,v]),follow);f('任务备注','task_note','','textarea',null,follow);
      // Keep only fields in the scroller; actions must not be clipped by either host sidebar.
      fields.tracking_number.required=true;fields.tracking_number.closest('label').firstChild.textContent='Tracking Number *';
      const extra=fold(form,'订单备注');extra.append(fields.note.closest('label'));
      grid.after(clientHeading,clientBox,addressSummary,deliveryBox.parentElement);
      const scroll=el('div',null,'ic-scroll');scroll.append(...form.childNodes);form.append(scroll);
      scroll.addEventListener('scroll',updateSuggestions,{signal:listeners.signal});
      const top=el('div',null,'ic-form-top');top.append(heading,expand);form.prepend(top);
      const outcome=el('p',null,'ic-note');outcome.setAttribute('role','status');const footer=el('div',null,'ic-footer');const save=button('保存订单',()=>form.requestSubmit(),'Check');save.classList.add('ic-primary');footer.append(total,outcome,button('收起',()=>{setExpanded(false);form.hidden=true;setOrderToggle(false);},'ChevronUp'),save);form.append(footer);
      function calculate(){if(!total.isConnected)return;const amount=lines.reduce((sum,l)=>sum+Math.round(Number(l.amount.value)*100),0)+Math.round(Number(fields.shipping_minor.value)*100)-Math.round(Number(fields.discount_minor.value)*100);for(const op of coupon.options){const c=coupons.find(c=>c.id===op.value);if(c){const reason=fields.nature.value!=='formal'?'仅正式订单':c.currency!==fields.currency.value?'币种不符':c.page_id!==fields.page_id.value?'主页不符':amount<c.minimum_minor||amount<c.amount_minor?'未达金额门槛':'';op.disabled=!!reason;op.textContent=op.dataset.label+(reason?'（'+reason+'）':'');}}if(coupon.selectedOptions[0]?.disabled)coupon.value='';const c=coupons.find(c=>c.id===coupon.value);total.textContent=fields.nature.value==='inquiry'?'潜在咨询 · 不计销售额':`${fields.currency.value} ${money(amount-(c?.amount_minor||0))}`;}
      for(const n of ['page_id','market','currency'])fields[n].addEventListener('change',()=>{if(n==='market')fields.currency.value=fields.market.value==='SG'?'SGD':'MYR';for(const l of lines){options(l);reprice(l);details(l);}if(n!=='page_id')shippingManual=false;suggestShipping();calculate();});
      fields.shipping_minor.addEventListener('input',()=>{shippingManual=true;shippingHint.textContent='已手动修改运费。';calculate();});fields.discount_minor.addEventListener('input',calculate);coupon.addEventListener('change',calculate);
      fields.nature.addEventListener('change',()=>{const formal=fields.nature.value==='formal';for(const n of ['phone','customer_name','address','payment','erp_id','tracking_number'])fields[n].required=formal;for(const l of lines)l.amount.required=formal;syncRecipient();calculate();});
      let pending=null;
      form.addEventListener('submit',async e=>{e.preventDefault();if(save.disabled)return;validatePhone();if(!form.reportValidity())return;try{
        if(!pending){const order={};for(const n of ['order_date','nature','page_id','currency','market','customer_name','phone','address','platform','source','payment','erp_id','tracking_number','note','due_date','task_tag','task_note'])order[n]=fields[n].value;
          order.phone=normalize(order.phone);order.customer_id=customer?.id||'';
          order.lines=lines.map(l=>({sku_id:l.sku.value,sku_version:catalog.skus.find(s=>s.id===l.sku.value)?.version,quantity:Number(l.qty.value),is_gift:l.kind.value==='gift',goods_minor:order.nature==='inquiry'||l.kind.value==='gift'?0:Math.round(Number(l.amount.value)*100),choices:Object.fromEntries(Object.entries(l.choices).map(([g,n])=>[g,n.value]))}));
          Object.assign(order,{sku_id:order.lines[0].sku_id,quantity:order.lines[0].quantity,sku_version:order.lines[0].sku_version,choices:order.lines[0].choices,goods_minor:order.lines.reduce((s,l)=>s+l.goods_minor,0),shipping_minor:order.nature==='inquiry'?0:Math.round(Number(fields.shipping_minor.value)*100),discount_minor:order.nature==='inquiry'?0:Math.round(Number(fields.discount_minor.value)*100),coupon_minor:order.nature==='inquiry'?0:coupons.find(c=>c.id===coupon.value)?.amount_minor||0});
          order.referral_phone=referral.checked?normalize(fields.referral_phone.value):'';order.coupon_id=coupon.value||'';
          if(giftCoupon.checked&&order.nature==='formal')order.gift_coupon={name:giftName.value,amount_minor:Math.round(Number(giftAmount.value)*100),minimum_minor:Math.round(Number(giftMinimum.value)*100),expires_on:giftExpiry.value||null};
          order.delivery={profile_id:delivery?.id||null,profile_version:delivery?.version,label:fields.delivery_label.value,recipient_name:fields.recipient_name.value,recipient_phone:normalize(fields.recipient_phone.value),address:fields.address.value,remember:remember.checked,set_default:remember.checked&&setDefault.checked};
          pending={request_id:crypto.randomUUID(),order};
        }
        save.disabled=true;const result=await call('save-order',pending);outcome.textContent='订单已保存 · #'+(result.number||result.id);pending=null;for(const n of ['erp_id','tracking_number','note'])fields[n].value='';try{customer=(await call('current')).customer;}catch{outcome.append(el('span',' 客户资料刷新未完成，请重新查询。'));}await refreshCoupons();onSaved?.();
      }catch(e){error(outcome,e);if(e.message==='inline_preview_only'||/^[0-9A-Z]{5}$/.test(e.code||''))pending=null;else outcome.append(el('span',' 再点保存重试同一份资料。'));}finally{for(const input of form.querySelectorAll('input,select,textarea'))input.disabled=!!pending;save.disabled=false;}});
      panes.crm.append(form);addLine();calculate();if(fields.phone.value&&catalog.order_promotions_enabled)void refreshCoupons();
    }
    function actionForm(parent,label,inputs,action,payload,after){
      const form=el('form'),note=el('p',null,'ic-note'),values=inputs(form),submit=button(label,()=>form.requestSubmit(),'Check');form.append(submit,note);parent.append(form);let pending=null;
      form.addEventListener('submit',async e=>{e.preventDefault();if(submit.disabled||!form.reportValidity())return;try{pending??={...payload,...values(),request_id:crypto.randomUUID()};submit.disabled=true;const result=await call(typeof action==='function'?action():action,pending);pending=null;await after(result);}catch(e){error(note,e);if(e.message==='inline_preview_only'||e.message==='lucky_cutover_required'||/^[0-9A-Z]{5}$/.test(e.code||''))pending=null;}finally{for(const input of form.querySelectorAll('input,select,textarea'))input.disabled=!!pending;submit.disabled=false;}});return form;
    }
    async function referralView(){
      const box=panes.referrals,controls=el('div',null,'ic-legacy-controls'),results=el('div',null,'ic-legacy-results');box.replaceChildren(controls,results);
      controls.append(el('p','查看这位顾客介绍过谁，以及尚未寄出的推荐礼物。','ic-legacy-intro'));
      const phone=el('input');phone.type='tel';phone.name='referral_subject_phone';phone.placeholder='当前顾客电话号码';phone.setAttribute('aria-label','当前顾客电话号码');phone.value=customer?.phones?.[0]||snapshot.context.phone||'';controls.append(phone);
      const actions=el('div',null,'ic-legacy-actions'),status=el('p',null,'ic-legacy-status');status.setAttribute('role','status');
      actions.append(button('查看推荐记录',()=>void refresh(false)),button('立即检查新订单',()=>void refresh(true)));controls.append(actions,status);
      async function refresh(checkNew){
        const token=++serial,subjectPhone=normalize(phone.value);status.classList.remove('ic-error');status.textContent=checkNew?'正在检查已入库订单…':'正在查询推荐记录…';results.replaceChildren();
        try{
          const checked=checkNew?await call('referral-check',{subject_phone:subjectPhone}):null;
          const data=await call('referrals',{subject_phone:subjectPhone});if(token!==serial)return;
          const subjectId=data.subject?.id,items=data.items||[];
          const introduced=items.filter(r=>r.referrer_id===subjectId||r.eligibility?.referrer_id===subjectId);
          const incoming=items.filter(r=>r.buyer_id===subjectId&&!introduced.includes(r));
          const pending=introduced.filter(r=>r.status==='qualified'&&!['shipped','completed','void'].includes(r.fulfillment));
          const other=introduced.filter(r=>!pending.includes(r));
          function section(title,rows,pendingTitle=false){if(!rows.length)return;results.append(el('h3',title,'ic-legacy-section'+(pendingTitle?' pending':'')));for(const r of rows)results.append(referralCard(r,data,subjectPhone,refresh));}
          section(`尚未寄出的礼物 (${pending.length})`,pending,true);
          section('这位顾客的推荐来源',incoming);
          section('已寄出或其他推荐记录',other);
          if(!items.length)results.append(el('div','没有找到好友推荐记录。','ic-legacy-empty'));
          status.textContent=checked?.mode==='off'?'旧订单资料尚未核对完整，自动推荐资格暂未开启。':checked?.held?`已自动确认 ${checked.qualified} 笔；${checked.held} 笔因旧记录待核对，暂不安排赠品。`:checked?`订单检查完成，自动确认 ${checked.qualified} 笔。`:pending.length?`这位介绍人有 ${pending.length} 份礼物尚未寄出。`:items.length?'已显示好友推荐记录。':'没有找到好友推荐记录。';
        }catch(e){if(token===serial){error(status,e);results.append(el('div','推荐记录暂时无法显示。','ic-legacy-empty'));}}
      }
      await refresh(false);
    }
    function referralCard(r,data,subjectPhone,refresh){
      const card=el('article',null,'ic-legacy-card collapsible'),summary=button('',()=>{body.hidden=!body.hidden;summary.setAttribute('aria-expanded',String(!body.hidden));chevron.textContent=body.hidden?'▸':'▾';});
      summary.className='ic-legacy-summary';summary.setAttribute('aria-label',`展开 ${r.buyer_name||'推荐记录'} · 订单 #${r.order_number||'未编号'}`);summary.setAttribute('aria-expanded','false');
      const text=el('span'),chevron=el('span','▸','ic-legacy-chevron'),first=r.status==='qualified'?'首次下单':r.eligibility?.reason==='not_first_order'?'已有历史订单':r.eligibility?.eligible?'待自动检查':'需要核对';
      text.append(el('strong',r.buyer_name||'未命名顾客'),el('small',[r.buyer_phone,r.order_date,r.order_number?`订单 #${r.order_number}`:''].filter(Boolean).join(' · ')),el('span',first,'ic-legacy-badge'+(first==='首次下单'?'':first==='已有历史订单'?' muted':' warning')));summary.replaceChildren(text,chevron);
      const body=el('div',null,'ic-legacy-body');body.hidden=true;card.append(summary,body);
      const notQualified=r.status==='pending'&&['not_first_order','already_rewarded'].includes(r.eligibility?.reason);
      const qualification=notQualified?'NOT QUALIFIED':r.status==='qualified'?'QUALIFIED':r.status?.toUpperCase();
      const reward=r.status==='qualified'?rewardText(r.rewards):notQualified?'无（非首购，不重复发放）':'待核对资格';
      for(const [label,value] of [['资格',qualification],['介绍人',r.referrer_name||'未匹配'],['介绍人电话',r.referral_phone],['被介绍人',r.buyer_name],['被介绍人电话',r.buyer_phone],['下单日期',r.order_date],['首次下单检查',first],['订单',r.order_number],['配套',r.sku_name],['销售额',r.gmv_myr_minor!=null?`RM ${money(r.gmv_myr_minor)}`:''],['奖励',reward],['介绍人选择',({with_friend:'跟被介绍人的订单一起寄出',next_order:'保留至介绍人下次订单',self_postage:'介绍人付邮费，单独寄出'})[r.delivery_method]],['寄送状态',statusText(r.fulfillment)],['Tracking',r.tracking_number]])detailRow(body,label,value);
      const base={id:r.id,version:r.version,subject_phone:subjectPhone};
      if(r.status==='pending')body.append(el('p',r.eligibility?.eligible?'点击「立即检查新订单」自动核对资格；通过后即可处理赠品。':reasonText(r.eligibility?.reason),'ic-note'));
      if(!data.preview_only&&r.status==='qualified'&&!['shipped','completed','void'].includes(r.fulfillment)){
        body.append(el('h4','赠品处理','ic-legacy-section'));
        const deliveryForm=actionForm(body,'保存介绍人选择',form=>{
          const method=field(form,'介绍人的选择','delivery_method',r.delivery_method==='not_selected'?'':r.delivery_method||'','text',[['','请选择'],['with_friend','跟被介绍人的订单一起寄出'],['self_postage',`介绍人付 RM${money(data.settings.postage_minor)}，单独寄出`],['next_order','保留至介绍人下次订单']]);method.required=true;
          const selfBox=el('div',null,'ic-legacy-extra'),nextBox=el('div');form.append(selfBox,nextBox);
          const shipment=field(nextBox,'关联推荐人的下一张订单','shipment_order_id','','text',[['','尚未下单，先保留']]),nextNote=el('p',null,'ic-note');nextBox.append(nextNote);
          const track=field(selfBox,'Tracking number *','tracking_number','','text'),paid=check(selfBox,`确认已收到 RM${money(data.settings.postage_minor)} 邮费`,'postage_paid');paid.checked=!!r.postage_paid;
          let nextLoaded=false;
          const sync=async()=>{selfBox.hidden=method.value!=='self_postage';nextBox.hidden=method.value!=='next_order';track.required=!selfBox.hidden;paid.required=!selfBox.hidden&&Number(data.settings.postage_minor)>0;
            if(!nextBox.hidden&&!nextLoaded){shipment.disabled=true;try{const result=await call('referral-next-orders',{id:r.id,subject_phone:subjectPhone});if(!nextBox.isConnected)return;for(const o of result.items){const op=el('option',`#${o.number} · ${o.order_date} · ${o.customer_name}`);op.value=o.id;shipment.append(op);}nextLoaded=true;nextNote.textContent=result.items.length?'':'没有符合条件的下一张订单，可先保留奖励。';}catch(e){error(nextNote,e);}finally{shipment.disabled=false;}}
          };method.addEventListener('change',sync);void sync();return()=>({delivery_method:method.value,tracking_number:method.value==='self_postage'?track.value:'',postage_paid:method.value==='self_postage'&&paid.checked,shipment_order_id:method.value==='next_order'?shipment.value:''});
        },()=>deliveryForm.querySelector('[name=delivery_method]').value==='self_postage'?'referral-ship-self-postage':'referral-delivery',base,()=>refresh(false));
        const method=deliveryForm.querySelector('[name=delivery_method]'),submit=deliveryForm.querySelector('button[type=button]');
        let shipForm=null;
        const label=()=>{const title=method.value==='self_postage'?'登记已寄出':'保存介绍人选择';submit.title=title;submit.setAttribute('aria-label',title);submit.querySelector('span').textContent=title;if(shipForm)shipForm.hidden=method.value==='self_postage';};method.addEventListener('change',label);
        if(r.fulfillment==='ready'&&r.delivery_method!=='self_postage')shipForm=actionForm(body,'登记已寄出',form=>{const track=field(form,'Tracking number *','tracking_number','','text');track.required=true;return()=>({tracking_number:track.value});},'referral-ship',base,()=>refresh(false));
        label();
      }
      for(const form of body.querySelectorAll('form'))form.classList.add('ic-legacy-form');
      return card;
    }
    async function luckyView(){
      const token=++serial,box=panes.lucky,controls=el('div',null,'ic-legacy-controls'),results=el('div',null,'ic-legacy-results'),status=el('p','正在查询…','ic-legacy-status');box.replaceChildren(controls,results);
      controls.append(el('p','按当前顾客电话读取订单；抽奖机会必须由客服人工确认发放。','ic-legacy-intro'));
      const refresh=button('刷新订单',()=>void luckyView(),'RefreshCw');refresh.classList.add('ic-blue');controls.append(refresh,status);
      try{
        const data=await call('lucky',{campaign_id:campaignId});if(token!==serial)return;
        if(!data.campaign){status.textContent='尚未设置抽奖活动。';return;}
        campaignId=data.campaign.id;status.textContent=data.preview_only?'测试版 · 不开放真实抽奖机会':'抽奖资料已更新。';
        if(data.campaigns.length>1){const select=field(controls,'活动','campaign',campaignId,'text',data.campaigns.map(c=>[c.id,c.name]));select.addEventListener('change',()=>{campaignId=select.value;void luckyView();});}
        const active=data.grants.filter(g=>g.status==='active');
        const summary=el('article',null,'ic-legacy-card'),title=el('h3',data.campaign.name||"D'WELL Lucky Draw");summary.append(title,el('span',data.campaign.active?'活动已开启':'活动尚未开启','ic-legacy-campaign'+(data.campaign.active?'':' inactive')));
        if(active.length){const metrics=el('div',null,'ic-legacy-metrics');for(const [label,value] of [['总次数',active.reduce((n,g)=>n+g.chances,0)],['已使用',active.reduce((n,g)=>n+g.used,0)],['剩余',active.reduce((n,g)=>n+g.chances-g.used,0)]]){const item=el('span',label);item.prepend(el('strong',value));metrics.append(item);}summary.append(metrics);}
        else summary.append(el('p','这位顾客尚未建立永久抽奖链接。符合订单经人工确认后会自动建立。','ic-legacy-intro'));
        const linkBox=el('div',null,'ic-legacy-link');summary.append(linkBox);
        async function showLink(result){if(token!==serial)return;linkBox.replaceChildren();const input=field(linkBox,'顾客抽奖链接','lucky_url',result.url||'');input.readOnly=true;const copy=button('复制抽奖链接',async()=>{try{await navigator.clipboard.writeText(input.value);status.textContent='抽奖链接已复制；请由客服确认顾客后自行发送。';}catch{input.focus();input.select();status.textContent='请手动复制链接。';}},'Copy');copy.classList.add('ic-blue');linkBox.append(copy);}
        if(links.has(campaignId))await showLink(links.get(campaignId));
        else if(data.grants.length)linkBox.append(button('取得抽奖链接',async()=>{try{const result=await call('lucky-link',{campaign_id:campaignId,request_id:crypto.randomUUID()});links.set(campaignId,result);await showLink(result);}catch(e){error(status,e);}},'Link'));
        results.append(summary,el('h3',`最近正式订单 (${data.orders.length})`,'ic-legacy-section'));
        if(!data.orders.length)results.append(el('div','销售记录中没有找到这位顾客的正式订单。','ic-legacy-empty'));
        for(const o of data.orders){
          const card=el('article',null,'ic-legacy-card'),head=el('div',null,'ic-legacy-order-head');head.append(el('span',o.erp_id||`#${o.number}`),el('span',`${o.currency} ${money(o.gmv_minor)}`));card.append(head,el('div',o.order_date||'-','ic-legacy-date'));
          const eligible=o.eligibility?.eligible&&!o.issued,reason=o.issued?'已处理':eligible?'符合抽奖资格':reasonText(o.eligibility?.reason);card.append(el('div',reason,'ic-legacy-eligibility'+(eligible?' success':'')));
          if(o.eligibility?.chances>0)card.append(el('p',`系统计算：${o.eligibility.chances} 次抽奖机会`));
          if(o.issued)card.append(el('p',`已发放 ${o.issued.chances} 次 · ${statusText(o.issued.status)}`));
          else if(eligible){const selectedCampaign=campaignId;const form=actionForm(card,'开放抽奖机会',form=>{const confirm=check(form,'已核对这张订单，确认开放次数','confirmed');confirm.required=true;return()=>({});},'lucky-grant',{campaign_id:selectedCampaign,order_id:o.id},async result=>{links.set(selectedCampaign,result);await luckyView();});form.classList.add('ic-legacy-form');}
          results.append(card);
        }
        if(data.results.length)results.append(el('h3',`中奖记录 (${data.results.length})`,'ic-legacy-section'));
        for(const r of data.results){const card=el('article',null,'ic-legacy-card'),prizeStatus=r.status==='void'?'void':r.coupon_id?r.coupon_status:r.status;card.append(el('h3',r.snapshot?.name||'奖品'),el('p',`原订单 #${r.order_number} · ${statusText(prizeStatus)}`));results.append(card);
          if(!r.coupon_id&&r.status==='pending'){const form=actionForm(card,'标记已寄出',form=>{const track=field(form,'运单号码 *','tracking_number','','text');track.required=true;return()=>({tracking_number:track.value});},'lucky-ship',{id:r.id,version:r.version,campaign_id:campaignId},luckyView);form.classList.add('ic-legacy-form');}
          if(r.coupon_id)card.append(el('p','优惠券在后续订单选券使用；旧券只读。','ic-legacy-intro'));
        }
      }catch(e){if(token===serial)error(status,e);}
    }
    container.append(root);switchTab('crm');return {refreshCoupons:()=>couponReloader?.(),dispose(){alive=false;serial++;listeners.abort();for(const menu of root.querySelectorAll('.ic-suggestions:popover-open'))menu.hidePopover();if(orderDialog.open)orderDialog.close();root.remove();profileNode.hidden=false;},root};
  }
  globalThis.DwellInlineCRM=Object.freeze({mount,copyControl,customerCopyText});
})();
