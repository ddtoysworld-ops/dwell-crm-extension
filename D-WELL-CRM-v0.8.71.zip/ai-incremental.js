(() => {
  async function digest(value){
    const bytes=new TextEncoder().encode(value);
    const hash=await crypto.subtle.digest('SHA-256',bytes);
    return [...new Uint8Array(hash)].map(byte=>byte.toString(16).padStart(2,'0')).join('');
  }
  async function tokens(contextKey,entries){
    return Promise.all(entries.map(entry=>digest(`${contextKey}\n${entry.kind||'text'}\n${entry.id||''}\n${entry.incoming?'in':'out'}\n${entry.text||''}`)));
  }
  function fresh(entries,entryTokens,seen){return entries.filter((_,index)=>!seen.has(entryTokens[index]));}
  function lines(entries){return entries.map(entry=>entry.line||`${entry.source==='flow_choice'?'顾客点击自动选项（未确认是本人情况）':entry.incoming?'顾客':'客服'}：${entry.text}`).join('\n');}
  function customerText(entries){return entries.filter(entry=>entry.incoming&&entry.source!=='flow_choice').map(entry=>entry.text).join('\n').slice(0,4000);}
  function turnStart(entries){const lastSent=entries.findLastIndex(entry=>!entry.incoming);return entries.findIndex((entry,index)=>index>lastSent&&entry.incoming);}
  function replyTurn(entries,startIndex=turnStart(entries)){
    const start=Number.isInteger(startIndex)&&startIndex>=0&&entries[startIndex]?.incoming?startIndex:-1;
    const current=start<0?[]:entries.slice(start).filter(entry=>entry.incoming);
    const sentWithin=start<0?[]:entries.slice(start).filter(entry=>!entry.incoming);
    return {start,current,sentWithin,focus:current.at(-1)?.text||'',history:start<0?entries:entries.slice(0,start)};
  }
  function replyInput({draft='',entries=[],context='',progress='',captured=false,manualDraft='',startIndex}){
    const turn=captured?replyTurn(entries,startIndex):null;
    const latest=turn?.current.at(-1);
    const focus=latest?.source==='flow_choice'
      ? `顾客点击了自动流程选项「${turn.focus}」。这是点选内容，不等于顾客亲口描述的症状或用药；如需确认请询问顾客。`
      : turn?.focus;
    const sections=turn?.focus
      ? [`本轮最需要回答的顾客最新消息：\n${focus.slice(0,1400)}`]
      : [`本轮顾客问题或客服修改的草稿：\n${draft.trim()}`];
    if(turn?.current.length>1)sections.push(`本轮还需顾及的较早顾客消息：\n${lines(turn.current.slice(0,-1).slice(-4)).slice(-1300)}`);
    if(turn?.sentWithin.length)sections.push(`本轮客服已经发出的消息（避免重复，不能当作顾客问题）：\n${lines(turn.sentWithin.slice(-3)).slice(-900)}`);
    if(turn?.focus&&manualDraft.trim())sections.push(`客服补充的问题或要求：\n${manualDraft.trim().slice(0,800)}`);
    if(turn?.history.length)sections.push(`双方此前实际发出的消息（只作背景，已回答的不要重复）：\n${lines(turn.history.slice(-8)).slice(-1600)}`);
    if(progress)sections.push(`之前的对话进度（背景，不是本轮新问题；已答过的内容不要重复）：\n${progress.slice(0,900)}`);
    if(context)sections.push(`之前记录的顾客情况（只是背景；与本轮问题无关时不要展开）：\n${context.slice(0,1000)}`);
    return sections.join('\n\n').slice(0,4000);
  }
  globalThis.DwellAIIncremental=Object.freeze({digest,tokens,fresh,lines,customerText,turnStart,replyTurn,replyInput});
})();
