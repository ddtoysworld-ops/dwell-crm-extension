export function validConversationIdentity(identity) {
  if (!identity || typeof identity!=='object' || Array.isArray(identity)) return false;
  const {platform,identity_kind,identity_value}=identity;
  return platform==='messenger'&&identity_kind==='uid'&&/^\d{5,30}:\d{5,30}$/.test(identity_value)||
    platform==='whatsapp'&&identity_kind==='phone'&&/^(?:60\d{8,10}|65\d{8})$/.test(identity_value)||
    platform==='whatsapp'&&identity_kind==='username'&&/^@[a-z0-9._-]{3,64}$/.test(identity_value)||
    platform==='whatsapp'&&identity_kind==='name'&&typeof identity_value==='string'&&
      identity_value.length>=1&&identity_value.length<=100&&identity_value===identity_value.trim()&&
      !/[\x00-\x1f\x7f]/.test(identity_value);
}

export function conversationIdentity(context) {
  if (context?.platform === 'messenger' && context.status === 'ready' &&
    /^\d{5,30}$/.test(context.page || '') && /^\d{5,30}$/.test(context.uid || '') &&
    context.key === `messenger:${context.page}:${context.uid}`) {
    return {platform:'messenger',identity_kind:'uid',identity_value:`${context.page}:${context.uid}`};
  }
  if (context?.platform !== 'whatsapp') return null;
  if (context.status === 'ready' && /^(?:60\d{8,10}|65\d{8})$/.test(context.phone || '') &&
    context.key === `whatsapp:${context.phone}`) {
    return {platform:'whatsapp',identity_kind:'phone',identity_value:context.phone};
  }
  if (context.status !== 'phone_missing' || !context.key) return null;
  const title=String(context.title || '').normalize('NFKC').trim().replace(/\s+/g,' ');
  if (context.key !== `whatsapp-chat:${context.title}`) return null;
  if (/^@[a-z0-9._-]{3,64}$/i.test(title)) {
    return {platform:'whatsapp',identity_kind:'username',identity_value:title.toLowerCase()};
  }
  if (!title || title.length>100 || title.startsWith('@') || /[\x00-\x1f\x7f]/.test(title)) return null;
  return {platform:'whatsapp',identity_kind:'name',identity_value:title.toLocaleLowerCase()};
}
