export const canUseAI=context=>context?.status==='ready'||
  (context?.status==='phone_missing'&&context.platform==='whatsapp'&&!!context.key);

export async function generateDraft({fetcher=fetch,url,anonKey,token,payload,assertCurrent}){
  if(!token)throw Error('ai_login_required');
  if(typeof payload?.input_text!=='string'||!payload.input_text.trim()||payload.input_text.length>4000||
      !['answer_question','polish_translate'].includes(payload.mode))throw Error('ai_invalid_request');
  const response=await fetcher(`${url}/functions/v1/dwell-ai-reply`,{method:'POST',
    headers:{authorization:`Bearer ${token}`,apikey:anonKey,'content-type':'application/json'},
    body:JSON.stringify({input_text:payload.input_text,focus_text:payload.focus_text||'',content_id:payload.content_id||null,agent_id:payload.agent_id||null,
      mode:payload.mode,target_language:payload.target_language||'',recent_media_ids:payload.recent_media_ids||[]})});
  let result={};try{result=await response.json();}catch{}
  await assertCurrent();
  if(!response.ok)throw Error(result.code||'ai_service_failed');
  if(typeof result.reply!=='string'||!result.reply.trim())throw Error('ai_empty_reply');
  const items=Array.isArray(result.media_items)?result.media_items:result.media?[result.media]:[];
  const seen=new Set(),mediaItems=[];
  for(const media of items){
    if(!/^[0-9a-f-]{36}$/i.test(media?.id||'')||
      !/^agent-media\/[0-9a-f-]{36}\.(jpg|png|webp)$/.test(media?.image_path||'')||
      typeof media?.name!=='string'||seen.has(media.id))continue;
    seen.add(media.id);
    mediaItems.push({id:media.id,name:media.name.slice(0,120),image_path:media.image_path,
      image_url:`${url}/storage/v1/object/public/dwell-ai-packages/${media.image_path}`,
      reason:String(media.reason||'请核对照片用途').slice(0,120),order:mediaItems.length+1});
    if(mediaItems.length===5)break;
  }
  return {reply:result.reply.slice(0,16000),media_items:mediaItems,media:mediaItems[0]||null};
}
