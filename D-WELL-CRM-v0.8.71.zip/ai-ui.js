(() => {
  const catalogCache=new Map(),imageCache=new Map();let preloadPending=null,cacheRevision=0;
  const lastReplyByConversation=new Map();
  const sectionState={assistant:true,listing:true};
  const catalogKey=()=>null;
  function resetCatalog(){cacheRevision++;catalogCache.clear();imageCache.clear();lastReplyByConversation.clear();preloadPending=null;}
  async function preload(){return;}
  const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
    const errors={ai_service_failed:'AI 服务暂时未返回有效结果，请稍后手动重试。',ai_key_not_configured:'AI 密钥尚未配置，请联系管理员。',ai_catalog_unavailable:'配套资料暂时无法读取。',ai_content_unavailable:'所选配套已停用或更改，请重新选择。',ai_login_required:'请先登录客服账号。',ai_busy:'当前对话正在生成，请等待完成。',ai_invalid_request:'请填写不超过 4000 字的内容。',ai_message_missing:'当前已加载的对话里没有文字消息；请切换顾客对话，或手动粘贴。',ai_direction_uncertain:'有消息无法确认是顾客还是客服发出的，已停止自动抓取。请检查聊天页面或手动粘贴问题。',ai_empty_reply:'没有可用回复，请重新生成或输入草稿。',ai_selection_missing:'请先选中当前顾客的文字，或手动粘贴到问题栏。',ai_composer_missing:'无法唯一确认回复框，请复制草稿后手动粘贴。',ai_composer_not_empty:'回复框已有草稿，未覆盖。请先自行处理原有文字。',ai_insert_failed:'未能放入回复框，请复制草稿后手动粘贴。',workbench_context_changed:'顾客已切换，请重新核对内容。',sidebar_access_denied:'请先登录客服账号。',ai_generation_locked:'AI 生成尚未开放。'};
  function mount({container,snapshot,send,chat=globalThis.DwellAIChat}){
    let alive=true,busy=false,listingSequence=0,loadSequence=0,draftRevision=0,listings=[],recommendedMedia=[],photoEligible=false;
    const recentMediaByAgent=new Map();
    const expected={documentId:snapshot.documentId,revision:snapshot.revision};
    const root=el('section',null,'ai-tools');
    const style=el('style',`.ai-tools{font:14px/1.55 Arial,"Microsoft YaHei",sans-serif;letter-spacing:0;padding-top:14px;color:#203b35}.ai-tools *{box-sizing:border-box}.ai-tools label{display:grid;gap:6px;margin:12px 0;font-size:13px}.ai-tools textarea,.ai-tools select{font:14px/1.5 Arial,"Microsoft YaHei",sans-serif;width:100%;min-width:0;border:1px solid #cbd8d7;border-radius:5px;padding:9px;background:white;color:#203b35}.ai-tools textarea{resize:vertical;min-height:105px}.ai-tools button{font:13px/1.4 Arial,"Microsoft YaHei",sans-serif;min-height:38px;border:1px solid #cbd8d7;border-radius:5px;background:white;color:#203b35;padding:8px;display:inline-flex;align-items:center;justify-content:center;gap:6px;cursor:pointer}.ai-tools button:disabled{opacity:.55;cursor:default}.ai-tools button svg{width:16px;height:16px;flex-shrink:0}.ai-row{display:flex;gap:7px;flex-wrap:wrap}.ai-row button{flex:1;min-width:90px}.ai-tools .ai-primary{background:#236d58;color:white;border-color:#236d58}.ai-tools .ai-status{white-space:pre-line;font-size:12px;color:#566b73;margin:10px 0}.ai-tools details{margin-top:18px;border-top:1px solid #dce5e5;padding-top:12px}.ai-tools summary{font-weight:bold;cursor:pointer;min-height:36px}.ai-tools a{color:#216294;overflow-wrap:anywhere}.ai-media{display:grid;gap:8px}.ai-media article{padding:10px 0;border-bottom:1px solid #e4e9ee}.ai-media img{display:block;width:100%;max-height:240px;object-fit:contain;margin:8px 0}.ai-tools button:focus-visible,.ai-tools textarea:focus-visible,.ai-tools select:focus-visible{outline:2px solid #286eaa;outline-offset:2px}`);root.append(style);
    const button=(label,fn,icon)=>{const b=el('button');b.type='button';b.title=label;b.setAttribute('aria-label',label);if(globalThis.lucide?.icons?.[icon])b.append(lucide.createElement(lucide.icons[icon],{'aria-hidden':'true'}));b.append(el('span',label));b.addEventListener('click',fn);return b;};
    style.textContent+=' .ai-media img[hidden]{display:none}';
    style.textContent+=' .ai-tools details,.ai-tools label{min-width:0;max-width:100%}.ai-tools>.ai-section{width:100%}.ai-tools select,.ai-tools textarea{max-width:100%}';
    style.textContent+=' .ai-tools>.ai-section{margin-top:0;padding-top:0;border-top:0;border-bottom:1px solid #dce5e5;padding-bottom:12px;margin-bottom:14px}.ai-tools>.ai-section>summary{display:flex;align-items:center;justify-content:space-between;gap:12px;list-style:none;min-height:42px;color:#203b35}.ai-tools>.ai-section>summary::-webkit-details-marker{display:none}.ai-tools>.ai-section>summary::after{content:"";width:0;height:0;border-left:5px solid #718091;border-top:4px solid transparent;border-bottom:4px solid transparent;flex-shrink:0}.ai-tools>.ai-section[open]>summary::after{transform:rotate(90deg)}.ai-tools summary:focus-visible{outline:2px solid #286eaa;outline-offset:2px}';
    function section(label,key){const node=el('details',null,'ai-section');node.dataset.section=key;node.open=sectionState[key];node.append(el('summary',label));node.addEventListener('toggle',()=>{if(alive&&node.isConnected)sectionState[key]=node.open;});root.append(node);return node;}
    const assistant=section('AI 回复助手','assistant');
    style.textContent+=' .ai-tools>.ai-section>summary::after{margin-right:3px}';
    style.textContent+=' .ai-controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}.ai-controls button{min-width:0;min-height:42px}.ai-tools .ai-full{width:100%;min-height:42px;margin:0 0 10px}.ai-tools .ai-primary{background:#1265ef;border-color:#1265ef}.ai-tools textarea::placeholder{color:#768394;opacity:1}.ai-tools textarea[name=ai_input]{min-height:100px}.ai-tools textarea[name=ai_output]{min-height:156px}';
    style.textContent+=' .ai-tools{background:#eaf0f7;border:1px solid #cfdae8;border-radius:6px;padding:10px;color:#203b35}.ai-tools>.ai-section{background:#f7f9fc;border:1px solid #d4deea;border-radius:5px;padding:0 10px 12px;margin:0 0 10px}.ai-tools>.ai-section:not([open]){padding-bottom:0}.ai-tools>.ai-section>summary{color:#1d394c;border-bottom:1px solid #dce4ed}.ai-tools>.ai-section:not([open])>summary{border-bottom:0}.ai-tools textarea,.ai-tools select,.ai-tools button:not(.ai-primary){background:#fff;border-color:#c5d2df}.ai-tools label{color:#4a6074}.ai-tools .ai-primary{background:#1265ef;border-color:#1265ef;color:#fff;font-weight:600}.ai-tools .ai-primary:hover:not(:disabled){background:#0959db}.ai-tools button:hover:not(:disabled):not(.ai-primary){background:#f0f6ff;border-color:#92b3dc}.ai-tools textarea:focus,.ai-tools select:focus{border-color:#3b82d6;box-shadow:0 0 0 2px #d9eafd;outline:0}';
    const field=(parent,label,tag,name)=>{const wrap=el('label',label),n=el(tag);n.name=name;wrap.append(n);parent.append(wrap);return n;};
    const status=el('p','正在读取配套资料…','ai-status');status.setAttribute('role','status');
    const fail=e=>{if(alive)status.textContent=errors[e.message]||'操作未完成，请重试。';};
    async function call(action,payload={}){if(!alive)throw Error('workbench_context_changed');const key=action==='image'?payload.url:action==='content-image'?payload.path:action==='content'?'content':catalogKey(action,payload),cache=action==='image'||action==='content-image'?imageCache:catalogCache;if(key&&payload.refresh===true)cache.delete(key);if(key&&cache.has(key))return cache.get(key);const version=cacheRevision,result=await send({type:'dwell-ai',action,payload,expected},60000);if(!alive||version!==cacheRevision)throw Error('workbench_context_changed');if(!result?.ok)throw Error(result?.code||result?.error||'ai_service_failed');if(key){cache.set(key,result.value);if(cache===imageCache&&cache.size>8)cache.delete(cache.keys().next().value);}return result.value;}
    const agentSelect=field(assistant,'AI Agent','select','ai_agent');agentSelect.disabled=true;
    const memoryLabels={concern:'主要问题',symptoms:'症状',age:'年龄',medications:'正在使用的药',triggers:'什么情况下不舒服',progress:'使用后变化'};
    const memoryPanel=el('details',null,'ai-memory'),memoryTitle=el('summary','顾客情况'),memoryNotice=el('p','正在读取顾客情况…','ai-memory-note'),memoryList=el('div'),memoryForm=el('div');
    memoryPanel.open=true;
    memoryPanel.append(memoryTitle,memoryNotice,memoryList,memoryForm);assistant.append(memoryPanel);
    let memoryData=null,memorySettings=null,memoryConflict=null,legacyMemoryData=null,memoryEditing=false,memoryClearConfirming=false,memoryClearing=false,memoryReady=Promise.resolve(),memoryExtractPending=Promise.resolve();
    const progressPanel=el('details',null,'ai-memory'),progressTitle=el('summary','对话进度'),progressNotice=el('p','正在读取对话进度…','ai-memory-note'),progressText=el('p','','ai-memory-note');
    progressPanel.open=true;progressPanel.append(progressTitle,progressNotice,progressText);assistant.append(progressPanel);
    let progressData=null,progressReady=Promise.resolve(),progressUpdatePending=Promise.resolve();
    const replyKey=JSON.stringify([snapshot.context.platform,snapshot.context.key]);
    function renderProgress(){progressText.textContent=progressData?.summary||'还没有记录对话进度。';}
    function progressFailure(error,action){const code=/^[a-z][a-z0-9_]{2,60}$/i.test(error?.message||'')?error.message:'unknown';
      if(code==='ai_action_invalid')return '插件背景程序仍是旧版，请在 Chrome 扩充功能中重新载入插件。';
      if(code==='workbench_context_changed')return '当前对话已改变，请刷新插件后重试。';
      return `对话进度${action}失败（${code}）；回复草稿仍可使用。`;}
    async function loadProgress(){try{const result=await call('progress-read');if(result?.status!=='matched'){progressNotice.textContent='当前对话尚无可用的识别资料。';return false;}
      if(!result.progress||!Number.isInteger(result.progress.version))throw Error('ai_progress_invalid_response');
      progressData=result.progress;progressNotice.textContent=progressData.retained_for_customer?'已归户顾客；对话进度保留。':'未归户对话；30 天没有更新后会自动清理对话进度。';renderProgress();return true;}
      catch(e){progressNotice.textContent=progressFailure(e,'读取');return false;}}
    progressPanel.append(button('重试读取进度',()=>{progressReady=loadProgress();},'RefreshCw'));
    style.textContent+=' .ai-memory{margin:12px 0!important;padding:8px 0!important}.ai-memory summary{font-weight:600}.ai-memory-note{font-size:12px;color:#566b73;margin:8px 0}.ai-memory-row{display:grid;grid-template-columns:90px minmax(0,1fr);gap:6px;padding:5px 0;border-bottom:1px solid #e2e9ef;overflow-wrap:anywhere}.ai-memory-row strong{font-size:12px}.ai-memory .ai-row{margin-top:10px}.ai-memory label{margin:8px 0}.ai-memory input{width:100%;min-width:0;border:1px solid #c5d2df;border-radius:5px;padding:8px;font:inherit}.ai-memory-conflict{color:#9a5c11}';
    function renderMemory(){
      memoryList.replaceChildren();memoryForm.replaceChildren();
      if(!memoryData)return;
      const facts=memoryData.facts||{};
      for(const [key,label] of Object.entries(memoryLabels))if(facts[key]){const row=el('div',null,'ai-memory-row');row.append(el('strong',label),el('span',facts[key]));memoryList.append(row);}
      if(!memoryList.childNodes.length)memoryList.append(el('p','还没有记录顾客情况。','ai-memory-note'));
      if(legacyMemoryData?.facts&&Object.keys(legacyMemoryData.facts).length){
        memoryList.append(el('p','旧 CRM 顾客档案摘要（只读，不是本次对话）：','ai-memory-note'));
        for(const [key,label] of Object.entries(memoryLabels))if(legacyMemoryData.facts[key]){
          const row=el('div',null,'ai-memory-row');row.append(el('strong',label),el('span',legacyMemoryData.facts[key]));memoryList.append(row);
        }
      }
      if(memoryConflict&&Object.keys(memoryConflict).length){const warning=el('p','新对话有与档案不同的内容，请核对后手动修改：','ai-memory-note ai-memory-conflict');memoryList.append(warning);for(const [key,value] of Object.entries(memoryConflict))memoryList.append(el('p',`${memoryLabels[key]||key}：${value}`,'ai-memory-note ai-memory-conflict'));}
      const memoryActions=el('div',null,'ai-row');
      const edit=button(memoryEditing?'取消修改':'修改顾客情况',()=>{memoryEditing=!memoryEditing;memoryClearConfirming=false;renderMemory();},memoryEditing?'X':'Pencil');
      const clear=button('清除对话记忆',()=>{memoryClearConfirming=true;memoryEditing=false;renderMemory();},'Trash2');
      clear.disabled=memoryClearing;memoryActions.append(edit,clear);memoryList.append(memoryActions);
      if(memoryClearConfirming){
        const confirm=el('div',null,'ai-memory-clear-confirm');
        confirm.append(el('p','清除当前对话保存在 Supabase 的顾客情况与对话进度；旧 CRM 档案、订单和聊天消息不会删除。此操作无法在插件内撤销。'));
        const controls=el('div',null,'ai-row');
        controls.append(button('取消',()=>{memoryClearConfirming=false;renderMemory();},'X'));
        const erase=button('确认清除',()=>{void clearConversationMemory();},'Trash2');erase.disabled=memoryClearing;controls.append(erase);
        confirm.append(controls);memoryList.append(confirm);
      }
      if(!memoryEditing)return;
      for(const [key,label] of Object.entries(memoryLabels)){const wrap=el('label',label),field=el('input');field.name=key;field.maxLength=500;field.value=facts[key]||'';wrap.append(field);memoryForm.append(wrap);}
      memoryForm.append(button('保存顾客情况',async()=>{try{const next={};for(const key of Object.keys(memoryLabels)){const value=memoryForm.querySelector(`[name="${key}"]`).value.trim();if(value)next[key]=value;}
        const result=await call('memory-save',{facts:next,version:memoryData.version,request_id:crypto.randomUUID()});memoryData=result.memory;memoryConflict=null;memoryEditing=false;memoryNotice.textContent='顾客情况已保存。';renderMemory();}
        catch(e){memoryNotice.textContent=errors[e.message]||'保存失败，请刷新后重试。';}},'Check'));
    }
    style.textContent+=' .ai-memory-clear-confirm{margin-top:10px;padding:10px;border:1px solid #d9a7a7;background:#fff7f7;border-radius:5px;color:#7f3030}.ai-memory-clear-confirm p{margin:0 0 10px}.ai-memory-clear-confirm button:last-child{color:#a12e2e;border-color:#d9a7a7}';
    async function clearConversationMemory(){
      if(memoryClearing)return;
      memoryClearing=true;renderMemory();memoryNotice.textContent='正在清除当前对话记忆…';
      let memoryWasCleared=false;
      try{
        if(!currentConversation())throw Error('workbench_context_changed');
        await Promise.all([memoryExtractPending,progressUpdatePending]);
        const latest=await call('memory-read');
        if(latest.status!=='matched')throw Error('workbench_context_changed');
        const result=await call('memory-clear',{version:latest.memory.version,request_id:crypto.randomUUID()});
        if(result.status!=='matched')throw Error('workbench_context_changed');
        memoryWasCleared=true;
        memoryData=result.memory;memoryConflict=null;legacyMemoryData=null;memoryEditing=false;memoryClearConfirming=false;
        draftRevision++;input.value='';output.value='';captureEntries=[];captureTokens=[];renderFocus();lastGenerated=false;capturedDraft='';manualDraft='';
        photoEligible=false;recommendedMedia=[];recentMediaByAgent.clear();recommend();
        lastReplyByConversation.delete(replyKey);refreshRestoreButton();
        let localCleared=true;
        try{seenFallback.clear();await chrome.storage.local.remove(await seenKey());}
        catch{localCleared=false;seenPersistenceAvailable=false;}
        let progressCleared=false;
        try{
          const currentProgress=await call('progress-read');
          if(currentProgress.status!=='matched')throw Error('ai_progress_unavailable');
          if(currentProgress.progress?.summary?.trim()){
            const cleared=await call('progress-clear',{version:currentProgress.progress.version,request_id:crypto.randomUUID()});
            if(cleared.status!=='matched')throw Error('ai_progress_unavailable');
            progressData=cleared.progress;
          }else progressData=currentProgress.progress;
          progressCleared=true;renderProgress();
        }catch(e){progressNotice.textContent=progressFailure(e,'清除');}
        memoryNotice.textContent=!progressCleared?'顾客情况已清除，但对话进度未清除；请重新加载插件后再清除一次。':
          !localCleared?'Supabase 记忆已清除，但本机抓取记录未清除；请刷新插件后再试。':
          '当前对话的顾客情况和对话进度已清除，可重新抓取。';
        status.textContent=memoryNotice.textContent;
      }catch(e){memoryNotice.textContent=memoryWasCleared?'顾客情况已清除，但后续清理未完成；请重新连接后核对。':
        e.message==='core_stale_version'?'资料刚被其他客服修改，请重新确认后再清除。':errors[e.message]||'清除失败，资料未确认删除；请重试。';}
      finally{memoryClearing=false;renderMemory();}
    }
    async function loadMemory(){try{const result=await call('memory-read');if(result.status!=='matched'){memoryNotice.textContent='当前对话尚无可用的识别资料，暂不保存摘要。';return;}
      memoryData=result.memory;memorySettings=result.settings;legacyMemoryData=result.legacy_memory;
      memoryNotice.textContent=result.match_source==='name'?'按当前 WhatsApp 联系人姓名保存对话摘要。':'按当前对话身份保存摘要，不需要先建立 CRM 顾客。';renderMemory();}
      catch{memoryNotice.textContent='顾客情况暂时无法读取；不影响手动回复。';}}
    const input=field(assistant,'顾客问题 / 草稿','textarea','ai_input');input.maxLength=4000;input.placeholder='顾客问题，或大概回复内容…';
    const focusWrap=el('div',null,'ai-focus'),focusSelect=field(focusWrap,'本轮从哪条顾客消息开始','select','ai_focus'),focusPreview=el('p','','ai-status');
    focusWrap.hidden=true;focusWrap.append(focusPreview);assistant.append(focusWrap);
    style.textContent+=' .ai-focus[hidden]{display:none}.ai-focus{border-left:3px solid #1265ef;padding-left:10px;margin:8px 0}.ai-focus label{margin:4px 0}.ai-focus .ai-status{margin:6px 0;overflow-wrap:anywhere}';
    style.textContent+=' .ai-dictation{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:end;margin:8px 0}.ai-dictation label{margin:0}.ai-dictation button{min-width:92px}.ai-dictation button.ai-recording{border-color:#b74949;color:#a12e2e;background:#fff3f2}';
    const dictationRow=el('div',null,'ai-dictation'),speechLanguage=field(dictationRow,'口述语言','select','ai_speech_language');
    for(const [value,label] of [['zh-CN','中文'],['en-MY','English'],['ms-MY','Bahasa Melayu']]){const option=el('option',label);option.value=value;speechLanguage.append(option);}
    let speech=null;
    const speechButton=button('开始口述',()=>{if(speech){stopSpeech();return;}startSpeech();},'Mic');dictationRow.append(speechButton);assistant.append(dictationRow);
    function speechButtonState(){const recording=!!speech;speechButton.querySelector('span').textContent=recording?(speech.stopping?'识别中…':'停止口述'):'开始口述';speechButton.setAttribute('aria-label',recording?'停止口述':'开始口述');speechButton.title=recording?'停止口述':'开始口述';speechButton.disabled=!!speech?.stopping;speechButton.classList.toggle('ai-recording',recording);speechLanguage.disabled=recording;}
    function currentConversation(){const observe=globalThis.DwellReadContext?.observe;if(!observe)return true;try{const current=observe(document,location.href);return !!current&&current.key===snapshot.context.key&&current.status===snapshot.context.status;}catch{return false;}}
    function abortSpeech(){if(!speech)return;const previous=speech;speech=null;previous.recognition.onstart=null;previous.recognition.onresult=null;previous.recognition.onerror=null;previous.recognition.onend=null;try{previous.recognition.abort();}catch{}speechButtonState();}
    function stopSpeech(){if(!speech||speech.stopping)return;speech.stopping=true;speechButtonState();try{speech.recognition.stop();}catch{abortSpeech();status.textContent='口述未能结束，请重试。';}}
    function startSpeech(){
      if(!currentConversation()){fail(Error('workbench_context_changed'));return;}
      const Recognition=globalThis.SpeechRecognition||globalThis.webkitSpeechRecognition;
      if(!Recognition){status.textContent='此浏览器暂不支持语音输入，请手动填写。';return;}
      const recognition=new Recognition(),session={recognition,stopping:false,notice:'',finalResults:new Set()};speech=session;
      recognition.lang=speechLanguage.value;recognition.continuous=true;recognition.interimResults=false;recognition.maxAlternatives=1;
      recognition.onstart=()=>{if(speech===session&&alive)status.textContent='正在听取口述…';};
      recognition.onresult=event=>{
        if(speech!==session||!alive)return;
        if(!currentConversation()){abortSpeech();fail(Error('workbench_context_changed'));return;}
        for(let i=event.resultIndex;i<event.results.length;i++){
          const result=event.results[i];if(!result.isFinal||session.finalResults.has(i))continue;session.finalResults.add(i);
          const words=String(result[0]?.transcript||'').trim();if(!words)continue;
          const addition=(input.value.trim()? '\n':'')+words,available=input.maxLength-input.value.length;
          if(available<=0){session.notice='草稿已达到字数上限。';stopSpeech();break;}
          input.value+=addition.slice(0,available);input.dispatchEvent(new Event('input',{bubbles:true}));
          status.textContent='已加入草稿，可继续说话。';
          if(addition.length>available){session.notice='草稿已达到字数上限。';stopSpeech();break;}
        }
      };
      recognition.onerror=event=>{if(speech!==session||!alive)return;session.notice=event.error==='not-allowed'||event.error==='service-not-allowed'?'麦克风未获准使用，请检查 Chrome 权限。':event.error==='no-speech'?'没有听到语音，请再试一次。':event.error==='audio-capture'?'找不到可用麦克风。':'语音识别暂时失败，请重试。';};
      recognition.onend=()=>{if(speech!==session||!alive)return;speech=null;speechButtonState();status.textContent=session.notice||'口述结束，文字可以修改。';};
      speechButtonState();status.textContent='正在开启麦克风…';
      try{recognition.start();}catch{abortSpeech();status.textContent='麦克风未能启动，请检查 Chrome 权限后重试。';}
    }
    assistant.addEventListener('toggle',()=>{if(!assistant.open)abortSpeech();});
    const actions=el('div',null,'ai-controls');assistant.append(actions);
    style.textContent+=' .ai-tools .ai-capture-loading:disabled{opacity:1;cursor:progress}.ai-capture-loading svg{display:none}.ai-capture-loading::before{content:"";width:14px;height:14px;flex:none;border:2px solid #a5b9d5;border-top-color:#1265ef;border-radius:50%;animation:ai-capture-spin .8s linear infinite}@keyframes ai-capture-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.ai-capture-loading::before{animation:none;border-top-color:#a5b9d5}}';
    let captureBusy=false,lastVoiceCount=0,captureButton,captureEntries=[],captureTokens=[],lastGenerated=false,capturedDraft='',manualDraft='';
    const incremental=globalThis.DwellAIIncremental;
    function renderFocus(reset=false){
      const selected=focusSelect.value;
      focusSelect.replaceChildren();
      const incoming=captureEntries.map((entry,index)=>({entry,index})).filter(item=>item.entry.incoming);
      focusWrap.hidden=!incoming.length;
      if(!incoming.length)return;
      const preferred=incremental.turnStart(captureEntries);
      const blank=el('option',preferred<0?'客服已发言；如需继续回答，请选择顾客消息':'请选择本轮顾客消息');blank.value='';focusSelect.append(blank);
      for(const {entry,index} of incoming){const option=el('option',`${index+1}. ${String(entry.text||'语音').replace(/\s+/g,' ').slice(0,80)}`);option.value=String(index);focusSelect.append(option);}
      focusSelect.value=!reset&&selected&&incoming.some(item=>String(item.index)===selected)?selected:preferred>=0?String(preferred):'';
      updateFocusPreview();
    }
    function updateFocusPreview(){
      const turn=incremental.replyTurn(captureEntries,focusSelect.value===''?-1:Number(focusSelect.value));
      focusPreview.textContent=turn.focus?`主要回答最新消息：${turn.focus.slice(0,160)}${turn.current.length>1?`；本轮另有 ${turn.current.length-1} 条顾客消息。`:''}`:'客服最后已发言。若仍需 AI 接续，请核对后选择要回答的顾客消息。';
    }
    focusSelect.addEventListener('change',updateFocusPreview);
    const seenFallback=new Set();let seenPersistenceAvailable=true;
    async function seenKey(){return `dwell-ai-seen:${await incremental.digest(snapshot.context.key)}`;}
    async function readSeen(){
      if(!globalThis.chrome?.storage?.local){seenPersistenceAvailable=false;return new Set(seenFallback);}
      try{const key=await seenKey(),stored=(await chrome.storage.local.get(key))?.[key];if(stored!=null&&!Array.isArray(stored))throw Error('seen_storage_invalid');
        const seen=new Set(stored||[]);seenFallback.clear();for(const token of seen)seenFallback.add(token);seenPersistenceAvailable=true;return seen;
      }catch{seenPersistenceAvailable=false;return new Set(seenFallback);}
    }
    async function markSeen(){if(!captureTokens.length)return;const seen=await readSeen();for(const token of captureTokens)seen.add(token);
      seenFallback.clear();for(const token of seen)seenFallback.add(token);
      if(!seenPersistenceAvailable)throw Error('seen_storage_unavailable');
      try{const key=await seenKey();await chrome.storage.local.set({[key]:[...seen].slice(-120)});}
      catch{seenPersistenceAvailable=false;throw Error('seen_storage_unavailable');}}
    function setCaptureBusy(value){
      captureBusy=value;
      captureButton.disabled=value;
      captureButton.classList.toggle('ai-capture-loading',value);
      captureButton.querySelector('span').textContent=value?'抓取中…':'抓近期对话';
      captureButton.setAttribute('aria-label',value?'正在抓取近期对话':'抓近期对话');
      captureButton.setAttribute('aria-busy',String(value));
      captureButton.title=value?'正在抓取近期对话':'抓近期对话';
    }
    async function captureText({allowExisting=false}={}){
      if(captureBusy)return false;
      setCaptureBusy(true);
      const ticket=++draftRevision;let captureStage='检查对话';
      try{
        abortSpeech();
        if(!currentConversation())throw Error('workbench_context_changed');
        captureStage='读取文字';
        let texts=[],textError=null;
        try{texts=chat.recentEntries(snapshot.context.platform).map(entry=>({...entry,kind:entry.kind||'text'}));}
        catch(e){textError=e;}
        if(textError&&textError.message!=='ai_message_missing')throw textError;
        captureStage='读取语音';status.textContent='正在读取近期语音…';
        let voice={lines:[],failed:0,remaining:0},voiceError=false;
        try{
          if(!globalThis.DwellVoiceForAI?.transcribeRecent)throw Error('voice_unavailable');
          voice=await globalThis.DwellVoiceForAI.transcribeRecent(snapshot.context.platform);
        }catch{voiceError=true;}
        if(!alive||!currentConversation()||ticket!==draftRevision)throw Error('workbench_context_changed');
        const voices=(voice.entries||voice.lines.map(line=>({id:line,text:line,incoming:line.startsWith('顾客'),line})))
          .map(entry=>({...entry,kind:'voice'}));
        if(textError&&voices.length===0&&!(allowExisting&&input.value.trim()&&!lastGenerated))throw textError;
        captureStage='整理消息';const all=[...texts,...voices].sort((a,b)=>(a.order??Infinity)-(b.order??Infinity)),allTokens=await incremental.tokens(snapshot.context.key,all);
        captureStage='读取去重记录';const seen=await readSeen();
        const fresh=all.filter((_,index)=>!seen.has(allTokens[index]));
        const previous=lastGenerated?'':input.value.trim();
        let usable=fresh,omitted=0;
        while(usable.length>1&&incremental.lines(usable).length+previous.length+(previous?1:0)>input.maxLength){usable=usable.slice(1);omitted++;}
        let value=incremental.lines(usable);
        if(!value){
          if(!all.length&&allowExisting&&input.value.trim()&&!lastGenerated){status.textContent='使用手动填写的问题生成回复。';return true;}
          if(all.length&&!voiceError&&!voice.failed&&!voice.remaining){
            if(allowExisting&&input.value.trim()&&!lastGenerated){status.textContent='没有新消息，继续使用目前的顾客问题生成回复。';return true;}
            status.textContent='没有新的顾客消息。若要重新检查，可先修改或粘贴问题。';return false;
          }
          if(voiceError){status.textContent='没有抓到顾客文字，语音服务也暂时无法读取；请重试或手动粘贴。';return false;}
          if(voice.failed||voice.remaining){status.textContent='没有抓到顾客文字，近期语音尚未全部转写；请重试转写。';return false;}
          throw Error('ai_message_missing');
        }
        if(!usable.some(entry=>entry.incoming)&&!(allowExisting&&input.value.trim()&&!lastGenerated)){
          status.textContent='这次只有我方的新消息，没有新的顾客问题。';return false;
        }
        const existingLines=new Set(previous.split('\n'));
        const addition=value.split('\n').filter(line=>!existingLines.has(line)).join('\n');
        const combined=[previous,addition].filter(Boolean).join('\n');
        if(combined.length>input.maxLength){status.textContent='现有草稿与近期对话合计超过 4000 字，请先删减后再抓取。';return false;}
        captureStage='更新草稿';if(combined!==input.value){output.value='';photoEligible=false;recommendedMedia=[];recommend();}
        if(lastGenerated)manualDraft='';
        else if(!captureEntries.length&&!capturedDraft)manualDraft=previous;
        input.value=combined;capturedDraft=combined;
        const freshTokens=allTokens.filter((_,index)=>!seen.has(allTokens[index]));
        const priorCount=captureEntries.length;
        for(let index=0;index<omitted;index++)if(!captureTokens.includes(freshTokens[index]))captureTokens.push(freshTokens[index]);
        for(let index=omitted;index<fresh.length;index++)if(!captureTokens.includes(freshTokens[index])){captureEntries.push(fresh[index]);captureTokens.push(freshTokens[index]);}
        renderFocus(captureEntries.length>priorCount);
        lastGenerated=false;lastVoiceCount=voices.filter(entry=>usable.includes(entry)).length;
        status.textContent=voiceError?'已抓取新文字；语音暂时无法读取，请核对后生成。':voice.failed||voice.remaining
          ?`已抓取新文字与 ${lastVoiceCount} 条语音；${voice.failed} 条转写失败，${voice.remaining} 条尚未处理。请核对后生成。`
          :`已抓取 ${usable.length} 条新消息${lastVoiceCount?`，含 ${lastVoiceCount} 条语音`:''}，请核对后生成。`;
        if(omitted)status.textContent+=` 较早的 ${omitted} 条超出字数上限，未加入本轮。`;
        if(!seenPersistenceAvailable)status.textContent+=' 去重记录暂时无法读取；下次可能重复抓取。';
        if(voiceError||voice.failed||voice.remaining){status.textContent+=' 语音未全部读取，暂不生成回复；请重试。';return false;}
        return true;
      }catch(e){if(errors[e.message])fail(e);else status.textContent=`抓取未完成（${captureStage}），请重试。`;return false;}
      finally{setCaptureBusy(false);}
    }
    captureButton=button('抓近期对话',()=>{void captureText();},'MessageSquare');actions.append(captureButton);
    const generateButtons=[];
    async function generate(mode,language){
      if(busy||captureBusy)return;
      if(mode==='answer_question'&&!(await captureText({allowExisting:true})))return;
      if(!input.value.trim()){fail(Error('ai_invalid_request'));return;}
      if(mode==='answer_question'){
        await Promise.all([memoryReady,progressReady,progressUpdatePending]);
        if(!progressData)progressReady=loadProgress();
        await progressReady;
      }
      busy=true;const ticket=++draftRevision;for(const b of generateButtons)b.disabled=true;output.value='';photoEligible=false;recommendedMedia=[];recommend();status.textContent='正在生成回复…';
      try{const selected=mode==='answer_question'&&pack.value!==''?listings[Number(pack.value)]:null;
        const remembered={...(legacyMemoryData?.facts||{}),...(memoryData?.facts||{})};
        const context=mode==='answer_question'&&memoryData?Object.entries(remembered).filter(([key])=>memorySettings?.enabled_fields?.includes(key)).map(([key,value])=>`${memoryLabels[key]}：${value}`).join('\n'):'';
        const selectedTurn=captureEntries.length?incremental.replyTurn(captureEntries,focusSelect.value===''?-1:Number(focusSelect.value)):null;
        const captured=!!selectedTurn?.focus&&input.value.includes(selectedTurn.focus.slice(0,Math.min(24,selectedTurn.focus.length)));
        const currentTurn=captured?selectedTurn:null;
        if(captureEntries.length&&!selectedTurn?.focus&&input.value===capturedDraft){status.textContent='客服最后已发言；如仍需 AI 回答，请在「本轮从哪条顾客消息开始」选择问题。';return;}
        const inputText=mode==='answer_question'?incremental.replyInput({draft:input.value,entries:captureEntries,
          context,progress:progressData?.summary||'',captured,manualDraft,startIndex:currentTurn?.start}):input.value.slice(0,4000);
        const focusText=mode==='answer_question'?(currentTurn?.focus||input.value.trim()).slice(0,1500):'';
        const agentId=agentSelect.value||'';
        const recentIds=recentMediaByAgent.get(agentId)||[];
        const result=await call('generate',{input_text:inputText,focus_text:focusText,content_id:selected?.id||null,agent_id:agentId||null,
          mode,target_language:language,recent_media_ids:recentIds});
        if(ticket!==draftRevision){status.textContent='文字已修改，未覆盖目前草稿。';return;}
        output.value=result.reply;photoEligible=mode==='answer_question';
        const suggestions=Array.isArray(result.media_items)?result.media_items:result.media?[result.media]:[];
        recommendedMedia=photoEligible?suggestions.filter(item=>!recentIds.includes(item.id)).slice(0,5):[];
        if(recommendedMedia.length)recentMediaByAgent.set(agentId,[...recentIds,...recommendedMedia.map(item=>item.id)].slice(-15));
        if(mode==='answer_question'){
          lastReplyByConversation.delete(replyKey);
          lastReplyByConversation.set(replyKey,{reply:result.reply,media:recommendedMedia.map(item=>({...item})),agent:agentSelect.selectedOptions[0]?.textContent||''});
          if(lastReplyByConversation.size>8)lastReplyByConversation.delete(lastReplyByConversation.keys().next().value);
          refreshRestoreButton();
        }
        status.textContent=mode==='answer_question'&&lastVoiceCount?'草稿已生成，已纳入近期语音；尚未发送。':'草稿已生成，尚未发送。';recommend();
        if(mode==='answer_question'){
          const completedEntries=captureEntries.map(entry=>({...entry}));
          lastGenerated=true;try{await markSeen();}catch{status.textContent+=' 去重状态未保存，下次可能需重新抓取。';}
          const customerText=incremental.customerText(captureEntries);
          captureEntries=[];captureTokens=[];capturedDraft='';manualDraft='';renderFocus();
          if(completedEntries.length&&progressData){
            progressNotice.textContent='正在更新对话进度…';
            progressUpdatePending=call('progress-update',{messages:completedEntries.slice(-20).map(entry=>({incoming:!!entry.incoming,kind:entry.kind||'text',text:(entry.source==='flow_choice'?`顾客点击自动流程选项（不是亲口症状陈述）：${entry.text}`:String(entry.text||'')).slice(0,700)})),version:progressData.version})
              .then(value=>{if(value.status==='matched'&&alive){progressData=value.progress;progressNotice.textContent='已记录双方实际消息；AI 草稿不会当作已发送。';renderProgress();}})
              .catch(e=>{if(alive)progressNotice.textContent=progressFailure(e,'保存');});
          }else if(completedEntries.length&&alive)progressNotice.textContent='对话进度未保存：请先重新载入插件，再点「重试读取进度」。';
          if(customerText&&memoryData){memoryNotice.textContent='正在更新顾客情况…';
             memoryExtractPending=call('memory-extract',{customer_text:customerText,version:memoryData.version}).then(value=>{if(value.status==='matched'&&alive){memoryData=value.memory;memoryConflict=value.conflicts;memoryNotice.textContent='已从顾客原话提取，请客服核对。';renderMemory();}})
               .catch(()=>{if(alive)memoryNotice.textContent='顾客情况未能自动更新，回复草稿仍可使用。';});}
        }
      }
      catch(e){fail(e);}finally{busy=false;if(alive)for(const b of generateButtons)b.disabled=false;}
    }
    const generateButton=button('生成回复',()=>generate('answer_question',''),'Sparkles');generateButton.classList.add('ai-primary');generateButtons.push(generateButton);actions.append(generateButton);
    const output=field(assistant,'AI 回复草稿','textarea','ai_output');output.placeholder='等待生成 AI 回复…';
    const polishActions=el('div',null,'ai-controls');
    for(const [label,lang] of [['美化华语','zh'],['美化英文','en']]){const b=button(label,()=>generate('polish_translate',lang),'Languages');generateButtons.push(b);polishActions.append(b);}assistant.append(polishActions);
    async function copy(text,notice=status,target=output){if(!text.trim()){notice.textContent='没有可复制的话术。';return;}try{await call('check');await navigator.clipboard.writeText(text);if(alive)notice.textContent='已复制话术，尚未发送。';}catch(e){if(alive){notice.textContent='未能自动复制，请手动复制话术。';target.focus();target.select();}}}
    const insertButton=button('放进回复框',async()=>{try{await call('check');chat.insert(snapshot.context.platform,output.value);status.textContent='已放入回复框，尚未发送。';}catch(e){fail(e);}},'TextCursorInput');insertButton.classList.add('ai-full','ai-primary');
    const resetButton=button('清空草稿',()=>{abortSpeech();draftRevision++;input.value='';output.value='';captureEntries=[];captureTokens=[];renderFocus();lastGenerated=false;capturedDraft='';manualDraft='';photoEligible=false;recommendedMedia=[];recommend();status.textContent='已清空当前问题与 AI 草稿；可恢复上次生成的回复。';},'RotateCcw');resetButton.classList.add('ai-full');
    const restoreButton=button('恢复上次回复',()=>{
      const saved=lastReplyByConversation.get(replyKey);
      if(!saved)return;
      draftRevision++;output.value=saved.reply;recommendedMedia=saved.media.map(item=>({...item}));photoEligible=true;lastGenerated=true;
      recommend();status.textContent=`已恢复${saved.agent?`「${saved.agent}」的`:''}上次回复和推荐照片；请核对后自行发送。`;
    },'History');restoreButton.classList.add('ai-full');
    function refreshRestoreButton(){restoreButton.disabled=!lastReplyByConversation.has(replyKey);}
    refreshRestoreButton();assistant.append(insertButton,resetButton,restoreButton,status);
    style.textContent+=' .ai-photo-recommend{margin:10px 0 14px;padding-top:10px;border-top:1px solid #dce4ed}.ai-photo-recommend[hidden],.ai-photo-recommend img[hidden],.ai-photo-recommend button[hidden]{display:none!important}.ai-photo-recommend>strong{display:block;margin-bottom:6px;color:#1d394c}.ai-photo-item{padding:10px 0;border-top:1px solid #dce4ed}.ai-photo-item:first-child{border-top:0}.ai-photo-item h4{font-size:13px;margin:0;color:#1d394c}.ai-photo-item p{margin:5px 0;overflow-wrap:anywhere}.ai-photo-recommend img{display:block;width:100%;height:160px;object-fit:contain;background:#fff;border:1px solid #dce5ed;border-radius:5px}.ai-photo-recommend .ai-row{margin-top:8px}.ai-photo-recommend a{display:inline-flex;align-items:center;justify-content:center;min-height:38px;flex:1;border:1px solid #c5d2df;border-radius:5px;text-decoration:none;background:#fff}';
    const assets=el('div',null,'ai-photo-recommend'),assetTitle=el('strong','推荐照片 · 0 张'),assetBox=el('div');assets.hidden=true;assets.append(assetTitle,assetBox);output.parentElement.insertAdjacentElement('afterend',assets);
    function recommend(){
      assetBox.replaceChildren();assets.hidden=true;
      if(!photoEligible||!output.value.trim())return;
      assets.hidden=false;
      assetTitle.textContent=`推荐照片 · ${recommendedMedia.length} 张`;
      if(!recommendedMedia.length){assetBox.append(el('p','本次没有合适的推荐照片。','ai-status'));return;}
      for(const [index,item] of recommendedMedia.entries()){
        const card=el('article',null,'ai-photo-item');
        card.append(el('h4',`${index+1}. ${item.name}`),el('p',item.reason||'请核对照片用途'));
        const preview=el('img'),imageStatus=el('p','正在读取照片…','ai-status'),controls=el('div',null,'ai-row');
        preview.alt=item.name;preview.hidden=true;imageStatus.setAttribute('role','status');card.append(preview,imageStatus,controls);assetBox.append(card);
        const copyImage=button(`复制照片 ${index+1}`,async()=>{if(!preview.complete||!preview.naturalWidth)return;try{await call('check');const canvas=document.createElement('canvas');canvas.width=preview.naturalWidth;canvas.height=preview.naturalHeight;canvas.getContext('2d').drawImage(preview,0,0);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('ai_image_failed');await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);if(alive&&preview.isConnected)imageStatus.textContent='照片已复制，尚未发送。';}catch{if(alive&&preview.isConnected)imageStatus.textContent='无法复制，请打开照片后手动复制。';}},'Copy');copyImage.disabled=true;controls.append(copyImage);
        if(item.image_url){const link=el('a','打开照片');link.href=item.image_url;link.target='_blank';link.rel='noopener noreferrer';controls.append(link);}
        const retry=button(`重试照片 ${index+1}`,()=>void load(true),'RefreshCw');retry.hidden=true;controls.append(retry);
        async function load(refresh=false){try{copyImage.disabled=true;retry.hidden=true;imageStatus.textContent='正在读取照片…';const result=await call('content-image',{path:item.image_path,refresh});if(!alive||!preview.isConnected)return;if(!/^data:image\/(png|jpeg|webp);base64,/.test(result.data_url||''))throw Error('ai_image_failed');preview.src=result.data_url;await preview.decode();if(!alive||!preview.isConnected)return;if(!preview.naturalWidth||preview.naturalWidth*preview.naturalHeight>40000000)throw Error('ai_image_failed');preview.hidden=false;copyImage.disabled=false;imageStatus.textContent='请核对照片后复制，由客服自行发送。';}catch{if(alive&&preview.isConnected){preview.hidden=true;imageStatus.textContent='照片未能载入，请重试。';retry.hidden=false;}}}
        void load();
      }
    }
    input.addEventListener('input',()=>{draftRevision++;if(captureEntries.length&&!captureEntries.some(entry=>input.value.includes(String(entry.text||'').slice(0,20)))){captureEntries=[];captureTokens=[];renderFocus();}capturedDraft='';manualDraft=input.value;lastGenerated=false;output.value='';photoEligible=false;recommendedMedia=[];recommend();});output.addEventListener('input',()=>{draftRevision++;photoEligible=false;recommendedMedia=[];recommend();});
    agentSelect.addEventListener('change',()=>{draftRevision++;photoEligible=false;recommendedMedia=[];recommend();status.textContent='已切换 AI Agent，请重新生成草稿。';});
    const listing=section('配套资料','listing');
    const listingStatus=el('p','','ai-status');listingStatus.setAttribute('role','status');listing.append(listingStatus);
    const market=field(listing,'地区与语言','select','ai_listing_market');market.disabled=true;
    const pack=field(listing,'配套','select','ai_listing_package');
    style.textContent+=' .ai-listing-preview{margin:8px 0 10px;padding:9px;border:1px solid #cbd8d7;border-radius:7px;background:#fff}.ai-listing-preview img{display:block;width:100%;height:160px;object-fit:contain;border:1px solid #dce5ed;border-radius:5px;background:#f8fafc}.ai-listing-preview img[hidden],.ai-listing-retry[hidden],.ai-listing-actions [hidden]{display:none!important}.ai-listing-block{min-width:0;margin-top:9px;border-top:1px solid #e0e7ed;padding-top:8px}.ai-listing-block-header{display:flex;align-items:center;justify-content:space-between;gap:6px;min-height:38px;font-size:12px;font-weight:600;color:#294658}.ai-listing-block-header button{min-height:32px;padding:5px 7px;flex-shrink:0}.ai-listing-preview textarea{display:block;height:110px;min-height:110px;max-height:110px;resize:none;overflow-y:auto;margin-top:4px;border:0;border-radius:0;padding:0;font-size:12px;line-height:1.45;color:#566b73}.ai-listing-preview textarea:focus-visible{outline-offset:1px}.ai-listing-actions{margin-bottom:10px}.ai-listing-actions a{display:flex;align-items:center;justify-content:center;min-height:38px;border:1px solid #cbd8d7;border-radius:5px;text-align:center;text-decoration:none;font-size:13px}.ai-listing-retry{margin:8px 0 0}';
    const listingPreview=el('div',null,'ai-listing-preview'),listingImage=el('img'),listingImageStatus=el('p','','ai-status');
    const listingText=el('textarea');listingText.name='ai_listing_text';listingText.setAttribute('aria-label','价格与配套内容');listingText.readOnly=true;
    const listingExtraText=el('textarea');listingExtraText.name='ai_listing_extra_text';listingExtraText.setAttribute('aria-label','补充话术');listingExtraText.readOnly=true;listingExtraText.placeholder='此配套尚未填写补充话术。';
    const listingRetry=button('重试图片',()=>loadListingImage(true),'RefreshCw');listingRetry.className='ai-listing-retry';listingRetry.hidden=true;
    const listingCopy=button('复制配套话术',()=>copy(listingText.value,listingStatus,listingText),'Copy');
    const listingExtraCopy=button('复制补充话术',()=>copy(listingExtraText.value,listingStatus,listingExtraText),'Copy');
    function listingBlock(label,copyButton,textarea){const block=el('div',null,'ai-listing-block'),header=el('div',null,'ai-listing-block-header');header.append(el('span',label),copyButton);block.append(header,textarea);return block;}
    listingPreview.append(listingImage,listingImageStatus,listingRetry,listingBlock('配套话术',listingCopy,listingText),listingBlock('补充话术',listingExtraCopy,listingExtraText));listing.append(listingPreview);
    const listingActions=el('div',null,'ai-listing-actions'),listingOpen=el('a','打开配套图片');
    const listingImageCopy=button('复制配套图片',async()=>{
      if(!listingImage.complete||!listingImage.naturalWidth){listingStatus.textContent='图片尚未载入，请稍后重试。';return;}
      try{await call('check');const canvas=document.createElement('canvas');canvas.width=listingImage.naturalWidth;canvas.height=listingImage.naturalHeight;canvas.getContext('2d').drawImage(listingImage,0,0);
        const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('ai_image_failed');
        await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);listingStatus.textContent='图片已复制，尚未发送。';
      }catch{listingStatus.textContent='无法复制图片，请打开图片后手动复制。';}
    },'Copy');
    listingOpen.target='_blank';listingOpen.rel='noopener noreferrer';listingActions.append(listingImageCopy,listingOpen);listing.append(listingActions);
    let previewSequence=0;
    async function loadListingImage(refresh=false){const item=pack.value===''?null:listings[Number(pack.value)];if(!item?.image_path)return;const token=++previewSequence;listingImage.hidden=true;listingRetry.hidden=true;listingImageStatus.textContent='正在读取图片…';try{const result=await call('content-image',{path:item.image_path,refresh});if(token!==previewSequence)return;if(!/^data:image\/(png|jpeg|webp);base64,/.test(result.data_url||''))throw Error('ai_image_failed');listingImage.src=result.data_url;await listingImage.decode();if(token!==previewSequence)return;if(!listingImage.naturalWidth||listingImage.naturalWidth*listingImage.naturalHeight>40000000)throw Error('ai_image_failed');listingImage.hidden=false;listingImageStatus.textContent='';}catch(e){if(alive&&token===previewSequence){listingImage.hidden=true;listingImageStatus.textContent='图片未能载入，请重试或打开图片。';listingRetry.hidden=false;}}}
    function showListing(){previewSequence++;const item=pack.value===''?null:listings[Number(pack.value)];listingText.value=item?.text||'';listingText.scrollTop=0;listingCopy.disabled=!listingText.value.trim();listingExtraText.value=item?.extra_text||'';listingExtraText.scrollTop=0;listingExtraCopy.disabled=!listingExtraText.value.trim();listingImage.hidden=true;listingImage.removeAttribute('src');listingImage.alt=item?.title||'';listingImageStatus.textContent='';listingRetry.hidden=true;listingImageCopy.hidden=!item?.image_path;listingOpen.hidden=!item?.image_url;if(item?.image_url){listingOpen.href=item.image_url;void loadListingImage();}else listingOpen.removeAttribute('href');}
    let allContent=[],allOptions=[];
    function showCombinations(){
      const previous=market.value,labels=new Map(allOptions.map(option=>[`${option.kind}:${option.code}`,option.label]));
      const fallback=new Map([['market:MY','西马'],['market:EM','东马'],['market:SG','新加坡'],['language:zh','中文'],['language:en','English'],['language:ms','Bahasa Melayu']]);
      const keys=[...new Set(allContent.map(item=>`${item.market}:${item.language}`))];
      const order=new Map(allOptions.map(option=>[`${option.kind}:${option.code}`,Number(option.sort_order)||100]));
      keys.sort((a,b)=>{const [am,al]=a.split(':'),[bm,bl]=b.split(':');return (order.get(`market:${am}`)||100)-(order.get(`market:${bm}`)||100)||(order.get(`language:${al}`)||100)-(order.get(`language:${bl}`)||100)||a.localeCompare(b);});
      market.replaceChildren();for(const key of keys){const [region,language]=key.split(':');const label=`${labels.get(`market:${region}`)||fallback.get(`market:${region}`)||region} · ${labels.get(`language:${language}`)||fallback.get(`language:${language}`)||language}`;const op=el('option',label);op.value=key;market.append(op);}
      market.disabled=!keys.length;market.value=keys.includes(previous)?previous:keys[0]||'';
    }
    function filterListings(){const [region,language]=market.value.split(':');listings=allContent.filter(item=>item.market===region&&item.language===language).map(item=>({...item,title:item.package_name,text:item.copy_primary,extra_text:item.copy_secondary})).sort((a,b)=>a.title.localeCompare(b.title));pack.replaceChildren();const choose=el('option','选择配套以查看或引用');choose.value='';pack.append(choose);for(const [i,item] of listings.entries()){const op=el('option',item.title);op.value=i;pack.append(op);}pack.disabled=!listings.length;showListing();listingStatus.textContent=listings.length?`Supabase 配套资料 · ${listings.length} 项`:'暂无已启用的配套资料。';}
    async function loadListings(refresh=false){const token=++listingSequence;pack.replaceChildren();pack.disabled=true;listings=[];showListing();listingStatus.textContent='正在读取配套资料…';try{const result=await call('content',{refresh});if(token!==listingSequence)return;allContent=result.items||[];allOptions=result.options||[];showCombinations();filterListings();recommend();}catch(e){if(alive&&token===listingSequence)listingStatus.textContent='配套读取失败，请重新读取。';}}
    market.addEventListener('change',filterListings);pack.addEventListener('change',showListing);listing.append(button('重新读取配套',()=>loadListings(true),'RefreshCw'));
    async function load(){const token=++loadSequence;try{const result=await call('agents');if(token!==loadSequence)return;const previous=agentSelect.value;agentSelect.replaceChildren();for(const item of result.agents||[]){const option=el('option',item.name);option.value=item.id;agentSelect.append(option);}const agents=result.agents||[];agentSelect.value=agents.some(item=>item.id===previous)?previous:agents.find(item=>item.is_default)?.id||agents[0]?.id||'';agentSelect.disabled=!agents.length;status.textContent=agents.length?'请核对顾客问题；生成结果只是草稿。':'暂无启用的 AI Agent，请联系管理员。';}catch(e){if(token===loadSequence)fail(e);}}
    assistant.append(button('重新连接',()=>{void load();void loadListings(true);memoryReady=loadMemory();progressReady=loadProgress();},'RefreshCw'));container.append(root);void load();void loadListings();memoryReady=loadMemory();progressReady=loadProgress();
    return {dispose(){alive=false;abortSpeech();listingSequence++;root.remove();}};
  }
  globalThis.DwellAI=Object.freeze({mount,preload,resetCatalog});
})();
