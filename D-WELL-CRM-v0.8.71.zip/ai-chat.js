(() => {
  const visible=n=>n?.getBoundingClientRect().width>0&&n.getBoundingClientRect().height>0;
  function whatsappDirection(node){
    const marked=node.closest('.message-in,.message-out');
    if(marked)return marked.classList.contains('message-in');
    const row=node.closest('[role="row"]');
    const onlyMessageInRow=row?.querySelectorAll('[data-testid="msg-container"]').length===1;
    const incoming=!!(node.querySelector('[data-testid="tail-in"]')||(onlyMessageInRow&&row.querySelector('[data-testid="tail-in"]')));
    const outgoing=!!(node.querySelector('[data-testid="tail-out"]')||(onlyMessageInRow&&row.querySelector('[data-testid="tail-out"]')));
    if(incoming&&outgoing)return null;
    if(incoming!==outgoing)return incoming;
    const bubble=node.matches('[data-testid="msg-container"]')?node:node.querySelector('[data-testid="msg-container"]');
    const rect=bubble?.getBoundingClientRect(),bounds=(row||document.querySelector('#main'))?.getBoundingClientRect();
    if(!rect||!bounds||rect.width<=0||rect.width>=bounds.width*.95)return null;
    const left=rect.left-bounds.left,right=bounds.right-rect.right;
    if(Math.abs(left-right)<bounds.width*.08)return null;
    return left<right;
  }
  function whatsappMessages(){
    const old=[...document.querySelectorAll('#main .message-in,#main .message-out')].filter(visible);
    const found=[...document.querySelectorAll('#main [role="row"] [data-testid="msg-container"]')]
      .filter(node=>visible(node)&&!node.closest('.message-in,.message-out')).map(node=>{
      return {node,incoming:whatsappDirection(node)};
    });
    return [...old.map(node=>({node,incoming:node.classList.contains('message-in')})),...found]
      .sort((a,b)=>a.node.compareDocumentPosition(b.node)&Node.DOCUMENT_POSITION_FOLLOWING?-1:1);
  }
  function whatsappText(node){
    return [...node.querySelectorAll('.selectable-text')]
      .filter(part=>!part.querySelector('.selectable-text')&&!part.closest('[data-testid="quoted-message"]'))
      .map(part=>part.innerText||part.textContent).join(' ').trim();
  }
  function hasSentPhoto(node){
    return [...node.querySelectorAll('img')].some(image=>{
      if(image.closest('[data-testid="quoted-message"]'))return false;
      const box=image.getBoundingClientRect();
      return box.width>=80&&box.height>=80;
    });
  }
  function flowOption(value){return String(value||'').replace(/\s+/g,' ').trim();}
  function messengerFlowOptions(message,region){
    if(message.querySelector('[dir="auto"]'))return [];
    const rect=message.getBoundingClientRect(),bounds=region.getBoundingClientRect();
    if(!rect.width||rect.left-bounds.left<=bounds.right-rect.right)return [];
    const labels=[...message.querySelectorAll('span')]
      .filter(node=>!node.children.length)
      .map(node=>flowOption(node.innerText||node.textContent))
      .filter(value=>value.length>0&&value.length<=120);
    return labels.length>=2?labels:[];
  }
  function composer(platform){
    const selector=platform==='whatsapp'?'#main footer [contenteditable="true"][role="textbox"]':'[contenteditable="true"][aria-placeholder="Reply in Messenger…"], [contenteditable="true"][aria-placeholder="Reply in Messenger..."], [contenteditable="true"][aria-label="Reply in Messenger..."], [contenteditable="true"][aria-label="Reply in Messenger"], textarea[placeholder="Reply in Messenger"], [contenteditable="true"][aria-label="在 Messenger 中回复…"], [contenteditable="true"][aria-label="回复 Messenger…"]';
    const found=[...document.querySelectorAll(selector)].filter(visible);
    if(found.length!==1)throw Error('ai_composer_missing');return found[0];
  }
  function latest(platform){
    if(platform==='messenger')return latestMessenger();
    const recent=whatsappMessages().slice(-30).filter(message=>whatsappText(message.node));
    if(recent.some(message=>message.incoming===null))throw Error('ai_direction_uncertain');
    const last=recent.filter(message=>message.incoming).at(-1);
    const value=last?whatsappText(last.node):'';
    if(!value||value.length>4000)throw Error('ai_message_missing');return value;
  }
  function latestMessenger(){
    const regions=[...document.querySelectorAll('[role="region"]')].filter(n=>visible(n)&&n.querySelector('[data-message-id]'));
    if(regions.length!==1)throw Error('ai_message_missing');
    const region=regions[0],names=new Set();
    for(const a of document.querySelectorAll('a')){
      if(!['View profile','查看个人主页','查看個人檔案','查看主页'].includes(a.textContent.trim()))continue;
      for(let p=a.parentElement,depth=0;p&&depth<4;p=p.parentElement,depth++){
        const h=p.querySelector('h3,[role="heading"]');if(h){names.add(h.textContent.trim());break;}
      }
    }
    if(names.size>1)throw Error('ai_message_missing');
    const name=[...names][0];
    const messages=[...region.querySelectorAll('[data-message-id]')].filter(visible);
    const sender=message=>{
      for(let row=message.parentElement,depth=0;row&&row!==region&&depth<7;row=row.parentElement,depth++){
        const content=[...row.children].find(child=>child.contains(message));
        if(!content)continue;
        const avatars=[...row.children].filter(child=>child!==content&&!child.querySelector('[data-message-id]'))
          .flatMap(child=>[...child.querySelectorAll('img[alt], [role="img"][aria-label]')]);
        const labels=avatars.filter(avatar=>{const rect=avatar.getBoundingClientRect();return rect.width>0&&rect.width<=64&&rect.height>0&&rect.height<=64;})
          .map(avatar=>(avatar.getAttribute('alt')||avatar.getAttribute('aria-label')||'').trim()).filter(Boolean);
        if(name&&labels.includes(name))return name;
        if(!name&&labels.length)return labels.length===1?labels[0]:'';
      }
      return '';
    };
    const senders=messages.map(sender).filter(Boolean);
    if(new Set(senders).size>1)throw Error('ai_message_missing');
    const identified=senders[0];
    const incoming=messages.filter(message=>{
      const avatarName=sender(message);
      if(avatarName)return avatarName===(name||identified);
      // Older Messenger layouts have no avatar beside every bubble. Use the old
      // plugin's left-side signal, but only inside the unique active message list.
      if(!name&&!identified)return false;
      const rect=message.querySelector('[dir="auto"]')?.getBoundingClientRect()||message.getBoundingClientRect();
      const bounds=region.getBoundingClientRect();
      return rect.width>0&&rect.width<bounds.width*.8&&rect.left<bounds.left+bounds.width*.55;
    });
    const last=incoming.at(-1);
    const parts=last?[...last.querySelectorAll('[dir="auto"]')].filter(n=>!n.querySelector('[dir="auto"]')&&!n.closest('button,[role="button"]')):[];
    const value=parts.map(n=>n.innerText||n.textContent).join('\n').trim();
    if(!value||value.length>4000)throw Error('ai_message_missing');return value;
  }
  function recentEntries(platform){
    if(platform==='whatsapp'){
      const timeline=whatsappMessages();
      const entries=timeline.slice(-30).flatMap(({node,incoming})=>{
        const order=timeline.findIndex(message=>message.node===node);
        const value=whatsappText(node);
        const photo=hasSentPhoto(node);
        if(!value&&!photo)return [];
        if(incoming===null)throw Error('ai_direction_uncertain');
        const id=node.getAttribute?.('data-id')||node.querySelector?.('[data-id]')?.getAttribute?.('data-id')||
          `${node.querySelector?.('[data-pre-plain-text]')?.getAttribute?.('data-pre-plain-text')||''}|${value}`;
        return [value?{id:`wa:${id}`,text:value,incoming,kind:'text',order}:null,
          !incoming&&photo?{id:`wa:${id}:photo`,text:'已发送照片（内容未识别）',incoming:false,kind:'photo',order}:null].filter(Boolean);
      });
      if(!entries.length)throw Error('ai_message_missing');
      return entries;
    }
    const regions=[...document.querySelectorAll('[role="region"]')].filter(node=>visible(node)&&node.querySelector('[data-message-id]'));
    if(regions.length!==1)throw Error('ai_message_missing');
    const region=regions[0],timeline=[...region.querySelectorAll('[data-message-id]')].filter(visible),messages=timeline.slice(-30);
    const flowChoices=new Map();
    timeline.slice(-100).forEach(message=>{
      const order=timeline.indexOf(message);
      for(const label of messengerFlowOptions(message,region))if(!flowChoices.has(label))flowChoices.set(label,order);
    });
    const names=new Set();
    for(const link of document.querySelectorAll('a')){
      if(!['View profile','查看个人主页','查看個人檔案','查看主页'].includes(link.textContent.trim()))continue;
      for(let parent=link.parentElement,depth=0;parent&&depth<4;parent=parent.parentElement,depth++){
        const heading=parent.querySelector('h3,[role="heading"]');if(heading){names.add(heading.textContent.trim());break;}
      }
    }
    if(names.size!==1)throw Error('ai_message_missing');
    const name=[...names][0];
    const entries=messages.flatMap(message=>{
      const order=timeline.indexOf(message);
      const parts=[...message.querySelectorAll('[dir="auto"]')].filter(node=>!node.querySelector('[dir="auto"]')&&!node.closest('button,[role="button"]'));
      const value=parts.map(node=>node.innerText||node.textContent).join(' ').trim();if(!value&&!hasSentPhoto(message))return [];
      let incoming=false,identified=false;
      for(let row=message.parentElement,depth=0;row&&row!==region&&depth<7;row=row.parentElement,depth++){
        const content=[...row.children].find(child=>child.contains(message));if(!content)continue;
        const labels=[...row.children].filter(child=>child!==content&&!child.querySelector('[data-message-id]'))
          .flatMap(child=>[...child.querySelectorAll('img[alt],[role="img"][aria-label]')])
          .filter(avatar=>{const rect=avatar.getBoundingClientRect();return rect.width>0&&rect.width<=64&&rect.height>0&&rect.height<=64;})
          .map(avatar=>(avatar.getAttribute('alt')||avatar.getAttribute('aria-label')||'').trim()).filter(Boolean);
        if(labels.length){identified=true;incoming=labels.includes(name);break;}
      }
      if(!identified){const rect=parts[0]?.getBoundingClientRect()||message.getBoundingClientRect(),bounds=region.getBoundingClientRect();
        if(!(rect.width>0&&rect.width<bounds.width*.8))throw Error('ai_direction_uncertain');
        incoming=rect.left<bounds.left+bounds.width*.55;
      }
      const id=`ms:${message.getAttribute?.('data-message-id')||value}`;
      const option=flowOption(value);
      const flowOrder=flowChoices.get(option);
      const source=incoming&&option.length<=120&&flowOrder!==undefined&&flowOrder<order&&order-flowOrder<=8?'flow_choice':'message';
      return [value?{id,text:value,incoming,kind:'text',source,order}:null,
        !incoming&&hasSentPhoto(message)?{id:`${id}:photo`,text:'已发送照片（内容未识别）',incoming:false,kind:'photo',order}:null].filter(Boolean);
    });
    if(!entries.length)throw Error('ai_message_missing');
    return entries;
  }
  function recent(platform){return recentEntries(platform).map(entry=>`${entry.incoming?'顾客':'客服'}：${entry.text}`).join('\n').slice(-3000);}
  function insert(platform,text){
    if(!text.trim())throw Error('ai_empty_reply');const box=composer(platform);
    if((box.value??box.innerText??box.textContent).trim())throw Error('ai_composer_not_empty');
    box.focus();
    if(box.tagName==='TEXTAREA'){const setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;setter.call(box,text);box.dispatchEvent(new Event('input',{bubbles:true}));}
    else{const range=document.createRange();range.selectNodeContents(box);range.collapse(false);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);if(!document.execCommand('insertText',false,text))throw Error('ai_insert_failed');}
    // Never dispatch Enter, click Send, or replace an existing draft.
  }
  globalThis.DwellAIChat=Object.freeze({latest,recent,recentEntries,insert,composer,whatsappDirection});
})();
