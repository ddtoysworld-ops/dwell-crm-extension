import {mediaPath} from './flow-service.mjs';
export function createFlowJobs({chrome,operations,context,authorize,origin}){
 const jobs=new Map();
 const owner=s=>s.tab?.id!=null?'tab:'+s.tab.id:'panel';
 async function current(job){await authorize();const found=await context(job.sender,job.windowId);if(found.tabId!==job.tabId||found.snapshot?.documentId!==job.snapshot.documentId||found.snapshot?.revision!==job.snapshot.revision||found.snapshot?.context?.key!==job.snapshot.context.key)throw Error('对话已切换，已停止后续发送');if(job.cancelled)throw Error('已停止后续发送');}
 async function invoke(action,payload,sender){
  await authorize();
  for(const [key,j]of jobs)if(j.expires<Date.now()){j.cancelled=true;jobs.delete(key);}
  if(action==='chat'){const found=await context(sender,payload.windowId,payload.recheck===true);if(!found.snapshot||!['ready','phone_missing'].includes(found.snapshot.context?.status))return {hasChat:false};return chrome.tabs.sendMessage(found.tabId,{type:'dwell-flow-chat'},{frameId:0});}
  if(action==='prepare'){
   const found=await context(sender,payload.windowId,true),s=found.snapshot;
   if(!s||!['ready','phone_missing'].includes(s.context?.status)||!s.context.key)throw Error('请先打开一个可确认的顾客对话');
   const chat=await chrome.tabs.sendMessage(found.tabId,{type:'dwell-flow-chat'},{frameId:0});if(!chat?.hasChat)throw Error('请先打开一个顾客对话');
   const flows=await operations.invoke('list');const flow=flows.find(f=>f.id===payload.id&&f.status==='published');if(!flow?.steps.length)throw Error('Flow 未发布、已删除或没有内容');
   const ticket=crypto.randomUUID(),job={ticket,owner:owner(sender),sender,windowId:payload.windowId,tabId:found.tabId,snapshot:s,flow,cancelled:false,started:false,done:false,message:'等待确认',expires:Date.now()+3600000};
   await current(job);jobs.set(ticket,job);
   const recent=(await chrome.storage.session.get('dwell-flow-recent'))['dwell-flow-recent']||[];
   return {ticket,chatName:chat.chatName,name:flow.name,steps:flow.steps,duplicate:recent.some(x=>x.key===s.context.key&&x.flow===flow.id&&Date.now()-x.at<600000)};
  }
  const job=jobs.get(payload.ticket);if(!job)throw Error('发送会话已过期，请先核对聊天记录再重试');
  if(action==='check'){
   if(sender.tab?.id!==job.tabId||sender.frameId!==0)throw Error('发送权限无效');await current(job);return {};
  }
  if(owner(sender)!==job.owner)throw Error('发送权限无效');
  if(action==='stop'){job.cancelled=true;void chrome.tabs.sendMessage(job.tabId,{type:'dwell-flow-stop',ticket:job.ticket},{frameId:0}).catch(()=>{});return {};}
  if(action==='status')return {done:job.done,message:job.message,complete:job.complete===true};
  if(action!=='start')throw Error('未知发送操作');
  if(job.started)throw Error('此 Flow 已开始发送，请勿重复点击');await current(job);
  if([...jobs.values()].some(j=>j!==job&&j.tabId===job.tabId&&j.started&&!j.done))throw Error('这个对话正在发送其他 Flow');
  await operations.invoke('refresh');const fresh=(await operations.invoke('list')).find(f=>f.id===job.flow.id);if(!fresh||JSON.stringify(fresh)!==JSON.stringify(job.flow))throw Error('Flow 已更新，请重新确认后发送');
  await current(job);job.started=true;job.message='正在发送…';
  const recent=(await chrome.storage.session.get('dwell-flow-recent'))['dwell-flow-recent']||[];
  await chrome.storage.session.set({'dwell-flow-recent':[...recent.filter(x=>Date.now()-x.at<600000).slice(-99),{key:job.snapshot.context.key,flow:job.flow.id,at:Date.now()}]});
  const steps=job.flow.steps.map(s=>({...s,...(s.media_path?{url:origin+'/storage/v1/object/public/flow-media/'+mediaPath(s.media_path)}:{})}));
  void chrome.tabs.sendMessage(job.tabId,{type:'dwell-flow-execute',ticket:job.ticket,expected:job.snapshot,steps},{frameId:0}).then(result=>{job.done=true;job.complete=result?.ok===true;job.message=result?.ok?'“'+job.flow.name+'”已完成发送步骤，请核对聊天记录':result?.error||'发送中断，结果待核对，未自动重试';},()=>{job.done=true;job.message='页面连接中断，发送结果待核对，未自动重试';});
  return {started:true};
 }
 function progress(message,sender){const job=jobs.get(message.ticket);if(job?.tabId===sender.tab?.id&&sender.frameId===0)job.message=String(message.message).slice(0,300);}
 return {invoke,progress,clear(){for(const job of jobs.values()){job.cancelled=true;void chrome.tabs.sendMessage(job.tabId,{type:'dwell-flow-stop',ticket:job.ticket},{frameId:0}).catch(()=>{});}jobs.clear();}};
}
