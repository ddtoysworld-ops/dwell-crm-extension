// Generated from the existing Flow Lite UI. Edit the port recipe or adapter, not the staff extension.
(()=>{globalThis.DwellFlowLegacy={mount({container,api}){let disposed=false;const host=document.createElement('div');container.append(host);const root=host.attachShadow({mode:'closed'});const sheet=new CSSStyleSheet();sheet.replaceSync(":host {\n  color-scheme: light;\n  --green: #087a5a;\n  --green-dark: #056044;\n  --paper: #ffffff;\n  --ink: #18211e;\n  --muted: #66736e;\n  --line: #dce4e0;\n  --soft: #f2f7f5;\n  --danger: #b42318;\n}\n\n* { box-sizing: border-box; }\n:host {\n  margin: 0;\n  background: #f6f8f7;\n  color: var(--ink);\n  font: 14px/1.45 Inter, system-ui, -apple-system, \"Segoe UI\", sans-serif;\n}\nbutton, input, textarea, select { font: inherit; }\nbutton { cursor: pointer; }\n.hidden { display: none !important; }\n\n.app-header {\n  display: flex;\n  align-items: center;\n  justify-content: space-between;\n  padding: 16px;\n  color: white;\n  background: linear-gradient(135deg, #075e54, #0a8f69);\n}\n.app-header h1 { margin: 0; font-size: 20px; }\n.app-header p { margin: 3px 0 0; font-size: 12px; opacity: .82; }\nmain { padding: 14px; }\n.panel, .chat-card, .flow-card, .admin-flow-item {\n  border: 1px solid var(--line);\n  border-radius: 12px;\n  background: var(--paper);\n  box-shadow: 0 2px 8px rgb(24 33 30 / 5%);\n}\n.panel { padding: 15px; }\nh2 { margin: 0 0 12px; font-size: 17px; }\n.muted { color: var(--muted); }\nlabel { display: block; margin: 12px 0; color: var(--muted); font-weight: 600; }\ninput, textarea, select {\n  width: 100%;\n  margin-top: 6px;\n  padding: 10px 11px;\n  border: 1px solid var(--line);\n  border-radius: 9px;\n  color: var(--ink);\n  background: white;\n  outline: none;\n}\ntextarea { resize: vertical; }\ninput:focus, textarea:focus, select:focus { border-color: var(--green); box-shadow: 0 0 0 3px rgb(8 122 90 / 12%); }\nbutton { border: 0; border-radius: 9px; padding: 9px 12px; }\n.primary { width: 100%; color: white; background: var(--green); font-weight: 700; }\n.primary:hover { background: var(--green-dark); }\n.ghost { border: 1px solid var(--line); background: white; color: var(--ink); }\n.app-header .ghost { color: white; background: rgb(255 255 255 / 10%); border-color: rgb(255 255 255 / 35%); }\n.danger { width: 100%; margin-top: 9px; color: white; background: var(--danger); }\n.link-button { width: 100%; margin-top: 8px; background: transparent; color: var(--green); }\n.tabs { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; margin-bottom: 12px; }\n.tab { background: #e8efec; color: var(--muted); }\n.tab.active { color: white; background: var(--green); }\n.chat-card { display: grid; grid-template-columns: 1fr auto; gap: 3px 8px; padding: 12px; }\n.chat-card span { color: var(--muted); font-size: 12px; }\n.chat-card strong { grid-column: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.chat-card button { grid-column: 2; grid-row: 1 / span 2; }\n.search { margin: 12px 0; }\n.flow-list, .admin-flow-list, .step-editor { display: grid; gap: 10px; }\n.flow-folder { overflow: hidden; border: 1px solid var(--line); border-radius: 12px; background: #edf5f1; }\n.flow-folder > summary { display: grid; grid-template-columns: auto 1fr auto; gap: 8px; align-items: center; padding: 12px 13px; color: var(--green-dark); cursor: pointer; list-style: none; }\n.flow-folder > summary::-webkit-details-marker { display: none; }\n.flow-folder > summary small { color: var(--muted); font-weight: 500; }\n.folder-icon { transition: transform .16s ease; }\n.flow-folder[open] .folder-icon { transform: rotate(90deg); }\n.flow-folder-content { display: grid; gap: 9px; padding: 0 9px 9px; }\n.flow-card { padding: 13px; }\n.flow-card h3 { margin: 0; font-size: 16px; }\n.flow-card p { margin: 5px 0 10px; color: var(--muted); font-size: 12px; }\n.flow-card .primary { padding-block: 10px; }\n.progress { margin-top: 12px; padding: 11px; border-radius: 9px; color: #075e54; background: #def6ed; }\n.admin-toolbar { display: grid; grid-template-columns: 1fr auto auto; gap: 8px; margin-bottom: 11px; }\n.admin-flow-item { display: flex; align-items: center; justify-content: space-between; padding: 11px; }\n.admin-flow-item small { color: var(--muted); }\n.form-title-row { display: flex; align-items: center; justify-content: space-between; }\n.form-title-row h2 { margin: 0; }\n.field-hint { display: block; margin-top: 5px; color: var(--muted); font-weight: 400; }\n.step-actions { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; margin: 14px 0; }\n.step-card { border: 1px solid var(--line); border-radius: 10px; padding: 11px; background: var(--soft); }\n.step-head { display: flex; align-items: center; justify-content: space-between; gap: 6px; }\n.step-head strong { font-size: 13px; }\n.step-buttons { display: flex; gap: 4px; }\n.step-buttons button { padding: 4px 7px; background: white; border: 1px solid var(--line); }\n.image-preview { width: 100%; max-height: 150px; margin-top: 8px; object-fit: contain; border-radius: 8px; background: #e6ece9; }\n.video-preview { display: block; width: 100%; max-height: 220px; margin-top: 8px; object-fit: contain; border-radius: 8px; background: #111; }\n.audio-preview { display: block; width: 100%; margin-top: 8px; }\n.media-source-actions { display: grid; grid-template-columns: 1fr 1fr; gap: 7px; margin-top: 10px; }\n.file-button { margin: 0; padding: 9px 10px; border: 1px solid var(--line); border-radius: 9px; color: var(--ink); background: white; text-align: center; cursor: pointer; }\n.file-button input { display: none; }\n.selected-media-name { margin: 7px 0 0; color: var(--muted); font-size: 12px; overflow-wrap: anywhere; }\n.compact { margin: 2px 0 0; font-size: 12px; }\n.modal { position: fixed; inset: 0; z-index: 20; display: flex; align-items: flex-end; padding: 10px; background: rgb(0 0 0 / 42%); }\n.modal-card { width: 100%; max-height: 88vh; padding: 14px; overflow: auto; border-radius: 14px; background: white; box-shadow: 0 12px 40px rgb(0 0 0 / 28%); }\n.media-library-list { display: grid; gap: 8px; }\n.media-bulk-actions { display: grid; grid-template-columns: auto 1fr auto; gap: 8px; align-items: center; margin: 0 0 10px; }\n.media-bulk-actions span { color: var(--muted); font-size: 12px; text-align: center; }\n.danger-inline { color: white; background: var(--danger); }\n.danger-inline:disabled { cursor: not-allowed; opacity: .45; }\n.media-library-item { display: grid; grid-template-columns: 58px minmax(0, 1fr) auto; gap: 10px; align-items: center; width: 100%; padding: 8px; border: 1px solid var(--line); border-radius: 9px; background: white; text-align: left; }\n.media-library-item:hover { border-color: var(--green); background: var(--soft); }\n.media-thumb { display: grid; place-items: center; width: 58px; height: 58px; overflow: hidden; border-radius: 7px; background: #e6ece9; }\n.media-thumb img, .media-thumb video { width: 100%; height: 100%; object-fit: cover; }\n.preview-loading, .preview-failed { padding: 4px; color: var(--muted); font-size: 11px; text-align: center; }\n.audio-icon { color: var(--green); font-size: 28px; font-weight: 700; }\n.media-meta { min-width: 0; }\n.media-meta strong, .media-meta small { display: block; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }\n.media-meta small { margin-top: 3px; color: var(--muted); }\n.media-item-action { min-width: 64px; }\n.media-select-button { width: auto; }\n.media-checkbox { display: flex; align-items: center; gap: 6px; margin: 0; padding: 8px; border: 1px solid var(--line); border-radius: 8px; color: var(--ink); background: white; cursor: pointer; }\n.media-checkbox input { width: 18px; height: 18px; margin: 0; accent-color: var(--green); }\n.media-checkbox.disabled { cursor: not-allowed; color: var(--muted); background: #e8efec; }\nhr { border: 0; border-top: 1px solid var(--line); margin: 22px 0; }\n.toast { position: fixed; right: 12px; bottom: 12px; left: 12px; padding: 11px; border-radius: 9px; color: white; background: #26342f; box-shadow: 0 5px 20px rgb(0 0 0 / 25%); }\n.toast.error { background: var(--danger); }\n\n:host{display:block;letter-spacing:0;min-width:0}button{min-height:38px}button,input,textarea,select{letter-spacing:0} .app-header{background:#087a5a}.app-header h1{font-size:19px}.tabs{position:sticky;top:0;z-index:2;background:#f6f8f7;padding:2px 0}.modal{position:fixed;z-index:2147483646}.modal-card{max-width:min(580px,calc(100vw - 24px));max-height:90dvh}.flow-folder-content{min-width:0}.flow-card h3,.admin-flow-item strong,.media-meta strong{overflow-wrap:anywhere}.admin-toolbar{flex-wrap:wrap}.admin-toolbar .primary{flex:1;min-width:110px}.step-toolbar{flex-wrap:wrap}\n\n.admin-flow-item>span{min-width:0;flex:1}.admin-flow-item>small{flex-shrink:0;white-space:nowrap}.toast{box-sizing:border-box;max-width:100vw}.step-buttons button{min-width:32px}.step-buttons{flex-shrink:0}\n");root.adoptedStyleSheets=[sheet];root.innerHTML="\n    <header class=\"app-header\">\n      <div>\n        <h1>Flow Lite</h1>\n        <p id=\"accountLine\">正在连接…</p>\n      </div>\n      <button id=\"logoutButton\" class=\"ghost hidden\">退出</button>\n    </header>\n\n    <main>\n      <section id=\"loginView\" class=\"panel hidden\"><p>请先在新版插件的安全侧栏登录。</p><button id=\"retryLoginButton\" class=\"primary\">重新连接</button></section><section id=\"appView\" class=\"hidden\">\n        <nav class=\"tabs\">\n          <button id=\"sendTab\" class=\"tab active\">发送 Flow</button>\n          <button id=\"adminTab\" class=\"tab hidden\">管理 Flow</button>\n        </nav>\n\n        <div id=\"sendView\">\n          <div class=\"chat-card\">\n            <span>当前对话</span>\n            <strong id=\"chatName\">检查中…</strong>\n            <button id=\"refreshButton\" class=\"ghost\">刷新</button>\n          </div>\n          <input id=\"searchInput\" class=\"search\" placeholder=\"搜索 Flow\">\n          <div id=\"flowList\" class=\"flow-list\"></div>\n          <div id=\"sendProgress\" class=\"progress hidden\"></div>\n          <button id=\"stopButton\" class=\"danger hidden\">停止后续发送</button>\n        </div>\n\n        <div id=\"adminView\" class=\"hidden\">\n          <div class=\"admin-toolbar\">\n            <button id=\"newFlowButton\" class=\"primary\">＋ 新 Flow</button>\n            <button id=\"manageMediaButton\" class=\"ghost\">媒体库</button>\n            <button id=\"reloadAdminButton\" class=\"ghost\">刷新</button>\n          </div>\n          <div id=\"adminFlowList\" class=\"admin-flow-list\"></div>\n          <form id=\"flowForm\" class=\"panel hidden\">\n            <div class=\"form-title-row\">\n              <h2 id=\"editorTitle\">新 Flow</h2>\n              <button id=\"closeEditorButton\" type=\"button\" class=\"ghost\">关闭</button>\n            </div>\n            <label>Flow 名称<input id=\"flowNameInput\" required maxlength=\"80\"></label>\n            <label>文件夹／分类\n              <input id=\"flowFolderInput\" list=\"flowFolderOptions\" maxlength=\"60\" placeholder=\"例如：新进来、价钱、产品资料\">\n              <datalist id=\"flowFolderOptions\"></datalist>\n              <small class=\"field-hint\">可选择已有文件夹，也可以直接输入新名称。</small>\n            </label>\n            <label>状态\n              <select id=\"flowStatusInput\">\n                <option value=\"draft\">草稿（员工看不到）</option>\n                <option value=\"published\">已发布</option>\n              </select>\n            </label>\n            <div class=\"step-actions\">\n              <button id=\"addTextButton\" type=\"button\" class=\"ghost\">＋文字</button>\n              <button id=\"addImageButton\" type=\"button\" class=\"ghost\">＋照片</button>\n              <button id=\"addVideoButton\" type=\"button\" class=\"ghost\">＋视频</button>\n              <button id=\"addAudioButton\" type=\"button\" class=\"ghost\">＋语音</button>\n              <button id=\"addWaitButton\" type=\"button\" class=\"ghost\">＋等待</button>\n            </div>\n            <div id=\"stepEditor\" class=\"step-editor\"></div>\n            <button id=\"saveFlowButton\" type=\"submit\" class=\"primary\">保存 Flow</button>\n            <button id=\"deleteFlowButton\" type=\"button\" class=\"danger hidden\">删除 Flow</button>\n          </form>\n        </div>\n      </section>\n    </main>\n\n    <div id=\"mediaLibrary\" class=\"modal hidden\" role=\"dialog\" aria-modal=\"true\" aria-labelledby=\"mediaLibraryTitle\">\n      <div class=\"modal-card\">\n        <div class=\"form-title-row\">\n          <div>\n            <h2 id=\"mediaLibraryTitle\">选择已有文件</h2>\n            <p id=\"mediaLibraryHint\" class=\"muted compact\">从 Supabase 媒体库直接复用，不会再次上传。</p>\n          </div>\n          <button id=\"closeMediaLibraryButton\" type=\"button\" class=\"ghost\">关闭</button>\n        </div>\n        <input id=\"mediaSearchInput\" class=\"search\" placeholder=\"搜索文件名\">\n        <div id=\"mediaBulkActions\" class=\"media-bulk-actions hidden\">\n          <button id=\"selectUnusedMediaButton\" type=\"button\" class=\"ghost\">全选未使用</button>\n          <span id=\"selectedMediaCount\">已选 0 个</span>\n          <button id=\"deleteSelectedMediaButton\" type=\"button\" class=\"danger-inline\" disabled>删除已选</button>\n        </div>\n        <div id=\"mediaLibraryList\" class=\"media-library-list\"></div>\n      </div>\n    </div>\n\n    <div id=\"toast\" class=\"toast hidden\"></div>\n    ";
function placeOverlay(node,toast=false){const r=host.getBoundingClientRect(),top=Math.max(0,r.y);Object.assign(node.style,{left:Math.max(0,r.x)+'px',right:'auto',width:Math.min(r.width,innerWidth)+'px',...(toast?{bottom:'12px'}:{top:top+'px',bottom:'0'})});const card=node.querySelector('.modal-card');if(card)card.style.maxHeight='calc(100dvh - '+(top+20)+'px)';}
const state = {
  profile: null,
  flows: [],
  adminFlows: [],
  editing: null,
  cancelled: false,
  sending: false,
  saving: false,
  demoMode: false,
  mediaAssets: [],
  mediaPicker: null,
  selectedMediaPaths: new Set(),
  mediaPreviewUrls: new Map(),
  mediaPreviewPromises: new Map()
};

const $ = (id) => root.getElementById(id);
const escapeHtml = (value) => String(value ?? "").replace(/[&<>'"]/g, (char) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
}[char]));

function showOnly(id) {
  for (const view of ["loginView", "appView"]) $(view).classList.toggle("hidden", view !== id);
}

function toast(message, isError = false) {
  const node = $("toast"); placeOverlay(node,true);
  node.textContent = message;
  node.classList.toggle("error", isError);
  node.classList.remove("hidden");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.add("hidden"), 3500);
}

async function refreshChat(recheck=false){try{const chat=await api.chat(recheck);$('chatName').textContent=chat.hasChat?chat.platformLabel+' · '+chat.chatName:'请先在聊天区打开一个顾客对话';return chat;}catch(error){$('chatName').textContent=error.message;return {hasChat:false,error:error.message};}}
function stepSummary(steps) {
  const counts = { text: 0, image: 0, video: 0, audio: 0, wait: 0 };
  steps.forEach((step) => { counts[step.kind] = (counts[step.kind] || 0) + 1; });
  const parts = [];
  if (counts.text) parts.push(`${counts.text} 段文字`);
  if (counts.image) parts.push(`${counts.image} 张照片`);
  if (counts.video) parts.push(`${counts.video} 段视频`);
  if (counts.audio) parts.push(`${counts.audio} 段语音`);
  if (counts.wait) parts.push(`${counts.wait} 个等待`);
  return parts.join(" · ") || "空 Flow";
}

function normalizeFolder(value) {
  return String(value || "").trim() || "未分类";
}

function folderNames() {
  return [...new Set(state.adminFlows.map((flow) => normalizeFolder(flow.folder)))].sort((left, right) => {
    if (left === "未分类") return 1;
    if (right === "未分类") return -1;
    return left.localeCompare(right, "zh-Hans");
  });
}

function renderFolderOptions() {
  $("flowFolderOptions").innerHTML = folderNames()
    .map((folder) => `<option value="${escapeHtml(folder)}"></option>`)
    .join("");
}

function renderFlows() {
  const query = $("searchInput").value.trim().toLowerCase();
  const rows = state.flows.filter((flow) => {
    const searchable = `${normalizeFolder(flow.folder)} ${flow.name}`.toLowerCase();
    return searchable.includes(query);
  });
  const groups = new Map();
  for (const flow of rows) {
    const folder = normalizeFolder(flow.folder);
    if (!groups.has(folder)) groups.set(folder, []);
    groups.get(folder).push(flow);
  }
  const orderedGroups = [...groups.entries()].sort(([left], [right]) => {
    if (left === "未分类") return 1;
    if (right === "未分类") return -1;
    return left.localeCompare(right, "zh-Hans");
  });
  $("flowList").innerHTML = orderedGroups.length ? orderedGroups.map(([folder, flows]) => `
    <details class="flow-folder" ${query || orderedGroups.length === 1 ? "open" : ""}>
      <summary>
        <span class="folder-icon" aria-hidden="true">▸</span>
        <strong>${escapeHtml(folder)}</strong>
        <small>${flows.length} 个 Flow</small>
      </summary>
      <div class="flow-folder-content">
        ${flows.map((flow) => `
          <article class="flow-card">
            <h3>${escapeHtml(flow.name)}</h3>
            <p>${escapeHtml(stepSummary(flow.steps))}</p>
            <button class="primary send-flow" data-id="${flow.id}">发送整个 Flow</button>
          </article>
        `).join("")}
      </div>
    </details>
  `).join("") : '<p class="muted">没有找到已发布的 Flow。</p>';
  root.querySelectorAll(".send-flow").forEach((button) => {
    button.addEventListener("click", () => runFlow(button.dataset.id));
  });
}

async function loadFlows() {
  if (state.demoMode) {
    state.flows = [];
    renderFlows();
    return;
  }
  state.flows = await api.flows(false);
  renderFlows();
}

async function runFlow(id){
 if(state.sending)return toast('这个 Flow 正在发送，请不要重复点击',true);
 state.sending=true;root.querySelectorAll('.send-flow').forEach(b=>b.disabled=true);
 $('sendProgress').classList.remove('hidden');$('sendProgress').textContent='正在检查对话与流程…';
 try{
  const prepared=await api.prepare(id);state.job=prepared.ticket;
  if(!confirm('发送给：'+prepared.chatName+'\n流程：'+prepared.name+'\n'+stepSummary(prepared.steps)+'\n\n确认发送整个 Flow？')){$('sendProgress').textContent='已取消发送';return;}
  if(prepared.duplicate&&!confirm('10 分钟内已尝试向这个对话发送同一个 Flow。是否仍要重复发送？')){$('sendProgress').textContent='已取消重复发送';return;}
  $('stopButton').classList.remove('hidden');$('sendProgress').classList.remove('hidden');$('sendProgress').textContent='正在发送…';
  const result=await api.start(prepared.ticket);$('sendProgress').textContent=result.message;toast(result.message,!result.complete);
 }catch(error){$('sendProgress').classList.remove('hidden');$('sendProgress').textContent=error.message+'；请先核对聊天记录，未自动重试。';toast(error.message,true);}
 finally{if(state.job)await api.stop(state.job).catch(()=>{});state.job=null;state.sending=false;root.querySelectorAll('.send-flow').forEach(b=>b.disabled=false);$('stopButton').classList.add('hidden');}
}
function blankFlow() {
  return { id: null, name: "", folder: "未分类", status: "draft", steps: [] };
}

function renderAdminList() {
  $("adminFlowList").innerHTML = state.adminFlows.length ? state.adminFlows.map((flow) => `
    <button class="admin-flow-item" data-id="${flow.id}" type="button">
      <span><strong>${escapeHtml(flow.name)}</strong><br><small>${escapeHtml(normalizeFolder(flow.folder))} · ${escapeHtml(stepSummary(flow.steps))}</small></span>
      <small>${flow.status === "published" ? "已发布" : "草稿"}</small>
    </button>
  `).join("") : '<p class="muted">还没有 Flow。</p>';
  root.querySelectorAll(".admin-flow-item").forEach((button) => {
    button.addEventListener("click", () => editFlow(button.dataset.id));
  });
}

async function loadAdminFlows() {
  state.adminFlows = await api.flows(true);
  renderAdminList();
  renderFolderOptions();
  const mediaPaths = state.adminFlows.flatMap((flow) => flow.steps.map((step) => step.media_path).filter(Boolean));
  
}

function editFlow(id = null) {
  const source = id ? state.adminFlows.find((flow) => flow.id === id) : blankFlow();
  state.editing = {
    id: source.id,
    updated_at: source.updated_at,
    name: source.name,
    folder: normalizeFolder(source.folder),
    status: source.status,
    steps: source.steps.map((step) => ({ ...step }))
  };
  $("editorTitle").textContent = id ? "编辑 Flow" : "新 Flow";
  $("flowNameInput").value = state.editing.name;
  renderFolderOptions();
  $("flowFolderInput").value = state.editing.folder;
  $("flowStatusInput").value = state.editing.status;
  $("deleteFlowButton").classList.toggle("hidden", !id);
  $("flowForm").classList.remove("hidden");
  renderStepEditor();
}

function renderStepEditor() {
  const labels = { text: "文字", image: "照片", video: "视频", audio: "语音", wait: "等待" };
  $("stepEditor").innerHTML = state.editing.steps.map((step, index) => {
    let body = "";
    if (step.kind === "text") {
      body = `<textarea data-field="text_content" data-index="${index}" rows="4" placeholder="输入要发送的文案">${escapeHtml(step.text_content || "")}</textarea>`;
    } else if (step.kind === "image") {
      const preview = step.previewUrl || state.mediaPreviewUrls.get(step.media_path) || "";
      body = mediaStepBody(step, index, "image/*", preview, preview ? `<img class="image-preview" src="${escapeHtml(preview)}">` : "");
    } else if (step.kind === "video") {
      const preview = step.previewUrl || state.mediaPreviewUrls.get(step.media_path) || "";
      body = mediaStepBody(step, index, "video/mp4,video/webm,video/quicktime", preview, preview ? `<video class="video-preview" controls preload="metadata" src="${escapeHtml(preview)}"></video>` : "");
    } else if (step.kind === "audio") {
      const preview = step.previewUrl || state.mediaPreviewUrls.get(step.media_path) || "";
      body = mediaStepBody(step, index, "audio/*", preview, preview ? `<audio class="audio-preview" controls src="${escapeHtml(preview)}"></audio>` : "");
    } else {
      body = `<label>等待毫秒<input data-field="delay_ms" data-index="${index}" type="number" min="300" step="100" value="${Number(step.delay_ms || 1000)}"></label>`;
    }
    return `<div class="step-card">
      <div class="step-head"><strong>${index + 1}. ${labels[step.kind]}</strong><div class="step-buttons">
        <button type="button" data-action="up" data-index="${index}">↑</button>
        <button type="button" data-action="down" data-index="${index}">↓</button>
        <button type="button" data-action="remove" data-index="${index}">×</button>
      </div></div>${body}</div>`;
  }).join("");

  hydrateStepPreviews();
  $("stepEditor").querySelectorAll("textarea, input[type=number]").forEach((input) => {
    input.addEventListener("input", () => {
      state.editing.steps[Number(input.dataset.index)][input.dataset.field] = input.value;
    });
  });
  $("stepEditor").querySelectorAll('input[type="file"]').forEach((input) => {
    input.addEventListener("change", () => {
      const file = input.files?.[0];
      if (!file) return;
      const step = state.editing.steps[Number(input.dataset.index)];
      step.file = file;
      if (step.previewUrl && ![...state.mediaPreviewUrls.values()].includes(step.previewUrl)) URL.revokeObjectURL(step.previewUrl);
      step.previewUrl = URL.createObjectURL(file);
      renderStepEditor();
    });
  });
  $("stepEditor").querySelectorAll("button[data-action]").forEach((button) => {
    button.addEventListener("click", () => mutateStep(button.dataset.action, Number(button.dataset.index)));
  });
  $("stepEditor").querySelectorAll("button[data-library-index]").forEach((button) => {
    button.addEventListener("click", () => openMediaLibrary(Number(button.dataset.libraryIndex)));
  });
}

function mediaStepBody(step, index, accept, preview, previewMarkup) {
  const selectedName = step.file?.name || step.original_name || step.media_path?.split("/").pop() || "尚未选择文件";
  return `<div class="media-source-actions">
    <label class="file-button">上传新文件<input data-field="file" data-index="${index}" type="file" accept="${accept}"></label>
    <button class="ghost" type="button" data-library-index="${index}">选择已有文件</button>
  </div>
  <p class="selected-media-name">${escapeHtml(selectedName)}</p>
  <div data-step-media="${index}">${preview ? previewMarkup : ""}</div>`;
}

function mediaKind(mimeType = "") {
  if (mimeType.startsWith("image/")) return "image";
  if (mimeType.startsWith("video/")) return "video";
  if (mimeType.startsWith("audio/")) return "audio";
  return "";
}

function isGeneratedMediaName(name = "") {
  const basename = String(name).split("/").pop() || "";
  return /^(?:[0-9a-f]{8}-[0-9a-f-]{27}|[0-9a-f]{64})(?:\.[a-z0-9]+)?$/i.test(basename);
}

function mediaDisplayName(asset) {
  const rawName = asset.original_name || asset.media_path?.split("/").pop() || "素材";
  if (!isGeneratedMediaName(rawName)) return rawName;
  const label = { image: "旧照片", video: "旧视频", audio: "旧语音" }[mediaKind(asset.mime_type || "")] || "旧素材";
  const date = asset.created_at ? new Date(asset.created_at) : null;
  const dateLabel = date && !Number.isNaN(date.getTime())
    ? new Intl.DateTimeFormat("zh-MY", { dateStyle: "short", timeStyle: "short" }).format(date)
    : "原名未保存";
  return `${label} · ${dateLabel}`;
}

function mediaSearchText(asset) {
  return `${mediaDisplayName(asset)} ${asset.original_name || ""} ${asset.media_path || ""}`.toLowerCase();
}

function formatBytes(bytes) {
  const value = Number(bytes || 0);
  if (value < 1024) return `${value} B`;
  if (value < 1024 ** 2) return `${(value / 1024).toFixed(1)} KB`;
  return `${(value / 1024 ** 2).toFixed(1)} MB`;
}

function mediaUsageCount(mediaPath) {
  return state.adminFlows.reduce((total, flow) => total + flow.steps.filter((step) => step.media_path === mediaPath).length, 0);
}

function updateMediaBulkActions() {
  const manage = Boolean(state.mediaPicker?.manage);
  $("mediaBulkActions").classList.toggle("hidden", !manage);
  if (!manage) return;
  const validPaths = new Set(state.mediaAssets.filter((asset) => mediaUsageCount(asset.media_path) === 0).map((asset) => asset.media_path));
  state.selectedMediaPaths = new Set([...state.selectedMediaPaths].filter((path) => validPaths.has(path)));
  $("selectedMediaCount").textContent = `已选 ${state.selectedMediaPaths.size} 个`;
  $("deleteSelectedMediaButton").disabled = state.selectedMediaPaths.size === 0;
}

function applyMediaPreview(node, asset, url) {
  if (!node?.isConnected || node.dataset.mediaPreview !== asset.media_path) return;
  node.replaceChildren();
  const kind = mediaKind(asset.mime_type || "");
  if (kind === "image") {
    const image = document.createElement("img");
    image.alt = mediaDisplayName(asset);
    image.loading = "lazy";
    image.src = url;
    image.addEventListener("error", () => {
      node.textContent = "图片";
      node.classList.add("preview-failed");
    }, { once: true });
    node.append(image);
  } else if (kind === "video") {
    const video = document.createElement("video");
    video.muted = true;
    video.playsInline = true;
    video.preload = "metadata";
    video.src = url;
    video.addEventListener("loadedmetadata", () => {
      if (video.duration > 0.2) video.currentTime = Math.min(0.25, video.duration / 2);
    }, { once: true });
    video.addEventListener("error", () => {
      node.textContent = "视频";
      node.classList.add("preview-failed");
    }, { once: true });
    node.append(video);
  }
}

function hydrateMediaPreviews() {
  for (const node of $("mediaLibraryList").querySelectorAll("[data-media-preview]")) {
    const mediaPath = node.dataset.mediaPreview;
    const asset = state.mediaAssets.find((item) => item.media_path === mediaPath);
    if (!asset || !["image", "video"].includes(mediaKind(asset.mime_type || ""))) continue;
    const cached = state.mediaPreviewUrls.get(mediaPath);
    if (cached) {
      applyMediaPreview(node, asset, cached);
      continue;
    }
    let pending = state.mediaPreviewPromises.get(mediaPath);
    if (!pending) {
      pending = api.mediaPreviewUrl(mediaPath)
        .then((url) => {
          if(disposed){URL.revokeObjectURL(url);throw Error("面板已关闭");}state.mediaPreviewUrls.set(mediaPath, url);
          return url;
        })
        .finally(() => state.mediaPreviewPromises.delete(mediaPath));
      state.mediaPreviewPromises.set(mediaPath, pending);
    }
    pending.then((url) => applyMediaPreview(node, asset, url)).catch(() => {
      if (node.isConnected) {
        node.textContent = mediaKind(asset.mime_type || "") === "video" ? "视频" : "图片";
        node.classList.add("preview-failed");
      }
    });
  }
}

function renderMediaLibrary() {
  if (!state.mediaPicker) return;
  const query = $("mediaSearchInput").value.trim().toLowerCase();
  const kind = state.mediaPicker.kind;
  const manage = state.mediaPicker.manage;
  const rows = state.mediaAssets.filter((asset) => manage || mediaKind(asset.mime_type || "") === kind)
    .filter((asset) => mediaSearchText(asset).includes(query));
  $("mediaLibraryTitle").textContent = manage ? "媒体库管理" : "选择已有文件";
  $("mediaLibraryHint").textContent = manage
    ? "使用中的文件会锁定；先从所有 Flow 移除后才能删除。"
    : "从 Supabase 媒体库直接复用，不会再次上传。";
  $("mediaLibraryList").innerHTML = rows.length ? rows.map((asset) => {
    const assetKind = mediaKind(asset.mime_type || "");
    const preview = assetKind === "image"
      ? `<span class="preview-loading" data-media-preview="${escapeHtml(asset.media_path)}">载入中</span>`
      : assetKind === "video"
        ? `<span class="preview-loading" data-media-preview="${escapeHtml(asset.media_path)}">载入中</span>`
        : '<span class="audio-icon">♪</span>';
    const usageCount = mediaUsageCount(asset.media_path);
    const checked = state.selectedMediaPaths.has(asset.media_path);
    const action = manage
      ? `<label class="media-checkbox ${usageCount ? "disabled" : ""}"><input type="checkbox" data-media-check="${escapeHtml(asset.media_path)}" ${checked ? "checked" : ""} ${usageCount ? "disabled" : ""}><span>${usageCount ? `使用中 ${usageCount}` : "选择"}</span></label>`
      : `<button type="button" class="primary media-select-button" data-media-path="${escapeHtml(asset.media_path)}">选择</button>`;
    return `<article class="media-library-item">
      <span class="media-thumb">${preview}</span>
      <span class="media-meta"><strong title="${escapeHtml(asset.original_name || "")}">${escapeHtml(mediaDisplayName(asset))}</strong><small>${isGeneratedMediaName(asset.original_name || "") ? "旧版本未保存原名 · " : ""}${escapeHtml(formatBytes(asset.size_bytes))} · ${usageCount ? `${usageCount} 个步骤使用` : "未使用"}</small></span>
      <span class="media-item-action">${action}</span>
    </article>`;
  }).join("") : '<p class="muted">没有符合的已有文件，请选择“上传新文件”。</p>';
  $("mediaLibraryList").querySelectorAll("button[data-media-path]").forEach((button) => {
    button.addEventListener("click", () => chooseMediaAsset(button.dataset.mediaPath));
  });
  $("mediaLibraryList").querySelectorAll("input[data-media-check]").forEach((input) => {
    input.addEventListener("change", () => {
      if (input.checked) state.selectedMediaPaths.add(input.dataset.mediaCheck);
      else state.selectedMediaPaths.delete(input.dataset.mediaCheck);
      updateMediaBulkActions();
    });
  });
  updateMediaBulkActions();
  hydrateMediaPreviews();
}

async function openMediaLibrary(index) {
  const step = state.editing?.steps[index];
  if (!step || !["image", "video", "audio"].includes(step.kind)) return;
  state.mediaPicker = { index, kind: step.kind };
  placeOverlay($("mediaLibrary")); $("mediaLibrary").classList.remove("hidden");
  $("mediaSearchInput").value = "";
  $("mediaLibraryList").innerHTML = '<p class="muted">正在读取媒体库…</p>';
  try {
    const referencedPaths = state.adminFlows.flatMap((flow) => flow.steps.map((item) => item.media_path).filter(Boolean));
    
    state.mediaAssets = await api.mediaLibraryAssets();
    renderMediaLibrary();
  } catch (error) {
    $("mediaLibraryList").innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

async function openMediaManager() {
  state.mediaPicker = { index: null, kind: "all", manage: true };
  state.selectedMediaPaths.clear();
  placeOverlay($("mediaLibrary")); $("mediaLibrary").classList.remove("hidden");
  $("mediaSearchInput").value = "";
  $("mediaLibraryList").innerHTML = '<p class="muted">正在读取媒体库…</p>';
  try {
    state.mediaAssets = await api.mediaLibraryAssets();
    renderMediaLibrary();
  } catch (error) {
    $("mediaLibraryList").innerHTML = `<p class="muted">${escapeHtml(error.message)}</p>`;
  }
}

function selectAllUnusedMedia() {
  const query = $("mediaSearchInput").value.trim().toLowerCase();
  state.mediaAssets.filter((asset) => mediaUsageCount(asset.media_path) === 0)
    .filter((asset) => mediaSearchText(asset).includes(query))
    .forEach((asset) => state.selectedMediaPaths.add(asset.media_path));
  renderMediaLibrary();
}

async function deleteSelectedMedia() {
  const assets = state.mediaAssets.filter((asset) => state.selectedMediaPaths.has(asset.media_path));
  if (!assets.length) return;
  const totalBytes = assets.reduce((sum, asset) => sum + Number(asset.size_bytes || 0), 0);
  if (!confirm(`确定永久删除已选的 ${assets.length} 个文件（${formatBytes(totalBytes)}）吗？删除后无法恢复。`)) return;
  const deleteButton = $("deleteSelectedMediaButton");
  deleteButton.disabled = true;
  deleteButton.textContent = `删除中 0/${assets.length}`;
  const deleted = [];
  const failed = [];
  for (let index = 0; index < assets.length; index += 1) {
    deleteButton.textContent = `删除中 ${index + 1}/${assets.length}`;
    try {
      await api.deleteMediaAsset(assets[index]);
      deleted.push(assets[index].media_path);
    } catch (error) {
      failed.push(error.message);
    }
  }
  state.mediaAssets = state.mediaAssets.filter((asset) => !deleted.includes(asset.media_path));
  deleted.forEach((mediaPath) => {
    const previewUrl = state.mediaPreviewUrls.get(mediaPath);
    if (previewUrl?.startsWith("blob:")) URL.revokeObjectURL(previewUrl);
    state.mediaPreviewUrls.delete(mediaPath);
    state.mediaPreviewPromises.delete(mediaPath);
  });
  state.selectedMediaPaths.clear();
  deleteButton.textContent = "删除已选";
  renderMediaLibrary();
  if (failed.length) toast(`已删除 ${deleted.length} 个，${failed.length} 个失败：${failed[0]}`, true);
  else toast(`已删除 ${deleted.length} 个文件`);
}

function chooseMediaAsset(mediaPath) {
  const asset = state.mediaAssets.find((item) => item.media_path === mediaPath);
  const step = state.editing.steps[state.mediaPicker.index];
  if (step.previewUrl?.startsWith("blob:") && ![...state.mediaPreviewUrls.values()].includes(step.previewUrl)) URL.revokeObjectURL(step.previewUrl);
  delete step.file;
  step.media_path = mediaPath;
  step.original_name = asset?.original_name || mediaPath.split("/").pop();
  step.previewUrl = state.mediaPreviewUrls.get(mediaPath) || "";
  closeMediaLibrary();
  renderStepEditor();
}

function closeMediaLibrary() {
  state.mediaPicker = null;
  $("mediaLibrary").classList.add("hidden");
}

function mutateStep(action, index) {
  const steps = state.editing.steps;
  if (action === "remove") steps.splice(index, 1);
  if (action === "up" && index > 0) [steps[index - 1], steps[index]] = [steps[index], steps[index - 1]];
  if (action === "down" && index < steps.length - 1) [steps[index + 1], steps[index]] = [steps[index], steps[index + 1]];
  renderStepEditor();
}

function addStep(kind) {
  if (!state.editing) editFlow();
  if (kind === "text") state.editing.steps.push({ kind, text_content: "" });
  if (kind === "image") state.editing.steps.push({ kind, media_path: null });
  if (kind === "video") state.editing.steps.push({ kind, media_path: null });
  if (kind === "audio") state.editing.steps.push({ kind, media_path: null });
  if (kind === "wait") state.editing.steps.push({ kind, delay_ms: 1000 });
  renderStepEditor();
}

async function saveEditingFlow(event) {
  event.preventDefault();
  if (state.saving) return;
  state.editing.name = $("flowNameInput").value.trim();
  state.editing.folder = normalizeFolder($("flowFolderInput").value);
  state.editing.status = $("flowStatusInput").value;
  if (!state.editing.name) return toast("请填写 Flow 名称", true);
  if (!state.editing.steps.length) return toast("请至少加入一个步骤", true);
  for (const step of state.editing.steps) {
    if (step.kind === "text" && !String(step.text_content || "").trim()) return toast("文字步骤不能为空", true);
    if (["image", "video", "audio"].includes(step.kind) && !step.file && !step.media_path) {
      const mediaLabel = { image: "照片", video: "视频", audio: "语音" }[step.kind];
      return toast(`请选择${mediaLabel}`, true);
    }
  }
  const saveButton = $("saveFlowButton");
  const originalLabel = saveButton.textContent;
  state.saving = true;
  saveButton.disabled = true;
  saveButton.textContent = "保存中…";
  try {
    await api.saveFlow(state.editing);
    toast("Flow 已保存");
    $("flowForm").classList.add("hidden");
    state.editing = null;
    await Promise.all([loadAdminFlows(), loadFlows()]);
  } catch (error) {
    toast(error.message, true);
  } finally {
    state.saving = false;
    saveButton.disabled = false;
    saveButton.textContent = originalLabel;
  }
}

async function deleteEditingFlow() {
  if (!state.editing?.id || !confirm(`确定删除“${state.editing.name}”吗？`)) return;
  try {
    await api.deleteFlow(state.editing.id);
    $("flowForm").classList.add("hidden");
    state.editing = null;
    await Promise.all([loadAdminFlows(), loadFlows()]);
    toast("Flow 已删除");
  } catch (error) {
    toast(error.message, true);
  }
}

function switchTab(tab) {
  const admin = tab === "admin";
  $("sendTab").classList.toggle("active", !admin);
  $("adminTab").classList.toggle("active", admin);
  $("sendView").classList.toggle("hidden", admin);
  $("adminView").classList.toggle("hidden", !admin);
  if (admin) loadAdminFlows().catch((error) => toast(error.message, true));
}

async function enterApp() {
  try {
    state.profile = await api.profile();
    $("accountLine").textContent = `${state.profile.email} · ${state.profile.role === "admin" ? "管理员" : "员工"}`;
    $("logoutButton").classList.remove("hidden");
    $("adminTab").classList.toggle("hidden", state.profile.role !== "admin");
    showOnly("appView");
    await Promise.all([loadFlows(), refreshChat()]);
  } catch (error) {
    showOnly("loginView");
    toast(error.message, true);
  }
}

$("searchInput").addEventListener("input", renderFlows);
$('stopButton').addEventListener('click',()=>{if(state.job)void api.stop(state.job);$('sendProgress').textContent='正在停止后续发送…';});
$("sendTab").addEventListener("click", () => switchTab("send"));
$("adminTab").addEventListener("click", () => switchTab("admin"));
$("newFlowButton").addEventListener("click", () => editFlow());
$("manageMediaButton").addEventListener("click", () => openMediaManager());
$("reloadAdminButton").addEventListener("click", () => api.refresh().then(loadAdminFlows).catch((error) => toast(error.message, true)));
$("closeEditorButton").addEventListener("click", () => $("flowForm").classList.add("hidden"));
$("addTextButton").addEventListener("click", () => addStep("text"));
$("addImageButton").addEventListener("click", () => addStep("image"));
$("addVideoButton").addEventListener("click", () => addStep("video"));
$("addAudioButton").addEventListener("click", () => addStep("audio"));
$("addWaitButton").addEventListener("click", () => addStep("wait"));
$("flowForm").addEventListener("submit", saveEditingFlow);
$("deleteFlowButton").addEventListener("click", deleteEditingFlow);
$("closeMediaLibraryButton").addEventListener("click", closeMediaLibrary);
$("mediaSearchInput").addEventListener("input", renderMediaLibrary);
$("selectUnusedMediaButton").addEventListener("click", selectAllUnusedMedia);
$("deleteSelectedMediaButton").addEventListener("click", deleteSelectedMedia);
$("mediaLibrary").addEventListener("click", (event) => { if (event.target === $("mediaLibrary")) closeMediaLibrary(); });


$('logoutButton').addEventListener('click',()=>{void api.logout().catch(e=>toast(e.message,true));});
 $('retryLoginButton').addEventListener('click',()=>void enterApp());
 $('refreshButton').addEventListener('click',()=>Promise.all([api.refresh(),refreshChat(true)]).then(loadFlows).catch(e=>toast(e.message,true)));
 const unsubscribe=api.onProgress(event=>{if(event.ticket===state.job)$('sendProgress').textContent=event.message;});
 const overlays=new ResizeObserver(()=>{placeOverlay($("mediaLibrary"));placeOverlay($("toast"),true);});overlays.observe(host);
 void enterApp();
 return {refresh:()=>api.refresh().then(()=>Promise.all([loadFlows(),refreshChat(true)])),dispose(){overlays.disconnect();disposed=true;unsubscribe();if(state.job)void api.stop(state.job);clearTimeout(toast.timer);for(const step of state.editing?.steps||[])if(step.file&&step.previewUrl)URL.revokeObjectURL(step.previewUrl);for(const url of state.mediaPreviewUrls.values())URL.revokeObjectURL(url);for(const media of root.querySelectorAll('audio,video'))media.pause();host.remove();}};

function hydrateStepPreviews(){
 for(const node of $('stepEditor').querySelectorAll('[data-step-media]')){
  const step=state.editing.steps[Number(node.dataset.stepMedia)];if(!step.media_path||node.childElementCount)continue;
  node.textContent='载入中…';let pending=state.mediaPreviewPromises.get(step.media_path);
  if(!pending){pending=api.mediaPreviewUrl(step.media_path).then(url=>{if(disposed){URL.revokeObjectURL(url);throw Error('面板已关闭');}state.mediaPreviewUrls.set(step.media_path,url);return url;}).finally(()=>state.mediaPreviewPromises.delete(step.media_path));state.mediaPreviewPromises.set(step.media_path,pending);}
  pending.then(url=>{if(!node.isConnected||state.editing?.steps[Number(node.dataset.stepMedia)]!==step)return;const media=document.createElement(step.kind==='image'?'img':step.kind==='audio'?'audio':'video');media.className=step.kind+'-preview';media.src=url;if(step.kind==='image')media.alt=step.original_name||'Flow 照片';else{media.controls=true;media.preload='metadata';}node.replaceChildren(media);}).catch(()=>{if(!node.isConnected)return;const retry=document.createElement('button');retry.type='button';retry.textContent='重新载入预览';retry.onclick=()=>{node.replaceChildren();hydrateStepPreviews();};node.replaceChildren(retry);});
 }
}

}};})();
