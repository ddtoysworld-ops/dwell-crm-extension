(() => {
  let host, root, body, flowBody, heading, rail, drawer, snapshot, key = '', generation = 0;
  let open = false, mode = 'crm', busy = false, nextRead = 0, recheck = refresh;
  let failures = 0, contextExpired = false, rendered = '', connection;
  let inlineCRM, inlineHost, inlineAI, inlineFlow, couponView;
  const isWA = location.hostname === 'web.whatsapp.com';
  const labels = { crm: 'CRM', ai: 'AI 回复', flow: 'Flow' };
  const messages = {
    signed_out: '请先在独立侧栏登录。', transition: '正在确认当前对话…',
    not_found: '未找到已导入的客户，不会自动建立客户。', conflict: '客户资料有多个匹配，请先核对。',
    unavailable: '暂时无法读取客户资料。', missing_messenger: '请打开 Messenger 顾客对话。',
    phone_missing: '未自动匹配客户（对话未显示电话号码）', group: '群组不查询个人客户资料。',
    unverified_chat: '暂不能确认这是个人对话。', no_conversation: '请选择顾客对话。',
    reconnecting: '连接暂时中断，正在自动重试…', offline: '网络已断开，联网后会自动重新查询。',
    retry: '暂时无法连接，请稍后重新查询。',
    context_expired: '插件已更新或重新加载，请刷新此聊天页面一次。',
    unsupported: '此页面暂不支持客户查询。'
  };
  function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text != null) node.textContent = text;
    if (className) node.className = className;
    return node;
  }
  function button(label, icon, action) {
    const node = element('button'); node.type = 'button'; node.title = label; node.setAttribute('aria-label', label);
    if (globalThis.lucide?.icons?.[icon]) node.append(lucide.createElement(lucide.icons[icon], { width: 17, height: 17, 'aria-hidden': 'true' }));
    else node.textContent = label;
    node.addEventListener('click', action); return node;
  }
  function titleRow(label, icon) {
    const title = element('h3');
    if (globalThis.lucide?.icons?.[icon]) title.append(lucide.createElement(lucide.icons[icon], { width: 15, height: 15, 'aria-hidden': 'true' }));
    title.append(element('span', label)); return title;
  }
  function findHost() {
    for (const a of document.querySelectorAll('a')) {
      if (!['View profile', '查看个人主页', '查看個人檔案', '查看主页'].includes(a.textContent.trim())) continue;
      for (let n = a.parentElement, depth = 0; n && depth < 12; n = n.parentElement, depth++) {
        const rect = n.getBoundingClientRect();
        if (rect.width < 230 || rect.width > 560 || rect.x < innerWidth * .45) continue;
        const titles = [...n.querySelectorAll('[role="heading"],h3')].map(h => h.textContent.trim());
        if (titles.some(t => ['About', '关于', '關於'].includes(t)) && titles.some(t => ['Labels', '标签', '標籤'].includes(t))) return n;
      }
    }
    return null;
  }
  const css = `
    :host{all:initial;display:block;color:#203b35;font:13px/1.5 Arial,"Microsoft YaHei",sans-serif;letter-spacing:0;color-scheme:light}
    *{box-sizing:border-box}button{font:inherit;cursor:pointer;color:inherit;background:white;border:1px solid #cad9d4;border-radius:4px;display:inline-flex;align-items:center;justify-content:center;gap:7px;min-height:34px;padding:6px 10px;letter-spacing:0}button:hover{background:#edf5f1}button:focus-visible{outline:2px solid #287b66;outline-offset:2px}button:disabled{cursor:default}svg{flex-shrink:0}h2,h3,p{margin:0}h2{font-size:15px}h3{font-size:15px;overflow-wrap:anywhere}small{color:#657a72}a{color:#185eaa}.shell{background:white;border-bottom:1px solid #d9e3df;padding:14px;min-height:160px}.bar{display:flex;align-items:center;gap:8px}.bar h2{flex:1}.tabs{display:flex;gap:5px;margin:12px 0}.tabs button{flex:1;border:0;border-radius:0;border-bottom:2px solid transparent;padding:7px 2px}.tabs button[aria-selected=true]{border-color:#176750;color:#176750;font-weight:bold}.body{min-height:76px;overflow-wrap:anywhere}.notice{padding:12px 0;color:#657a72}.action{margin-top:10px}.identity{padding:8px 0 14px;border-bottom:1px solid #e1e9e5}.metrics{display:grid;grid-template-columns:1fr 1fr;gap:10px;padding:14px 0}.metrics strong{display:block;font-size:16px}.section{border-top:1px solid #e1e9e5;padding:14px 0}.section h3{font-size:13px;margin-bottom:8px}.muted{color:#657a72}.order{padding:8px 0;border-bottom:1px solid #edf1ef}.rail{position:fixed;right:0;top:120px;display:flex;flex-direction:column;gap:8px;z-index:2147483000}.rail button{width:38px;min-height:88px;padding:8px 5px;writing-mode:vertical-rl;background:#176750;color:white;border-color:#c2d7cf;border-radius:6px 0 0 6px}.rail button:nth-child(2){background:#215c96}.rail button:nth-child(3){background:#5b6070}.rail button[aria-expanded=true]{box-shadow:inset 3px 0 #edc96d}.drawer{position:fixed;right:42px;top:96px;bottom:94px;width:350px;max-width:calc(100vw - 54px);overflow:auto;border:1px solid #d4dfda;box-shadow:0 6px 22px #0002;z-index:2147482999;border-radius:6px;background:white}.drawer[hidden]{display:none}.drawer .shell{border:0;min-height:100%}.drawer .bar{position:sticky;top:-14px;background:white;padding:4px 0;z-index:1}@media(max-height:480px){.rail{top:60px;gap:4px}.rail button{min-height:65px}.drawer{top:50px;bottom:65px}}`;
  const refinedCSS = `
    :host{font:13px/1.55 Arial,"Microsoft YaHei",sans-serif;color:#273c36}
    .shell{padding:16px;min-height:0}.bar{gap:6px}.bar h2{font-size:14px;line-height:1.4}
    .bar button{width:30px;height:30px;min-height:30px;padding:6px;border-color:#dce4e0}
    .connection{display:flex;align-items:center;gap:6px;margin:7px 0 0;font-size:11px;color:#6a7b74}
    .connection:before{content:'';width:6px;height:6px;flex-shrink:0;border-radius:50%;background:#85948e}
    .connection[data-state=matched]:before{background:#27866c}.connection[data-state=reconnecting]:before{background:#ba7b28}
    .tabs{margin:15px -16px 0;padding:0 16px;border-bottom:1px solid #e2e8e5;gap:18px}
    .tabs button{font-size:12px;min-height:38px;white-space:nowrap}.body{min-height:0}
    .identity{display:flex;gap:11px;align-items:center;padding:20px 0 16px;border:0}
    .avatar{width:36px;height:36px;border-radius:6px;background:#edf3ef;color:#25644f;display:grid;place-items:center;font-size:16px;font-weight:bold;flex-shrink:0}
    .identity h3{font-size:15px;font-weight:700;line-height:1.4}.identity p{font-size:12px;margin-top:3px;font-variant-numeric:tabular-nums}.identity>div:last-child{min-width:0}
    .metrics{gap:12px;padding:12px 0 16px;border-bottom:1px solid #e3e9e6}.metrics>div+div{border-left:1px solid #e3e9e6;padding-left:12px;min-width:0}
    .metrics small{font-size:11px}.metrics strong{font-size:17px;line-height:1.4;margin-top:4px;font-variant-numeric:tabular-nums;overflow-wrap:anywhere}
    .section{padding:18px 0;border-top:0;border-bottom:1px solid #e3e9e6}.section h3{display:flex;align-items:center;gap:7px;font-size:12px;color:#536960;margin:0 0 11px}.section h3 svg{color:#809189}
    .section p{font-size:12px;line-height:1.7}.delivery-label{color:#7a6550;font-size:10px;margin-left:auto;background:#f6f1e9;padding:2px 6px;border-radius:3px;font-weight:normal}
    .section .muted{margin-top:6px;font-size:11px;color:#7d8983}.recipient{font-weight:bold;margin-bottom:4px}.address{white-space:pre-line}
    .order{display:flex;justify-content:space-between;align-items:flex-start;gap:10px;padding:9px 0;border:0}.order+.order{border-top:1px solid #f0f3f1}.order p{font-size:12px;font-weight:bold}.order time{display:block;color:#7b8982;font-size:11px;margin-top:2px}.order small{font-size:10px;color:#426c5b;background:#eff5f1;padding:2px 6px;border-radius:3px;white-space:normal;text-align:right}
    .rewards-note{margin-top:14px;font-size:11px;line-height:1.6;color:#7b8982}.workbench-actions{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin:0 0 14px}.workbench-actions button{font-size:11px;min-width:0;padding:7px 5px}.workbench-actions button:first-child{grid-column:1/-1;background:#21654e;color:white;border-color:#21654e}.workbench-actions button span{overflow-wrap:anywhere}
    .notice{padding:22px 0 8px;font-size:12px;line-height:1.7}.action{margin:10px 0 6px;min-height:32px;font-size:12px}.body[data-status=context_expired] .notice,.body[data-status=retry] .notice{color:#84612c}
    .drawer{top:90px;bottom:auto;width:340px;max-height:calc(100dvh - 180px);overscroll-behavior:contain;box-shadow:0 5px 22px #0003}
    .drawer .shell{min-height:0;padding:18px}.drawer .bar{position:static;padding:0}.drawer .identity{padding-top:22px}
    .rail{top:110px;gap:6px}.rail button{min-height:74px;width:34px;font-size:12px;font-weight:bold}.rail button[aria-expanded=true]{box-shadow:inset 3px 0 #edc96d}
    @media(max-height:480px){.drawer{top:46px;max-height:calc(100dvh - 106px)}.rail{top:60px}.rail button{min-height:60px}}
    @media(prefers-reduced-motion:no-preference){.connection[data-state=loading]:before{animation:pulse 1s ease-in-out infinite alternate}@keyframes pulse{to{opacity:.3}}}
    .bar button{width:38px;height:38px;min-height:38px}.tabs button{font-size:13px;min-height:42px}
    .drawer{width:380px}
    .shell:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden])){display:flex;flex-direction:column;height:min(780px,calc(100dvh - 180px));overflow:hidden}
    .shell:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden]))>.body{display:none}
    .shell:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden]))>.inline-host{display:flex;flex-direction:column;flex:1;min-height:0}
    .inline-host:has(.ic-pane:not([hidden]) .ic-form:not([hidden])) .inline-crm{display:flex;flex-direction:column;min-height:0;flex:1}
    .ic-pane:has(.ic-form:not([hidden])){display:flex;flex-direction:column;min-height:0;flex:1}
    .shell .ic-pane .ic-form{flex:1;min-height:0;max-height:none;height:auto}
    .shell:has(.inline-host:not([hidden]) .ic-form:not([hidden])) .bar,.shell:has(.inline-host:not([hidden]) .ic-form:not([hidden]))>.tabs{flex-shrink:0}
    .drawer:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden])){overflow:hidden}
    @media(max-height:600px){.shell:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden])){height:calc(100dvh - 106px);padding:10px}.drawer:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden])){top:46px;max-height:calc(100dvh - 106px)}.shell:has(.inline-host:not([hidden]) .ic-form:not([hidden]))>.connection{display:none}.shell:has(.inline-host:not([hidden]) .ic-form:not([hidden])) .tabs{margin-top:4px}.shell:has(.inline-host:not([hidden]) .ic-form:not([hidden])) .inline-crm{margin-top:4px}.ic-form .ic-footer{padding-top:6px;gap:4px}}
    .body[data-status=matched]{height:clamp(240px,calc(100dvh - 380px),520px);overflow:auto;overscroll-behavior:contain;scrollbar-gutter:stable;border:1px solid #dbe4eb;border-radius:6px;padding:14px;margin-top:12px;background:#f7f9fc}
    .body[data-status=matched] .identity{padding:0 0 14px}.identity h3{font-size:16px}.identity p{font-size:14px}.metrics{padding:10px 0 16px;border:0}.metrics small{font-size:12px}.metrics strong{font-size:18px}
    .profile-facts{display:grid;grid-template-columns:minmax(88px,40%) 1fr;gap:12px 10px;margin:0;padding:14px 0;line-height:1.6;font-size:14px}.profile-facts dt{color:#60716f;font-size:13px}.profile-facts dd{margin:0;overflow-wrap:anywhere;font-variant-numeric:tabular-nums}
    .customer-type{display:inline-block;border-radius:4px;padding:3px 8px;background:#eaf2fb;color:#225985;font-size:13px;margin-top:8px}
    .section{padding:18px 0;border:0}.section h3{font-size:14px;color:#253e37;margin-bottom:12px}.section p{font-size:14px}.section .muted{font-size:12px}.order{display:block;padding:14px 0;border-bottom:1px solid #dfe7ed}.order-head{display:flex;justify-content:space-between;gap:8px;font-size:14px}.order .order-head time{font-size:13px;color:#536c7e;margin:0}.order p{font-weight:normal;font-size:14px;line-height:1.6;margin-top:7px}.order .order-meta{color:#60716f;font-size:13px}.history-more{width:100%;min-height:38px;margin-top:12px}.history-note{font-size:12px;color:#60716f;line-height:1.6;margin:10px 0}
    .bar button{width:34px;height:34px;min-height:34px}.tabs button{min-height:38px}
    .embedded .body[data-status=flow]{max-height:calc(100dvh - 250px);overflow:auto;overscroll-behavior:contain}
    [data-mode=flow]>.shell{padding:0}
    [data-mode=flow]>.shell>.bar,[data-mode=flow]>.shell>.connection{display:none}
    .embedded[data-mode=flow]>.shell>.tabs{margin:8px 12px}
    .embedded[data-mode=flow] .body{max-height:calc(100dvh - 160px)}
    .body[data-status=matched]{padding:12px;background:#f5f7fc;border:0;border-top:1px solid #d7dfed;border-radius:0;color:#071c39;font-size:13px}
    .legacy-customer-card{border:1px solid #d7dfed;border-radius:8px;background:white;padding:13px;min-width:0}
    .body[data-status=matched] .legacy-customer-card .identity{display:block;padding:0;border:0;margin:0 0 8px}.legacy-customer-card .identity h3{font-size:15px;line-height:1.4}
    .legacy-customer-card .customer-copy{margin:0 0 8px!important}.legacy-customer-card .customer-copy button{min-height:30px;font-size:12px;line-height:1.2;font-weight:bold;padding:5px 6px;border:1px solid #d7dfed;border-radius:8px;color:#0866ff}.legacy-customer-card .customer-copy svg{display:none}.legacy-customer-card .ic-note:empty{display:none}
    .legacy-customer-card .profile-facts{display:grid;grid-template-columns:92px minmax(0,1fr);gap:0 8px;margin:0;padding:0;line-height:1.5;font-size:13px}
    .legacy-customer-card .profile-facts dt,.legacy-customer-card .profile-facts dd{border-top:1px solid #eef1f6;padding:5px 0;margin:0;font-size:13px;white-space:pre-line}.legacy-customer-card .profile-facts dt{font-size:12px;color:#657390}
    .legacy-customer-card .customer-history{margin-top:12px;padding:10px 0 0;border-top:1px solid #eef1f6}.legacy-customer-card .customer-history h3{font-size:14px;margin:0 0 8px;color:inherit}.legacy-customer-card .order{padding:8px 0;border-color:#eef1f6}.legacy-customer-card .order:first-child{border:0}.legacy-customer-card .order p{margin-top:3px;font-size:13px;line-height:1.4}.legacy-customer-card .order .order-meta,.legacy-customer-card .order time{font-size:12px;color:#657390}.legacy-customer-card .order-head{font-size:13px}.legacy-customer-card .history-note:empty{display:none}
    .legacy-customer-card .customer-unbind{width:100%;min-height:34px;margin-top:12px;border:1px solid #ffb3b3;border-radius:8px;color:#e12424;font-size:12px;background:white}
    .customer-coupons{margin:12px 0;padding:10px 0;border-top:1px solid #e7ebf1;border-bottom:1px solid #e7ebf1}.customer-coupons summary{display:flex;align-items:center;gap:8px;cursor:pointer;min-height:24px;font-size:13px;list-style:none}.customer-coupons summary:after{content:'▸';margin-left:auto;color:#657390}.customer-coupons[open] summary:after{content:'▾'}.coupon-badge:not([hidden]){display:inline-flex;align-items:center;justify-content:center;min-width:19px;height:19px;padding:0 5px;border-radius:999px;background:#be2837;color:#fff;font-size:11px;font-weight:700;line-height:1}.coupon-count{font-size:11px;color:#657390}.coupon-body{padding-top:10px}.coupon-actions{display:flex;gap:6px}.coupon-actions button{font-size:12px;min-height:30px}.coupon-note{font-size:12px;line-height:1.5;color:#657390;margin:8px 0!important}.coupon-note:empty{display:none}.coupon-row{padding:10px 0;border-bottom:1px solid #eef1f6}.coupon-row p{margin:6px 0}.coupon-row-top{display:flex;justify-content:space-between;gap:8px;align-items:baseline}.coupon-row-top strong{overflow-wrap:anywhere}.coupon-status{font-size:11px;color:#657390;flex-shrink:0}.coupon-reserve{display:flex;align-items:center;gap:6px;font-size:12px}.coupon-reserve input{width:16px;height:16px}.coupon-grant{display:grid;gap:10px;padding:10px 0}.coupon-grant[hidden]{display:none}.coupon-grant label{display:grid;gap:4px;font-size:12px}.coupon-grant input,.coupon-grant select{width:100%;min-width:0;border:1px solid #d7dfed;border-radius:5px;min-height:34px;padding:6px;font:inherit}.coupon-grant button{background:#0866ff;color:white;border-color:#0866ff}
    .customer-coupons>.coupon-body>.coupon-list{display:grid;gap:7px}.customer-coupons .coupon-actions button[hidden]{display:none!important}.customer-coupons .coupon-row{padding:0;border:1px solid #d8e2e1;border-radius:6px;background:#fff;min-width:0}.customer-coupons .coupon-row>summary{padding:9px 10px;align-items:center;gap:8px}.customer-coupons .coupon-row>summary:after{content:'▸';margin-left:0;order:3}.customer-coupons .coupon-row[open]>summary:after{content:'▾'}.customer-coupons .coupon-row-heading{display:grid;gap:2px;min-width:0;flex:1}.customer-coupons .coupon-row-heading strong{font-size:12px;line-height:1.35;overflow-wrap:anywhere}.customer-coupons .coupon-row-heading small{font-size:11px;color:#657390}.customer-coupons .coupon-row-body{padding:0 10px 10px;border-top:1px solid #eef1f3}.customer-coupons .coupon-row-body p{margin:7px 0}.customer-coupons .coupon-reserve{padding-top:7px}.customer-coupons .coupon-redeem{display:grid;gap:6px;padding-top:7px}.customer-coupons .coupon-redeem[hidden]{display:none}.customer-coupons .coupon-redeem input{width:100%;min-width:0;border:1px solid #d7dfed;border-radius:5px;padding:6px;font:inherit}.customer-coupons .coupon-redeem button{min-height:30px}
    @media(max-height:600px){.body[data-status=matched]{height:220px;min-height:0}}
  `;
  const whatsappCSS = `
    .drawer,.drawer:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden])){
      top:0;right:0;bottom:0;width:min(440px,calc(100vw - 38px));max-width:none;
      height:100dvh;max-height:none;border-radius:0;border-width:0 0 0 1px;
      overflow:hidden;box-shadow:-3px 0 14px #0002
    }
    .drawer .shell,.drawer .shell:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden])){
      display:flex;flex-direction:column;height:100%;min-height:0;overflow:hidden;padding:16px
    }
    .drawer .bar,.drawer .connection{flex-shrink:0}
    .drawer .inline-host{min-height:0;overflow:auto;overscroll-behavior:contain}
    .drawer .inline-host:has(.ic-pane:not([hidden]) .ic-form:not([hidden])){overflow:hidden}
    .drawer .body{flex:1;min-height:0;overflow:auto;overscroll-behavior:contain}
    .drawer .body[data-status=matched]{height:auto}
    .drawer:not([hidden])~.rail{right:min(440px,calc(100vw - 38px))}
    @media(max-height:600px){.drawer .shell,.drawer .shell:has(.inline-host:not([hidden]) .ic-pane:not([hidden]) .ic-form:not([hidden])){padding:10px}}
    .drawer[data-mode=flow]>.shell{padding:0}
  `;
  function remove() { couponView?.dispose();couponView=null;inlineFlow?.dispose();inlineFlow=null;inlineAI?.dispose();inlineAI=null;inlineCRM?.dispose();inlineCRM=null; ++generation; busy = false; rendered = ''; host?.remove(); host = root = body = flowBody = connection = null; key = ''; }
  function mount() {
    if (host?.isConnected) return true;
    const target = isWA ? document.body : findHost();
    if (!target) return false;
    host = element('section'); host.id = isWA ? 'dwell-readonly-drawer' : 'dwell-readonly-embedded';
    // Native DOM avoids the failed cross-origin iframe, without exposing auth inputs or tokens.
    root = host.attachShadow({ mode: 'closed' });
    const style = element('style', css + refinedCSS + (isWA ? whatsappCSS : '')); root.append(style);
    drawer = element('div', null, isWA ? 'drawer' : 'embedded');
    const shell = element('section', null, 'shell'); drawer.append(shell);
    const bar = element('header', null, 'bar'); heading = element('h2', "D'WELL 客户资料");
    bar.append(heading, button('重新查询', 'RefreshCw', () => mode==='flow'&&inlineFlow?inlineFlow.refresh():recheck()));
    if (isWA) bar.append(button('收起面板', 'PanelRightClose', () => toggle(mode, false)));
    connection = element('p', 'Supabase · 正式库进单', 'connection'); shell.append(bar, connection);
    if (!isWA) {
      const tabs = element('div', null, 'tabs'); tabs.setAttribute('role', 'tablist');
      for (const [id, label] of Object.entries(labels)) {
        const b = element('button', label); b.type = 'button'; b.dataset.mode = id; b.setAttribute('role', 'tab');
        b.addEventListener('click', () => toggle(id, true)); tabs.append(b);
      }
      shell.append(tabs);
    }
    inlineHost=element('div',null,'inline-host');shell.append(inlineHost);
    body = element('div', null, 'body'); body.setAttribute('aria-live', 'polite'); shell.append(body);
    flowBody = element('div', null, 'body'); flowBody.dataset.status = 'flow'; flowBody.hidden = true; shell.append(flowBody); root.append(drawer);
    if (isWA) {
      rail = element('nav', null, 'rail'); rail.setAttribute('aria-label', "D'WELL 测试侧栏");
      for (const [id, label] of Object.entries(labels)) {
        const b = element('button', label); b.type = 'button'; b.dataset.mode = id;
        b.title = `展开或收起 ${label}`; b.addEventListener('click', () => toggle(id, !(open && mode === id))); rail.append(b);
      }
      root.append(rail);
    } else open = true;
    root.addEventListener('keydown', e => { if (isWA && e.key === 'Escape' && open) { toggle(mode, false); rail.querySelector(`[data-mode="${mode}"]`).focus(); e.stopPropagation(); } });
    if (isWA) target.append(host); else target.prepend(host);
    updateMode(); return true;
  }
  function updateMode() {
    if (!root) return;
    drawer.hidden = isWA && !open;
    drawer.dataset.mode=mode;
    if(inlineHost)inlineHost.hidden=mode!=='crm';
    body.hidden=mode==='flow';
    flowBody.hidden=mode!=='flow';
    heading.textContent = mode === 'crm' ? "D'WELL 客户资料" : labels[mode];
    connection.textContent=mode==='ai'?'原 AI 服务 · 草稿 · 记录已启用':mode==='flow'?'Supabase · Flow Lite':'Supabase · 正式库进单';
    for (const b of root.querySelectorAll('[data-mode]')) b.setAttribute(isWA ? 'aria-expanded' : 'aria-selected', String(b.dataset.mode === mode && open));
    if(mode==='ai'){
      body.dataset.status='ai';
      const context=snapshot?.context;
      const aiReady=context?.status==='ready'||(context?.status==='phone_missing'&&context.platform==='whatsapp'&&!!context.key);
      if(!inlineAI){body.replaceChildren();if(aiReady&&globalThis.DwellAI)inlineAI=DwellAI.mount({container:body,snapshot,send:DwellTransport.send});else body.append(element('p',messages[context?.status]||'请打开顾客对话。','notice'));}
    }else if(mode==='flow'){
      if(!inlineFlow&&globalThis.DwellFlow){flowBody.replaceChildren();inlineFlow=DwellFlow.mount({container:flowBody,documentId:snapshot?.documentId,send:DwellTransport.send});}
    }
  }
  function toggle(next, expanded) {
    if (next === mode && mode === 'flow') {
      open = expanded;
      updateMode();
      return;
    }
    couponView?.dispose();couponView=null;
    inlineAI?.dispose();inlineAI=null;
    ++generation; busy = false; mode = next; open = expanded; nextRead = 0;
    rendered = ''; body.replaceChildren(); updateMode(); if (open && mode === 'crm') void query();
  }
  function notice(status, error) {
    if (!body || mode !== 'crm') return;
    const manualEntry=status==='phone_missing'&&snapshot?.context?.platform==='whatsapp'&&!!snapshot.context.key;
    if(!['not_found','loading'].includes(status)&&!manualEntry){inlineCRM?.dispose();inlineCRM=null;}
    rendered = ''; body.dataset.status = status; connection.dataset.state = status;
    body.replaceChildren(element('p', error || messages[status] || '正在读取客户资料…', 'notice'));
    if (status === 'not_found' || manualEntry) ensureInline(null);
    if (status === 'context_expired') {
      const reload = button('刷新聊天页面', 'RefreshCw', () => location.reload());
      reload.append(element('span', '刷新聊天页面')); reload.classList.add('action'); body.append(reload);
    } else if (['retry', 'error'].includes(status)) {
      const retry = button('重试连接', 'RefreshCw', () => { failures = 0; recheck(); });
      retry.append(element('span', '重试连接')); retry.classList.add('action'); body.append(retry);
    }
    if (status === 'signed_out') {
      const b = button('打开安全登录侧栏', 'LogIn', async () => {
        try {
          const result = await DwellTransport.send({ type: 'dwell-content-view', action: 'open-login' });
          if (!result?.ok) notice('error', result?.error || '请点击 Chrome 工具栏的 D’WELL 图标登录。');
        } catch (error) { failure(error); }
      }); b.append(element('span', '打开登录侧栏')); b.classList.add('action'); body.append(b);
    }
  }
  const currencyText=(amount,currency='MYR')=>amount==null?'尚未载入':`${currency==='MYR'?'RM':currency==='SGD'?'S$':currency} ${(Number(amount)/100).toLocaleString('en-MY',{minimumFractionDigits:2,maximumFractionDigits:2})}`;
  function daysSince(date){
    if(!/^\d{4}-\d{2}-\d{2}$/.test(date||''))return null;
    const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
    return Math.max(0,Math.floor((Date.parse(today+'T00:00:00Z')-Date.parse(date+'T00:00:00Z'))/86400000));
  }
  function ensureInline(profile){
    if(!inlineCRM&&globalThis.DwellInlineCRM)inlineCRM=DwellInlineCRM.mount({container:inlineHost,profileNode:body,profile,snapshot,send:DwellTransport.send,onSaved:()=>{void couponView?.refresh();nextRead=0;void query();},onBound:()=>refresh()});
  }
  function profile(value) {
    const p = value.profile, c = p?.customer;
    if (!c) { notice('unavailable'); return; }
    const signature = JSON.stringify(value);
    body.dataset.status = 'matched'; connection.dataset.state = 'matched';
    if (rendered === signature) return;
    rendered = signature;
    ensureInline(p);
    couponView?.dispose();couponView=null;
    const card=element('article',null,'legacy-customer-card'),identity=element('section',null,'identity');identity.append(element('h3',c.name||'客户'));
    card.append(identity);if(globalThis.DwellInlineCRM)card.append(DwellInlineCRM.copyControl(c));
    const wallet=element('div');card.append(wallet);body.replaceChildren(card);
    const expected={documentId:snapshot.documentId,revision:snapshot.revision},sourceKey=key;
    if(globalThis.DwellCoupons)couponView=DwellCoupons.mount({container:wallet,send:DwellTransport.send,expected,onChanged:()=>inlineCRM?.refreshCoupons?.()});
    const count=Number(p.summary?.purchase_count||0);
    const facts=element('dl',null,'profile-facts');
    const fact=(label,value)=>{const v=element('dd',String(value??'尚未载入'));facts.append(element('dt',label),v);return v;};
    const lastDate=p.summary?.last_purchase_date||null,days=daysSince(lastDate);
    fact('电话',(c.phones||[]).join(' / ')||'未记录');fact('姓名',c.name||'未记录');
    const lastAmount=fact('上一单金额',count?'正在读取…':'暂无有效购买');
    fact('总消费',currencyText(p.summary?.gmv_myr_minor||0));fact('最后下单日期',lastDate||'暂无有效购买');fact('未复购天数',days??'暂无有效购买');
    fact('客户等级',p.summary?.customer_level||c.customer_level||'未记录');
    const lastPackage=fact('上次购买配套',count?'正在读取…':'暂无有效购买'),consumption=fact('标准消耗天数','未记录');
    fact('累计购买次数',count);fact('下单渠道',c.channel||'未记录');
    const address = c.delivery_profiles?.find(d => d.is_default);
    fact('地址',address?.address||(c.addresses||[]).join('\n')||'未记录');const lastPayment=fact('付款方式',count?'正在读取…':'未记录');card.append(facts);
    const orders = element('section', null, 'section customer-history'),historyTitle=element('h3','购买记录');orders.append(historyTitle);
    const historyList=element('div'),historyStatus=element('p','正在读取购买记录…','history-note');historyStatus.setAttribute('role','status');orders.append(historyStatus,historyList);
    card.append(orders);
    if(snapshot.context.platform==='messenger'){
      const note=element('p',null,'history-note'),unbind=button('解除绑定','Unlink',async()=>{
        if(!confirm('确认解除当前对话与此客户的关联？客户和订单资料不会删除。'))return;unbind.disabled=true;
        try{const state=await DwellTransport.send({type:'dwell-inline',action:'binding-status',payload:{},expected});if(!state?.ok)throw Error('无法核对当前绑定，请刷新');
          const result=await DwellTransport.send({type:'dwell-inline',action:'unbind-customer',payload:{version:state.value.version,request_id:crypto.randomUUID()},expected});
          if(!note.isConnected||sourceKey!==key)return;if(!result?.ok)throw Error(result.error==='inline_preview_only'?'测试版未开放解除绑定，原有关联没有改变。':result.error||'解除绑定失败');refresh();
        }catch(e){if(note.isConnected)note.textContent=e.message;}finally{unbind.disabled=false;}
      });unbind.textContent='解除绑定';unbind.classList.add('customer-unbind');card.append(unbind,note);
    }
    async function loadHistory(){
      try{
        const r=await DwellTransport.send({type:'dwell-inline',action:'customer-history',payload:{},expected});
        if(!historyList.isConnected||sourceKey!==key||rendered!==signature)return;
        if(!r?.ok)throw new Error('购买记录未能载入，请重试。');
        const all=r.value.items||[],last=all.find(o=>o.nature==='formal'&&o.status==='open');
        lastAmount.textContent=last?currencyText(last.gmv_minor,last.currency):count?'未找到对应记录':'暂无有效购买';lastPayment.textContent=last?.payment|| (count?'未记录':'暂无有效购买');
        lastPackage.textContent=last?.sku_name||last?.product_name||last?.lines?.map(l=>l.sku_name).filter(Boolean).join('、')||'未记录';
        consumption.textContent=last?.consumption_snapshot?.map(x=>x.days!=null?String(x.days):'').filter(Boolean).join(' / ')||'未记录';
        historyTitle.textContent=`购买记录（最近 ${all.length} 张）`;historyStatus.textContent=all.length?'':'暂无订单记录';historyList.replaceChildren();
        let shown=0;const more=button('加载更多购买记录','ChevronDown',appendPage);more.append(element('span','加载更多购买记录'));more.classList.add('history-more');
        function appendPage(){more.remove();for(const o of all.slice(shown,shown+20)){
          const n=element('article',null,'order'),head=element('div',null,'order-head');head.append(element('time',o.order_date||'未记录日期'),element('strong',currencyText(o.gmv_minor,o.currency)));n.append(head);
          const products=o.lines?.length?o.lines.map(l=>`${l.sku_name||l.sku_code||'商品'} × ${l.quantity||1}${l.is_gift?'（赠品）':''}`).join('、'):(o.sku_name||o.product_name||'未记录产品');n.append(element('p',products));
          n.append(element('p',[o.historical?'历史导入':'新订单',o.payment||'未记录付款方式',o.platform||o.page_name,`#${o.number}`].filter(Boolean).join(' · '),'order-meta'));
          const state=o.nature==='inquiry'?'潜在咨询':({open:'',cancelled:'已取消',cod_rejected:'COD 拒收'})[o.status]||'';if(state)n.append(element('p',state,'order-meta'));
          if(o.net_minor!=null&&o.gmv_minor!=null&&o.net_minor!==o.gmv_minor)n.append(element('p','调整后净额 '+currencyText(o.net_minor,o.currency),'order-meta'));
          historyList.append(n);
        }shown=Math.min(shown+20,all.length);if(shown<all.length)historyList.append(more);}
        appendPage();
      }catch{if(historyList.isConnected&&sourceKey===key&&rendered===signature){historyStatus.textContent='购买记录暂未载入。';lastAmount.textContent=count?'暂未载入':'暂无有效购买';lastPayment.textContent=count?'暂未载入':'暂无有效购买';const retry=button('重试购买记录','RefreshCw',()=>{retry.remove();void loadHistory();});retry.append(element('span','重试购买记录'));historyList.replaceChildren(retry);}}
    }
    void loadHistory();
  }
  function expired() {
    couponView?.dispose();couponView=null;
    inlineFlow?.dispose();inlineFlow=null;
    inlineAI?.dispose();inlineAI=null;
    contextExpired = true; ++generation; busy = false; nextRead = Infinity; notice('context_expired');
  }
  function failure(error) {
    if (DwellTransport.classify(error) === 'context_expired') { expired(); return; }
    ++failures;
    nextRead = failures <= 3 ? Date.now() + [1000, 3000, 8000][failures - 1] : Infinity;
    notice(navigator.onLine === false ? 'offline' : failures <= 3 ? 'reconnecting' : 'retry');
  }
  async function query() {
    if (!snapshot || !body || !open || mode !== 'crm' || busy) return;
    if (contextExpired) { notice('context_expired'); return; }
    if (navigator.onLine === false) { nextRead = Infinity; notice('offline'); return; }
    const ticket = ++generation; busy = true; nextRead = Date.now() + 15000;
    if (!rendered) notice('loading');
    try {
      const result = await DwellTransport.send({ type: 'dwell-content-view', action: 'current-customer', expected: { documentId: snapshot.documentId, revision: snapshot.revision } });
      if (ticket !== generation || !host?.isConnected) return;
      if (!result || typeof result.ok !== 'boolean') throw new Error('message_channel_closed');
      if (!result.ok && result.retryable) throw new Error('transient_read_failure');
      failures = 0;
      // A stable conversation only needs another read after its identity changes or the user refreshes.
      nextRead = Infinity;
      if (!result?.ok) notice('error', result?.error || '读取失败，请点击重新查询。');
      else if (result.value.status === 'matched') profile(result.value);
      else notice(result.value.status);
    } catch (error) { if (ticket === generation) failure(error); }
    finally { if (ticket === generation) busy = false; }
  }
  function invalidate() { couponView?.dispose();couponView=null;inlineAI?.dispose();inlineAI=null;inlineCRM?.dispose();inlineCRM=null; ++generation; busy = false; failures = 0; rendered = ''; nextRead = 0; if (body) { if(mode==='flow'&&inlineFlow)return; body.replaceChildren(); if (mode === 'crm') notice(contextExpired ? 'context_expired' : 'transition'); else updateMode(); } }
  function refresh() { inlineFlow?.dispose();inlineFlow=null;invalidate(); if (host?.isConnected && open && mode === 'crm') void query(); }
  function sync(next) {
    snapshot = next;
    if (next.context.status === 'legacy_plugin' || next.context.status === 'unsupported') { remove(); return; }
    const newKey = JSON.stringify(next);
    if (newKey !== key) { key = newKey; invalidate(); }
    if (!mount()) return;
    if (!contextExpired && open && mode === 'crm' && Date.now() >= nextRead) void query();
  }
  addEventListener('online', () => { if (!contextExpired) { failures = 0; recheck(); } });
  addEventListener('offline', () => { invalidate(); nextRead = Infinity; notice('offline'); });
  globalThis.DwellEmbed = Object.freeze({ sync, invalidate, refresh, expired, findHost, showAI:()=>{if(mount())toggle('ai',true);},setRecheck: fn => { recheck = fn; } });
})();
