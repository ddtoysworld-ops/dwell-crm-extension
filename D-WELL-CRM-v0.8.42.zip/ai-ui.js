(() => {
  const catalogCache=new Map(),imageCache=new Map();let preloadPending=null,cacheRevision=0;
  const sectionState={assistant:true,listing:true};
  const catalogKey=(action,payload)=>action==='prompts'||action==='media'?action:action==='listings'?`listings:${payload.listing_key}`:null;
  function resetCatalog(){cacheRevision++;catalogCache.clear();imageCache.clear();preloadPending=null;}
  async function preload(send){
    if(catalogCache.size===6)return;
    if(preloadPending)return preloadPending;
    const version=cacheRevision;
    const request=send({type:'dwell-ai',action:'preload'},60000).then(result=>{
      if(version!==cacheRevision||!result?.ok)return;
      for(const entry of result.value.entries||[])if(!catalogCache.has(entry.key))catalogCache.set(entry.key,entry.value);
    }).catch(()=>{}).finally(()=>{if(preloadPending===request)preloadPending=null;});
    preloadPending=request;return request;
  }
  const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  const errors={ai_service_failed:'AI 服务暂时未返回有效结果，请稍后手动重试。',ai_timeout:'生成超时，没有自动重试；旧 AI记录可能已写入。',ai_busy:'当前对话正在生成，请等待完成。',ai_invalid_request:'请填写不超过 4000 字的内容并选择话术。',ai_empty_reply:'没有可用回复，请重新生成或输入草稿。',ai_selection_missing:'请先选中当前顾客的文字，或手动粘贴到问题栏。',ai_composer_missing:'无法唯一确认回复框，请复制草稿后手动粘贴。',ai_composer_not_empty:'回复框已有草稿，未覆盖。请先自行处理原有文字。',ai_insert_failed:'未能放入回复框，请复制草稿后手动粘贴。',workbench_context_changed:'顾客已切换，请重新核对内容。',sidebar_access_denied:'请先登录客服账号。',ai_generation_locked:'AI 生成尚未开放。'};
  function mount({container,snapshot,send,chat=globalThis.DwellAIChat}){
    let alive=true,busy=false,listingSequence=0,loadSequence=0,draftRevision=0,media=[],listings=[];
    const expected={documentId:snapshot.documentId,revision:snapshot.revision};
    const root=el('section',null,'ai-tools');
    const style=el('style',`.ai-tools{font:14px/1.55 Arial,"Microsoft YaHei",sans-serif;letter-spacing:0;padding-top:14px;color:#203b35}.ai-tools *{box-sizing:border-box}.ai-tools label{display:grid;gap:6px;margin:12px 0;font-size:13px}.ai-tools textarea,.ai-tools select{font:14px/1.5 Arial,"Microsoft YaHei",sans-serif;width:100%;min-width:0;border:1px solid #cbd8d7;border-radius:5px;padding:9px;background:white;color:#203b35}.ai-tools textarea{resize:vertical;min-height:105px}.ai-tools button{font:13px/1.4 Arial,"Microsoft YaHei",sans-serif;min-height:38px;border:1px solid #cbd8d7;border-radius:5px;background:white;color:#203b35;padding:8px;display:inline-flex;align-items:center;justify-content:center;gap:6px;cursor:pointer}.ai-tools button:disabled{opacity:.55;cursor:default}.ai-tools button svg{width:16px;height:16px;flex-shrink:0}.ai-row{display:flex;gap:7px;flex-wrap:wrap}.ai-row button{flex:1;min-width:90px}.ai-tools .ai-primary{background:#236d58;color:white;border-color:#236d58}.ai-tools .ai-status{white-space:pre-line;font-size:12px;color:#566b73;margin:10px 0}.ai-tools details{margin-top:18px;border-top:1px solid #dce5e5;padding-top:12px}.ai-tools summary{font-weight:bold;cursor:pointer;min-height:36px}.ai-tools a{color:#216294;overflow-wrap:anywhere}.ai-media{display:grid;gap:8px}.ai-media article{padding:10px 0;border-bottom:1px solid #e4e9ee}.ai-media img{display:block;width:100%;max-height:240px;object-fit:contain;margin:8px 0}.ai-tools button:focus-visible,.ai-tools textarea:focus-visible,.ai-tools select:focus-visible{outline:2px solid #286eaa;outline-offset:2px}`);root.append(style);
    const button=(label,fn,icon)=>{const b=el('button');b.type='button';b.title=label;b.setAttribute('aria-label',label);if(globalThis.lucide?.icons?.[icon])b.append(lucide.createElement(lucide.icons[icon],{'aria-hidden':'true'}));b.append(el('span',label));b.addEventListener('click',fn);return b;};
    style.textContent+=' .ai-media img[hidden]{display:none}';
    style.textContent+=' .ai-tools details,.ai-tools label{min-width:0;max-width:100%}.ai-tools>.ai-section{width:100%}.ai-tools select,.ai-tools textarea{max-width:100%}';
    style.textContent+=' .ai-tools>.ai-section{margin-top:0;padding-top:0;border-top:0;border-bottom:1px solid #dce5e5;padding-bottom:12px;margin-bottom:14px}.ai-tools>.ai-section>summary{display:flex;align-items:center;justify-content:space-between;gap:12px;list-style:none;min-height:42px;color:#203b35}.ai-tools>.ai-section>summary::-webkit-details-marker{display:none}.ai-tools>.ai-section>summary::after{content:"";width:0;height:0;border-left:5px solid #718091;border-top:4px solid transparent;border-bottom:4px solid transparent;flex-shrink:0}.ai-tools>.ai-section[open]>summary::after{transform:rotate(90deg)}.ai-tools summary:focus-visible{outline:2px solid #286eaa;outline-offset:2px}';
    function section(label,key){const node=el('details',null,'ai-section');node.dataset.section=key;node.open=sectionState[key];node.append(el('summary',label));node.addEventListener('toggle',()=>{if(alive&&node.isConnected)sectionState[key]=node.open;});root.append(node);return node;}
    const assistant=section('AI 回复助手','assistant');
    style.textContent+=' .ai-tools>.ai-section>summary::after{margin-right:3px}';
    style.textContent+=' .ai-controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}.ai-controls button{min-width:0;min-height:42px}.ai-tools .ai-full{width:100%;min-height:42px;margin:0 0 10px}.ai-tools .ai-primary{background:#1265ef;border-color:#1265ef}.ai-tools textarea::placeholder{color:#768394;opacity:1}.ai-tools textarea[name=ai_input]{min-height:100px}.ai-tools textarea[name=ai_output]{min-height:156px}';
    style.textContent+=' .ai-tools{background:#eaf0f7;border:1px solid #cfdae8;border-radius:6px;padding:10px;color:#203b35}.ai-tools>.ai-section{background:#f7f9fc;border:1px solid #d4deea;border-radius:5px;padding:0 10px 12px;margin:0 0 10px}.ai-tools>.ai-section:not([open]){padding-bottom:0}.ai-tools>.ai-section>summary{color:#1d394c;border-bottom:1px solid #dce4ed}.ai-tools>.ai-section:not([open])>summary{border-bottom:0}.ai-tools textarea,.ai-tools select,.ai-tools button:not(.ai-primary){background:#fff;border-color:#c5d2df}.ai-tools label{color:#4a6074}.ai-tools .ai-primary{background:#1265ef;border-color:#1265ef;color:#fff;font-weight:600}.ai-tools .ai-primary:hover:not(:disabled){background:#0959db}.ai-tools button:hover:not(:disabled):not(.ai-primary){background:#f0f6ff;border-color:#92b3dc}.ai-tools textarea:focus,.ai-tools select:focus{border-color:#3b82d6;box-shadow:0 0 0 2px #d9eafd;outline:0}';
    const field=(parent,label,tag,name)=>{const wrap=el('label',label),n=el(tag);n.name=name;wrap.append(n);parent.append(wrap);return n;};
    const status=el('p','正在连接现有 AI 服务…','ai-status');status.setAttribute('role','status');
    const fail=e=>{if(alive)status.textContent=e.message==='ai_message_missing'?'暂时抓不到顾客的文字问题，可以手动粘贴。':errors[e.message]||'操作未完成，请重试。';};
    async function call(action,payload={}){if(!alive)throw Error('workbench_context_changed');const key=action==='image'?payload.url:catalogKey(action,payload),cache=action==='image'?imageCache:catalogCache;if(key&&payload.refresh===true)cache.delete(key);if(key&&cache.has(key))return cache.get(key);const version=cacheRevision,result=await send({type:'dwell-ai',action,payload,expected},60000);if(!alive||version!==cacheRevision)throw Error('workbench_context_changed');if(!result?.ok)throw Error(result?.code||result?.error||'ai_service_failed');if(key){cache.set(key,result.value);if(cache===imageCache&&cache.size>8)cache.delete(cache.keys().next().value);}return result.value;}
    const prompt=field(assistant,'Prompt','select','ai_prompt'),input=field(assistant,'顾客问题 / 草稿','textarea','ai_input');input.maxLength=4000;input.placeholder='顾客问题，或大概回复内容…';
    const actions=el('div',null,'ai-controls');assistant.append(actions);
    function captureText(){try{const current=globalThis.DwellReadContext?.observe?.(document,location.href);if(current&&(current.key!==snapshot.context.key||current.status!==snapshot.context.status))throw Error('workbench_context_changed');const value=chat.latest(snapshot.context.platform);input.value=value;draftRevision++;status.textContent='已抓取顾客问题，请核对后生成。';}catch(e){fail(e);}}
    actions.append(button('抓最后问题',captureText,'MessageSquare'));
    const generateButtons=[];
    async function generate(mode,language){
      if(busy)return;if(!input.value.trim()||!prompt.value){fail(Error('ai_invalid_request'));return;}
      busy=true;const ticket=++draftRevision;for(const b of generateButtons)b.disabled=true;output.value='';status.textContent='正在生成回复…';
      try{const key=mode==='polish_translate'&&[...prompt.options].some(o=>o.value==='polish_translate')?'polish_translate':prompt.value;const result=await call('generate',{input_text:input.value,prompt_key:key,mode,target_language:language});if(ticket!==draftRevision){status.textContent='文字已修改，未覆盖目前草稿。';return;}output.value=result.reply;status.textContent='草稿已生成，尚未发送。';recommend();}
      catch(e){fail(e);}finally{busy=false;if(alive)for(const b of generateButtons)b.disabled=false;}
    }
    const generateButton=button('生成回复',()=>generate('answer_question',''),'Sparkles');generateButton.classList.add('ai-primary');generateButtons.push(generateButton);actions.append(generateButton);
    const output=field(assistant,'AI 回复草稿','textarea','ai_output');output.placeholder='等待生成 AI 回复…';
    const polishActions=el('div',null,'ai-controls');
    for(const [label,lang] of [['美化华语','zh'],['美化英文','en']]){const b=button(label,()=>generate('polish_translate',lang),'Languages');generateButtons.push(b);polishActions.append(b);}assistant.append(polishActions);
    async function copy(text,notice=status,target=output){if(!text.trim()){notice.textContent='没有可复制的话术。';return;}try{await call('check');await navigator.clipboard.writeText(text);if(alive)notice.textContent='已复制话术，尚未发送。';}catch(e){if(alive){notice.textContent='未能自动复制，请手动复制话术。';target.focus();target.select();}}}
    const insertButton=button('放进回复框',async()=>{try{await call('check');chat.insert(snapshot.context.platform,output.value);status.textContent='已放入回复框，尚未发送。';}catch(e){fail(e);}},'TextCursorInput');insertButton.classList.add('ai-full','ai-primary');
    const resetButton=button('重置记忆',()=>{draftRevision++;input.value='';output.value='';recommend();status.textContent='已清空当前问题与 AI 草稿。';},'RotateCcw');resetButton.title='清空当前问题与 AI 草稿';resetButton.classList.add('ai-full');assistant.append(insertButton,resetButton,status);
    const assets=el('details'),assetBox=el('div',null,'ai-media');assets.append(el('summary','相关素材'),assetBox);assistant.append(assets);
    function asset(parent,title,url){
      const row=el('article'),preview=el('img'),imageStatus=el('p','正在读取图片…','ai-status'),controls=el('div',null,'ai-row');
      controls.style.cssText='display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:8px;align-items:center';
      preview.alt=title;preview.referrerPolicy='no-referrer';preview.style.cssText='width:100%;height:220px;object-fit:contain;background:#f4f7fa;border:1px solid #dce5ed;border-radius:5px';preview.hidden=true;
      imageStatus.setAttribute('role','status');row.append(el('strong',title),preview,imageStatus,controls);parent.append(row);
      let dataUrl='',pending=null;
      const current=()=>{if(!alive||!row.isConnected)throw Error('workbench_context_changed');};
      function loadImage(refresh=false){
        if(dataUrl)return Promise.resolve(dataUrl);if(pending)return pending;
        preview.hidden=true;imageStatus.textContent='正在读取图片…';
        pending=call('image',{url,refresh}).then(async result=>{
          current();if(!/^data:image\/(png|jpeg|webp|gif);base64,/.test(result.data_url||''))throw Error('ai_image_failed');
          preview.src=result.data_url;await preview.decode();current();
          if(!preview.naturalWidth||preview.naturalWidth*preview.naturalHeight>40000000)throw Error('ai_image_failed');
          dataUrl=result.data_url;preview.hidden=false;imageStatus.textContent='';return dataUrl;
        }).catch(e=>{if(alive&&row.isConnected){preview.hidden=true;imageStatus.textContent='图片未能载入，请重试或打开图片。';}throw e;}).finally(()=>{pending=null;});
        return pending;
      }
      controls.append(button('重试图片',()=>{dataUrl='';void loadImage(true).catch(()=>{});},'RefreshCw'));
      const link=el('a','打开图片');link.href=url;link.target='_blank';link.rel='noopener noreferrer';controls.append(link);
      void loadImage().catch(()=>{});
    }
    function recommend(){assetBox.replaceChildren();const query=(input.value+' '+output.value).toLowerCase();const found=media.filter(m=>m.keywords.split(/[,，;；\n|]/).map(k=>k.trim().toLowerCase()).some(k=>k&&query.includes(k))).slice(0,8);for(const m of found)asset(assetBox,m.title,m.url);if(!found.length)assetBox.append(el('p','暂无匹配素材','ai-status'));}
    input.addEventListener('input',()=>{draftRevision++;});output.addEventListener('input',()=>{draftRevision++;recommend();});
    const listing=section('配套与价钱','listing');
    const listingStatus=el('p','','ai-status');listingStatus.setAttribute('role','status');listing.append(listingStatus);
    const market=field(listing,'地区与语言','select','ai_listing_market');for(const [value,label] of [['my_cn','马来西亚 · 中文'],['my_en','马来西亚 · English'],['sg_cn','新加坡 · 中文'],['sg_en','新加坡 · English']]){const op=el('option',label);op.value=value;market.append(op);}
    const pack=field(listing,'配套','select','ai_listing_package');
    style.textContent+=' .ai-listing-preview{margin:8px 0 10px;padding:9px;border:1px solid #cbd8d7;border-radius:7px;background:#fff}.ai-listing-preview img{display:block;width:100%;height:160px;object-fit:contain;border:1px solid #dce5ed;border-radius:5px;background:#f8fafc}.ai-listing-preview img[hidden],.ai-listing-retry[hidden],.ai-listing-open[hidden]{display:none}.ai-listing-block{min-width:0;margin-top:9px;border-top:1px solid #e0e7ed;padding-top:8px}.ai-listing-block-header{display:flex;align-items:center;justify-content:space-between;gap:6px;min-height:38px;font-size:12px;font-weight:600;color:#294658}.ai-listing-block-header button{min-height:32px;padding:5px 7px;flex-shrink:0}.ai-listing-preview textarea{display:block;height:110px;min-height:110px;max-height:110px;resize:none;overflow-y:auto;margin-top:4px;border:0;border-radius:0;padding:0;font-size:12px;line-height:1.45;color:#566b73}.ai-listing-preview textarea:focus-visible{outline-offset:1px}.ai-listing-actions{margin-bottom:10px}.ai-listing-actions a{display:flex;align-items:center;justify-content:center;min-height:38px;border:1px solid #cbd8d7;border-radius:5px;text-align:center;text-decoration:none;font-size:13px}.ai-listing-retry{margin:8px 0 0}';
    const listingPreview=el('div',null,'ai-listing-preview'),listingImage=el('img'),listingImageStatus=el('p','','ai-status');
    const listingText=el('textarea');listingText.name='ai_listing_text';listingText.setAttribute('aria-label','价格与配套内容');listingText.readOnly=true;
    const listingExtraText=el('textarea');listingExtraText.name='ai_listing_extra_text';listingExtraText.setAttribute('aria-label','补充话术');listingExtraText.readOnly=true;listingExtraText.placeholder='此配套尚未填写补充话术。';
    const listingRetry=button('重试图片',()=>loadListingImage(true),'RefreshCw');listingRetry.className='ai-listing-retry';listingRetry.hidden=true;
    const listingCopy=button('复制配套话术',()=>copy(listingText.value,listingStatus,listingText),'Copy');
    const listingExtraCopy=button('复制补充话术',()=>copy(listingExtraText.value,listingStatus,listingExtraText),'Copy');
    function listingBlock(label,copyButton,textarea){const block=el('div',null,'ai-listing-block'),header=el('div',null,'ai-listing-block-header');header.append(el('span',label),copyButton);block.append(header,textarea);return block;}
    listingPreview.append(listingImage,listingImageStatus,listingRetry,listingBlock('配套话术',listingCopy,listingText),listingBlock('补充话术',listingExtraCopy,listingExtraText));listing.append(listingPreview);
    const listingActions=el('div',null,'ai-listing-actions'),listingOpen=el('a','打开配套图片');
    listingOpen.target='_blank';listingOpen.rel='noopener noreferrer';listingActions.append(listingOpen);listing.append(listingActions);
    let previewSequence=0;
    async function loadListingImage(refresh=false){const item=listings[Number(pack.value)];if(!item?.image_url)return;const token=++previewSequence;listingImage.hidden=true;listingRetry.hidden=true;listingImageStatus.textContent='正在读取图片…';try{const result=await call('image',{url:item.image_url,refresh});if(token!==previewSequence)return;if(!/^data:image\/(png|jpeg|webp|gif);base64,/.test(result.data_url||''))throw Error('ai_image_failed');listingImage.src=result.data_url;await listingImage.decode();if(token!==previewSequence)return;if(!listingImage.naturalWidth||listingImage.naturalWidth*listingImage.naturalHeight>40000000)throw Error('ai_image_failed');listingImage.hidden=false;listingImageStatus.textContent='';}catch(e){if(alive&&token===previewSequence){listingImage.hidden=true;listingImageStatus.textContent='图片未能载入，请重试或打开图片。';listingRetry.hidden=false;}}}
    function showListing(){previewSequence++;const item=listings[Number(pack.value)];listingText.value=item?.text||'';listingText.scrollTop=0;listingCopy.disabled=!listingText.value.trim();listingExtraText.value=item?.extra_text||'';listingExtraText.scrollTop=0;listingExtraCopy.disabled=!listingExtraText.value.trim();listingImage.hidden=true;listingImage.removeAttribute('src');listingImage.alt=item?.title||'';listingImageStatus.textContent='';listingRetry.hidden=true;listingOpen.hidden=!item?.image_url;if(item?.image_url){listingOpen.href=item.image_url;void loadListingImage();}else listingOpen.removeAttribute('href');}
    async function loadListings(refresh=false){const token=++listingSequence;pack.replaceChildren();pack.disabled=true;listings=[];showListing();listingStatus.textContent='正在读取配套与价钱…';try{await call('check');const result=await call('listings',{listing_key:market.value,refresh});if(token!==listingSequence)return;listings=result.listings;for(const [i,item] of listings.entries()){const op=el('option',item.title);op.value=i;pack.append(op);}showListing();listingStatus.textContent=listings.length?`原 AI 配套资料 · ${listings.length} 项`:'此地区与语言暂无配套。';pack.disabled=!listings.length;}catch(e){if(alive&&token===listingSequence)listingStatus.textContent='配套读取失败，请重新读取。';}}
    market.addEventListener('change',()=>loadListings());pack.addEventListener('change',showListing);listing.append(button('重新读取配套',()=>loadListings(true),'RefreshCw'));
    async function load(refresh=false){const token=++loadSequence;try{await call('check');const result=await call('prompts',{refresh});if(token!==loadSequence)return;prompt.replaceChildren();for(const p of result.prompts){const op=el('option',p.name);op.value=p.key;prompt.append(op);}status.textContent=result.prompts.length?'':'没有可用话术。';const assets=await call('media',{refresh});if(token!==loadSequence)return;media=assets.media;recommend();}catch(e){if(token===loadSequence)fail(e);}}
    assistant.append(button('重新连接',()=>{void load(true);void loadListings(true);},'RefreshCw'));container.append(root);void load();void loadListings();
    return {dispose(){alive=false;listingSequence++;root.remove();}};
  }
  globalThis.DwellAI=Object.freeze({mount,preload,resetCatalog});
})();
