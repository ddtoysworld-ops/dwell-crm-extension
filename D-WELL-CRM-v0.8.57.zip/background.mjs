import './vendor/supabase-worker.js';
import { supabaseUrl, publishableKey } from './live-config.mjs';
import { ReadonlyCustomers, readActions, errorMessage } from './readonly-client.mjs';
import { AuthStorage } from './auth-storage.mjs';
import { viewSender, topLevelView, supported, readContext, contentSender, currentCustomerView, canUseInline } from './broker.mjs';
import { allowedWorkbenchOperation, workbenchSender, workbenchViews } from './workbench-policy.mjs';
import { workbenchWritesEnabled } from './workbench-release.mjs';
import { guardedWorkbenchFetch } from './workbench-transport.mjs';
import { createInlineService } from './inline-service.mjs';
import { inlineWritesEnabled } from './inline-release.mjs';
import {canUseAI,generateDraft} from './ai-reply-service.mjs';
import { fetchVoiceAudio, transcribeVoice } from './voice-service.mjs';
import {createFlowReader} from './flow-service.mjs';
import {createFlowOperations} from './flow-operations.mjs';
import {createFlowJobs} from './flow-jobs.mjs';
const aiBusy=new Set();
const candidateVerifications=new Map();
const storage = new AuthStorage(chrome.storage);
const client = globalThis.createDwellSupabaseClient(supabaseUrl, publishableKey, {
  auth: { storage, storageKey: 'dwell-test-extension-auth', persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
  global: { fetch: guardedWorkbenchFetch(fetch, workbenchWritesEnabled, inlineWritesEnabled) }
});
const data = new ReadonlyCustomers(client);
const flowReader = createFlowReader({config:{url:supabaseUrl,anonKey:publishableKey},getSession:async()=>{
  const {data:auth,error}=await client.auth.getSession();if(error)throw Error('flow_login_required');return auth.session;
}});
const flowOperations=createFlowOperations({config:{url:supabaseUrl,anonKey:publishableKey},getSession:async()=>(await client.auth.getSession()).data.session,onChanged:()=>flowReader.clear()});
const flowJobs=createFlowJobs({chrome,operations:flowOperations,origin:supabaseUrl,authorize:async()=>{if(!(await authState()).member)throw Error('请先登录客服账号');},context:(sender,windowId,recheck)=>readContext(chrome,contentSender(sender,chrome.runtime)?{...sender,frameId:1}:sender,windowId,recheck)});
const readFailure = error => ({ ok: false, error: errorMessage(error), retryable: /message (?:port|channel)|receiving end|could not establish connection|failed to fetch|network|timeout|timed out/i.test(String(error?.message || error)) });
let member = null, memberAt = 0, authEpoch = 0, authBusy = false;
const broadcast = message => chrome.runtime.sendMessage(message).catch(() => {});
const contentViews = new Set();
const panelLaunches = new Map();
function authChanged(resetCatalog=true) {
  candidateVerifications.clear();
  void broadcast({ type: 'dwell-auth-changed' });
  for (const tabId of contentViews) void chrome.tabs.sendMessage(tabId, { type: 'dwell-auth-update',resetCatalog }, { frameId: 0 }).catch(() => contentViews.delete(tabId));
}
client.auth.onAuthStateChange(event => { member = null; memberAt = 0; ++authEpoch; flowReader.clear(); flowOperations.clear(); flowJobs.clear(); if(event==='SIGNED_OUT')void chrome.storage.session.remove('dwell-workbench-tickets'); authChanged(!['INITIAL_SESSION','TOKEN_REFRESHED'].includes(event)); });
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
async function authState() {
  if (authBusy) return { member: null };
  const { data: auth, error } = await client.auth.getSession();
  if (error || !auth.session) { member = null; return { member: null }; }
  if (!member || Date.now() - memberAt > 15000) { member = await data.read('self'); memberAt = Date.now(); }
  return { member: { display_name: member.display_name, read_only: true } };
}
async function handle(message, sender) {
  if (!viewSender(sender, chrome.runtime)) throw new Error('sidebar_access_denied');
  if (message.action === 'auth-state') return authState();
  if (message.action === 'login') {
    if (!topLevelView(sender, chrome.runtime) || authBusy) throw new Error('sidebar_access_denied');
    authBusy = true;
    try {
      await client.auth.signOut({ scope: 'local' });
      await storage.configure(message.remember === true);
      const { error } = await client.auth.signInWithPassword({ email: String(message.email || ''), password: String(message.password || '') });
      message.password = ''; if (error) throw error;
      member = await data.read('self'); memberAt = Date.now();
      return { member: { display_name: member.display_name, read_only: true } };
    } catch (error) { await client.auth.signOut({ scope: 'local' }).catch(() => {}); throw error; }
    finally { message.password = ''; authBusy = false; authChanged(); }
  }
  if (message.action === 'logout') { ++authEpoch; member = null; memberAt = 0; await client.auth.signOut({ scope: 'local' }); await storage.removeItem('dwell-test-extension-auth'); return { member: null }; }
  if (message.action === 'context') return readContext(chrome, sender, message.windowId, message.recheck);
  if (message.action === 'resolve') {
    if (!(await authState()).member) throw new Error('sidebar_access_denied');
    const epoch = authEpoch;
    const result = await data.resolve(message.context || {});
    if (epoch !== authEpoch || authBusy) throw new Error('sidebar_access_denied');
    return result;
  }
  if(message.action==='open-ai'){
    if(!topLevelView(sender,chrome.runtime)||!(await authState()).member)throw Error('sidebar_access_denied');
    const found=await readContext(chrome,sender,message.windowId);
    if(!canUseAI(found.snapshot?.context))throw Error('workbench_context_changed');
    await chrome.tabs.sendMessage(found.tabId,{type:'dwell-open-ai'},{frameId:0});return {};
  }
  if (message.action === 'read' && readActions.has(message.readAction)) {
    if (!(await authState()).member) throw new Error('sidebar_access_denied');
    const epoch = authEpoch;
    const result = await data.read(message.readAction, message.payload || {});
    if (epoch !== authEpoch || authBusy) throw new Error('sidebar_access_denied');
    return result;
  }
  throw new Error('readonly_operation_blocked');
}
async function openWorkbench(message, sender, opening) {
  if (!workbenchViews.has(message.view)) throw new Error('readonly_operation_blocked');
  const sequence=(panelLaunches.get(sender.tab.id)||0)+1;panelLaunches.set(sender.tab.id,sequence);
  await opening;
  const first = await readContext(chrome, { ...sender, frameId: 1 });
  const current = first.snapshot;
  if (!current || current.documentId !== message.expected?.documentId || current.revision !== message.expected?.revision || current.context.status !== 'ready') throw new Error('workbench_context_changed');
  if (!(await authState()).member) throw new Error('sidebar_access_denied');
  const epoch = authEpoch;
  const result = await currentCustomerView({ api: chrome, sender, expected: message.expected, auth: authState, data, epoch: () => authEpoch });
  if (!['matched','not_found'].includes(result.status)) throw new Error('workbench_context_changed');
  const { data: auth } = await client.auth.getSession();
  if (!auth.session || epoch !== authEpoch) throw new Error('sidebar_access_denied');
  const final = (await readContext(chrome, { ...sender, frameId: 1 })).snapshot;
  if (!final || final.documentId !== current.documentId || final.revision !== current.revision || final.context.key !== current.context.key) throw new Error('workbench_context_changed');
  const ticket = crypto.randomUUID();
  const saved = (await chrome.storage.session.get('dwell-workbench-tickets'))['dwell-workbench-tickets'] || {};
  const tickets = Object.fromEntries(Object.entries(saved).filter(([,v]) => v.expires > Date.now()).slice(-19));
  if(panelLaunches.get(sender.tab.id)!==sequence)throw new Error('workbench_context_changed');
  tickets[ticket] = { view: message.view, context: current.context, tabId:sender.tab.id,documentId:current.documentId,revision:current.revision, customerId: result.profile?.customer?.id || null, userId: auth.session.user.id, expires: Date.now()+3600000 };
  await chrome.storage.session.set({ 'dwell-workbench-tickets': tickets });
  await chrome.sidePanel.setOptions({tabId:sender.tab.id,path:'workbench/index.html?ticket='+ticket+'&surface=sidepanel',enabled:true});
  return {};
}
async function currentWorkbench(sender,ticket) {
  if(new URL(sender.url).searchParams.get('ticket')!==ticket)throw new Error('workbench_ticket_expired');
  const saved=(await chrome.storage.session.get('dwell-workbench-tickets'))['dwell-workbench-tickets']||{};
  const item=saved[ticket],{data:auth}=await client.auth.getSession();
  if(!item||item.expires<Date.now()||item.userId!==auth.session?.user.id)throw new Error('workbench_ticket_expired');
  const source=await readContext(chrome,{frameId:1,tab:{id:item.tabId}});
  if(source.snapshot?.documentId!==item.documentId||source.snapshot?.revision!==item.revision||source.snapshot?.context?.key!==item.context.key)throw new Error('workbench_context_changed');
  return item;
}
async function handleWorkbench(message, sender) {
  if (!workbenchSender(sender, chrome.runtime)) throw new Error('sidebar_access_denied');
  if (!(await authState()).member) throw new Error('sidebar_access_denied');
  const item=await currentWorkbench(sender,message.ticket);
  if(message.action==='check-context')return {current:true};
  if (message.action === 'launch') {
    const epoch = authEpoch;
    const p = item.customerId ? await data.read('profile', { id: item.customerId }) : null;
    await currentWorkbench(sender,message.ticket);
    if (epoch !== authEpoch) throw new Error('sidebar_access_denied');
    return { view: item.view, context: item.context, customer: p?.customer || null, preview_only: !workbenchWritesEnabled };
  }
  if (message.action !== 'rpc' || !allowedWorkbenchOperation(message.name,message.args,workbenchWritesEnabled)) throw new Error('workbench_preview_only');
  const epoch = authEpoch;
  const { data: value, error } = await client.rpc(message.name, message.args);
  if (error) throw error;
  await currentWorkbench(sender,message.ticket);
  if (epoch !== authEpoch || authBusy) throw new Error('sidebar_access_denied');
  return value;
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if(message?.type==='dwell-voice'){
    if(!contentSender(sender,chrome.runtime)){respond({ok:false,error:'语音操作只限当前客服对话。'});return;}
    const epoch=authEpoch;
    const assertCurrent=async()=>{
      const found=await readContext(chrome,{...sender,frameId:1});
      if(found.snapshot?.documentId!==message.expected?.documentId||
          found.snapshot?.revision!==message.expected?.revision||
          !canUseAI(found.snapshot?.context))throw Error('当前对话已改变，请重新抓取语音。');
      if(!(await authState()).member||epoch!==authEpoch)throw Error('请先登录客服账号。');
    };
    (async()=>{
      await assertCurrent();
      let value;
      if(message.action==='VOICE_FETCH_MESSENGER_AUDIO'){
        value=await fetchVoiceAudio(message.payload?.sourceUrl,sender.url);
      }else if(message.action==='VOICE_TRANSCRIBE'){
        const {data:auth,error}=await client.auth.getSession();
        if(error||!auth.session?.access_token)throw Error('请先登录客服账号。');
        await assertCurrent();
        value=await transcribeVoice(message.payload||{},{url:supabaseUrl,key:publishableKey,token:auth.session.access_token});
      }else throw Error('不支持这个语音操作。');
      await assertCurrent();
      return value;
    })().then(value=>respond({ok:true,value}),error=>respond({ok:false,error:error.message,code:error.code||'UNKNOWN',diagnosticData:error.diagnosticData||null}));return true;
  }
  if(['dwell-flow-ops','dwell-flow-job','dwell-flow-progress'].includes(message?.type)){
    if(!contentSender(sender,chrome.runtime)&&!topLevelView(sender,chrome.runtime)){respond({ok:false,error:'Flow 访问被拒绝'});return;}
    const epoch=authEpoch;
    const check=async()=>{
      if(!(await authState()).member||epoch!==authEpoch)throw Error('请先登录客服账号');
      if(contentSender(sender,chrome.runtime)&&!['check'].includes(message.action)){
        const found=await readContext(chrome,{...sender,frameId:1});
        if(!found.snapshot||found.snapshot.documentId!==message.documentId||['legacy_plugin','unsupported'].includes(found.snapshot.context?.status))throw Error('插件页面已改变，请刷新后重试');
      }
    };
    if(sender.tab?.id)contentViews.add(sender.tab.id);
    (async()=>{
      if(message.type==='dwell-flow-progress'){flowJobs.progress(message,sender);return {};}
      await check();
      if(message.type==='dwell-flow-job')return flowJobs.invoke(message.action,message,sender);
      if(message.action==='logout'){await client.auth.signOut({scope:'local'});await storage.removeItem('dwell-test-extension-auth');return {};}
      return flowOperations.invoke(message.action,message.payload,`${sender.tab?.id||sender.url}:${message.documentId||'panel'}`,check);
    })().then(value=>respond({ok:true,value}),e=>respond({ok:false,error:e.message}));return true;
  }
  if(message?.type==='dwell-flow'){
    if(!contentSender(sender,chrome.runtime)&&!topLevelView(sender,chrome.runtime)){respond({ok:false,code:'flow_access_denied'});return;}
    if(!['list','media'].includes(message.action)){respond({ok:false,code:'flow_readonly'});return;}
    const epoch=authEpoch;
    if(sender.tab?.id)contentViews.add(sender.tab.id);
    const check=async()=>{
      if(!(await authState()).member||epoch!==authEpoch)throw Error('flow_login_required');
      if(contentSender(sender,chrome.runtime)){
        const found=await readContext(chrome,{...sender,frameId:1});
        if(!found.snapshot||found.snapshot.documentId!==message.documentId||['legacy_plugin','unsupported'].includes(found.snapshot.context?.status))throw Error('flow_session_changed');
      }
    };
    (async()=>{await check();const result=message.action==='list'?await flowReader.list(message.force===true):await flowReader.media(message.flowId,message.stepId);await check();return result;})()
      .then(value=>respond({ok:true,value}),error=>respond({ok:false,code:error.message}));return true;
  }
  if(message?.type==='dwell-ai'){
    if(!contentSender(sender,chrome.runtime)){respond({ok:false,code:'sidebar_access_denied'});return;}
    const epoch=authEpoch,tabId=sender.tab.id;
    contentViews.add(tabId);
    const assertAccess=async()=>{if(!(await authState()).member||epoch!==authEpoch)throw Error('sidebar_access_denied');};
    if(message.action==='preload'){
      contentViews.add(tabId);
      (async()=>{
        const found=await readContext(chrome,{...sender,frameId:1});
        if(!found.snapshot||['legacy_plugin','unsupported'].includes(found.snapshot.context?.status))throw Error('workbench_context_changed');
        await assertAccess();return {entries:[]};
      })().then(value=>respond({ok:true,value}),error=>respond({ok:false,code:error.message}));return true;
    }
    const assertCurrent=async()=>{
      const found=await readContext(chrome,{...sender,frameId:1});
      if(found.snapshot?.documentId!==message.expected?.documentId||found.snapshot?.revision!==message.expected?.revision||!canUseAI(found.snapshot?.context))throw Error('workbench_context_changed');
      if(!(await authState()).member||epoch!==authEpoch)throw Error('sidebar_access_denied');
    };
    const generating=message.action==='generate';
    if(generating&&aiBusy.has(tabId)){respond({ok:false,code:'ai_busy'});return;}
    if(generating)aiBusy.add(tabId);
    const run=async()=>{
      if(message.action==='content'){
        await assertCurrent();
        const {data:result,error}=await client.rpc('dwell_ops_ai_content_api',{p_action:'list',p_payload:{}});
        if(error)throw error;
        await assertCurrent();
        const options=(result?.options||[]).filter(option=>option.active===true&&['market','language'].includes(option.kind));
        const available=new Set(options.map(option=>`${option.kind}:${option.code}`));
        return {options:options
          .map(option=>({kind:option.kind,code:option.code,label:option.label,sort_order:option.sort_order})),
          items:(result?.items||[]).filter(item=>item.active===true&&(!Array.isArray(result?.options)||
            available.has(`market:${item.market}`)&&available.has(`language:${item.language}`))).map(item=>({
          id:item.id,package_name:item.package_name,
          market:item.market,language:item.language,image_path:item.image_path,
          image_url:typeof item.image_path==='string'&&/^content\/[0-9a-f-]{36}\.(jpg|png|webp)$/.test(item.image_path)?`${supabaseUrl}/storage/v1/object/public/dwell-ai-packages/${item.image_path}`:'',
          copy_primary:item.copy_primary,copy_secondary:item.copy_secondary
        }))};
      }
      if(message.action==='agents'){
        await assertCurrent();
        const {data:result,error}=await client.rpc('dwell_ops_ai_agents_api',{p_action:'list',p_payload:{}});
        if(error)throw error;
        await assertCurrent();
        return {agents:(result?.agents||[]).filter(item=>item.active===true).map(item=>({id:item.id,name:item.name,language:item.language,is_default:item.is_default}))};
      }
      if(['memory-read','memory-save','memory-extract'].includes(message.action)){
        await assertCurrent();
        const match=await currentCustomerView({api:chrome,sender,expected:message.expected,auth:authState,data,epoch:()=>authEpoch});
        if(match.status!=='matched')return {status:match.status};
        const customerId=match.profile.customer.id;
        if(message.action==='memory-extract'){
          const customerText=message.payload?.customer_text;
          if(typeof customerText!=='string'||!customerText.trim()||customerText.length>4000)throw Error('ai_memory_invalid_request');
          const {data:auth,error}=await client.auth.getSession();
          if(error||!auth.session?.access_token)throw Error('ai_login_required');
          const response=await fetch(`${supabaseUrl}/functions/v1/dwell-ai-memory`,{method:'POST',
            headers:{authorization:`Bearer ${auth.session.access_token}`,apikey:publishableKey,'content-type':'application/json'},
            body:JSON.stringify({customer_id:customerId,customer_text:customerText})});
          const result=await response.json().catch(()=>({}));
          await assertCurrent();
          if(!response.ok)throw Error(result.code||'ai_memory_unavailable');
          return {status:'matched',...result};
        }
        const payload=message.action==='memory-save'?{
          customer_id:customerId,facts:message.payload?.facts,version:message.payload?.version,
          request_id:message.payload?.request_id}:{customer_id:customerId};
        const {data:memory,error}=await client.rpc('dwell_ops_customer_memory_api',
          {p_action:message.action==='memory-save'?'save':'get',p_payload:payload});
        if(error)throw error;
        if(message.action==='memory-save'){await assertCurrent();return {status:'matched',memory,match_source:match.match_source};}
        const {data:settings,error:settingsError}=await client.rpc('dwell_ops_customer_memory_api',{p_action:'settings',p_payload:{}});
        if(settingsError)throw settingsError;
        await assertCurrent();
        return {status:'matched',memory,settings,match_source:match.match_source};
      }
      if(message.action==='content-image'){
        await assertCurrent();
        const path=message.payload?.path;
        if(typeof path!=='string'||!/^(?:content|agent-media)\/[0-9a-f-]{36}\.(?:jpg|png|webp)$/.test(path))throw Error('ai_image_invalid');
        const response=await fetch(`${supabaseUrl}/storage/v1/object/public/dwell-ai-packages/${path}`,{redirect:'error',credentials:'omit'});
        if(!response.ok||!/^image\/(jpeg|png|webp)/.test(response.headers.get('content-type')||''))throw Error('ai_image_failed');
        const bytes=new Uint8Array(await response.arrayBuffer());
        if(bytes.length<1||bytes.length>5242880)throw Error('ai_image_failed');
        let encoded='';for(let offset=0;offset<bytes.length;offset+=32768)encoded+=String.fromCharCode(...bytes.subarray(offset,offset+32768));
        await assertCurrent();
        return {data_url:`data:${response.headers.get('content-type').split(';')[0]};base64,${btoa(encoded)}`};
      }
      if(message.action==='check'){
        await assertCurrent();return {};
      }
      if(message.action==='generate'){
        await assertCurrent();
        const {data:auth,error}=await client.auth.getSession();
        if(error||!auth.session?.access_token)throw Error('ai_login_required');
        return generateDraft({url:supabaseUrl,anonKey:publishableKey,token:auth.session.access_token,
          payload:message.payload||{},assertCurrent});
      }
      throw Error('ai_action_invalid');
    };
    run().then(value=>respond({ok:true,value}),error=>respond({ok:false,code:error.message})).finally(()=>{if(generating)aiBusy.delete(tabId);});return true;
  }
  if(message?.type==='dwell-inline' && contentSender(sender,chrome.runtime)){
    const epoch=authEpoch;
    const prior=candidateVerifications.get(sender.tab.id);
    const verifiedCandidate=prior?.documentId===message.expected?.documentId&&prior?.revision===message.expected?.revision&&prior?.authEpoch===epoch?prior:null;
    const assertCurrent=async()=>{
      const found=await readContext(chrome,{...sender,frameId:1});
      if(found.snapshot?.documentId!==message.expected?.documentId||found.snapshot?.revision!==message.expected?.revision||!canUseInline(found.snapshot?.context))throw new Error('workbench_context_changed');
      if(!(await authState()).member||authEpoch!==epoch)throw new Error('sidebar_access_denied');
      return found.snapshot.context;
    };
    const service=createInlineService({writesEnabled:inlineWritesEnabled,verifiedCandidate,assertCurrent,
      rpc:async(name,args)=>{const {data:value,error}=await client.rpc(name,args);if(error)throw error;return value;},
      resolve:async()=>{const context=await assertCurrent();
        const found=await data.resolve(context);
        if(['conflict','unavailable','unlinked'].includes(found.status))return {customer:null,context};
        const profile=found.items?.length===1?await data.read('profile',{id:found.items[0].id}):null;
        return {customer:profile?.customer&&profile.customer.id===found.items?.[0]?.id&&profile.customer.active!==false?profile.customer:null,context,match_source:found.match_source||'identity'};}
    });
    service(message.action,message.payload).then(value=>{
      if(message.action==='candidate-verify')candidateVerifications.set(sender.tab.id,{documentId:message.expected.documentId,revision:message.expected.revision,authEpoch:epoch,id:value.customer_id,phone:value.verified_phone});
      respond({ok:true,value});
    },e=>respond({ok:false,error:e.message,code:e.code||e.message}));return true;
  }
  if (message?.type === 'dwell-workbench') {
    handleWorkbench(message,sender).then(value=>respond({ok:true,value}),error=>respond({ok:false,error:/workbench_context_changed/.test(error.message)?'当前对话已改变，旧草稿不能继续提交。请从新顾客的资料区重新打开。':/workbench_preview_only/.test(error.message)?'测试版未开放写入，没有保存任何资料。':/workbench_ticket_expired/.test(error.message)?'工作台入口已失效，请从当前顾客对话重新打开。':errorMessage(error),code:error.code||error.message}));return true;
  }
  if (message?.type === 'dwell-content-view' && contentSender(sender, chrome.runtime)) {
    if (message.action === 'open-workbench') {
      if(!workbenchViews.has(message.view)){respond({ok:false,error:'不支持此操作。'});return;}
      // Open synchronously while Chrome still recognizes the click's user gesture.
      const opening=chrome.sidePanel.open({tabId:sender.tab.id});
      openWorkbench(message,sender,opening).then(value=>respond({ok:true,value}),error=>respond({ok:false,error:/workbench_context_changed/.test(error.message)?'当前对话已改变，请重新查询后再打开。':errorMessage(error)}));return true;
    }
    if (message.action === 'open-login') {
      chrome.sidePanel.open({ windowId: sender.tab.windowId }).then(() => respond({ ok: true, value: {} }), () => respond({ ok: false, error: '请点击 Chrome 工具栏的 D’WELL 图标打开登录侧栏。' })); return true;
    }
    if (message.action !== 'current-customer') { respond({ ok: false, error: '只允许读取当前对话客户。' }); return; }
    contentViews.add(sender.tab.id);
    currentCustomerView({ api: chrome, sender, expected: message.expected, auth: authState, data, epoch: () => authEpoch }).then(value => respond({ ok: true, value }), error => respond(readFailure(error))); return true;
  }
  if (message?.type === 'dwell-context-invalidated' && sender.id === chrome.runtime.id && sender.frameId === 0 && supported(sender.tab?.url)) { void broadcast({ type: 'dwell-context-update', tabId: sender.tab.id }); return; }
  if (message?.type !== 'dwell-view') return;
  if (message.action === 'open-login' && viewSender(sender, chrome.runtime) && sender.tab?.windowId != null) {
    chrome.sidePanel.open({ windowId: sender.tab.windowId }).then(() => respond({ ok: true, value: {} }), () => respond({ ok: false, error: '请点击 Chrome 工具栏的 D’WELL 图标打开登录侧栏。' })); return true;
  }
  handle(message, sender).then(value => respond({ ok: true, value }), error => respond({ ok: false, error: errorMessage(error) })); return true;
});
chrome.tabs.onActivated.addListener(info => void broadcast({ type: 'dwell-tab-update', windowId: info.windowId }));
chrome.tabs.onUpdated.addListener((tabId, change) => { if (change.url || change.status === 'loading') void broadcast({ type: 'dwell-context-update', tabId }); });
chrome.tabs.onRemoved.addListener(tabId => { contentViews.delete(tabId);panelLaunches.delete(tabId);candidateVerifications.delete(tabId); void broadcast({ type: 'dwell-context-update', tabId }); });
