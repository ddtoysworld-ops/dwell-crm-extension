# AI reply photo recommendation (0.8.47)

- The AI reply draft recommends an existing uploaded package photo immediately below the draft.
- A package explicitly selected before generation wins. Otherwise, only one exact package-name match in the generated reply, for the currently selected market and language, is accepted.
- Missing photos, ambiguous matches and unrelated replies do not suggest another package's image.
- The image is read through the existing authenticated CRM extension action. Staff can copy or open it, then send it manually. No automatic customer message or image upload occurs.
- Starting a new generation or resetting the draft clears an older recommendation. Changing the chat unmounts the panel and invalidates the context.
- No database, Edge Function, site or GitHub changes are part of this package.
