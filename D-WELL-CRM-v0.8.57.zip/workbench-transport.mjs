import { guardedFetch } from './readonly-client.mjs';
import { allowedWorkbenchOperation } from './workbench-policy.mjs';
import { supabaseUrl } from './live-config.mjs';
export function guardedWorkbenchFetch(transport = fetch, writesEnabled = false, inlineEnabled = false) {
  const fallback = guardedFetch(transport);
  const can=feature=>inlineEnabled===true||Boolean(inlineEnabled?.[feature]);
  return (input, options = {}) => {
    const url = new URL(typeof input === 'string' ? input : input.url || String(input));
    if (url.origin === supabaseUrl && options.method?.toUpperCase() === 'POST' && url.pathname.startsWith('/rest/v1/rpc/')) {
      let args;
      try { args = JSON.parse(options.body); } catch { throw new Error('readonly_request_invalid'); }
      if (allowedWorkbenchOperation(url.pathname.slice('/rest/v1/rpc/'.length), args, writesEnabled)) return transport(input, { ...options, redirect: 'error', credentials: 'omit' });
      const name=url.pathname.slice('/rest/v1/rpc/'.length);
      if(name==='dwell_ops_ai_content_api'&&args&&Object.keys(args).sort().join(',')==='p_action,p_payload'&&args.p_action==='list'&&args.p_payload&&Object.keys(args.p_payload).length===0)
        return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(name==='dwell_ops_ai_agents_api'&&args&&Object.keys(args).sort().join(',')==='p_action,p_payload'&&args.p_action==='list'&&args.p_payload&&Object.keys(args.p_payload).length===0)
        return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(name==='dwell_ops_customer_memory_api'&&args&&Object.keys(args).sort().join(',')==='p_action,p_payload'&&
        args.p_payload&&typeof args.p_payload==='object'&&!Array.isArray(args.p_payload)&&
        (args.p_action==='settings'&&Object.keys(args.p_payload).length===0||
         args.p_action==='get'&&/^[0-9a-f-]{36}$/i.test(args.p_payload.customer_id||'')||
         args.p_action==='save'&&/^[0-9a-f-]{36}$/i.test(args.p_payload.customer_id||'')&&
           /^[0-9a-f-]{36}$/i.test(args.p_payload.request_id||'')&&
           Number.isInteger(args.p_payload.version)&&args.p_payload.version>=0&&
           args.p_payload.facts&&typeof args.p_payload.facts==='object'&&!Array.isArray(args.p_payload.facts)))
        return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('coupons')&&name==='dwell_ops_coupon_wallet'&&['grant','reserve','release'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('coupon_redeem')&&name==='dwell_ops_coupon_manual_redeem'&&args&&typeof args==='object'&&!Array.isArray(args)&&Object.keys(args).sort().join(',')==='p_coupon_id,p_customer_id,p_reason,p_request_id'&&/^[0-9a-f-]{36}$/i.test(args.p_coupon_id)&&/^[0-9a-f-]{36}$/i.test(args.p_customer_id)&&/^[0-9a-f-]{36}$/i.test(args.p_request_id)&&typeof args.p_reason==='string'&&args.p_reason.trim().length>0&&args.p_reason.length<=300)return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('bindings')&&name==='dwell_ops_sidebar_crm'&&['bind','unbind'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('orders')&&name==='dwell_ops_sidebar_crm'&&args.p_action==='save_order')return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('orders')&&name==='dwell_ops_orders_api'&&args.p_action==='save'&&args.p_payload&&typeof args.p_payload==='object'&&!Array.isArray(args.p_payload)&&!args.p_payload.id&&
        /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(args.p_payload.request_id||'')&&
        /^(60|65)\d{7,12}$/.test(args.p_payload.phone||''))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('referralCheck')&&name==='dwell_ops_referral_check_new'&&args&&typeof args==='object'&&!Array.isArray(args)&&Object.keys(args).length===1&&/^(60|65)\d{7,12}$/.test(args.p_phone))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('referrals')&&name==='dwell_ops_referrals_api'&&['approve','delivery','ship','ship_self_postage'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('legacy_prizes')&&name==='dwell_ops_customer_legacy_prize_action'&&args&&typeof args==='object'&&!Array.isArray(args)&&
        Object.keys(args).sort().join(',')==='p_action,p_customer_id,p_prize_id,p_tracking_number,p_version'&&
        ['hold','ship'].includes(args.p_action)&&
        /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(args.p_customer_id)&&
        /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(args.p_prize_id)&&
        Number.isInteger(args.p_version)&&args.p_version>0&&
        (args.p_action==='hold'&&args.p_tracking_number===null||
          args.p_action==='ship'&&typeof args.p_tracking_number==='string'&&args.p_tracking_number.trim().length>0&&args.p_tracking_number.length<=100))
        return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('lucky')&&name==='dwell_ops_plugin_lucky'&&['grant','link','ship'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('lucky_live')&&name==='dwell_ops_plugin_lucky_live'&&['grant','link','ship'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
    }
    return fallback(input, options);
  };
}
