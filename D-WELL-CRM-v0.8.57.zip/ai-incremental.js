(() => {
  async function digest(value){
    const bytes=new TextEncoder().encode(value);
    const hash=await crypto.subtle.digest('SHA-256',bytes);
    return [...new Uint8Array(hash)].map(byte=>byte.toString(16).padStart(2,'0')).join('');
  }
  async function tokens(contextKey,entries){
    return Promise.all(entries.map(entry=>digest(`${contextKey}\n${entry.kind||'text'}\n${entry.id||''}\n${entry.incoming?'in':'out'}\n${entry.text||''}`)));
  }
  function fresh(entries,entryTokens,seen){return entries.filter((_,index)=>!seen.has(entryTokens[index]));}
  function lines(entries){return entries.map(entry=>entry.line||`${entry.incoming?'顾客':'客服'}：${entry.text}`).join('\n');}
  function customerText(entries){return entries.filter(entry=>entry.incoming).map(entry=>entry.text).join('\n').slice(0,4000);}
  globalThis.DwellAIIncremental=Object.freeze({digest,tokens,fresh,lines,customerText});
})();
