(() => {
  const catalogCache=new Map(),imageCache=new Map();let preloadPending=null,cacheRevision=0;
  const sectionState={assistant:true,listing:true};
  const catalogKey=()=>null;
  function resetCatalog(){cacheRevision++;catalogCache.clear();imageCache.clear();preloadPending=null;}
  async function preload(){return;}
  const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
  const errors={ai_service_failed:'AI 服务暂时未返回有效结果，请稍后手动重试。',ai_key_not_configured:'AI 密钥尚未配置，请联系管理员。',ai_catalog_unavailable:'配套资料暂时无法读取。',ai_content_unavailable:'所选配套已停用或更改，请重新选择。',ai_login_required:'请先登录客服账号。',ai_busy:'当前对话正在生成，请等待完成。',ai_invalid_request:'请填写不超过 4000 字的内容。',ai_message_missing:'当前已加载的对话里没有顾客发来的文字或语音。自己发出的消息不会当成顾客问题；请切换顾客对话，或手动粘贴。',ai_empty_reply:'没有可用回复，请重新生成或输入草稿。',ai_selection_missing:'请先选中当前顾客的文字，或手动粘贴到问题栏。',ai_composer_missing:'无法唯一确认回复框，请复制草稿后手动粘贴。',ai_composer_not_empty:'回复框已有草稿，未覆盖。请先自行处理原有文字。',ai_insert_failed:'未能放入回复框，请复制草稿后手动粘贴。',workbench_context_changed:'顾客已切换，请重新核对内容。',sidebar_access_denied:'请先登录客服账号。',ai_generation_locked:'AI 生成尚未开放。'};
  function mount({container,snapshot,send,chat=globalThis.DwellAIChat}){
    let alive=true,busy=false,listingSequence=0,loadSequence=0,draftRevision=0,listings=[],recommendedContentId=null,recommendedMedia=null,photoEligible=false;
    const expected={documentId:snapshot.documentId,revision:snapshot.revision};
    const root=el('section',null,'ai-tools');
    const style=el('style',`.ai-tools{font:14px/1.55 Arial,"Microsoft YaHei",sans-serif;letter-spacing:0;padding-top:14px;color:#203b35}.ai-tools *{box-sizing:border-box}.ai-tools label{display:grid;gap:6px;margin:12px 0;font-size:13px}.ai-tools textarea,.ai-tools select{font:14px/1.5 Arial,"Microsoft YaHei",sans-serif;width:100%;min-width:0;border:1px solid #cbd8d7;border-radius:5px;padding:9px;background:white;color:#203b35}.ai-tools textarea{resize:vertical;min-height:105px}.ai-tools button{font:13px/1.4 Arial,"Microsoft YaHei",sans-serif;min-height:38px;border:1px solid #cbd8d7;border-radius:5px;background:white;color:#203b35;padding:8px;display:inline-flex;align-items:center;justify-content:center;gap:6px;cursor:pointer}.ai-tools button:disabled{opacity:.55;cursor:default}.ai-tools button svg{width:16px;height:16px;flex-shrink:0}.ai-row{display:flex;gap:7px;flex-wrap:wrap}.ai-row button{flex:1;min-width:90px}.ai-tools .ai-primary{background:#236d58;color:white;border-color:#236d58}.ai-tools .ai-status{white-space:pre-line;font-size:12px;color:#566b73;margin:10px 0}.ai-tools details{margin-top:18px;border-top:1px solid #dce5e5;padding-top:12px}.ai-tools summary{font-weight:bold;cursor:pointer;min-height:36px}.ai-tools a{color:#216294;overflow-wrap:anywhere}.ai-media{display:grid;gap:8px}.ai-media article{padding:10px 0;border-bottom:1px solid #e4e9ee}.ai-media img{display:block;width:100%;max-height:240px;object-fit:contain;margin:8px 0}.ai-tools button:focus-visible,.ai-tools textarea:focus-visible,.ai-tools select:focus-visible{outline:2px solid #286eaa;outline-offset:2px}`);root.append(style);
    const button=(label,fn,icon)=>{const b=el('button');b.type='button';b.title=label;b.setAttribute('aria-label',label);if(globalThis.lucide?.icons?.[icon])b.append(lucide.createElement(lucide.icons[icon],{'aria-hidden':'true'}));b.append(el('span',label));b.addEventListener('click',fn);return b;};
    style.textContent+=' .ai-media img[hidden]{display:none}';
    style.textContent+=' .ai-tools details,.ai-tools label{min-width:0;max-width:100%}.ai-tools>.ai-section{width:100%}.ai-tools select,.ai-tools textarea{max-width:100%}';
    style.textContent+=' .ai-tools>.ai-section{margin-top:0;padding-top:0;border-top:0;border-bottom:1px solid #dce5e5;padding-bottom:12px;margin-bottom:14px}.ai-tools>.ai-section>summary{display:flex;align-items:center;justify-content:space-between;gap:12px;list-style:none;min-height:42px;color:#203b35}.ai-tools>.ai-section>summary::-webkit-details-marker{display:none}.ai-tools>.ai-section>summary::after{content:"";width:0;height:0;border-left:5px solid #718091;border-top:4px solid transparent;border-bottom:4px solid transparent;flex-shrink:0}.ai-tools>.ai-section[open]>summary::after{transform:rotate(90deg)}.ai-tools summary:focus-visible{outline:2px solid #286eaa;outline-offset:2px}';
    function section(label,key){const node=el('details',null,'ai-section');node.dataset.section=key;node.open=sectionState[key];node.append(el('summary',label));node.addEventListener('toggle',()=>{if(alive&&node.isConnected)sectionState[key]=node.open;});root.append(node);return node;}
    const assistant=section('AI 回复助手','assistant');
    style.textContent+=' .ai-tools>.ai-section>summary::after{margin-right:3px}';
    style.textContent+=' .ai-controls{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;margin:12px 0}.ai-controls button{min-width:0;min-height:42px}.ai-tools .ai-full{width:100%;min-height:42px;margin:0 0 10px}.ai-tools .ai-primary{background:#1265ef;border-color:#1265ef}.ai-tools textarea::placeholder{color:#768394;opacity:1}.ai-tools textarea[name=ai_input]{min-height:100px}.ai-tools textarea[name=ai_output]{min-height:156px}';
    style.textContent+=' .ai-tools{background:#eaf0f7;border:1px solid #cfdae8;border-radius:6px;padding:10px;color:#203b35}.ai-tools>.ai-section{background:#f7f9fc;border:1px solid #d4deea;border-radius:5px;padding:0 10px 12px;margin:0 0 10px}.ai-tools>.ai-section:not([open]){padding-bottom:0}.ai-tools>.ai-section>summary{color:#1d394c;border-bottom:1px solid #dce4ed}.ai-tools>.ai-section:not([open])>summary{border-bottom:0}.ai-tools textarea,.ai-tools select,.ai-tools button:not(.ai-primary){background:#fff;border-color:#c5d2df}.ai-tools label{color:#4a6074}.ai-tools .ai-primary{background:#1265ef;border-color:#1265ef;color:#fff;font-weight:600}.ai-tools .ai-primary:hover:not(:disabled){background:#0959db}.ai-tools button:hover:not(:disabled):not(.ai-primary){background:#f0f6ff;border-color:#92b3dc}.ai-tools textarea:focus,.ai-tools select:focus{border-color:#3b82d6;box-shadow:0 0 0 2px #d9eafd;outline:0}';
    const field=(parent,label,tag,name)=>{const wrap=el('label',label),n=el(tag);n.name=name;wrap.append(n);parent.append(wrap);return n;};
    const status=el('p','正在读取配套资料…','ai-status');status.setAttribute('role','status');
    const fail=e=>{if(alive)status.textContent=errors[e.message]||'操作未完成，请重试。';};
    async function call(action,payload={}){if(!alive)throw Error('workbench_context_changed');const key=action==='image'?payload.url:action==='content-image'?payload.path:action==='content'?'content':catalogKey(action,payload),cache=action==='image'||action==='content-image'?imageCache:catalogCache;if(key&&payload.refresh===true)cache.delete(key);if(key&&cache.has(key))return cache.get(key);const version=cacheRevision,result=await send({type:'dwell-ai',action,payload,expected},60000);if(!alive||version!==cacheRevision)throw Error('workbench_context_changed');if(!result?.ok)throw Error(result?.code||result?.error||'ai_service_failed');if(key){cache.set(key,result.value);if(cache===imageCache&&cache.size>8)cache.delete(cache.keys().next().value);}return result.value;}
    const agentSelect=field(assistant,'AI Agent','select','ai_agent');agentSelect.disabled=true;
    const memoryLabels={concern:'主要问题',symptoms:'症状',age:'年龄',medications:'正在使用的药',triggers:'什么情况下不舒服',progress:'使用后变化'};
    const memoryPanel=el('details',null,'ai-memory'),memoryTitle=el('summary','顾客情况'),memoryNotice=el('p','正在读取顾客情况…','ai-memory-note'),memoryList=el('div'),memoryForm=el('div');
    memoryPanel.open=true;
    memoryPanel.append(memoryTitle,memoryNotice,memoryList,memoryForm);assistant.append(memoryPanel);
    let memoryData=null,memorySettings=null,memoryConflict=null,memoryEditing=false,memoryReady=Promise.resolve();
    style.textContent+=' .ai-memory{margin:12px 0!important;padding:8px 0!important}.ai-memory summary{font-weight:600}.ai-memory-note{font-size:12px;color:#566b73;margin:8px 0}.ai-memory-row{display:grid;grid-template-columns:90px minmax(0,1fr);gap:6px;padding:5px 0;border-bottom:1px solid #e2e9ef;overflow-wrap:anywhere}.ai-memory-row strong{font-size:12px}.ai-memory .ai-row{margin-top:10px}.ai-memory label{margin:8px 0}.ai-memory input{width:100%;min-width:0;border:1px solid #c5d2df;border-radius:5px;padding:8px;font:inherit}.ai-memory-conflict{color:#9a5c11}';
    function renderMemory(){
      memoryList.replaceChildren();memoryForm.replaceChildren();
      if(!memoryData)return;
      const facts=memoryData.facts||{};
      for(const [key,label] of Object.entries(memoryLabels))if(facts[key]){const row=el('div',null,'ai-memory-row');row.append(el('strong',label),el('span',facts[key]));memoryList.append(row);}
      if(!memoryList.childNodes.length)memoryList.append(el('p','还没有记录顾客情况。','ai-memory-note'));
      if(memoryConflict&&Object.keys(memoryConflict).length){const warning=el('p','新对话有与档案不同的内容，请核对后手动修改：','ai-memory-note ai-memory-conflict');memoryList.append(warning);for(const [key,value] of Object.entries(memoryConflict))memoryList.append(el('p',`${memoryLabels[key]||key}：${value}`,'ai-memory-note ai-memory-conflict'));}
      const edit=button(memoryEditing?'取消修改':'修改顾客情况',()=>{memoryEditing=!memoryEditing;renderMemory();},memoryEditing?'X':'Pencil');memoryList.append(edit);
      if(!memoryEditing)return;
      for(const [key,label] of Object.entries(memoryLabels)){const wrap=el('label',label),field=el('input');field.name=key;field.maxLength=500;field.value=facts[key]||'';wrap.append(field);memoryForm.append(wrap);}
      memoryForm.append(button('保存顾客情况',async()=>{try{const next={};for(const key of Object.keys(memoryLabels)){const value=memoryForm.querySelector(`[name="${key}"]`).value.trim();if(value)next[key]=value;}
        const result=await call('memory-save',{facts:next,version:memoryData.version,request_id:crypto.randomUUID()});memoryData=result.memory;memoryConflict=null;memoryEditing=false;memoryNotice.textContent='顾客情况已保存。';renderMemory();}
        catch(e){memoryNotice.textContent=errors[e.message]||'保存失败，请刷新后重试。';}},'Check'));
    }
    async function loadMemory(){try{const result=await call('memory-read');if(result.status!=='matched'){memoryNotice.textContent='当前对话未唯一识别顾客，暂不保存摘要。';return;}
      memoryData=result.memory;memorySettings=result.settings;memoryNotice.textContent=result.match_source==='name'?'按姓名匹配，请核对顾客身份。':'只记录顾客明确提到的情况。';renderMemory();}
      catch{memoryNotice.textContent='顾客情况暂时无法读取；不影响手动回复。';}}
    const input=field(assistant,'顾客问题 / 草稿','textarea','ai_input');input.maxLength=4000;input.placeholder='顾客问题，或大概回复内容…';
    style.textContent+=' .ai-dictation{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:end;margin:8px 0}.ai-dictation label{margin:0}.ai-dictation button{min-width:92px}.ai-dictation button.ai-recording{border-color:#b74949;color:#a12e2e;background:#fff3f2}';
    const dictationRow=el('div',null,'ai-dictation'),speechLanguage=field(dictationRow,'口述语言','select','ai_speech_language');
    for(const [value,label] of [['zh-CN','中文'],['en-MY','English'],['ms-MY','Bahasa Melayu']]){const option=el('option',label);option.value=value;speechLanguage.append(option);}
    let speech=null;
    const speechButton=button('开始口述',()=>{if(speech){stopSpeech();return;}startSpeech();},'Mic');dictationRow.append(speechButton);assistant.append(dictationRow);
    function speechButtonState(){const recording=!!speech;speechButton.querySelector('span').textContent=recording?(speech.stopping?'识别中…':'停止口述'):'开始口述';speechButton.setAttribute('aria-label',recording?'停止口述':'开始口述');speechButton.title=recording?'停止口述':'开始口述';speechButton.disabled=!!speech?.stopping;speechButton.classList.toggle('ai-recording',recording);speechLanguage.disabled=recording;}
    function currentConversation(){const observe=globalThis.DwellReadContext?.observe;if(!observe)return true;try{const current=observe(document,location.href);return !!current&&current.key===snapshot.context.key&&current.status===snapshot.context.status;}catch{return false;}}
    function abortSpeech(){if(!speech)return;const previous=speech;speech=null;previous.recognition.onstart=null;previous.recognition.onresult=null;previous.recognition.onerror=null;previous.recognition.onend=null;try{previous.recognition.abort();}catch{}speechButtonState();}
    function stopSpeech(){if(!speech||speech.stopping)return;speech.stopping=true;speechButtonState();try{speech.recognition.stop();}catch{abortSpeech();status.textContent='口述未能结束，请重试。';}}
    function startSpeech(){
      if(!currentConversation()){fail(Error('workbench_context_changed'));return;}
      const Recognition=globalThis.SpeechRecognition||globalThis.webkitSpeechRecognition;
      if(!Recognition){status.textContent='此浏览器暂不支持语音输入，请手动填写。';return;}
      const recognition=new Recognition(),session={recognition,stopping:false,notice:'',finalResults:new Set()};speech=session;
      recognition.lang=speechLanguage.value;recognition.continuous=true;recognition.interimResults=false;recognition.maxAlternatives=1;
      recognition.onstart=()=>{if(speech===session&&alive)status.textContent='正在听取口述…';};
      recognition.onresult=event=>{
        if(speech!==session||!alive)return;
        if(!currentConversation()){abortSpeech();fail(Error('workbench_context_changed'));return;}
        for(let i=event.resultIndex;i<event.results.length;i++){
          const result=event.results[i];if(!result.isFinal||session.finalResults.has(i))continue;session.finalResults.add(i);
          const words=String(result[0]?.transcript||'').trim();if(!words)continue;
          const addition=(input.value.trim()? '\n':'')+words,available=input.maxLength-input.value.length;
          if(available<=0){session.notice='草稿已达到字数上限。';stopSpeech();break;}
          input.value+=addition.slice(0,available);input.dispatchEvent(new Event('input',{bubbles:true}));
          status.textContent='已加入草稿，可继续说话。';
          if(addition.length>available){session.notice='草稿已达到字数上限。';stopSpeech();break;}
        }
      };
      recognition.onerror=event=>{if(speech!==session||!alive)return;session.notice=event.error==='not-allowed'||event.error==='service-not-allowed'?'麦克风未获准使用，请检查 Chrome 权限。':event.error==='no-speech'?'没有听到语音，请再试一次。':event.error==='audio-capture'?'找不到可用麦克风。':'语音识别暂时失败，请重试。';};
      recognition.onend=()=>{if(speech!==session||!alive)return;speech=null;speechButtonState();status.textContent=session.notice||'口述结束，文字可以修改。';};
      speechButtonState();status.textContent='正在开启麦克风…';
      try{recognition.start();}catch{abortSpeech();status.textContent='麦克风未能启动，请检查 Chrome 权限后重试。';}
    }
    assistant.addEventListener('toggle',()=>{if(!assistant.open)abortSpeech();});
    const actions=el('div',null,'ai-controls');assistant.append(actions);
    style.textContent+=' .ai-tools .ai-capture-loading:disabled{opacity:1;cursor:progress}.ai-capture-loading svg{display:none}.ai-capture-loading::before{content:"";width:14px;height:14px;flex:none;border:2px solid #a5b9d5;border-top-color:#1265ef;border-radius:50%;animation:ai-capture-spin .8s linear infinite}@keyframes ai-capture-spin{to{transform:rotate(360deg)}}@media(prefers-reduced-motion:reduce){.ai-capture-loading::before{animation:none;border-top-color:#a5b9d5}}';
    let captureBusy=false,lastVoiceCount=0,captureButton,captureEntries=[],captureTokens=[],lastGenerated=false;
    const incremental=globalThis.DwellAIIncremental;
    const seenFallback=new Set();
    async function seenKey(){return `dwell-ai-seen:${await incremental.digest(snapshot.context.key)}`;}
    async function readSeen(){if(!globalThis.chrome?.storage?.local)return new Set(seenFallback);const key=await seenKey();return new Set((await chrome.storage.local.get(key))[key]||[]);}
    async function markSeen(){if(!captureTokens.length)return;const key=await seenKey(),seen=await readSeen();for(const token of captureTokens)seen.add(token);
      if(globalThis.chrome?.storage?.local)await chrome.storage.local.set({[key]:[...seen].slice(-120)});else{seenFallback.clear();for(const token of seen)seenFallback.add(token);}}
    function setCaptureBusy(value){
      captureBusy=value;
      captureButton.disabled=value;
      captureButton.classList.toggle('ai-capture-loading',value);
      captureButton.querySelector('span').textContent=value?'抓取中…':'抓近期对话';
      captureButton.setAttribute('aria-label',value?'正在抓取近期对话':'抓近期对话');
      captureButton.setAttribute('aria-busy',String(value));
      captureButton.title=value?'正在抓取近期对话':'抓近期对话';
    }
    async function captureText(){
      if(captureBusy)return false;
      setCaptureBusy(true);
      const ticket=++draftRevision;
      try{
        abortSpeech();
        if(!currentConversation())throw Error('workbench_context_changed');
        let texts=[];
        try{texts=chat.recentEntries(snapshot.context.platform).map(entry=>({...entry,kind:'text'}));}
        catch{try{const latest=chat.latest(snapshot.context.platform);if(latest?.trim())texts=[{id:'latest',text:latest,incoming:true,kind:'text'}];}catch{}}
        status.textContent='正在读取近期语音…';
        let voice={lines:[],failed:0,remaining:0},voiceError=false;
        try{
          if(!globalThis.DwellVoiceForAI?.transcribeRecent)throw Error('voice_unavailable');
          voice=await globalThis.DwellVoiceForAI.transcribeRecent(snapshot.context.platform);
        }catch{voiceError=true;}
        if(!alive||!currentConversation()||ticket!==draftRevision)throw Error('workbench_context_changed');
        const voices=(voice.entries||voice.lines.map(line=>({id:line,text:line,incoming:line.startsWith('顾客'),line})))
          .map(entry=>({...entry,kind:'voice'}));
        const all=[...texts,...voices],allTokens=await incremental.tokens(snapshot.context.key,all),seen=await readSeen();
        const fresh=all.filter((_,index)=>!seen.has(allTokens[index]));
        let value=incremental.lines(fresh);
        if(!value){
          if(all.length&&!voiceError&&!voice.failed&&!voice.remaining){status.textContent='没有新的顾客消息。若要重新检查，可先修改或粘贴问题。';return false;}
          if(voiceError){status.textContent='没有抓到顾客文字，语音服务也暂时无法读取；请重试或手动粘贴。';return false;}
          if(voice.failed||voice.remaining){status.textContent='没有抓到顾客文字，近期语音尚未全部转写；请重试转写。';return false;}
          throw Error('ai_message_missing');
        }
        if(!fresh.some(entry=>entry.incoming)){status.textContent='这次只有我方的新消息，没有新的顾客问题。';return false;}
        input.value=value.slice(0,input.maxLength);captureEntries=fresh;captureTokens=allTokens.filter((_,index)=>!seen.has(allTokens[index]));lastGenerated=false;lastVoiceCount=voices.filter(entry=>fresh.includes(entry)).length;
        if(value.length>input.maxLength){status.textContent='近期对话与语音超过 4000 字，请先删减后再生成。';return false;}
        status.textContent=voiceError?'已抓取新文字；语音暂时无法读取，请核对后生成。':voice.failed||voice.remaining
          ?`已抓取新文字与 ${lastVoiceCount} 条语音；${voice.failed} 条转写失败，${voice.remaining} 条尚未处理。请核对后生成。`
          :`已抓取 ${fresh.length} 条新消息${lastVoiceCount?`，含 ${lastVoiceCount} 条语音`:''}，请核对后生成。`;
        if(voiceError||voice.failed||voice.remaining){status.textContent+=' 语音未全部读取，暂不生成回复；请重试。';return false;}
        return true;
      }catch(e){fail(e);return false;}
      finally{setCaptureBusy(false);}
    }
    async function appendRecentVoice(){
      if(captureBusy)return false;
      setCaptureBusy(true);const ticket=++draftRevision;
      try{
        abortSpeech();
        if(!currentConversation())throw Error('workbench_context_changed');
        status.textContent='正在读取近期语音…';
        const voice=await globalThis.DwellVoiceForAI.transcribeRecent(snapshot.context.platform);
        if(!alive||!currentConversation()||ticket!==draftRevision)throw Error('workbench_context_changed');
        if(voice.failed||voice.remaining){status.textContent='语音未全部读取，暂不生成回复；请重试。';return false;}
        const voices=(voice.entries||voice.lines.map(line=>({id:line,text:line,incoming:line.startsWith('顾客'),line}))).map(entry=>({...entry,kind:'voice'}));
        const voiceTokens=await incremental.tokens(snapshot.context.key,voices),seen=await readSeen();
        const fresh=voices.filter((entry,index)=>!seen.has(voiceTokens[index])&&!captureTokens.includes(voiceTokens[index]));
        const addition=incremental.lines(fresh);
        const combined=[input.value.trim(),addition].filter(Boolean).join('\n');
        if(combined.length>input.maxLength){status.textContent='顾客问题与语音合计超过 4000 字，请先删减后再生成。';return false;}
        input.value=combined;captureEntries.push(...fresh);captureTokens.push(...voiceTokens.filter((token,index)=>fresh.includes(voices[index])));lastVoiceCount=fresh.length;
        return true;
      }catch(e){
        if(e.message==='workbench_context_changed')fail(e);
        else status.textContent='语音暂时无法读取，未生成回复；请重试。';
        return false;
      }finally{setCaptureBusy(false);}
    }
    captureButton=button('抓近期对话',()=>{void captureText();},'MessageSquare');actions.append(captureButton);
    const generateButtons=[];
    async function generate(mode,language){
      if(busy||captureBusy)return;
      if(mode==='answer_question'&&!(input.value.trim()&&!lastGenerated?await appendRecentVoice():await captureText()))return;
      if(!input.value.trim()){fail(Error('ai_invalid_request'));return;}
      if(mode==='answer_question')await memoryReady;
      busy=true;const ticket=++draftRevision;for(const b of generateButtons)b.disabled=true;output.value='';photoEligible=false;recommendedContentId=null;recommendedMedia=null;recommend();status.textContent='正在生成回复…';
      try{const selected=mode==='answer_question'&&pack.value!==''?listings[Number(pack.value)]:null;
        const context=mode==='answer_question'&&memoryData?Object.entries(memoryData.facts||{}).filter(([key])=>memorySettings?.enabled_fields?.includes(key)).map(([key,value])=>`${memoryLabels[key]}：${value}`).join('\n'):'';
        const inputText=context?`已记录顾客情况（仅作参考，不是本次顾客发言）：\n${context}\n\n本次对话：\n${input.value}`.slice(0,4000):input.value.slice(0,4000);
        const result=await call('generate',{input_text:inputText,content_id:selected?.id||null,agent_id:agentSelect.value||null,mode,target_language:language});if(ticket!==draftRevision){status.textContent='文字已修改，未覆盖目前草稿。';return;}output.value=result.reply;photoEligible=mode==='answer_question';recommendedContentId=selected?.id||null;recommendedMedia=result.media||null;status.textContent=mode==='answer_question'&&lastVoiceCount?'草稿已生成，已纳入近期语音；尚未发送。':'草稿已生成，尚未发送。';recommend();
        if(mode==='answer_question'){
          lastGenerated=true;try{await markSeen();}catch{status.textContent+=' 去重状态未保存，下次可能需重新抓取。';}
          const customerText=incremental.customerText(captureEntries);
          if(customerText&&memoryData){memoryNotice.textContent='正在更新顾客情况…';
            void call('memory-extract',{customer_text:customerText}).then(value=>{if(value.status==='matched'&&alive){memoryData=value.memory;memoryConflict=value.conflicts;memoryNotice.textContent='已从顾客原话提取，请客服核对。';renderMemory();}})
              .catch(()=>{if(alive)memoryNotice.textContent='顾客情况未能自动更新，回复草稿仍可使用。';});}
        }
      }
      catch(e){fail(e);}finally{busy=false;if(alive)for(const b of generateButtons)b.disabled=false;}
    }
    const generateButton=button('生成回复',()=>generate('answer_question',''),'Sparkles');generateButton.classList.add('ai-primary');generateButtons.push(generateButton);actions.append(generateButton);
    const output=field(assistant,'AI 回复草稿','textarea','ai_output');output.placeholder='等待生成 AI 回复…';
    const polishActions=el('div',null,'ai-controls');
    for(const [label,lang] of [['美化华语','zh'],['美化英文','en']]){const b=button(label,()=>generate('polish_translate',lang),'Languages');generateButtons.push(b);polishActions.append(b);}assistant.append(polishActions);
    async function copy(text,notice=status,target=output){if(!text.trim()){notice.textContent='没有可复制的话术。';return;}try{await call('check');await navigator.clipboard.writeText(text);if(alive)notice.textContent='已复制话术，尚未发送。';}catch(e){if(alive){notice.textContent='未能自动复制，请手动复制话术。';target.focus();target.select();}}}
    const insertButton=button('放进回复框',async()=>{try{await call('check');chat.insert(snapshot.context.platform,output.value);status.textContent='已放入回复框，尚未发送。';}catch(e){fail(e);}},'TextCursorInput');insertButton.classList.add('ai-full','ai-primary');
    const resetButton=button('清空草稿',()=>{abortSpeech();draftRevision++;input.value='';output.value='';captureEntries=[];captureTokens=[];lastGenerated=false;photoEligible=false;recommendedContentId=null;recommendedMedia=null;recommend();status.textContent='已清空当前问题与 AI 草稿；顾客情况不会删除。';},'RotateCcw');resetButton.classList.add('ai-full');assistant.append(insertButton,resetButton,status);
    style.textContent+=' .ai-photo-recommend{margin:10px 0 14px;padding-top:10px;border-top:1px solid #dce4ed}.ai-photo-recommend[hidden],.ai-photo-recommend img[hidden],.ai-photo-recommend button[hidden]{display:none!important}.ai-photo-recommend>strong{display:block;margin-bottom:6px;color:#1d394c}.ai-photo-recommend img{display:block;width:100%;height:160px;object-fit:contain;background:#fff;border:1px solid #dce5ed;border-radius:5px}.ai-photo-recommend .ai-row{margin-top:8px}.ai-photo-recommend a{display:inline-flex;align-items:center;justify-content:center;min-height:38px;flex:1;border:1px solid #c5d2df;border-radius:5px;text-decoration:none;background:#fff}';
    const assets=el('div',null,'ai-photo-recommend'),assetBox=el('div');assets.hidden=true;assets.append(el('strong','推荐配套照片'),assetBox);output.parentElement.insertAdjacentElement('afterend',assets);
    function recommend(){
      assetBox.replaceChildren();assets.hidden=true;
      if(!photoEligible||!output.value.trim())return;
      let item=recommendedMedia||(recommendedContentId?allContent.find(entry=>entry.id===recommendedContentId):null);
      if(!item){
        const [region,language]=market.value.split(':'),reply=output.value.toLocaleLowerCase().replace(/\s+/g,' ');
        const matches=allContent.filter(entry=>entry.market===region&&entry.language===language&&entry.image_path&&entry.package_name&&reply.includes(entry.package_name.toLocaleLowerCase().replace(/\s+/g,' ')));
        if(matches.length===1)item=matches[0];
      }
      if(!item)return;
      assets.hidden=false;
      assetBox.append(el('p',item.package_name,'ai-status'));
      if(!item.image_path){assetBox.append(el('p','此配套尚未上传照片。','ai-status'));return;}
      const preview=el('img'),imageStatus=el('p','正在读取照片…','ai-status'),controls=el('div',null,'ai-row');preview.alt=item.package_name;preview.hidden=true;imageStatus.setAttribute('role','status');assetBox.append(preview,imageStatus,controls);
      const copyImage=button('复制照片',async()=>{if(!preview.complete||!preview.naturalWidth)return;try{await call('check');const canvas=document.createElement('canvas');canvas.width=preview.naturalWidth;canvas.height=preview.naturalHeight;canvas.getContext('2d').drawImage(preview,0,0);const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('ai_image_failed');await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);if(alive&&preview.isConnected)imageStatus.textContent='照片已复制，尚未发送。';}catch{if(alive&&preview.isConnected)imageStatus.textContent='无法复制，请打开照片后手动复制。';}},'Copy');copyImage.disabled=true;controls.append(copyImage);
      if(item.image_url){const link=el('a','打开照片');link.href=item.image_url;link.target='_blank';link.rel='noopener noreferrer';controls.append(link);}
      const retry=button('重试照片',()=>void load(true),'RefreshCw');retry.hidden=true;controls.append(retry);
      async function load(refresh=false){try{copyImage.disabled=true;retry.hidden=true;imageStatus.textContent='正在读取照片…';const result=await call('content-image',{path:item.image_path,refresh});if(!alive||!preview.isConnected)return;if(!/^data:image\/(png|jpeg|webp);base64,/.test(result.data_url||''))throw Error('ai_image_failed');preview.src=result.data_url;await preview.decode();if(!alive||!preview.isConnected)return;if(!preview.naturalWidth||preview.naturalWidth*preview.naturalHeight>40000000)throw Error('ai_image_failed');preview.hidden=false;copyImage.disabled=false;imageStatus.textContent='请核对照片后复制，由客服自行发送。';}catch{if(alive&&preview.isConnected){preview.hidden=true;imageStatus.textContent='照片未能载入，请重试。';retry.hidden=false;}}}
      void load();
    }
    input.addEventListener('input',()=>{draftRevision++;if(captureEntries.length&&!captureEntries.some(entry=>input.value.includes(String(entry.text||'').slice(0,20)))){captureEntries=[];captureTokens=[];}lastGenerated=false;});output.addEventListener('input',()=>{draftRevision++;recommend();});
    agentSelect.addEventListener('change',()=>{draftRevision++;photoEligible=false;recommendedMedia=null;recommendedContentId=null;recommend();status.textContent='已切换 AI Agent，请重新生成草稿。';});
    const listing=section('配套资料','listing');
    const listingStatus=el('p','','ai-status');listingStatus.setAttribute('role','status');listing.append(listingStatus);
    const market=field(listing,'地区与语言','select','ai_listing_market');market.disabled=true;
    const pack=field(listing,'配套','select','ai_listing_package');
    style.textContent+=' .ai-listing-preview{margin:8px 0 10px;padding:9px;border:1px solid #cbd8d7;border-radius:7px;background:#fff}.ai-listing-preview img{display:block;width:100%;height:160px;object-fit:contain;border:1px solid #dce5ed;border-radius:5px;background:#f8fafc}.ai-listing-preview img[hidden],.ai-listing-retry[hidden],.ai-listing-actions [hidden]{display:none!important}.ai-listing-block{min-width:0;margin-top:9px;border-top:1px solid #e0e7ed;padding-top:8px}.ai-listing-block-header{display:flex;align-items:center;justify-content:space-between;gap:6px;min-height:38px;font-size:12px;font-weight:600;color:#294658}.ai-listing-block-header button{min-height:32px;padding:5px 7px;flex-shrink:0}.ai-listing-preview textarea{display:block;height:110px;min-height:110px;max-height:110px;resize:none;overflow-y:auto;margin-top:4px;border:0;border-radius:0;padding:0;font-size:12px;line-height:1.45;color:#566b73}.ai-listing-preview textarea:focus-visible{outline-offset:1px}.ai-listing-actions{margin-bottom:10px}.ai-listing-actions a{display:flex;align-items:center;justify-content:center;min-height:38px;border:1px solid #cbd8d7;border-radius:5px;text-align:center;text-decoration:none;font-size:13px}.ai-listing-retry{margin:8px 0 0}';
    const listingPreview=el('div',null,'ai-listing-preview'),listingImage=el('img'),listingImageStatus=el('p','','ai-status');
    const listingText=el('textarea');listingText.name='ai_listing_text';listingText.setAttribute('aria-label','价格与配套内容');listingText.readOnly=true;
    const listingExtraText=el('textarea');listingExtraText.name='ai_listing_extra_text';listingExtraText.setAttribute('aria-label','补充话术');listingExtraText.readOnly=true;listingExtraText.placeholder='此配套尚未填写补充话术。';
    const listingRetry=button('重试图片',()=>loadListingImage(true),'RefreshCw');listingRetry.className='ai-listing-retry';listingRetry.hidden=true;
    const listingCopy=button('复制配套话术',()=>copy(listingText.value,listingStatus,listingText),'Copy');
    const listingExtraCopy=button('复制补充话术',()=>copy(listingExtraText.value,listingStatus,listingExtraText),'Copy');
    function listingBlock(label,copyButton,textarea){const block=el('div',null,'ai-listing-block'),header=el('div',null,'ai-listing-block-header');header.append(el('span',label),copyButton);block.append(header,textarea);return block;}
    listingPreview.append(listingImage,listingImageStatus,listingRetry,listingBlock('配套话术',listingCopy,listingText),listingBlock('补充话术',listingExtraCopy,listingExtraText));listing.append(listingPreview);
    const listingActions=el('div',null,'ai-listing-actions'),listingOpen=el('a','打开配套图片');
    const listingImageCopy=button('复制配套图片',async()=>{
      if(!listingImage.complete||!listingImage.naturalWidth){listingStatus.textContent='图片尚未载入，请稍后重试。';return;}
      try{await call('check');const canvas=document.createElement('canvas');canvas.width=listingImage.naturalWidth;canvas.height=listingImage.naturalHeight;canvas.getContext('2d').drawImage(listingImage,0,0);
        const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/png'));if(!blob)throw Error('ai_image_failed');
        await navigator.clipboard.write([new ClipboardItem({'image/png':blob})]);listingStatus.textContent='图片已复制，尚未发送。';
      }catch{listingStatus.textContent='无法复制图片，请打开图片后手动复制。';}
    },'Copy');
    listingOpen.target='_blank';listingOpen.rel='noopener noreferrer';listingActions.append(listingImageCopy,listingOpen);listing.append(listingActions);
    let previewSequence=0;
    async function loadListingImage(refresh=false){const item=pack.value===''?null:listings[Number(pack.value)];if(!item?.image_path)return;const token=++previewSequence;listingImage.hidden=true;listingRetry.hidden=true;listingImageStatus.textContent='正在读取图片…';try{const result=await call('content-image',{path:item.image_path,refresh});if(token!==previewSequence)return;if(!/^data:image\/(png|jpeg|webp);base64,/.test(result.data_url||''))throw Error('ai_image_failed');listingImage.src=result.data_url;await listingImage.decode();if(token!==previewSequence)return;if(!listingImage.naturalWidth||listingImage.naturalWidth*listingImage.naturalHeight>40000000)throw Error('ai_image_failed');listingImage.hidden=false;listingImageStatus.textContent='';}catch(e){if(alive&&token===previewSequence){listingImage.hidden=true;listingImageStatus.textContent='图片未能载入，请重试或打开图片。';listingRetry.hidden=false;}}}
    function showListing(){previewSequence++;const item=pack.value===''?null:listings[Number(pack.value)];listingText.value=item?.text||'';listingText.scrollTop=0;listingCopy.disabled=!listingText.value.trim();listingExtraText.value=item?.extra_text||'';listingExtraText.scrollTop=0;listingExtraCopy.disabled=!listingExtraText.value.trim();listingImage.hidden=true;listingImage.removeAttribute('src');listingImage.alt=item?.title||'';listingImageStatus.textContent='';listingRetry.hidden=true;listingImageCopy.hidden=!item?.image_path;listingOpen.hidden=!item?.image_url;if(item?.image_url){listingOpen.href=item.image_url;void loadListingImage();}else listingOpen.removeAttribute('href');}
    let allContent=[],allOptions=[];
    function showCombinations(){
      const previous=market.value,labels=new Map(allOptions.map(option=>[`${option.kind}:${option.code}`,option.label]));
      const fallback=new Map([['market:MY','西马'],['market:EM','东马'],['market:SG','新加坡'],['language:zh','中文'],['language:en','English'],['language:ms','Bahasa Melayu']]);
      const keys=[...new Set(allContent.map(item=>`${item.market}:${item.language}`))];
      const order=new Map(allOptions.map(option=>[`${option.kind}:${option.code}`,Number(option.sort_order)||100]));
      keys.sort((a,b)=>{const [am,al]=a.split(':'),[bm,bl]=b.split(':');return (order.get(`market:${am}`)||100)-(order.get(`market:${bm}`)||100)||(order.get(`language:${al}`)||100)-(order.get(`language:${bl}`)||100)||a.localeCompare(b);});
      market.replaceChildren();for(const key of keys){const [region,language]=key.split(':');const label=`${labels.get(`market:${region}`)||fallback.get(`market:${region}`)||region} · ${labels.get(`language:${language}`)||fallback.get(`language:${language}`)||language}`;const op=el('option',label);op.value=key;market.append(op);}
      market.disabled=!keys.length;market.value=keys.includes(previous)?previous:keys[0]||'';
    }
    function filterListings(){const [region,language]=market.value.split(':');listings=allContent.filter(item=>item.market===region&&item.language===language).map(item=>({...item,title:item.package_name,text:item.copy_primary,extra_text:item.copy_secondary})).sort((a,b)=>a.title.localeCompare(b.title));pack.replaceChildren();const choose=el('option','选择配套以查看或引用');choose.value='';pack.append(choose);for(const [i,item] of listings.entries()){const op=el('option',item.title);op.value=i;pack.append(op);}pack.disabled=!listings.length;showListing();listingStatus.textContent=listings.length?`Supabase 配套资料 · ${listings.length} 项`:'暂无已启用的配套资料。';}
    async function loadListings(refresh=false){const token=++listingSequence;pack.replaceChildren();pack.disabled=true;listings=[];showListing();listingStatus.textContent='正在读取配套资料…';try{const result=await call('content',{refresh});if(token!==listingSequence)return;allContent=result.items||[];allOptions=result.options||[];showCombinations();filterListings();recommend();}catch(e){if(alive&&token===listingSequence)listingStatus.textContent='配套读取失败，请重新读取。';}}
    market.addEventListener('change',filterListings);pack.addEventListener('change',showListing);listing.append(button('重新读取配套',()=>loadListings(true),'RefreshCw'));
    async function load(){const token=++loadSequence;try{const result=await call('agents');if(token!==loadSequence)return;const previous=agentSelect.value;agentSelect.replaceChildren();for(const item of result.agents||[]){const option=el('option',item.name);option.value=item.id;agentSelect.append(option);}const agents=result.agents||[];agentSelect.value=agents.some(item=>item.id===previous)?previous:agents.find(item=>item.is_default)?.id||agents[0]?.id||'';agentSelect.disabled=!agents.length;status.textContent=agents.length?'请核对顾客问题；生成结果只是草稿。':'暂无启用的 AI Agent，请联系管理员。';}catch(e){if(token===loadSequence)fail(e);}}
    assistant.append(button('重新连接',()=>{void load();void loadListings(true);memoryReady=loadMemory();},'RefreshCw'));container.append(root);void load();void loadListings();memoryReady=loadMemory();
    return {dispose(){alive=false;abortSpeech();listingSequence++;root.remove();}};
  }
  globalThis.DwellAI=Object.freeze({mount,preload,resetCatalog});
})();
