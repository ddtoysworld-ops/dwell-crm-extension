# CRM voice reference 0.8.46

- Built from the locally loaded 0.8.45 package. No GitHub, site or database deployment.
- The CRM extension includes its own WhatsApp/Messenger voice capture. The separate voice extension is no longer required for this feature.
- On "抓近期对话", the most recent three untranscribed incoming voice messages among the last 12 loaded messages are transcribed through the existing Supabase Edge Function. Original text and, when needed, Chinese translation are added to the AI input for staff review. Nothing is sent to customers automatically.
- Speech is not transcribed merely by opening a chat. A staff click triggers API usage; media is not stored in the CRM database. Older messages not loaded by the chat page are not read.
- Outgoing or ambiguously attributed voices are excluded from AI reference. Switching conversations invalidates the prior voice context. Messenger may require one manual click on the native play control if Meta does not expose audio to the extension automatically.
- The two Meta media host permissions are required for Messenger audio fallback. Chrome may ask the user to approve the new permissions when the extension is reloaded.
- Synthetic audio and mocked transcription tests passed for both platforms. Real customer audio and real message sending were not used for QA; staff should verify the first real transcript and AI draft before sending.
