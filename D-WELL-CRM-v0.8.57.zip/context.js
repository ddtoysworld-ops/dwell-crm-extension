(() => {
  const phone = value => {
    const text = String(value || '').trim();
    if (!/^[+\d ()-]+$/.test(text)) return '';
    const digits = text.replace(/[+ ()-]/g, '');
    return /^(?:60\d{8,10}|65\d{8})$/.test(digits) ? digits : '';
  };
  function identify(url, observation = {}) {
    let parsed;
    try { parsed = new URL(url); } catch { return { status: 'unsupported' }; }
    if (parsed.protocol !== 'https:') return { status: 'unsupported' };
    if (observation.conflict) return { status: 'legacy_plugin' };
    if (parsed.hostname === 'business.facebook.com' && /^\/latest\/inbox(?:\/|$)/.test(parsed.pathname)) {
      const query = parsed.searchParams;
      const page = query.get('mailbox_id') || query.get('asset_id');
      const uid = query.get('selected_item_id');
      if (query.get('thread_type') !== 'FB_MESSAGE' || !/^\d{5,30}$/.test(page || '') || !/^\d{5,30}$/.test(uid || '') || (query.get('asset_id') && query.get('asset_id') !== page)) return { status: 'missing_messenger' };
      return { status: 'ready', platform: 'messenger', page, uid, key: `messenger:${page}:${uid}` };
    }
    if (parsed.hostname === 'web.whatsapp.com') {
      if (!observation.hasHeader) return { status: 'no_conversation' };
      if (observation.group) return { status: 'group' };
      if (!observation.individual) return { status: 'unverified_chat' };
      const number = phone(observation.title);
      if (!number) {
        const title = String(observation.title || '').trim().slice(0,300);
        return { status: 'phone_missing', platform: 'whatsapp', title, key: title ? `whatsapp-chat:${title}` : '' };
      }
      return { status: 'ready', platform: 'whatsapp', phone: number, key: `whatsapp:${number}` };
    }
    return { status: 'unsupported' };
  }
  function observe(document, url) {
    const conflict = !!document.querySelector('#mcrm-root, #flow-lite-floating-root, #dai-root');
    const header = document.querySelector('#main header, [data-testid="conversation-header"]');
    const title = header?.querySelector('[data-testid="conversation-info-header-chat-title"], [data-testid="conversation-info-header"] span[title], span[title][dir="auto"], h1, h2');
    const group = !!header?.querySelector('[data-icon="default-group"], [data-testid="default-group"], [title="Group info"], [title="群组信息"], [title="群組資訊"]');
    const individual = !!header?.querySelector('[title="Profile details"], [title="个人主页详情"], [title="个人资料详情"], [title="個人檔案詳細資料"], [title="Contact info"], [title="联系人信息"], [title="聯絡人資訊"], [data-icon="default-user"], [data-testid="default-user"]');
    return identify(url, { conflict, hasHeader: !!header, group, individual, title: title?.getAttribute('title') || title?.textContent || '' });
  }
  globalThis.DwellReadContext = Object.freeze({ identify, observe, phone });
})();
