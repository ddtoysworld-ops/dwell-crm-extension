import { normalizeAdtsAudio } from './voice/audio-normalize.bundle.mjs';
import { fetchMessengerAudio, isAllowedMessengerAudioUrl } from './voice/remote-audio.mjs';

const MAX_AUDIO_BYTES = 12 * 1024 * 1024;
const ALLOWED_TYPES = new Set(['audio/aac', 'audio/mp4', 'audio/m4a', 'audio/ogg', 'audio/opus', 'audio/webm', 'audio/mpeg', 'audio/wav', 'audio/x-wav']);

export async function fetchVoiceAudio(sourceUrl, senderUrl) {
  if (!senderUrl?.startsWith('https://business.facebook.com/') || !isAllowedMessengerAudioUrl(sourceUrl)) {
    throw Error('不支持这个语音网址。');
  }
  const { bytes, mimeType, fileName } = await fetchMessengerAudio(sourceUrl);
  let binary = '';
  for (let offset = 0; offset < bytes.length; offset += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(offset, offset + 0x8000));
  }
  return { audioBase64: btoa(binary), audioByteLength: bytes.length, mimeType, fileName };
}

export async function transcribeVoice({ audioBase64, audioByteLength, mimeType, fileName }, { url, key, token }) {
  const length = Number(audioByteLength);
  if (!Number.isInteger(length) || length < 1 || length > MAX_AUDIO_BYTES ||
      typeof audioBase64 !== 'string' || audioBase64.length > Math.ceil(MAX_AUDIO_BYTES / 3) * 4 + 4) {
    throw Error('语音文件无效或太大。');
  }
  const declaredType = String(mimeType || '').split(';', 1)[0].toLowerCase();
  if (!ALLOWED_TYPES.has(declaredType)) throw Error('不支持这个语音格式。');
  let bytes;
  try {
    const binary = atob(audioBase64);
    bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
  } catch { throw Error('语音文件无效。'); }
  if (bytes.length !== length) throw Error('语音文件不完整。');
  const converted = await normalizeAdtsAudio(bytes, MAX_AUDIO_BYTES);
  const upload = converted || { bytes, mimeType: declaredType, fileName: /^[a-z0-9-]{1,40}\.(?:aac|m4a|mp3|mp4|ogg|opus|wav|webm)$/i.test(fileName || '') ? fileName : 'voice-message.webm' };
  const form = new FormData();
  form.append('file', new Blob([upload.bytes], { type: upload.mimeType }), upload.fileName);
  form.append('translate_to_zh', 'true');
  const response = await fetch(`${url}/functions/v1/dwell-voice-transcribe`, {
    method: 'POST', headers: { apikey: key, Authorization: `Bearer ${token}` }, body: form
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw Error(result.error || result.message || `语音转写失败 (${response.status})`);
  return {
    transcript: String(result.transcript || '').slice(0, 5000),
    translation_zh: String(result.translation_zh || '').slice(0, 5000),
    language: String(result.language || '').slice(0, 40)
  };
}
