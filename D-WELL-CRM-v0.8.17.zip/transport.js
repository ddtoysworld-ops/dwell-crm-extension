(() => {
  function classify(error) {
    return /extension context invalidated|context has been invalidated/i.test(String(error?.message || error))
      ? 'context_expired' : 'reconnecting';
  }
  async function send(message, timeoutMs = 12000) {
    let timer;
    try {
      if (!chrome.runtime?.id) throw new Error('Extension context invalidated');
      return await Promise.race([
        Promise.resolve().then(() => chrome.runtime.sendMessage(message)),
        new Promise((_, reject) => { timer = setTimeout(() => reject(new Error('message_timeout')), timeoutMs); })
      ]);
    } finally { clearTimeout(timer); }
  }
  globalThis.DwellTransport = Object.freeze({ send, classify });
})();
