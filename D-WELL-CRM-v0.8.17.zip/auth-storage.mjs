const preferenceKey = 'dwell-remember-login';
export class AuthStorage {
  constructor(storage) { this.storage = storage; this.ready = this.initialize(); }
  async initialize() {
    await this.storage.local.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
    await this.storage.session.setAccessLevel({ accessLevel: 'TRUSTED_CONTEXTS' });
    this.remember = (await this.storage.local.get(preferenceKey))[preferenceKey] === true;
  }
  async configure(remember) {
    await this.ready;
    this.remember = remember === true;
    await this.storage.local.set({ [preferenceKey]: this.remember });
  }
  async getItem(key) {
    await this.ready;
    return (await this.storage[this.remember ? 'local' : 'session'].get(key))[key] ?? null;
  }
  async setItem(key, value) {
    await this.ready;
    await this.storage[this.remember ? 'session' : 'local'].remove(key);
    await this.storage[this.remember ? 'local' : 'session'].set({ [key]: value });
  }
  async removeItem(key) { await this.ready; await this.storage.local.remove(key); await this.storage.session.remove(key); }
}
