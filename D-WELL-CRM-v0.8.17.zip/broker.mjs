export function supported(url) {
  try { const u = new URL(url); return u.protocol === 'https:' && (u.hostname === 'web.whatsapp.com' || (u.hostname === 'business.facebook.com' && /^\/latest\/inbox(?:\/|$)/.test(u.pathname))); } catch { return false; }
}
export function viewSender(sender, runtime) {
  if (sender.id !== runtime.id) return false;
  try { const u = new URL(sender.url); return u.origin === new URL(runtime.getURL('/')).origin && u.pathname === '/panel.html' && (!sender.frameId || supported(sender.tab?.url)); } catch { return false; }
}
export function topLevelView(sender, runtime) { return viewSender(sender, runtime) && (!sender.frameId || sender.frameId === 0); }
export function contentSender(sender, runtime) { return sender.id === runtime.id && sender.frameId === 0 && Number.isInteger(sender.tab?.id) && supported(sender.url) && supported(sender.tab.url); }
export function sameSnapshot(a,b) { return a?.documentId === b?.documentId && a?.revision === b?.revision && JSON.stringify(a?.context) === JSON.stringify(b?.context); }
export function canUseInline(context) {
  // A named personal chat supports manual entry, but is not a CRM identity.
  return context?.status === 'ready' || (context?.status === 'phone_missing' && context.platform === 'whatsapp' && !!context.key);
}
export async function currentCustomerView({ api, sender, expected, auth, data, epoch }) {
  // Only the background's fresh read of the sender's own tab determines identity.
  const bound = { ...sender, frameId: 1 };
  const first = await readContext(api, bound);
  if (!first.snapshot || first.snapshot.documentId !== expected?.documentId || first.snapshot.revision !== expected?.revision) return { status: 'transition' };
  const state = await auth();
  if (!state.member) return { status: 'signed_out' };
  const context = first.snapshot.context;
  if (context.status !== 'ready') return { status: context.status };
  const startEpoch = epoch();
  const found = await data.resolve(context);
  if (found.status === 'conflict' || found.status === 'unavailable') return { status: found.status };
  if (found.items?.length !== 1) return { status: found.items?.length ? 'conflict' : 'not_found' };
  const profile = await data.read('profile', { id: found.items[0].id });
  const last = await readContext(api, bound);
  if (startEpoch !== epoch() || !sameSnapshot(first.snapshot, last.snapshot)) return { status: 'transition' };
  return { status: 'matched', profile, display_name: state.member.display_name };
}
export async function readContext(api, sender, windowId, recheck) {
  const embedded = sender.frameId > 0;
  const tab = embedded ? await api.tabs.get(sender.tab.id) : (await api.tabs.query({ active: true, windowId }))[0];
  if (!tab || !supported(tab.url)) return { status: 'unsupported' };
  const snapshot = await api.tabs.sendMessage(tab.id, { type: 'dwell-context-read', recheck: recheck === true }, { frameId: 0 });
  const latest = embedded ? await api.tabs.get(tab.id) : (await api.tabs.query({ active: true, windowId }))[0];
  if (latest?.id !== tab.id || latest?.url !== tab.url) return { status: 'transition' };
  if (!snapshot?.documentId || !Number.isInteger(snapshot.revision) || !snapshot.context) return { status: 'disconnected' };
  return { tabId: tab.id, snapshot };
}
