// Public frontend configuration, copied from the existing private backend.
export const supabaseUrl = 'https://osgqzpdfjdnkzmyzitrm.supabase.co';
export const publishableKey = 'sb_publishable_IKABC_KIjLNgTbf45AZyFw_zGCFfpI5';
