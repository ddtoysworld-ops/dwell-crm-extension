const kinds = new Set(['text', 'image', 'video', 'audio', 'wait']);
const uuid = /^[a-f0-9-]{36}$/i;
export function mediaPath(path) {
  if (typeof path !== 'string' || !path || path.length > 1024 || /[%?#\\:\x00-\x1f]/.test(path)) throw Error('flow_media_invalid');
  if (path.split('/').some(p => !p || p === '.' || p === '..')) throw Error('flow_media_invalid');
  return path.split('/').map(encodeURIComponent).join('/');
}
export function flowFetch(transport, origin) {
  return (input, options = {}) => {
    const url = new URL(String(input)), method = (options.method || 'GET').toUpperCase();
    const read = method === 'GET' && (/^\/rest\/v1\/(profiles|flows|flow_steps)$/.test(url.pathname) || url.pathname.startsWith('/storage/v1/object/public/flow-media/'));
    if (url.origin !== origin || url.username || url.password || !read) throw Error('flow_readonly');
    return transport(url.href, {...options, redirect:'error', credentials:'omit', signal:options.signal || AbortSignal.timeout(30000)});
  };
}
export function createFlowReader({getSession, config, transport = fetch}) {
  let revision = 0, catalog = null, pending = null;
  const request = flowFetch(transport, config.url);
  async function access() {
    const session = await getSession();
    if (!session?.access_token || !session?.user?.id) throw Error('flow_login_required');
    return session;
  }
  async function guard(start, user) {
    const session = await access();
    if (revision !== start || session.user.id !== user) throw Error('flow_session_changed');
  }
  async function rows(table, query, session) {
    const all = [];
    for (let offset = 0; offset < 20000; offset += 200) {
      const params = new URLSearchParams({...query, limit:'200', offset:String(offset)});
      const response = await request(`${config.url}/rest/v1/${table}?${params}`, {headers:{apikey:config.anonKey, Authorization:'Bearer '+session.access_token}});
      if (!response.ok) throw Error(response.status === 401 ? 'flow_login_required' : 'flow_read_failed');
      const batch = await response.json();
      if (!Array.isArray(batch)) throw Error('flow_read_failed');
      all.push(...batch);
      if (batch.length < 200) return all;
    }
    throw Error('flow_catalog_too_large');
  }
  async function list(force = false) {
    const session = await access(), start = revision;
    if (force) { catalog = null; pending = null; ++revision; return list(); }
    if (catalog?.user === session.user.id) return catalog.value;
    if (pending?.user === session.user.id) return pending.promise;
    const promise = (async () => {
      const profiles = await rows('profiles', {select:'id,role',id:'eq.'+session.user.id,order:'id.asc'}, session);
      if (!profiles.some(p => p.id === session.user.id && ['staff','admin'].includes(p.role))) throw Error('flow_access_denied');
      const flows = await rows('flows', {select:'id,name,folder,status,updated_at',status:'eq.published',order:'folder.asc,name.asc,id.asc'}, session);
      const published = flows.filter(f => uuid.test(f.id) && f.status === 'published');
      const items = [];
      // Chunk IDs to keep URLs bounded; never request draft steps or the admin media library.
      for (let i = 0; i < published.length; i += 30) {
        const chunk = published.slice(i,i+30), ids = new Set(chunk.map(f => f.id));
        const steps = await rows('flow_steps', {select:'id,flow_id,position,kind,text_content,media_path,delay_ms',flow_id:'in.('+[...ids].join(',')+')',order:'position.asc,id.asc'}, session);
        await guard(start, session.user.id);
        for (const flow of chunk) items.push({id:flow.id,name:String(flow.name || '未命名流程'),folder:String(flow.folder || ''),updated_at:flow.updated_at,
          steps:steps.filter(s => s.flow_id === flow.id && uuid.test(s.id)).sort((a,b) => a.position-b.position || a.id.localeCompare(b.id)).map(s => ({
            id:s.id,kind:kinds.has(s.kind)?s.kind:'unsupported',text:String(s.text_content || ''),
            media_path:['image','video','audio'].includes(s.kind)?String(s.media_path || ''):'',delay_ms:Math.max(0,Number(s.delay_ms)||0)
          }))});
      }
      await guard(start, session.user.id);
      const value = {items}; catalog = {user:session.user.id,value}; return value;
    })();
    pending = {user:session.user.id,promise};
    try { return await promise; } finally { if(pending?.promise === promise) pending = null; }
  }
  async function media(flowId, stepId) {
    const session = await access(), start = revision, value = await list();
    const step = value.items.find(f => f.id === flowId)?.steps.find(s => s.id === stepId);
    if (!step || !['image','video','audio'].includes(step.kind)) throw Error('flow_media_invalid');
    const path = mediaPath(step.media_path);
    // The old bucket is public. Do not put any user access token in a media URL.
    const response = await request(`${config.url}/storage/v1/object/public/flow-media/${path}`);
    if (!response.ok) throw Error('flow_media_failed');
    const mime = (response.headers.get('content-type') || '').split(';')[0].toLowerCase();
    const accepted = {image:['image/png','image/jpeg','image/webp','image/gif'],video:['video/mp4','video/webm'],audio:['audio/mpeg','audio/mp4','audio/ogg','audio/wav','audio/x-wav','audio/webm']};
    if (!accepted[step.kind].includes(mime)) { await response.body?.cancel(); throw Error('flow_media_invalid'); }
    const max = 20*1024*1024;
    if (Number(response.headers.get('content-length')) > max) { await response.body?.cancel(); throw Error('flow_media_too_large'); }
    const reader = response.body.getReader(), chunks = []; let size = 0;
    for (;;) {
      const {done,value:chunk} = await reader.read(); if(done) break;
      size += chunk.length; if(size > max) { await reader.cancel(); throw Error('flow_media_too_large'); } chunks.push(chunk);
    }
    await guard(start, session.user.id);
    let binary = ''; for(const chunk of chunks) for(let i=0;i<chunk.length;i+=8192) binary += String.fromCharCode(...chunk.subarray(i,i+8192));
    return {data_url:`data:${mime};base64,${btoa(binary)}`};
  }
  return {list,media,clear(){++revision;catalog=null;pending=null;}};
}
