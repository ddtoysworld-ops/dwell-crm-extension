"use strict";
window.DwellReferrals=(()=>{
 const safe=escapeHtml,allowed=()=>window.DwellPayments?.canCoreAction?.('referrals','list')??window.DwellPayments?.canManagePages(),rpc=(a,b)=>DwellPayments.referralsRpc(a,b);
 const states={pending:'待审核',qualified:'资格已确认',void:'已作废',review:'异常待核对'};
 const deliveries={not_selected:'未安排',hold:'等下次订单',postage_pending:'待收邮费',ready:'待寄出',shipped:'已寄出',completed:'已完成',void:'已作废',review:'异常待核对'};
 const methods={with_friend:'随被推荐人订单寄出',self_postage:'独立寄出',next_order:'留待推荐人下次订单'};
 const reasons={order_closed:'订单已取消或拒收',not_formal:'尚未正式成交',campaign_paused:'活动已暂停',buyer_missing:'尚未关联客户',referrer_missing:'推荐电话未找到现有客户',self_referral:'不能推荐自己',not_first_order:'已有更早的有效订单',already_rewarded:'首购奖励已确认',no_eligible_bundle:'没有符合规则的付费配套'};
 let tab='records',search='',filter='',offset=0,report=null,settings=null,skus=[],generation=0,loading=false,error='',busy=false,editing=null,pending=null;
 const rewards=r=>(r||[]).map(x=>`${safe(x.name)} × ${x.quantity}`).join('<br>')||'—';
 const pill=r=>`<span class="pill ${r.status==='qualified'?'success':r.status==='pending'?'warning':'neutral'}">${states[r.status]||safe(r.status)}</span>`;
 const admin=()=>window.DwellPayments?.canManagePages();
 const can=a=>window.DwellPayments?.canCoreAction?.('referrals',a)??admin();
 const permitted=a=>['refresh','records','settings','search','prev','next','detail'].includes(a)||can(['delivery','ship','complete'].includes(a)?a:'save_settings');
 const btn=(a,id,label,ico='square-pen')=>!permitted(a)?'':`<button type="button" class="secondary" data-ref="${a}" data-id="${id}">${icon(ico)}${label}</button>`;
 function leave(){generation++;loading=false;report=null;settings=null;skus=[];editing=null;pending=null;error='';}
 function failure(e){const s=String(e?.message||e);if(s.includes('core_stale_version'))return '记录已被更新，请关闭窗口并刷新后重试。';
  if(s.includes('referral_history_required'))return '请确认首购历史并填写核对依据。';
  if(s.includes('referral_ineligible:'))return reasons[s.split('referral_ineligible:')[1]]||'当前资格不符合要求，请刷新核对。';
  if(s.includes('referral_order_locked'))return '该订单已确认推荐奖励，暂不能修改；取消订单会同步处理奖励状态。';
  if(s.includes('referral_shipment_order_invalid'))return '请选择推荐人之后的有效正式订单。';
  if(s.includes('referral_address_required'))return '请填写收件人、含国家码的电话号码及收货地址。';
  if(s.includes('core_owner_required'))return '当前账号没有此操作权限，请联系管理员。';
  if(e?.code==='PGRST202')return '好友推荐接口尚未部署，请稍后刷新。';
  if(/referral_|23505|23514|22P02/.test(s+' '+e?.code))return '资料或状态不符合要求，请核对输入并刷新记录。';
  return '连接失败，操作结果尚未确认，请刷新核对或重试。';}
 async function refresh(){if(!allowed()){leave();render(false);return;}const token=++generation;loading=true;error='';render(false);
  try{const data=await rpc('list',{search,status:filter,offset});const cfg=await rpc('settings');if(token!==generation||!allowed())return;report=data;settings=cfg;}
  catch(e){if(token===generation)error=failure(e);}finally{if(token===generation){loading=false;render(false);}}}
 function render(fetch=true){if(state.view!=='referrals')return;if(!allowed()){$('#main').innerHTML=heading('好友推荐','Supabase')+'<div class="empty">请使用主管理员账号登录。</div>';return;}
  if(fetch){void refresh();return;}
  $('#main').innerHTML=heading('好友推荐','Supabase · 首购资格与实物奖励',btn('refresh','','刷新','refresh-cw'))+
   `<div class="payment-tabs" role="tablist" aria-label="好友推荐视图"><button data-ref="records" role="tab" aria-selected="${tab==='records'}">推荐记录</button><button data-ref="settings" role="tab" aria-selected="${tab==='settings'}">活动设置</button></div>`+
   (loading?'<div class="empty" role="status">正在读取推荐资料…</div>':error?`<div class="alert-note" role="alert">${safe(error)}</div>`:report?(tab==='settings'?configuration():records()):'');icons();}
 function records(){return `<div class="stats">${stat('待审核',report.pending,'首购资格待核对','users')}${stat('已确认推荐',report.qualified,'奖励属于推荐人','user-check')}${stat('待寄出',report.awaiting_shipment,'包含未安排与待收邮费','package')}${stat('奖励数量',report.reward_units,'已确认且未作废 · 件','gift')}</div>
  <p class="notice">旧推荐记录未迁入。历史订单尚不完整，首购需核对旧记录；确认资格后即可安排奖励，不等签收。</p>
  <div class="ref-filters"><label class="field"><span>姓名、电话或 ERP 订单号</span><input id="ref-search" value="${safe(search)}" maxlength="100" type="search"></label><label class="field"><span>资格状态</span><select id="ref-filter"><option value="">全部</option>${Object.entries(states).map(([k,v])=>`<option value="${k}" ${filter===k?'selected':''}>${v}</option>`).join('')}</select></label>${btn('search','','查询','search')}</div>
  <div class="table-scroll"><table class="ref-table"><thead><tr>${['订单 / 主页','被推荐客户','推荐人','奖励','资格 / 寄送','操作'].map(v=>`<th>${v}</th>`).join('')}</tr></thead><tbody>${report.items.map(r=>`<tr><td>#${r.order_number}<small>${dateLabel(r.order_date)} · ${safe(r.page_name)}</small><small>${safe(r.erp_id)}</small></td><td>${safe(r.buyer_name)}<small>${safe(r.buyer_phone)}</small></td><td>${safe(r.referrer_name||'未匹配')}<small>${safe(r.referral_phone)}</small></td><td>${rewards(r.approved_at?r.rewards:r.eligibility.rewards)}${r.approved_at?'':'<small>预计奖励 · 未确认</small>'}</td><td>${pill(r)}<small>${deliveries[r.fulfillment]}</small>${r.status==='pending'&&!r.eligibility.eligible?`<small>${safe(reasons[r.eligibility.reason]||'待核对')}</small>`:''}</td><td>${btn('detail',r.id,'查看','eye')}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">暂无推荐记录</td></tr>'}</tbody></table></div>
  <div class="ref-pagination"><span>${report.total} 条 · 第 ${Math.floor(offset/25)+1} 页</span><div><button class="icon-button" data-ref="prev" title="上一页" aria-label="上一页" ${offset===0?'disabled':''}>${icon('chevron-left')}</button><button class="icon-button" data-ref="next" title="下一页" aria-label="下一页" ${offset+25>=report.total?'disabled':''}>${icon('chevron-right')}</button></div></div>`;}
 function configuration(){return `<section class="ref-section"><div class="section-title"><h2>奖励规则</h2>${btn('edit-settings','','修改规则','settings-2')}</div><p>活动${settings.active?'启用':'已暂停'} · 独立寄送邮费 RM ${fmt(settings.postage_minor)}</p><div class="table-scroll"><table><thead><tr><th>购买配套</th><th>推荐人奖励</th><th>每份数量</th><th>状态</th></tr></thead><tbody>${settings.rules.map(r=>`<tr><td>${safe(r.sku_name)}</td><td>${safe(r.reward_name)}</td><td>${r.quantity}</td><td>${r.active?'启用':'停用'}</td></tr>`).join('')||'<tr><td colspan="4">尚未设置规则</td></tr>'}</tbody></table></div><p class="notice">首张有效正式订单参与，按付费配套份数累加；赠品行不计奖励。已审核奖励保留当时的规则明细。</p></section>`;}
 async function detail(id){const token=generation;const r=await rpc('get',{id});if(token!==generation||!allowed())return;editing=r;pending=null;
  const eligible=can('approve')&&r.status==='pending'&&r.eligibility.eligible;
  showDialog(eligible?'referral-approve':'detail',id,'推荐详情',`<div class="ref-detail"><dl class="detail-grid"><div><dt>被推荐客户</dt><dd>${safe(r.buyer_name)}<small>${safe(r.buyer_phone)}</small></dd></div><div><dt>推荐人</dt><dd>${safe(r.referrer_name||'未匹配')}<small>${safe(r.referral_phone)}</small></dd></div><div><dt>来源订单</dt><dd>#${r.order_number} · ${safe(r.erp_id)}<small>${dateLabel(r.order_date)} · ${safe(r.page_name)}</small></dd></div><div><dt>资格</dt><dd>${pill(r)}</dd></div></dl><section class="ref-section"><h3>${r.approved_at?'已确认奖励':'预计奖励'}</h3><p>${rewards(r.approved_at?r.rewards:r.eligibility.rewards)}</p></section>
  ${eligible?`<p class="notice">已入库记录符合规则；旧历史尚未完整迁入，请核对首购及旧系统是否已发奖。</p><label class="ref-check"><input type="checkbox" name="history_verified" required>已核对完整历史：本单为首购，且未在旧系统领取推荐奖励</label><label class="field"><span>核对依据 *</span><textarea name="history_note" rows="3" maxlength="500" required></textarea></label>`:r.status==='pending'?`<p class="alert-note">${safe(reasons[r.eligibility.reason]||'待核对资格')}</p>`:''}
  ${r.approved_at?`<section class="ref-section"><h3>寄送安排</h3><p>${safe(methods[r.delivery_method]||'未选择寄送方式')} · ${deliveries[r.fulfillment]}</p>${r.delivery_method==='self_postage'?`<p>${safe(r.recipient)} · ${safe(r.phone)}<br>${safe(r.address)}<br>邮费 RM ${fmt(r.postage_minor)} · ${r.postage_paid?'已收':'未收'}</p>`:''}${r.shipment_order_id?`<p>关联寄送订单 ID：${safe(r.shipment_order_id)}</p>`:''}${r.tracking_number?`<p>运单 ${safe(r.tracking_number)}</p>`:''}<p class="crm-caption">核对依据：${safe(r.history_note)}</p><div class="wide-actions">${r.status==='qualified'&&!['shipped','completed'].includes(r.fulfillment)?btn('delivery',r.id,'安排寄送','package'):''}${r.status==='qualified'&&r.fulfillment==='ready'?btn('ship',r.id,'登记寄出','truck'):''}${r.status==='qualified'&&r.fulfillment==='shipped'?btn('complete',r.id,'确认完成','check'):''}</div>${r.status==='review'?'<p class="alert-note">原订单取消前奖励已寄出，需人工核对；寄送历史已保留。</p>':''}</section>`:''}</div>`,'正式资料 · 不发送客户消息');
  if(eligible)$('#save-button').innerHTML=`${icon('check')}确认资格与奖励`;icons();}
 function delivery(){pending=null;const r=editing;showDialog('referral-delivery',r.id,'安排推荐奖励寄送',`<div class="form-grid"><label class="field full"><span>寄送方式 *</span><select name="delivery_method">${Object.entries(methods).map(([k,v])=>`<option value="${k}" ${r.delivery_method===k?'selected':''}>${v}</option>`).join('')}</select></label></div><div id="ref-delivery-fields"></div>`,'奖励已确认 · '+r.referrer_name);deliveryFields();}
 function deliveryFields(){const r=editing,m=value('delivery_method');const box=$('#ref-delivery-fields');
  box.innerHTML=m==='with_friend'?`<p class="notice">随被推荐人的原订单 #${r.order_number} 寄出。</p>`:m==='self_postage'?`<div class="form-grid">${inputField('收件人','recipient',r.recipient||r.referrer_name,'text',true)}${inputField('电话号码（含国家码）','phone',r.phone||r.referral_phone,'tel',true)}<label class="field full"><span>地址 *</span><textarea name="address" rows="3" required maxlength="500">${safe(r.address)}</textarea></label></div><p>独立寄送邮费 RM ${fmt(settings.postage_minor)}</p><label class="ref-check"><input name="postage_paid" type="checkbox" ${r.postage_paid?'checked':''}>已收到邮费</label>`:
   `<label class="field"><span>推荐人的下一张订单</span><select name="shipment_order_id"><option value="">暂未下单，保留奖励</option></select></label><p id="ref-shipment-status" role="status">正在查询订单…</p>`;
  if(m==='next_order')void loadNextOrders(r);}
 async function loadNextOrders(r){const select=form.elements.shipment_order_id;const token=generation;try{let start=0,total=0,items=[];
   do{const data=await DwellPayments.operationsRpc('list',{scope:'orders',customer_id:r.referrer_id,offset:start,limit:100});items.push(...data.items);total=data.total;start+=data.items.length;if(!data.items.length)break;}while(start<total);
   if(token!==generation||!select.isConnected)return;
   items=items.filter(o=>o.customer_id===r.referrer_id&&o.nature==='formal'&&o.status==='open'&&(o.order_date>r.order_date||(o.order_date===r.order_date&&Number(o.number)>Number(r.order_number))));
   select.innerHTML='<option value="">暂未下单，保留奖励</option>'+items.map(o=>`<option value="${o.id}" ${r.shipment_order_id===o.id?'selected':''}>#${o.number} · ${dateLabel(o.order_date)} · ${safe(o.erp_id)} · ${safe(o.customer_name)}</option>`).join('');$('#ref-shipment-status').textContent=items.length?'':'尚无符合条件的下一张正式订单。';
  }catch(e){if(token===generation&&select.isConnected){select.disabled=true;$('#ref-shipment-status').textContent=failure(e);$('#save-button').disabled=true;}}}
 async function editSettings(){const token=generation;skus=await DwellOperations.catalog('skus');if(token!==generation||!allowed())return;pending=null;
  showDialog('referral-settings',null,'推荐活动设置',`<label class="ref-check"><input name="active" type="checkbox" ${settings.active?'checked':''}>启用好友推荐</label>${inputField('独立寄送邮费 · RM','postage',settings.postage_minor/100,'number',true,'min="0" max="10000" step="0.01"')}<div id="ref-rules">${settings.rules.map(ruleRow).join('')}</div>${btn('add-rule','','添加规则','plus')}`,'Supabase · 不修改已确认奖励');icons();}
 function ruleRow(r={quantity:1,active:true}){const options=(kind,id)=>'<option value="">请选择</option>'+skus.filter(s=>s.sku_kind===kind).map(s=>`<option value="${s.id}" ${s.id===id?'selected':''}>${safe(s.code)} · ${safe(s.name)}</option>`).join('');return `<div class="ref-rule"><label class="field"><span>购买配套 *</span><select data-rule="sku_id" required>${options('bundle',r.sku_id)}</select></label><label class="field"><span>奖励单品 *</span><select data-rule="reward_sku_id" required>${options('single',r.reward_sku_id)}</select></label><label class="field"><span>每份奖励数量 *</span><input data-rule="quantity" type="number" min="1" max="100" step="1" value="${r.quantity}" required></label><label class="ref-check"><input data-rule="active" type="checkbox" ${r.active?'checked':''}>启用</label><button type="button" class="icon-button" data-ref="remove-rule" title="删除规则" aria-label="删除规则">${icon('trash-2')}</button></div>`;}
 async function submit(){if(busy||!can(dialogKind==='referral-settings'?'save_settings':dialogKind.replace('referral-','')))return;const token=generation;try{
  if(!pending){let action=dialogKind.replace('referral-',''),body={id:editing?.id,version:editing?.version};
   if(action==='approve')Object.assign(body,{settings_version:settings.version,history_verified:!!form.elements.history_verified.checked,history_note:value('history_note')});
   else if(action==='delivery')Object.assign(body,{delivery_method:value('delivery_method'),recipient:value('recipient'),phone:value('phone'),address:value('address'),postage_paid:!!form.elements.postage_paid?.checked,shipment_order_id:value('shipment_order_id')});
   else if(action==='ship')body.tracking_number=value('tracking_number');
   else if(action==='settings'){action='save_settings';body={version:settings.version,active:!!form.elements.active.checked,postage_minor:Math.round(Number(value('postage'))*100),rules:Array.from(form.querySelectorAll('.ref-rule')).map(row=>Object.fromEntries(Array.from(row.querySelectorAll('[data-rule]')).map(el=>[el.dataset.rule,el.type==='checkbox'?el.checked:el.type==='number'?Number(el.value):el.value])))};}
   pending={action,body:{...body,request_id:crypto.randomUUID()}};
  }
  busy=true;$('#save-button').disabled=true;await rpc(pending.action,pending.body);if(token!==generation||!allowed())return;pending=null;dialog.close();await refresh();toast('推荐资料已保存');
 }catch(e){if(token!==generation)return;if(/^[0-9A-Z]{5}$/.test(e?.code||'')&&!e.code.startsWith('08'))pending=null;
  if(pending)form.querySelectorAll('#dialog-body input,#dialog-body select,#dialog-body textarea').forEach(el=>el.disabled=true);
  $('#form-error').textContent=failure(e)+(pending?' 再点保存会重试同一份内容。':'');
 }finally{busy=false;$('#save-button').disabled=false;}}
 function profileMarkup(rows){return `<section class="profile-section"><div class="profile-section-head"><h3>${icon('gift')}推荐奖励</h3></div>${rows?.length?rows.map(r=>`<p>推荐 ${safe(r.buyer_name)} · #${r.order_number}<br>${rewards(r.rewards)}<br>${pill(r)} · ${deliveries[r.fulfillment]}</p>`).join(''):'<p class="profile-empty">暂无新后台推荐奖励</p>'}</section>`;}
 document.addEventListener('change',e=>{if(dialogKind==='referral-delivery'&&e.target.name==='delivery_method'&&!busy&&!pending){$('#save-button').disabled=false;deliveryFields();}});
 document.addEventListener('click',async e=>{const b=e.target.closest('[data-ref]');if(!b||b.disabled||!allowed()||loading||busy||state.view!=='referrals')return;const a=b.dataset.ref;if(!permitted(a))return;
  try{if(a==='refresh')await refresh();else if(a==='records'||a==='settings'){tab=a;render(false);}else if(a==='search'){search=$('#ref-search').value;filter=$('#ref-filter').value;offset=0;await refresh();}
   else if(a==='prev'||a==='next'){offset+=a==='next'?25:-25;await refresh();}else if(a==='detail')await detail(b.dataset.id);else if(a==='delivery')delivery();
   else if(a==='ship'||a==='complete'){pending=null;showDialog('referral-'+a,editing.id,a==='ship'?'登记奖励寄出':'确认奖励完成',a==='ship'?inputField('运单号码','tracking_number','','text',true):'<p>确认这份推荐奖励已完成寄送处理？</p>','正式资料 · '+editing.referrer_name);}
   else if(a==='edit-settings')await editSettings();else if(a==='add-rule'&&!pending){$('#ref-rules').insertAdjacentHTML('beforeend',ruleRow());icons();}else if(a==='remove-rule'&&!pending)b.closest('.ref-rule').remove();
  }catch(err){toast(failure(err));}});
 function orderMarkup(rows){return rows?.length?`<section class="ref-section"><h3>随单寄送的推荐奖励</h3>${rows.map(r=>`<p>推荐人：${safe(r.referrer_name)}<br>${rewards(r.rewards)}<br>${deliveries[r.fulfillment]}</p>`).join('')}</section>`:'';}
 return {render,leave,submit,profileMarkup,orderMarkup,failure};
})();
