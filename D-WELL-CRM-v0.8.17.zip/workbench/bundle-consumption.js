"use strict";
window.DwellBundleConsumption=(()=>{
  let singles=[];
  function calculate(components,options){
    const groups=new Map(),basis=[];
    for(const [index,c] of components.entries()){
      const sku=options.find(s=>s.id===c.sku_id),quantity=Number(c.quantity)||0,days=Number(sku?.consumption_days)||0;
      const key=c.choice_group?.trim()||`fixed:${index}`;
      if(!groups.has(key))groups.set(key,[]);
      groups.get(key).push(days*quantity);
      if(days&&quantity)basis.push(`${sku.name} × ${quantity} = ${days*quantity} 天${c.choice_group?'（'+c.choice_group+'）':''}`);
    }
    let min=0,max=0;for(const values of groups.values()){min+=Math.min(...values);max+=Math.max(...values);}
    return {minimum_days:min,maximum_days:max,basis};
  }
  function label(c){return c?.maximum_days?`${c.minimum_days||0}${c.maximum_days!==c.minimum_days?'–'+c.maximum_days:''} 天/份`:'未设置组成单品周期';}
  function field(components,options){
    singles=options;
    const c=calculate(components||[],singles);
    return `<div class="field full"><span>配套服用天数 · 自动合计</span><output id="bundle-consumption-total" aria-live="polite">${escapeHtml(label(c))}</output><small id="bundle-consumption-basis">${escapeHtml(c.basis.join('；'))}</small></div>`;
  }
  function update(){
    const output=document.querySelector('#bundle-consumption-total');if(!output)return;
    const components=[...document.querySelectorAll('#bundle-components .component-row')].map(row=>({sku_id:row.querySelector('[data-component-sku]').value,quantity:row.querySelector('[data-component-quantity]').value,choice_group:row.querySelector('[data-component-group]').value}));
    const c=calculate(components,singles);output.textContent=label(c);document.querySelector('#bundle-consumption-basis').textContent=c.basis.join('；');
  }
  document.addEventListener('input',e=>{if(e.target.closest('#bundle-components'))update();});
  document.addEventListener('change',e=>{if(e.target.closest('#bundle-components'))update();});
  document.addEventListener('click',e=>{if(e.target.closest('[data-component-add],[data-component-remove]'))queueMicrotask(update);});
  function summary(r){return r.sku_kind==='bundle'?`自动合计 · ${label(r.consumption_calculation)}`:r.consumption_days?`服用 ${r.consumption_days} 天/份`:'未设置服用周期';}
  return {calculate,label,field,summary};
})();
