"use strict";
window.DwellCouponRecipient=(()=>{
  let selected=null,items=[],serial=0,timer,locked=()=>false,lastField='phone',query='',total=0;
  const normalize=s=>String(s||'').trim().replace(/[+ ()-]/g,'');
  const active=()=>dialog.open&&dialogKind==='cloud-gift'&&(window.DwellPayments?.canCoreAction?.('orders','grant_coupon')??window.DwellPayments?.canManagePages());
  const usable=c=>c.active&&c.phones?.length;
  function sync(){if(active())$('#save-button').disabled=!selected;}
  function reset(){serial++;clearTimeout(timer);selected=null;items=[];query='';total=0;}
  function status(message){if(active())$('#coupon-recipient-status').textContent=message;}
  function choose(c){
    if(!active()||locked()||!usable(c))return;
    const typed=lastField==='phone'?normalize(value('phone')):'';
    const phone=c.phones.find(p=>typed&&p.includes(typed))||c.phones[0];
    selected={id:c.id,name:c.name,phone};serial++;clearTimeout(timer);
    field('phone').value=phone;field('customer_name').value=c.name;
    const platform=field('platform');
    if(c.channel&&![...platform.options].some(o=>o.value===c.channel))
      platform.insertAdjacentHTML('beforeend',`<option value="${escapeHtml(c.channel)}">${escapeHtml(c.channel)}（原记录）</option>`);
    platform.value=c.channel||'';
    $('#coupon-recipient-results').innerHTML='';
    status(`已选择：${c.name} · ${phone} · 客户 ID ${c.id}`);sync();
  }
  function results(){
    $('#coupon-recipient-results').innerHTML=items.length?`<ul class="coupon-recipient-list">${items.map(c=>`<li><div><strong>${escapeHtml(c.name)}</strong><small>${escapeHtml(c.phones.join(' / ')||'未登记电话号码')} · ${escapeHtml(c.channel||'')} · ID ${escapeHtml(c.id.slice(0,8))}</small></div><button type="button" class="secondary" data-coupon-customer="${escapeHtml(c.id)}" ${usable(c)?'':'disabled'} aria-label="选择 ${escapeHtml(c.name)} · ${escapeHtml(c.phones.join(' / '))}">${!c.active?'已停用':!c.phones.length?'缺少电话':'选择'}</button></li>`).join('')}</ul>${items.length<total?'<button type="button" class="secondary" data-coupon-more>更多客户</button>':''}`:'';
  }
  async function search(more=false){
    if(!active()||locked())return;
    const q=more?query:value(lastField).trim(),token=++serial;
    selected=null;sync();
    if(!more){items=[];total=0;query=q;results();}
    if(!/[\p{L}\p{N}]/u.test(q)){status('请输入电话号码或客户姓名');return;}
    status('正在查询 CRM 客户…');
    const moreButton=$('[data-coupon-more]');if(moreButton)moreButton.disabled=true;
    try{
      const r=await window.DwellPayments.catalogRpc('list','customers',{search:q,offset:items.length,limit:20});
      if(token!==serial||!active()||locked())return;
      items=more?[...items,...r.items]:r.items;total=r.total;results();
      status(total?`找到 ${total} 位客户，请选择并核对电话号码。`:'未找到已迁入 CRM 的客户。请先在客户资料核对或建档；此处不会新建客户。');
    }catch{
      if(token!==serial||!active()||locked())return;
      items=[];total=0;results();status('客户查询失败，请重试；尚未选择客户，不能发券。');
    }
  }
  function mount(customer,isLocked){
    reset();locked=isLocked;lastField='phone';
    sync();
    if(customer&&usable(customer))choose(customer);
    else status(customer?'此客户已停用或没有登记电话，请先在客户资料核对。':'请输入电话号码或客户姓名，选择现有客户');
  }
  function payload(){
    if(!selected||normalize(value('phone'))!==selected.phone||value('customer_name')!==selected.name)
      throw Object.assign(new Error('coupon_customer_selection_required'),{code:'P0001'});
    return {customer_id:selected.id,phone:selected.phone,customer_name:selected.name};
  }
  form.addEventListener('input',e=>{
    if(!active()||locked()||!['phone','customer_name'].includes(e.target.name))return;
    const old=selected;selected=null;serial++;clearTimeout(timer);items=[];total=0;lastField=e.target.name;
    if(old){
      const other=lastField==='phone'?'customer_name':'phone';
      if(value(other)===(other==='phone'?old.phone:old.name))field(other).value='';
      field('platform').value='';
    }
    results();sync();status(value(lastField).trim()?'正在查询 CRM 客户…':'请输入电话号码或客户姓名');
    timer=setTimeout(()=>void search(),300);
  });
  document.addEventListener('click',e=>{
    if(!active()||locked())return;
    const pick=e.target.closest('[data-coupon-customer]');
    if(pick){const c=items.find(c=>c.id===pick.dataset.couponCustomer);if(c)choose(c);return;}
    if(e.target.closest('[data-coupon-search]')){clearTimeout(timer);void search();}
    if(e.target.closest('[data-coupon-more]'))void search(true);
  });
  form.addEventListener('keydown',e=>{
    if(active()&&['phone','customer_name'].includes(e.target.name)&&e.key==='Enter'){
      e.preventDefault();lastField=e.target.name;clearTimeout(timer);void search();
    }
  });
  dialog.addEventListener('close',reset);
  return {mount,payload,sync,reset};
})();
