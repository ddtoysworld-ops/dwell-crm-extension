"use strict";
window.DwellCloudHR=(()=>{
  let pages=null,result=null,pageId='',month=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit'}).format(new Date()).slice(0,7),loading=false,error='',generation=0,nav='';
  const safe=escapeHtml,allowed=()=>window.DwellPayments?.canCoreAction?.('hr')??window.DwellPayments?.canManagePages();
  function clear(){generation++;pages=null;result=null;error='';loading=false;}
  function verified(r){
    const sum=(rows,key)=>rows.reduce((s,v)=>s+v[key],0);
    return r&&r.sales.length===r.sales_count&&r.deductions.length===r.deduction_count&&sum(r.daily,'gross_minor')===r.gross_minor&&sum(r.sales,'gmv_myr_minor')===r.gross_minor&&sum(r.daily,'deduction_minor')+(r.month_only_deduction_minor||0)===r.deduction_minor&&sum(r.deductions.filter(d=>d.date_precision==='month'),'amount_myr_minor')===(r.month_only_deduction_minor||0)&&sum(r.deductions,'amount_myr_minor')===r.deduction_minor;
  }
  const copyRows=r=>r.daily.map(d=>`${dateLabel(d.date)}\t${(d.gross_minor/100).toFixed(2)}`).join('\n');
  async function load(){
    if(!allowed())return;const token=++generation;loading=true;render(nav);
    try{const ps=await window.DwellOperations.catalog('pages');if(token!==generation||!allowed())return;pages=ps;}
    catch(e){if(token===generation){pages=[];error=window.DwellOperations.failure(e);}}
    finally{if(token===generation){loading=false;if(state.view==='hr')render();}}
  }
  function render(){
    if(state.view!=='hr')return;
    nav='';if(!allowed()){$('#main').innerHTML=heading('HR 销售导出','Supabase')+'<div class="empty">请使用获 HR 导出权限的账号登录。<p><button class="primary" data-action="ops-account">后台账户</button></p></div>';return;}
    if(pages===null&&!loading){void load();return;}
    const ok=verified(result);
    $('#main').innerHTML=heading('HR 销售导出','Supabase · 按主页 · GMV · 马币',`<button class="secondary" data-action="open-hr">${icon('external-link')}打开 HR 系统</button>`)+
      `<div class="notice">迁移验收中 · 旧订单仅部分导入，不代表整月销售额，请勿用于正式佣金结算。销售额含运费、已扣折扣；取消、拒收与部分退款按确认月份另列扣减。</div><section class="data-surface"><div class="toolbar"><select id="cloud-hr-page" aria-label="HR 主页"><option value="">请选择主页</option>${(pages||[]).map(p=>`<option value="${p.id}" ${p.id===pageId?'selected':''}>${safe(p.name)}</option>`).join('')}</select><input type="month" id="cloud-hr-month" aria-label="HR 月份" value="${safe(month)}"><button class="primary" data-action="cloud-hr-query" ${loading?'disabled':''}>${icon('refresh-cw')}${loading?'读取中…':'生成对账'}</button></div>${error?`<div class="alert-note" role="alert">${safe(error)}</div>`:''}${result?`<div class="toolbar"><strong>${safe(result.page_name)} · ${safe(result.month)}</strong><span class="pill ${ok?'success':'danger'}">${ok?'汇总与明细一致':'金额不一致，禁止复制'}</span><small>${safe(new Date(result.as_of).toLocaleString('zh-CN',{timeZone:'Asia/Kuala_Lumpur'}))}</small></div><div class="form-grid" style="padding:16px"><div class="field"><span>每日销售 GMV</span><strong>RM ${fmt(result.gross_minor)}</strong></div><div class="field"><span>取消 / 拒收 / 部分退款</span><strong>RM ${fmt(result.deduction_minor)}</strong>${result.month_only_deduction_count?`<small>其中 ${result.month_only_deduction_count} 笔仅记录月份：RM ${fmt(result.month_only_deduction_minor)}</small>`:''}</div><div class="field"><span>本月净销售</span><strong>RM ${fmt(result.gross_minor-result.deduction_minor)}</strong></div><div class="field"><span>订单 / 扣减记录</span><strong>${result.sales_count} / ${result.deduction_count}</strong></div><label class="field full"><span>日期与销售额</span><textarea id="cloud-hr-copy" readonly rows="10">${safe(copyRows(result))}</textarea></label></div><div class="toolbar"><button class="primary" data-action="cloud-hr-copy" ${ok?'':'disabled'}>${icon('copy')}复制每日销售额</button><button class="secondary" data-action="cloud-hr-deduction" ${ok?'':'disabled'}>${icon('copy')}复制扣减总额</button></div><div class="notice">日期与销售额粘贴到 HR 的每日销售栏；取消、拒收、部分退款金额填入独立扣减栏，勿重复扣减。此处一致仅代表云端内部对账，不代表整月旧系统资料已核对完毕。</div><details style="padding:16px"><summary>销售明细（${result.sales_count}）</summary><div class="table-scroll"><table><thead><tr><th>日期 / 订单</th><th>客户</th><th>原币金额</th><th>GMV · RM</th><th>状态</th></tr></thead><tbody>${result.sales.map(r=>`<tr><td>${dateLabel(r.order_date)} · #${r.number}</td><td>${safe(r.customer_name)}</td><td>${r.currency} ${fmt(r.gmv_minor)}</td><td>${fmt(r.gmv_myr_minor)}</td><td>${safe(r.status)}</td></tr>`).join('')}</tbody></table></div></details><details style="padding:16px"><summary>扣减明细（${result.deduction_count}）</summary><div class="table-scroll"><table><thead><tr><th>确认日期 / 月份</th><th>原订单 / 日期</th><th>客户</th><th>扣减 · RM</th><th>原因</th></tr></thead><tbody>${result.deductions.map(r=>`<tr><td>${r.date_precision==='month'?safe(r.confirmed_month.slice(0,7))+'（具体日期未知）':dateLabel(r.confirmed_date)}</td><td>#${r.number} · ${dateLabel(r.order_date)}</td><td>${safe(r.customer_name)}</td><td>${fmt(r.amount_myr_minor)}</td><td>${r.kind==='partial_refund'?'部分退款':r.kind==='rejected'?'COD 拒收':'取消 / 拒收'}<small>${safe(r.reason)}</small></td></tr>`).join('')}</tbody></table></div></details>`:'<div class="empty">请选择主页和月份</div>'}</section>`;icons();
  }
  function showNegativeWarning(){
    if(!result||result.deduction_minor<=result.gross_minor)return;
    const el=document.createElement('p');el.className='alert-note';el.setAttribute('role','alert');el.textContent='本月净销售为负。旧 HR 可能按零计算，请先核对佣金处理。';$('#main .data-surface')?.prepend(el);
  }
  async function action(cmd){
    if(!allowed()||loading)return;
    if(cmd==='cloud-hr-query'){
      pageId=$('#cloud-hr-page').value;month=$('#cloud-hr-month').value;result=null;error='';
      if(!pageId||!month){error='请选择主页和月份。';render(nav);return;}
      const token=++generation;loading=true;render(nav);
      try{const r=await window.DwellPayments.hrRpc({page_id:pageId,month});if(token!==generation||!allowed())return;result=r;}
      catch(e){if(token===generation)error=String(e.message).includes('hr_month_invalid')?'月份不能晚于当前月份。':String(e.message).includes('hr_export_too_large')?'本月超过 10,000 条，请联系管理员分批对账，不会输出截断数据。':window.DwellOperations.failure(e);}
      finally{if(token===generation){loading=false;if(state.view==='hr'){render();showNegativeWarning();}}}
    }else if(verified(result)){
      try{await navigator.clipboard.writeText(cmd==='cloud-hr-deduction'?(result.deduction_minor/100).toFixed(2):copyRows(result));toast('已复制');}
      catch{if(cmd==='cloud-hr-deduction')toast(`复制失败，请手动输入扣减金额 ${(result.deduction_minor/100).toFixed(2)}`);else{toast('浏览器未允许复制，请选中导出框内容复制。');$('#cloud-hr-copy')?.select();}}
    }
  }
  document.addEventListener('change',e=>{if(['cloud-hr-page','cloud-hr-month'].includes(e.target.id)){generation++;loading=false;pageId=$('#cloud-hr-page').value;month=$('#cloud-hr-month').value;result=null;error='';render(nav);}});
  return {render,action,clear,leave:clear,verified};
})();
