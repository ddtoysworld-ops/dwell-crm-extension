"use strict";
(() => {
  let launch = null;
  const sidepanel=new URL(location.href).searchParams.get('surface')==='sidepanel';
  if(sidepanel)document.body.classList.add('plugin-panel');
  window.DwellWorkbenchContext = () => launch?.context ? { ...launch.context } : null;
  window.DwellWorkbenchCustomer = () => launch?.customer || null;
  const banner = document.createElement('section'); banner.id = 'workbench-context';
  const title = document.createElement('strong'); title.textContent = 'CRM 工作台';
  const status = document.createElement('p'); status.id = 'workbench-status';
  status.textContent = '测试版：真实资料只读，表单可填写；保存、绑定、发券和奖励操作尚未开放。';
  const mode=document.createElement('span');mode.className='workbench-mode';mode.textContent='测试草稿 · 线上只读';
  banner.append(title,mode,status); document.querySelector('.topbar').after(banner);
  const b = (text,action) => { const n=document.createElement('button');n.type='button';n.className='secondary';
    const symbol=({'填写订单':'plus','客户档案':'user-round','查询':'search','选用此客户':'check','绑定此对话':'link','解除绑定':'unlink'})[text];
    if(symbol)n.innerHTML=icon(symbol);const label=document.createElement('span');label.textContent=text;n.append(label);n.addEventListener('click',action);return n; };
  async function newOrder() {
    if(!launch){status.textContent='请从当前客户对话重新打开工作台。';return;}
    await DwellOperations.action('cloud-new');
    if (!dialog.open || dialogKind !== 'cloud-order') return;
    if(launch.preview_only!==false)$('#dialog-eyebrow').textContent='测试草稿 · 不保存线上订单';
    const c=launch?.customer;
    if(field('phone')) { field('phone').value=c?.phones?.[0] || launch?.context?.phone || ''; field('phone').dispatchEvent(new Event('input',{bubbles:true})); }
    if(field('customer_name') && c?.name)field('customer_name').value=c.name;
    if(field('platform'))field('platform').value=launch?.context?.platform==='whatsapp'?'WhatsApp':'Facebook';
    if(launch?.context?.page){
      const pages=await DwellOperations.catalog('pages');const page=pages.find(p=>p.mailbox_id===launch.context.page);
      if(page&&field('page_id')){field('page_id').value=page.id;field('page_id').dispatchEvent(new Event('change',{bubbles:true}));}
    }
    if(launch.preview_only!==false){const note=document.createElement('p');note.className='workbench-preview-note';note.textContent='测试草稿 · 不写入线上订单。默认收货资料请核对后使用。';$('#dialog-body').prepend(note);}
  }
  banner.append(b('填写订单',()=>void newOrder().catch(e=>{status.textContent=e.message;})));
  banner.append(b('客户档案',()=>{if(launch?.customer?.id)void DwellOperations.action('cloud-customer',launch.customer.id);else{state.view='customers';window.render();}}));
  document.addEventListener('click',event=>{
    const command=event.target.closest('[data-action]');
    if(command?.dataset.action==='cloud-new'){
      event.preventDefault();event.stopImmediatePropagation();void newOrder().catch(e=>{status.textContent=e.message;});
    }else if(command?.dataset.action==='cloud-gift'&&!command.dataset.id&&launch?.customer?.id){
      event.preventDefault();event.stopImmediatePropagation();void DwellOperations.action('cloud-gift',launch.customer.id);
    }
  },true);
  const finder=document.createElement('details');finder.className='workbench-finder';
  const summary=document.createElement('summary');summary.textContent='查找与关联客户';
  const search=document.createElement('input');search.type='search';search.placeholder='姓名或电话号码';search.setAttribute('aria-label','查找关联客户');search.maxLength=100;
  const results=document.createElement('div');results.className='workbench-results';results.setAttribute('aria-live','polite');
  let searchGeneration=0,selectionGeneration=0;
  const lookup=b('查询',async()=>{
    if(!launch){status.textContent='请从当前客户对话重新打开工作台。';return;}
    const generation=++searchGeneration;results.replaceChildren();
    try{
      const r=await DwellWorkbenchBridge('rpc',{name:'dwell_ops_sidebar_read',args:{p_action:'search',p_payload:{query:search.value.trim()}}});
      if(generation!==searchGeneration)return;
      if(!r.items?.length){results.textContent='未找到客户，不会自动建立重复客户。';return;}
      for(const customer of r.items){
        const row=document.createElement('div');row.className='workbench-match';
        const label=document.createElement('span');label.textContent=customer.name+' · '+(customer.phones||[]).join(' / ');
        row.append(label,b('选用此客户',async()=>{
          if(dialog.open){status.textContent='请先关闭当前表单，再更换关联客户。';return;}
          const selected=++selectionGeneration;
          try{
            const p=await DwellWorkbenchBridge('rpc',{name:'dwell_ops_sidebar_read',args:{p_action:'profile',p_payload:{id:customer.id}}});
            if(selected!==selectionGeneration||dialog.open)return;
            if(!p.customer?.id)throw new Error('客户资料不可用，请重新查询。');
            launch.customer=p.customer;title.textContent=p.customer.name+' · '+(p.customer.phones||[]).join(' / ');
            status.textContent='已选用客户资料，尚未永久绑定对话。';results.replaceChildren();finder.open=false;
          }catch(e){status.textContent=e.message;}
        }));results.append(row);
      }
    }catch(e){if(generation===searchGeneration)results.textContent=e.message;}
  });
  search.addEventListener('input',()=>{++searchGeneration;++selectionGeneration;results.replaceChildren();});
  search.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();lookup.click();}});
  finder.append(summary,search,lookup,results);banner.append(finder);
  async function binding(unbind=false){
    if(launch?.context?.platform!=='messenger'){status.textContent='WhatsApp 按电话号码查询，不需要绑定 Messenger 对话。';return;}
    if(!unbind&&!launch.customer?.id){status.textContent='请先查询并选用客户。';return;}
    const identity={mailbox_id:launch.context.page,uid:launch.context.uid};
    try{
      const previous=await DwellWorkbenchBridge('rpc',{name:'dwell_ops_sidebar_read',args:{p_action:'messenger',p_payload:identity}});
      const label=unbind?'解除此对话绑定':'绑定此对话到 '+launch.customer.name;
      showDialog('workbench-binding','',label,'<p class="notice">仅改变 Messenger 对话关联，不合并客户、不修改旧订单。</p><label class="payment-confirm"><input type="checkbox" required name="binding_confirm"><span>已核对当前对话与所选客户。</span></label>','Supabase · 客户关联');
      const form=$('#edit-form');
      const requestId=crypto.randomUUID(),customerId=launch.customer?.id;
      let saving=false;
      const save=async event=>{
        if(dialogKind!=='workbench-binding')return;
        event.preventDefault();event.stopImmediatePropagation();if(!form.reportValidity())return;
        if(launch.preview_only!==false){$('#form-error').textContent='测试版未开放绑定，没有修改现有对话关联。';return;}
        if(saving)return;saving=true;$('#save-button').disabled=true;
        try{
          await DwellWorkbenchBridge('rpc',{name:'dwell_ops_sidebar_crm',args:{p_action:unbind?'unbind':'bind',p_payload:{...identity,customer_id:unbind?undefined:customerId,version:previous.binding_version||0,request_id:requestId}}});
          dialog.close();status.textContent=unbind?'已解除绑定，旧订单保持不变。':'已绑定当前对话。';
        }catch(e){$('#form-error').textContent=e.message;}finally{saving=false;$('#save-button').disabled=false;}
      };
      form.addEventListener('submit',save,{capture:true});dialog.addEventListener('close',()=>form.removeEventListener('submit',save,{capture:true}),{once:true});
    }catch(e){status.textContent=e.message;}
  }
  const bindButton=b('绑定此对话',()=>void binding()),unbindButton=b('解除绑定',()=>void binding(true));
  bindButton.hidden=true;unbindButton.hidden=true;banner.append(bindButton,unbindButton);
  window.DwellWorkbenchInvalidate=(reason)=>{
    launch=null;++searchGeneration;++selectionGeneration;search.value='';results.replaceChildren();
    if(dialog.open)dialog.close();
    $('#dialog-body').replaceChildren();
    window.DwellOperations?.clear();window.DwellReferrals?.leave();window.DwellLucky?.leave();window.DwellRewards?.leave();
    $('#main').replaceChildren();
    title.textContent='CRM 工作台';bindButton.hidden=unbindButton.hidden=true;
    status.textContent=reason||'登录状态已改变，请从当前顾客对话重新打开工作台。';
  };
  let checking=false;
  async function checkContext(){
    if(!launch||checking)return;checking=true;
    try{await DwellWorkbenchBridge('check-context');}
    catch(e){
      if(['workbench_context_changed','workbench_ticket_expired','sidebar_access_denied','42501'].includes(e.code))window.DwellWorkbenchInvalidate(e.message);
      else status.textContent='暂时无法核对当前对话，草稿保留；连接恢复后再确认。';
    }finally{checking=false;}
  }
  chrome.runtime.onMessage.addListener(message=>{if(['dwell-context-update','dwell-tab-update'].includes(message?.type))void checkContext();});
  setInterval(()=>void checkContext(),5000);
  if(sidepanel){
    const head=document.createElement('header');head.className='plugin-header';
    const logo=document.createElement('img');logo.src='./dwell-logo.png';logo.alt="D'WELL";
    const label=document.createElement('strong');label.textContent="D'WELL 客户 CRM";
    const account=b('登录与账户',()=>{location.href='../panel.html';});head.append(logo,label,account);
    const nav=document.createElement('nav');nav.className='plugin-nav';nav.setAttribute('aria-label','插件功能');
    for(const [view,label] of [['customers','客户资料'],['orders','订单'],['tasks','跟进'],['referrals','好友推荐'],['draws','幸运抽奖'],['rewards','优惠券与奖品']]){
      const button=b(label,()=>{
        if(dialog.open)dialog.close();if(!launch)return;
        if(view==='customers'&&launch.customer?.id){void DwellOperations.action('cloud-customer',launch.customer.id);return;}
        state.view=view;window.render();for(const n of nav.querySelectorAll('button'))n.setAttribute('aria-selected',String(n===button));
      });
      button.setAttribute('role','tab');button.dataset.pluginView=view;nav.append(button);
    }
    banner.before(head,nav);
    const labelTables=()=>document.querySelectorAll('#main table').forEach(table=>{
      const headings=[...table.querySelectorAll('thead th')].map(n=>n.textContent.trim());
      table.querySelectorAll('tbody tr').forEach(row=>[...row.children].forEach((cell,index)=>{if(cell.colSpan===1)cell.dataset.label=headings[index]||'';}));
    });
    new MutationObserver(labelTables).observe($('#main'),{childList:true,subtree:true});
  }
  // The release gate is enforced in the worker too; this capture handler gives a clear UI outcome.
  document.addEventListener('submit', event => {
    if (event.target.id !== 'edit-form') return;
    if(launch?.preview_only===false)return;
    event.preventDefault();event.stopImmediatePropagation();
    if(!event.target.reportValidity())return;
    $('#form-error').textContent='测试版未开放保存：没有写入订单、客户、优惠券或奖励。';
  },true);
  document.addEventListener('DOMContentLoaded',async()=>{
    try {
      await DwellPayments.refresh();
      launch=await DwellWorkbenchBridge('launch',{ticket:new URL(location.href).searchParams.get('ticket')});
      if(!launch.preview_only){mode.textContent='Supabase · 业务操作';status.textContent='已关联当前对话。保存前请核对客户和收货资料。';}
      bindButton.hidden=unbindButton.hidden=launch.context?.platform!=='messenger';
      if(launch.customer)title.textContent=launch.customer.name+' · '+(launch.customer.phones?.[0]||'');
      else title.textContent='未匹配客户 · 请搜索或填写新客户资料';
      state.view=launch.view||'orders';window.render();
      document.querySelectorAll('[data-plugin-view]').forEach(n=>n.setAttribute('aria-selected',String(n.dataset.pluginView===state.view)));
      if(launch.view==='orders')await newOrder();
      if(launch.view==='customers'){finder.open=true;search.focus();}
    }catch(e){status.textContent=e.message||'无法读取，请重新从测试插件打开工作台。';}
  });
})();
