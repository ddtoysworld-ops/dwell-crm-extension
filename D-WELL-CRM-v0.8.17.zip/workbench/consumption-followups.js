"use strict";
window.DwellFollowups=(()=>{
  const allowed=()=>window.DwellPayments?.canCoreAction?.('orders','consumption_list')??window.DwellPayments?.canManagePages(),safe=escapeHtml;
  const rpc=(action,body)=>window.DwellPayments.operationsRpc(action,body);
  let mode='manual',rows=null,pages=[],total=0,offset=0,search='',pageId='',status='today',today='',loading=false,error='',generation=0,busy=false,pending=null,editing=null;
  let unsubscribe=null,connected=false,dirty=false,lastRead=0,quickPending=null;
  const active=()=>state.view==='tasks'&&mode==='consumption';
  const tabs=()=>`<div class="payment-tabs" role="tablist" aria-label="跟进任务类型"><button role="tab" aria-selected="${mode==='manual'}" data-action="follow-manual">手动待处理</button><button role="tab" aria-selected="${mode==='consumption'}" data-action="follow-consumption">服用到期跟进</button></div>`;
  function leave(){generation++;rows=null;loading=false;error='';unsubscribe?.();unsubscribe=null;connected=false;dirty=false;}
  function clear(){leave();pages=[];mode='manual';status='today';offset=0;search='';pageId='';pending=null;quickPending=null;editing=null;}
  function failure(e){
    const msg=String(e?.message||e);
    if(msg.includes('core_stale_version'))return '此任务已被更新，请刷新后重新处理。';
    if(msg.includes('consumption_not_open'))return '此轮已结束、顾客已复购或原订单已取消，请刷新名单。';
    if(msg.includes('task_date_invalid'))return '再次跟进日期不能早于今天。';
    if(msg.includes('core_owner_required'))return '当前账号没有跟进权限，请联系管理员。';
    if(e?.code==='PGRST202')return '服用跟进接口尚未部署。';
    return '读取或保存未成功，请重试并核对。';
  }
  async function refresh(silent=false){
    if(!allowed()||!active()||loading)return;
    const token=++generation,previous=JSON.stringify([rows,total,today,error]);loading=true;error='';dirty=false;if(!silent)render();
    try{
      const all=[];
      if(pages.length)all.push(...pages);
      else for(let start=0;;start+=100){const p=await window.DwellPayments.catalogRpc('list','pages',{offset:start,limit:100});all.push(...p.items);if(all.length>=p.total||!p.items.length)break;}
      const data=await rpc('consumption_list',{search,page_id:pageId,status,offset,limit:25});
      try{
        const identities=await window.DwellMessenger?.lookup(data.items)||[];
        data.items=data.items.map(r=>({...r,messenger:identities.find(l=>l.customer_id===r.customer_id&&l.page_id===r.page_id)}));
      }catch{data.items=data.items.map(r=>({...r,messenger_error:true}));}
      if(token!==generation||!allowed()||!active())return;
      pages=all;rows=data.items;total=data.total;today=data.today;lastRead=Date.now();
      if(offset&&offset>=total){offset=Math.max(0,Math.ceil(total/25)-1)*25;dirty=true;}
    }catch(e){if(token===generation){rows=[];total=0;error=failure(e);}}
    finally{if(token===generation){loading=false;if(!silent||previous!==JSON.stringify([rows,total,today,error]))render();if(dirty)requestRefresh();}}
  }
  function requestRefresh(){
    dirty=true;
    if(active()&&allowed()&&!document.hidden&&!dialog.open&&!loading&&!busy&&document.activeElement?.id!=='follow-search')void refresh(true);
  }
  function subscribe(){
    if(unsubscribe||!window.DwellPayments.subscribeFollowups)return;
    unsubscribe=window.DwellPayments.subscribeFollowups(requestRefresh,s=>{connected=s==='SUBSCRIBED';if(connected)requestRefresh();});
  }
  function channel(platform){
    const p=String(platform||'').trim().toLowerCase();
    if(p==='facebook'||p==='messenger')return 'Messenger';
    if(p.includes('whatsapp')||p.includes('网站')||p==='website')return 'WhatsApp';
    return p==='call'?'电话':p==='instagram'?'Instagram':'渠道待确认';
  }
  function row(r){
    const phone=String(r.phone||'').replace(/\D/g,''),contact=channel(r.platform),done=!!r.completed_at;
    return `<tr><td><input type="checkbox" class="follow-check" data-follow-complete="${r.id}" aria-label="完成跟进 ${safe(r.customer_name)}" ${done?'checked':''} ${done||busy||r.state!=='open'?'disabled':''}></td><td><strong>${safe(r.customer_name)}</strong><small>${safe(r.phone)}</small><button class="text-button" data-action="cloud-customer" data-id="${r.customer_id}">客户档案</button></td><td><strong>${contact}</strong><small>${safe(r.page_name)}</small><small>${safe(r.actor_name)}</small>${contact==='Messenger'?(r.messenger_error?'<small>对话资料读取失败</small>':window.DwellMessenger?.button(r.messenger)||'<small>未关联 Messenger 对话</small>'):''}${contact==='WhatsApp'&&/^6\d{7,15}$/.test(phone)?`<a class="text-button" href="https://wa.me/${phone}" target="_blank" rel="noopener noreferrer">打开 WhatsApp</a>`:''}</td><td><strong>${safe(r.product_name)}</strong>${r.items.map(i=>`<small>${safe(i.name)} × ${i.quantity} · ${i.days} 天/份</small>`).join('')}<small>订单 #${r.number} · ${dateLabel(r.order_date)}</small><small>ERP ${safe(r.erp_id||'—')}</small><small>运单 ${safe(r.tracking_number||'—')}</small></td><td><strong>${dateLabel(r.expected_end)}</strong><small>${r.duration_days} 天</small>${r.action_date!==r.expected_end?`<small>另约 ${dateLabel(r.action_date)}</small>`:''}${done?'<small>已完成</small>':''}</td><td>${r.purchase_count} 次<small>RM ${fmt(r.spend_minor)}</small></td><td>${safe(r.note||'—')}${done?'<small>今日已跟进</small>':''}</td><td>${r.state==='open'?`<button class="icon-button" data-action="follow-process" data-id="${r.id}" title="备注 / 再次跟进" aria-label="备注 / 再次跟进" ${busy?'disabled':''}>${icon('square-pen')}</button>`:''}</td></tr>`;
  }
  function render(){
    if(!active())return;
    if(!allowed()){clear();window.DwellOperations.render();return;}
    subscribe();
    if(rows===null&&!loading){void refresh();return;}
    $('#main').innerHTML=heading('待处理任务清单','Supabase · 全部主页',`<button class="secondary" data-action="follow-refresh" ${loading?'disabled':''}>${icon('refresh-cw')}刷新</button>`)+tabs()+
      `<div class="notice">马来西亚日期 ${today?dateLabel(today):'—'} · 仅含启用规则后产生的订单，旧资料尚未回填。</div>${error?`<div class="alert-note" role="alert">${safe(error)}</div>`:''}<section class="data-surface"><div class="toolbar"><label class="search-field">${icon('search')}<input id="follow-search" aria-label="搜索服用跟进" placeholder="姓名、电话或产品" maxlength="100" value="${safe(search)}"></label><select id="follow-page" aria-label="跟进主页"><option value="">全部主页</option>${pages.map(p=>`<option value="${p.id}" ${pageId===p.id?'selected':''}>${safe(p.name)}</option>`).join('')}</select><select id="follow-status" aria-label="服用跟进状态">${[['today','今日待跟进'],['completed_today','今日已完成'],['overdue','之前未完成']].map(([id,label])=>`<option value="${id}" ${status===id?'selected':''}>${label}</option>`).join('')}</select><button class="secondary" data-action="follow-search">${icon('search')}查询</button></div><div class="table-scroll"><table class="follow-checklist"><thead><tr>${['完成','客户','联系渠道 / 主页','产品 / 配套','预计用完日期','购买 / 累计金额','跟进备注','操作'].map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${(rows||[]).map(row).join('')}</tbody></table>${!rows?.length?`<div class="empty">${loading?'读取中…':error?'读取失败':status==='today'?'今天暂无待跟进客户':status==='completed_today'?'今天尚无完成记录':'暂无之前未完成的跟进'}</div>`:''}</div><div class="table-foot"><span>${total} 条 · 第 ${Math.floor(offset/25)+1} 页</span><div class="row-actions"><button class="icon-button" data-action="follow-prev" title="上一页" aria-label="上一页" ${loading||!offset?'disabled':''}>${icon('chevron-left')}</button><button class="icon-button" data-action="follow-next" title="下一页" aria-label="下一页" ${loading||offset+25>=total?'disabled':''}>${icon('chevron-right')}</button></div></div></section>`;icons();
  }
  function updateOutcome(){const date=field('follow_date');if(!date)return;const show=value('follow_outcome')==='reschedule';date.closest('label').hidden=!show;date.disabled=!show;date.required=show;}
  async function action(cmd,id){
    if(busy||!allowed()||loading&&cmd!=='follow-manual')return;
    if(cmd==='follow-manual'){mode='manual';leave();window.DwellOperations.render();return;}
    if(cmd==='follow-consumption'){mode='consumption';window.DwellOperations.leave();leave();render();return;}
    if(cmd==='follow-refresh'){await refresh();return;}
    if(cmd==='follow-search'){search=$('#follow-search').value.trim();pageId=$('#follow-page').value;status=$('#follow-status').value;offset=0;await refresh();return;}
    if(cmd==='follow-next'||cmd==='follow-prev'){offset=Math.max(0,offset+(cmd==='follow-next'?25:-25));await refresh();return;}
    if(cmd==='follow-process'){
      editing=rows?.find(r=>r.id===id);if(!editing)return;pending=null;
      showDialog('follow-process',id,'记录服用跟进',`<p class="follow-customer">${safe(editing.customer_name)} · ${safe(editing.product_name)}</p><div class="form-grid">${selectField('联系方法','follow_method',[['','请选择'],['message','信息'],['call','电话'],['other','其他']],'',true)}${selectField('处理结果','follow_outcome',[['reschedule','再次跟进'],['complete','结束本轮跟进']],'reschedule',true)}${inputField('再次跟进日期','follow_date','','date',true,`min="${today}"`)}<label class="field full"><span>跟进备注</span><textarea name="follow_note" rows="3" maxlength="2000"></textarea></label></div>`,'正式资料 · 保存至 Supabase');updateOutcome();
    }
  }
  async function complete(id){
    if(busy||loading||!allowed())return;
    const item=rows?.find(r=>r.id===id);if(!item||item.state!=='open')return;
    const token=generation;
    if(!quickPending||quickPending.id!==id||quickPending.version!==item.version){
      quickPending={id,version:item.version,request_id:crypto.randomUUID(),outcome:'complete',method:channel(item.platform)==='电话'?'call':'message',note:item.note||''};
    }
    busy=true;render();
    try{
      await rpc('consumption_process',quickPending);
      if(token!==generation||!allowed())return;
      quickPending=null;await refresh();toast('已完成跟进');
    }catch(e){
      if(token!==generation)return;
      if(/^[0-9A-Z]{5}$/.test(e?.code||'')&&!e.code.startsWith('08')&&!e.code.startsWith('PGRST'))quickPending=null;
      error=failure(e)+(quickPending?' 请再次勾选以重试同一笔记录。':'');
      if(/core_stale_version|consumption_not_open/.test(e?.message||'')){toast(error);await refresh();}
    }finally{busy=false;if(token<=generation&&active())render();if(dirty)requestRefresh();}
  }
  async function submit(){
    if(busy||!editing||!allowed())return;const token=generation;
    try{
      pending??={id:editing.id,version:editing.version,request_id:crypto.randomUUID(),outcome:value('follow_outcome'),method:value('follow_method'),due_date:value('follow_date'),note:value('follow_note')};
      busy=true;$('#save-button').disabled=true;
      await rpc('consumption_process',pending);
      if(token!==generation||!allowed())return;
      pending=null;dialog.close();await refresh();toast('跟进已记录');
    }catch(e){
      if(token!==generation)return;
      if(/^[0-9A-Z]{5}$/.test(e?.code||'')&&!e.code.startsWith('08')&&!e.code.startsWith('PGRST'))pending=null;
      if(pending)form.querySelectorAll('#dialog-body input,#dialog-body select,#dialog-body textarea').forEach(el=>el.disabled=true);
      $('#form-error').textContent=failure(e)+(pending?' 再点保存将重试同一份记录。':'');
    }finally{busy=false;$('#save-button').disabled=false;if(active())render();if(dirty)requestRefresh();}
  }
  form.addEventListener('change',e=>{if(dialogKind==='follow-process'&&e.target.name==='follow_outcome')updateOutcome();});
  dialog.addEventListener('cancel',e=>{if(busy&&dialogKind==='follow-process')e.preventDefault();});
  document.addEventListener('click',e=>{if(busy&&dialogKind==='follow-process'&&(e.target===dialog||e.target.closest('[data-close]'))){e.preventDefault();e.stopImmediatePropagation();}},true);
  document.addEventListener('keydown',e=>{if(e.target.id==='follow-search'&&e.key==='Enter'){e.preventDefault();void action('follow-search');}});
  document.addEventListener('change',e=>{
    if(e.target.matches('[data-follow-complete]')){e.target.checked=false;void complete(e.target.dataset.followComplete);}
    if(e.target.id==='follow-page'||e.target.id==='follow-status')void action('follow-search');
  });
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)requestRefresh();});
  window.addEventListener('focus',requestRefresh);
  window.addEventListener('online',requestRefresh);
  // Realtime invalidates the list; fallback polling and the clock handle reconnects and midnight.
  setInterval(()=>{if(dirty||Date.now()-lastRead>(connected?60000:5000))requestRefresh();},5000);
  return {active,tabs,render,action,submit,leave,clear};
})();
