"use strict";
window.DwellCloudAnalytics=(()=>{
  const safe=escapeHtml,allowed=()=>window.DwellPayments?.canCoreAction?.('orders','analytics')??window.DwellPayments?.canManagePages();
  const labels={none:'尚无有效购买',once:'购买 1 次',repeat:'购买 2 次及以上',under500:'低于 RM 500','500to1500':'RM 500 至不足 1,500','1500to3000':'RM 1,500 至不足 3,000','3000plus':'RM 3,000 及以上'};
  let data=null,pages=[],loading=false,error='',generation=0;
  let filters={page_id:'',search:'',sort:'amount',direction:'desc',purchase:'all',spend:'all',offset:0,limit:25};
  function clear(){generation++;data=null;pages=[];loading=false;error='';filters={page_id:'',search:'',sort:'amount',direction:'desc',purchase:'all',spend:'all',offset:0,limit:25};}
  async function refresh(){
    if(!allowed()){clear();render();return;}
    const token=++generation;loading=true;error='';paint();
    try{
      const ps=[];for(let offset=0;;offset+=100){const r=await DwellPayments.catalogRpc('list','pages',{offset,limit:100});ps.push(...r.items);if(ps.length>=r.total||!r.items.length)break;}
      const r=await DwellPayments.operationsRpc('analytics',{...filters});
      if(token!==generation||!allowed())return;pages=ps;data=r;
    }catch(e){if(token===generation){data=null;error=e?.code==='PGRST202'?'客户分析接口尚未部署。':'读取客户分析失败，请刷新重试。';}}
    finally{if(token===generation){loading=false;paint();}}
  }
  function options(items,value){return items.map(([k,v])=>`<option value="${safe(k)}" ${k===value?'selected':''}>${safe(v)}</option>`).join('');}
  function select(key,label,items){return `<label class="field"><span>${label}</span><select id="live-analytics-${key}" ${loading?'disabled':''}>${options(items,filters[key])}</select></label>`;}
  function chart(key,title,items){
    const n=data.summary.customers;
    return `<section class="crm-chart"><h2>${title}</h2><p class="crm-caption">分母：当前主页与搜索范围的 ${n} 位客户</p><div class="crm-bars">${items.map((r,i)=>{const pct=n?r.count/n*100:0;return `<button type="button" class="crm-bar-row" data-live-bucket="${key}" data-key="${r.key}" aria-pressed="${filters[key]===r.key}" ${loading||!r.count?'disabled':''}><span class="crm-bar-label">${labels[r.key]}</span><span class="crm-bar-track"><span class="crm-bar-fill tone-${i}" style="width:${pct}%"></span></span><span class="crm-bar-value">${r.count} 人 <strong>${pct.toFixed(1)}%</strong></span></button>`;}).join('')}</div></section>`;
  }
  function paint(){if(state.view==='analytics')render(false);}
  function render(fetch=true){
    if(!allowed()){$('#main').innerHTML=heading('客户分析','Supabase')+'<div class="empty">请使用获客户资料权限的账号登录后查看。</div>';return;}
    if(fetch){void refresh();return;}
    $('#main').innerHTML=heading('客户分析','Supabase · 已入库订单分析',`<div class="wide-actions"><button class="secondary" data-live-action="definitions">${icon('info')}统计口径</button><button class="secondary" data-live-action="refresh" ${loading?'disabled':''}>${icon('refresh-cw')}刷新</button></div>`)+
      `<div class="crm-filters">${select('page_id','所属主页',[['','全部主页'],...pages.map(p=>[p.id,p.name+(p.active?'':'（已停用）')])])}<label class="field"><span>客户姓名、号码或 ID</span><input id="live-analytics-search" maxlength="100" value="${safe(filters.search)}" ${loading?'disabled':''}></label><div class="wide-actions"><button class="secondary" data-live-action="search" ${loading?'disabled':''}>${icon('search')}查询</button></div></div>`+
      (loading?'<div class="empty" role="status">正在读取客户分析…</div>':error?`<div class="alert-note" role="alert">${safe(error)}</div>`:data?content():'');icons();
  }
  function content(){
    const s=data.summary;
    return `<p class="crm-scope">迁移验收中 · 仅统计已入库订单，不代表完整客户历史。<br>截至 ${dateLabel(data.today)} · RFM 分群规则待确认${data.unlinked_orders?` · ${data.unlinked_orders} 笔有效订单尚未关联客户，未计入分析`:''}</p>`+
      `<div class="stats crm-stats">${stat('客户人数',s.customers,'当前主页与搜索范围','users')}${stat('有购买客户',s.buyers,'有效购买次数 ≥ 1','shopping-bag','blue')}${stat('复购客户占比',s.buyers?(s.repeat_buyers/s.buyers*100).toFixed(1)+'%':'—',`${s.repeat_buyers} / ${s.buyers} 位购买客户`,'repeat','rose')}${stat('累计净销售','RM '+fmt(s.amount_minor),`${s.purchase_count} 笔有效购买`,'wallet')}</div>`+
      (!s.customers?'<div class="empty">当前范围暂无云端客户记录；未使用演示数据。</div>':`<div class="crm-chart-grid">${chart('purchase','购买次数分布',data.purchase_distribution)}${chart('spend','累计消费分布 · MYR',data.spend_distribution)}</div>`)+
      `<section class="crm-ranking"><h2>客户排行</h2><div class="crm-rank-controls">${select('sort','排序依据',[['amount','累计有效金额'],['count','有效购买次数'],['recency','距最近购买天数'],['average','平均每单金额']])}${select('direction','排序方向',[['desc','由大到小'],['asc','由小到大']])}${select('purchase','购买次数',[['all','全部'],...['none','once','repeat'].map(k=>[k,labels[k]])])}${select('spend','累计消费',[['all','全部'],...['none','under500','500to1500','1500to3000','3000plus'].map(k=>[k,labels[k]])])}</div>
      <div class="data-surface"><div class="table-scroll"><table class="crm-table"><thead><tr><th>排序</th><th>客户</th><th>R · 距最近购买</th><th>F · 有效购买次数</th><th>M · 累计净销售</th><th>平均每单</th><th>首次 / 最近购买</th></tr></thead><tbody>${data.items.map(r=>`<tr><td>${r.rank}</td><td><button type="button" class="customer-name" data-action="cloud-customer" data-id="${r.id}">${safe(r.name)}</button><small>${safe(r.phones.join(' / ')||'未留号码')}${r.active?'':' · 已停用'}</small></td><td>${r.recency_days===null?'—':r.recency_days+' 天'}</td><td>${r.purchase_count}</td><td>RM ${fmt(r.amount_minor)}</td><td>${r.average_minor===null?'—':'RM '+fmt(r.average_minor)}</td><td>${r.first_purchase?dateLabel(r.first_purchase):'—'}<small>${r.last_purchase?dateLabel(r.last_purchase):'—'}</small></td></tr>`).join('')}</tbody></table>${!data.items.length?'<div class="empty">此筛选下暂无客户</div>':''}</div><div class="table-foot"><span>${data.total} 位 · ${data.total?data.offset+1:0}–${Math.min(data.offset+data.limit,data.total)}</span><div class="row-actions"><button class="icon-button" data-live-action="prev" aria-label="上一页" ${data.offset===0?'disabled':''}>${icon('chevron-left')}</button><button class="icon-button" data-live-action="next" aria-label="下一页" ${data.offset+data.limit>=data.total?'disabled':''}>${icon('chevron-right')}</button></div></div></div></section>`;
  }
  function definitions(){showDialog('detail',null,'客户分析统计口径',`<dl class="detail-grid"><div><dt>来源 / 时间</dt><dd>仅统计 Supabase 已入库的客户及订单，截至马来西亚今日。旧资料尚未完整导入，首次、最近购买及累计值都只反映已入库范围，不能视作完整客户历史。按当前订单状态重算，不是历史时点快照。</dd></div><div><dt>客户与主页</dt><dd>每个客户 ID 只计一次，多个号码不重复。全部主页含所有客户；选主页后含该主页曾有订单或咨询的客户。停用客户保留历史。</dd></div><div><dt>有效购买</dt><dd>仅正式且未取消、未拒收的订单。零元正式订单也算一次；潜在咨询不计。未关联客户的订单不计入客户分析。</dd></div><div><dt>金额</dt><dd>商品＋运费－优惠券－其他折扣；新币按订单固定 ×3 换算马币。历史导入保留当时最终销售额，不另行重复加运费或减优惠券。部分退款按实际退款额扣减累计金额，不减少购买次数；原订单金额保留。HR 仍按确认月份扣减，不与此累计值直接比较。</dd></div><div><dt>百分比</dt><dd>两个分布图以当前主页与搜索范围的全部客户为分母；复购率以有购买的客户为分母。排行分类筛选不改变分布图分母。</dd></div><div><dt>RFM</dt><dd>R 为距最近有效购买天数，F 为有效订单笔数，M 为累计净销售，均遵循主页范围。消费金额区间仅用于查看分布，不代表 VIP 等级。</dd></div></dl>`,'实时查询 · 已入库范围');}
  document.addEventListener('change',e=>{if(state.view!=='analytics'||loading||!e.target.id.startsWith('live-analytics-')||e.target.id.endsWith('-search'))return;const key=e.target.id.replace('live-analytics-','');if(!(key in filters))return;filters[key]=e.target.value;filters.offset=0;void refresh();});
  document.addEventListener('keydown',e=>{if(e.target.id==='live-analytics-search'&&e.key==='Enter'){e.preventDefault();filters.search=e.target.value.trim();filters.offset=0;void refresh();}});
  document.addEventListener('click',e=>{
    if(state.view!=='analytics'||!allowed())return;const b=e.target.closest('[data-live-action],[data-live-bucket]');if(!b||loading)return;
    if(b.dataset.liveBucket){const k=b.dataset.liveBucket;filters[k]=filters[k]===b.dataset.key?'all':b.dataset.key;filters.offset=0;void refresh();return;}
    const a=b.dataset.liveAction;if(a==='definitions'){definitions();return;}
    if(a==='search'){filters.search=$('#live-analytics-search').value.trim();filters.offset=0;}
    if(a==='prev')filters.offset=Math.max(0,filters.offset-25);if(a==='next')filters.offset+=25;
    void refresh();
  });
  return {render,clear};
})();
