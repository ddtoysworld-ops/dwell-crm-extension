"use strict";
window.DwellOperations=(()=>{
  const safe=escapeHtml,allowed=()=>window.DwellPayments?.canCoreAction?.('orders','list')??window.DwellPayments?.canManagePages();
  const rpc=(action,body={})=>window.DwellPayments.operationsRpc(action,body);
  const tags=['延迟寄出','潜在客户跟进','想要做复购的动作'];
  const status=r=>r.adjustment?.kind==='cancelled_or_rejected'?'已取消 / 拒收（未细分）':r.status==='cancelled'?'已取消':r.status==='rejected'?'COD 拒收':r.nature==='inquiry'?'潜在咨询':r.refunded_minor>0?'部分退款':'正式订单';
  const localToday=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  let tab='orders',rows=null,pages=[],skus=[],total=0,offset=0,query='',pageId='',month='',customerId='',customerLabel='',taskStatus='due';
  let loading=false,busy=false,error='',generation=0,today=localToday(),editing=null,pending=null,matched=null,phoneSerial=0,phoneTimer,autoFilled={},conversionPriced=false;
  const visible=()=>['orders','tasks'].includes(state.view);
  function leave(){generation++;phoneSerial++;rows=null;loading=false;error='';}
  const can=action=>window.DwellPayments?.canCoreAction?.('orders',action)??window.DwellPayments?.canManagePages();
  const button=(action,id,label,ico='square-pen')=>(!can(({edit:'save',schedule:'task',complete:'task',customer:'customer','refund-history':'get'})[action]||action))?'':`<button type="button" class="icon-button" data-action="cloud-${action}" data-id="${id}" title="${label}" aria-label="${label}">${icon(ico)}</button>`;
  function clear(){generation++;phoneSerial++;rows=null;pages=[];skus=[];editing=null;matched=null;pending=null;loading=false;error='';customerId='';customerLabel='';window.DwellCouponRecipient?.reset();window.DwellCloudHR?.clear();window.DwellCloudAnalytics?.clear();window.DwellFollowups?.clear();}
  function failure(e){
    const refundErrors={refund_order_locked:'本单已有部分退款，原订单资料已锁定；仍可安排跟进、登记部分退款或取消。',refund_order_invalid:'仅未取消、未拒收的正式订单可登记部分退款。',refund_amount_invalid:'退款金额须大于 0，且累计退款须小于原订单金额。整单取消请使用取消 / COD 拒收。',refund_currency_invalid:'请使用原订单币种登记退款。',refund_date_invalid:'确认日期不能早于订单或上一笔退款，也不能晚于今天。',refund_cancel_date_invalid:'取消确认日期不能早于已登记的退款日期。',refund_reason_required:'请填写退款原因。'};
    for(const [code,msg] of Object.entries(refundErrors))if(String(e?.message||e).includes(code))return msg;
    if(String(e?.message||e).includes('order_erp_duplicate'))return '此主页已存在相同 ERP 订单号，请先搜索原订单，避免重复进单。';
    if(String(e?.message||e).includes('referral_order_locked'))return '本单已确认推荐奖励，暂不能修改订单；取消时会同步处理奖励状态。';
    const deliveryErrors={delivery_invalid:'请检查收件人、收货电话、地址及地址名称。',delivery_not_found:'所选收货资料不属于当前客户，请重新选择。',delivery_stale:'收货资料刚被更新，请关闭窗口后重新打开。',delivery_changed:'收货资料已修改，请作为新地址保存。',delivery_required:'请刷新后台，以保留订单原有的收货资料。',delivery_limit:'每位客户最多保存 20 组收货资料。'};
    for(const [code,msg] of Object.entries(deliveryErrors))if(String(e?.message||e).includes(code))return msg;
    if(String(e?.message||e).includes('coupon_customer_selection_required'))return '请先搜索并选择一位现有 CRM 客户，不会自动建立客户。';
    if(String(e?.message||e).includes('coupon_customer_not_found'))return '所选客户已不存在，请重新搜索核对。';
    const lineErrors={order_lines_required:'此订单包含多个商品，请刷新后台后再修改。',order_lines_invalid:'请核对商品明细、数量和金额，最多添加 30 项。',order_lines_duplicate:'同一 SKU 的同类商品请合并数量；销售与赠品可以分开。',order_sale_line_required:'请至少保留一项正常销售的产品或配套。',order_lines_legacy_sku:'旧版 SKU 不开放新订单，请选择单品或配套。'};
    for(const [code,msg] of Object.entries(lineErrors))if(String(e?.message||e).includes(code))return msg;
    const promotionError=window.DwellOrderPromotions?.error(e);if(promotionError)return promotionError;
    if(String(e?.message||e).includes('history_order_readonly'))return '历史订单原始资料已锁定；请通过核对流程处理更正。';
    if(String(e?.message||e).includes('sku_market_unavailable'))return '此单品或配套在所选地区暂不开放直接销售，请重新选择。';
    const errors={adjustment_month_invalid:'请填写有效的确认月份，不能早于订单月份或晚于本月。',adjustment_precision_invalid:'请选择具体日期或仅月份。',history_adjustment_required:'只有历史订单可以记录未知日期或未细分的取消类型。',adjustment_kind_invalid:'请选择取消或拒收类型。',core_owner_required:'请使用获授权账号登录，或联系管理员调整权限。',core_stale_version:'记录已被其他操作修改，请关闭窗口并刷新后重试。',core_request_conflict:'重试内容不一致，请刷新核对记录。',order_customer_mismatch:'号码与所选客户不一致，请先在云端客户资料中维护号码。',order_phone_invalid:'电话号码须含 60 / 65 国家码，请核对。',order_customer_name_required:'新号码需要填写客户姓名。',order_customer_inactive:'此客户已停用。',order_closed:'订单已取消或拒收，不能再修改。',order_date_invalid:'日期须在订单日期范围内，且不能晚于今天。',task_date_invalid:'后续操作日期不能早于今天。',order_sku_page:'配套不属于这个主页，请重新选择。',order_sku_inactive:'SKU 已停用或不存在。',core_page_inactive:'主页已停用或不存在。',core_product_inactive:'产品已停用。',task_not_open:'任务已完成，请刷新。',order_not_found:'找不到这张订单。'};
    for(const [code,msg] of Object.entries(errors))if(String(e?.message||e).includes(code))return msg;
    const bundleErrors={bundle_choice_required:'请选择每组赠品。',bundle_choices_invalid:'赠品选项无效，请重新选择。',bundle_component_unavailable:'配套内有已停用的单品，请管理员核对配套。',bundle_catalog_changed:'配套刚刚更新，请关闭窗口并重新选择。',order_snapshot_locked:'已有订单的商品明细已保留，不能直接重选赠品。',order_market_currency:'请检查送货地区和付款币种。'};
    for(const [code,msg] of Object.entries(bundleErrors))if(String(e?.message||e).includes(code))return msg;
    if(e?.code==='23505')return '号码或记录已存在，请刷新后核对。';
    if(['23514','23502','22P02','22003','22007','22008'].includes(e?.code))return '请检查必填资料、日期、金额和数量；折扣不能大于商品加运费。';
    if(e?.code==='PGRST202')return '云端订单接口尚未部署，暂时不能保存。';
    return '连接失败或保存结果尚未确认，请重试原请求或刷新核对。';
  }
  async function catalog(kind){
    const all=[];
    for(let start=0;;start+=100){const r=await window.DwellPayments.catalogRpc('list',kind,{offset:start,limit:100});all.push(...r.items);if(all.length>=r.total||!r.items.length)return all;}
  }
  async function refresh(){
    if(!allowed()){clear();return;}
    const token=++generation;loading=true;error='';if(visible())render();
    try{
      const opts=await catalog('pages');
      const r=await rpc('list',{scope:tab,search:query,page_id:pageId,month:tab==='orders'?month:'',customer_id:customerId,task_status:taskStatus,offset,limit:25});
      if(token!==generation||!allowed())return;
      pages=opts;rows=r.items;total=r.total;today=r.today;
    }catch(e){if(token===generation){error=failure(e);rows=[];total=0;}}
    finally{if(token===generation){loading=false;if(visible())render();}}
  }
  function nav(){return '';}
  function productLabel(r){
    const original=(r.sku_name||'').trim();
    if(r.historical&&r.sku_code==='HIST-UNCLASSIFIED'){
      return `<strong>历史混合／未归类产品</strong>${original&&original!=='历史混合／未归类产品'?`<small>${safe(original)}</small>`:''}`;
    }
    return safe(original||'历史配套未记录');
  }
  function row(r){return `<tr><td><strong>#${r.number}</strong><small>${dateLabel(r.order_date)}</small>${r.historical?`<small>旧单 ${safe(r.historical.source.order_id)}</small>`:''}${r.inquiry_date?`<small>首次咨询 ${dateLabel(r.inquiry_date)}</small>`:''}</td><td><strong>${safe(r.customer_name||'未留姓名')}</strong><small>${safe(r.phone||'未留电话')}</small>${r.customer_id?button('customer',r.customer_id,'客户订单','users'):''}</td><td>${safe(r.page_name)}<small>${safe(r.platform)} · ${safe(r.source)}</small></td><td>${productLabel(r)}<small>${r.line_items?.length?r.line_items.length+' 项商品':r.quantity+' 份'} · ${r.units*r.quantity} ${r.historical?'历史销售数量':'主商品数量'}</small>${r.historical?'<small>历史赠品明细未记录</small>':''}</td><td>${r.nature==='inquiry'?'—':`${safe(r.currency)} ${fmt(r.gmv_minor)}<small>RM ${fmt(r.gmv_myr_minor)}</small>${r.refunded_minor?`<small>已退 ${safe(r.currency)} ${fmt(r.refunded_minor)}</small><small>净额 ${safe(r.currency)} ${fmt(r.net_minor)} · RM ${fmt(r.net_myr_minor)}</small>`:''}`}</td><td>${safe(r.erp_id||'—')}<small>运单 ${safe(r.tracking_number||'未填')}</small></td><td><span class="pill ${r.status!=='open'?'danger':r.nature==='inquiry'?'warning':'success'}">${status(r)}</span><small>${safe(r.historical?.salesperson||r.actor_name)}</small>${r.task?`<small>${safe(r.task.tag)} · ${r.task.due_date?dateLabel(r.task.due_date):'原日期未记录'}${r.task.completed_at||r.task.archived_completed?' · 已完成':''}</small>`:''}</td><td><div class="row-actions">${r.status==='open'?(!r.historical&&!r.refunded_minor?button('edit',r.id,r.nature==='inquiry'?'修改 / 成交':'修改订单'):'')+button('schedule',r.id,'安排后续处理','calendar'):''}${r.task&&!r.task.completed_at&&!r.task.archived_completed&&r.status==='open'?button('complete',r.id,'完成任务','check'):''}${r.nature==='formal'&&r.status==='open'?button('refund',r.id,'登记部分退款','undo-2')+button('cancel',r.id,'取消 / COD 拒收','ban'):''}${r.refunded_minor?button('refund-history',r.id,'退款记录','history'):''}${button('audit',r.id,r.historical?'历史资料与变更记录':'变更记录','history')}</div></td></tr>`;}
  function render(){
    if(!visible())return;
    if(window.DwellFollowups?.active()){window.DwellFollowups.render();return;}
    if(tab!==state.view){tab=state.view;leave();offset=0;query='';pageId='';month='';customerId='';customerLabel='';}
    if(!allowed()){$('#main').innerHTML=heading(tab==='orders'?'销售订单':'待处理任务清单','Supabase')+'<div class="empty">请使用获授权账号登录后读取真实资料。<p><button class="primary" data-action="ops-account">后台账户</button></p></div>';return;}
    if(rows===null&&!loading){void refresh();return;}
    $('#main').innerHTML=heading(tab==='orders'?'销售订单':'待处理任务清单','Supabase · 全部主页',`<div class="wide-actions"><button class="secondary" data-action="cloud-refresh" ${loading?'disabled':''}>${icon('refresh-cw')}刷新</button>${can('grant_coupon')?`<button class="secondary" data-action="cloud-gift">${icon('gift')}单独发券</button>`:''}${can('save')?`<button class="primary" data-action="cloud-new" ${loading||error?'disabled':''}>${icon('plus')}新增订单</button>`:''}</div>`)+
      (tab==='tasks'?window.DwellFollowups?.tabs()||'':'')+
      `<div class="notice">真实保存 · 旧资料未完整迁入；旧插件与抽奖尚未接通。推荐奖励在「好友推荐」审核。${tab==='tasks'?`马来西亚日期 ${dateLabel(today)}`:''}</div>${error?`<div class="alert-note" role="alert">${safe(error)}</div>`:''}`+
      `<section class="data-surface"><div class="toolbar"><label class="search-field">${icon('search')}<input id="cloud-search" aria-label="搜索云端订单" maxlength="100" placeholder="客户、电话、ERP、运单或编号" value="${safe(query)}"></label><select id="cloud-page" aria-label="筛选云端主页"><option value="">全部主页</option>${pages.map(p=>`<option value="${p.id}" ${p.id===pageId?'selected':''}>${safe(p.name)}</option>`).join('')}</select>${tab==='orders'?`<input type="month" id="cloud-month" aria-label="云端订单月份" value="${safe(month)}">`:`<select id="cloud-task-status" aria-label="任务时间">${[['due','今日与逾期'],['future','未来任务'],['completed','已完成'],['all','全部任务']].map(([k,v])=>`<option value="${k}" ${k===taskStatus?'selected':''}>${v}</option>`).join('')}</select>`}<button class="secondary" data-action="cloud-search">${icon('search')}查询</button>${customerId?`<button class="secondary" data-action="cloud-clear-customer">${icon('x')}取消客户筛选：${safe(customerLabel)}</button>`:''}</div><div class="table-scroll"><table><thead><tr>${['订单 / 日期','客户','主页 / 平台','配套 / 数量','GMV','ERP / 运单号码','状态 / 经手人','操作'].map(s=>`<th>${s}</th>`).join('')}</tr></thead><tbody>${(rows||[]).map(row).join('')}</tbody></table>${!rows?.length?`<div class="empty">${loading?'读取中…':error?'读取失败':'尚无记录'}</div>`:''}</div><div class="table-foot"><span>${total} 条 · 第 ${Math.floor(offset/25)+1} 页</span><div class="row-actions"><button class="icon-button" data-action="cloud-prev" aria-label="上一页" ${offset===0||loading?'disabled':''}>${icon('chevron-left')}</button><button class="icon-button" data-action="cloud-next" aria-label="下一页" ${offset+25>=total||loading?'disabled':''}>${icon('chevron-right')}</button></div></div></section>`;icons();
  }
  function money(label,name,minor=0){return inputField(label,name,String(minor/100),'number',true,'min="0" max="100000000" step="0.01"');}
  function text(label,name,v='',required=false,max=100){return inputField(label,name,v,'text',required,`maxlength="${max}"`);}
  function paymentField(selected=''){
    const methods=['Bank Transfer','COD','TNG','Cash','credit card','shopee','Installment'];
    const options=[['','请选择'],...methods.map(v=>[v,v])];
    if(selected&&!methods.includes(selected))options.push([selected,selected+'（原记录）']);
    return selectField('支付方式','payment',options,selected,true);
  }
  function optionField(label,name,options,selected='',required=true){
    const items=[['','请选择'],...options.map(v=>[v,v])];
    if(selected&&!options.includes(selected))items.push([selected,selected+'（原记录）']);
    return selectField(label,name,items,selected,required);
  }
  async function edit(id){
    const token=generation,r=id?await rpc('get',{id}):null;
    const ps=await catalog('pages'),ss=await catalog('skus');
    if(token!==generation||!allowed())return;
    pages=ps;skus=ss;editing=r;pending=null;matched=r?.customer_id||null;phoneSerial++;autoFilled={};conversionPriced=false;
    showDialog('cloud-order',id,r?'修改云端订单':'新增云端订单',`<div class="form-grid">${inputField('日期','order_date',r?.order_date||today,'date',true,`max="${today}" min="2000-01-01"`)}${selectField('订单性质','nature',[['formal','正式订单'],['inquiry','潜在咨询']],r?.nature||'formal',true)}${selectField('所属主页','page_id',[['','请选择主页'],...pages.filter(p=>p.active||p.id===r?.page_id).map(p=>[p.id,p.name])],r?.page_id||pageId,true)}${selectField('产品配套','sku_id',[['','请选择 SKU']],r?.sku_id||'',true)}${inputField('配套份数','quantity',r?.quantity||1,'number',true,'min="1" max="1000" step="1"')}${selectField('币种','currency',[['MYR','MYR'],['SGD','SGD']],r?.currency||'MYR',true)}</div><h3 class="section-title">订单金额</h3><div class="form-grid">${money('商品 / 配套金额','goods_minor',r?.goods_minor)}${money('运费','shipping_minor',r?.shipping_minor)}${money('优惠券折扣（手动金额）','coupon_minor',r?.coupon_minor)}${money('其他折扣','discount_minor',r?.discount_minor)}${paymentField(r?.payment||'')}</div><div id="cloud-gmv" class="notice"></div><h3 class="section-title">客户与订单资料</h3><div class="form-grid">${text('电话号码（含国家码）','phone',r?.phone||'',false,30)}${text('客户姓名','customer_name',r?.customer_name||'',false,80)}<div class="field full"><span id="cloud-match" role="status">${r?.customer_id?'已关联客户 '+safe(r.customer_id):'尚未关联客户'}</span></div>${selectField('已存收货地址','saved_address',[['','手动填写 / 本单地址']],'')}${text('邮寄地址','address',r?.address||'',false,500)}${optionField('本单下单平台','platform',['Facebook','Business Whatsapp','Manychat Whatsapp',"D'WELL 网站",'CALL','Instagram','WhatsApp','网站'],r?.platform||'Facebook')}${optionField('客户来源','source',['广告','朋友介绍','自行询问','repeat order'],r?.source||'')}${text('ERP 订单 ID','erp_id',r?.erp_id||'')}${text('Tracking Number','tracking_number',r?.tracking_number||'')}<label class="field full"><span>订单备注</span><textarea name="note" rows="3" maxlength="2000">${safe(r?.note||'')}</textarea></label></div>${!r?`<h3 class="section-title">后续处理</h3><div class="form-grid">${inputField('后续操作日期','due_date','','date',false,`min="${today}"`)}${selectField('订单标签','task_tag',tags.map(t=>[t,t]),'潜在客户跟进')}<label class="field full"><span>任务备注</span><textarea name="task_note" maxlength="2000"></textarea></label></div>`:''}`,'正式资料 · 保存至 Supabase');
    field('currency').closest('label').insertAdjacentHTML('beforebegin',selectField('送货地区','market',[['MY','马来西亚 · 西马'],['EM','马来西亚 · 东马'],['SG','新加坡']],r?.market||(r?.currency==='SGD'?'SG':'MY'),true));
    $('#dialog-body .form-grid').insertAdjacentHTML('afterend','<div id="cloud-items"></div>');
    updateSkuOptions(r?.sku_id||'');refreshItems();window.DwellOrderLines?.mount(r,skus,refreshForm);refreshForm();window.DwellOrderPromotions.mount(r,refreshForm);window.DwellOrderLayout?.mount(r);window.DwellDelivery.mount(r,()=>busy||Boolean(pending));if(r?.phone)void matchPhone();
  }
  function refreshItems(preserve=false){
    const selected=preserve?window.DwellSkuForms.choices():{},s=skus.find(s=>s.id===value('sku_id'));
    $('#cloud-items').innerHTML=window.DwellSkuForms.orderMarkup(s,editing,Number(value('quantity'))||1);
    for(const el of document.querySelectorAll('[data-order-choice]'))if(selected[el.dataset.orderChoice])el.value=selected[el.dataset.orderChoice];
  }
  function updateSkuOptions(selected=''){
    const pg=value('page_id'),market=value('market');field('sku_id').innerHTML='<option value="">请选择 SKU</option>'+skus.filter(s=>(s.active||s.id===editing?.sku_id)&&(!s.page_id||s.page_id===pg)&&(window.DwellSkuSales.allowed(s,market)||s.id===editing?.sku_id)).map(s=>`<option value="${s.id}" ${s.id===selected?'selected':''}>${safe(s.code+' · '+s.name)}</option>`).join('');
  }
  function refreshForm(){
    window.DwellDelivery?.requirements();
    window.DwellOrderPromotions?.refresh();
    const inquiry=value('nature')==='inquiry';
    for(const n of ['phone','customer_name','address','payment','erp_id']){field(n).required=!inquiry;const label=field(n).closest('label')?.querySelector('span');if(label)label.textContent=label.textContent.replace(/\s*\*$/,'')+(inquiry?'':' *');}
    for(const n of ['goods_minor','shipping_minor','coupon_minor','discount_minor'])field(n).disabled=inquiry;
    if(editing?.nature==='formal')field('nature').disabled=true;
    const converting=editing?.nature==='inquiry'&&!inquiry;field('order_date').disabled=converting;if(converting)field('order_date').value=today;
    if(!inquiry&&window.DwellOrderLines?.isActive()&&(!value('goods_minor')||!value('shipping_minor'))){$('#cloud-gmv').textContent='待确认商品金额与整单运费';return;}
    try{const g=inquiry?0:moneyInput('goods_minor')+moneyInput('shipping_minor')-moneyInput('coupon_minor')-moneyInput('discount_minor');$('#cloud-gmv').textContent=inquiry?'潜在咨询 · 不计入销售':`${value('currency')} ${fmt(g)} · 佣金 GMV RM ${fmt(g*(value('currency')==='SGD'?3:1))}`;}catch{$('#cloud-gmv').textContent='请核对金额';}
  }
  async function matchPhone(){
    const serial=++phoneSerial,token=generation,ph=value('phone');matched=null;
    if(!ph){window.DwellDelivery.match(null);$('#cloud-match').textContent='尚未关联客户';return;}
    $('#cloud-match').textContent='正在核对电话号码…';
    try{const {customer}=await rpc('phone',{phone:ph});if(serial!==phoneSerial||token!==generation||!dialog.open||dialogKind!=='cloud-order'||pending)return;
      matched=customer?.id||null;$('#cloud-match').textContent=customer?`${customer.active?'已关联':'客户已停用'}：${customer.name} · ${customer.id}`:'未找到客户；保存时按此号码创建客户';
      for(const [name,next] of Object.entries({customer_name:customer?.name==='未留姓名'?'':customer?.name||''})){
        if(!value(name)||value(name)===autoFilled[name]){field(name).value=next;autoFilled[name]=next;}
      }
      window.DwellDelivery.match(customer);
      await window.DwellOrderPromotions.load();
    }catch(e){if(serial===phoneSerial&&token===generation&&$('#cloud-match'))$('#cloud-match').textContent=failure(e);}
  }
  async function profile(id){
    const token=generation,[p,legacy]=await Promise.all([
      rpc('customer',{id}),
      window.DwellPayments.legacyCustomerHistoryRpc(id).catch(()=>({items:[],review_count:0,unavailable:true}))
    ]);if(token!==generation||!allowed())return;
    const c=p.customer,s=p.summary;
    const date=v=>v?dateLabel(v):'尚无有效购买';
    const cells=(a)=>a.length?a.map(v=>`<span class="inline-tag">${safe(v)}</span>`).join(''):'—';
    const historyRows=[
      ...p.orders.map(r=>({date:r.order_date,html:`<tr><td>#${r.number}<small>${dateLabel(r.order_date)} · 新订单</small>${r.inquiry_date?`<small>首次咨询 ${dateLabel(r.inquiry_date)}</small>`:''}</td><td>${productLabel(r)}<small>${safe(r.platform)} · ${safe(r.page_name)}</small></td><td>${r.nature==='formal'?'RM '+fmt(r.net_myr_minor??r.gmv_myr_minor):'—'}${r.refunded_minor?`<small>原额 RM ${fmt(r.gmv_myr_minor)} · 已退 RM ${fmt(r.refunded_myr_minor)}</small>`:''}</td><td>${status(r)}</td></tr>`})),
      ...(legacy.items||[]).filter(r=>r.kind==='sale').map(r=>({date:r.occurred_on,html:`<tr><td>${r.occurred_on?dateLabel(r.occurred_on):'日期未记录'}<small>Google Sheet · 只读</small></td><td>${safe(r.product_text||'原表未记录商品')}</td><td>${r.amount_myr_minor!=null?'RM '+fmt(r.amount_myr_minor):r.amount_sgd_minor!=null?'SGD '+fmt(r.amount_sgd_minor):'—'}</td><td>${safe(r.source_status||'原表状态未记录')}</td></tr>`}))
    ].sort((a,b)=>(b.date||'').localeCompare(a.date||''));
    showDialog('detail',id,'客户档案',`<div class="cloud-profile">
      <header class="profile-identity"><span class="avatar">${safe(c.name.slice(0,1))}</span><div><h3>${safe(c.name)}</h3><div class="profile-meta">${cells(p.channels)}<span class="pill ${c.active?'success':'neutral'}">${c.active?'启用':'已停用'}</span></div><small class="profile-id">客户 ID · ${safe(c.id)}</small></div></header>
      <dl class="profile-stats"><div><dt>新系统净销售 · MYR</dt><dd>RM ${fmt(s.gmv_myr_minor)}</dd></div><div><dt>新系统有效购买</dt><dd>${s.purchase_count}<small> 次</small></dd></div><div><dt>新系统首次购买</dt><dd class="profile-date">${date(s.first_purchase_date)}</dd></div><div><dt>新系统最近购买</dt><dd class="profile-date">${date(s.last_purchase_date)}</dd></div></dl>
      <section class="profile-section"><div class="profile-section-head"><h3>${icon('phone')}联系方式</h3></div><div class="profile-phones">${cells(c.phones)}</div><div id="profile-messenger-slot"></div></section>
      <section class="profile-section">${window.DwellDelivery.markup(c)}
      ${(c.addresses?.length||p.order_addresses?.length)?`<details class="profile-history"><summary>旧版与历史订单地址</summary><dl><dt>客户常用地址</dt><dd>${(c.addresses||[]).map(safe).join('<br>')||'—'}</dd><dt>订单曾用地址</dt><dd>${(p.order_addresses||[]).map(safe).join('<br>')||'—'}</dd></dl></details>`:''}</section>
      <section class="profile-section"><div class="profile-section-head"><h3>${icon('shopping-bag')}购买记录</h3><button type="button" class="secondary" data-action="cloud-customer-orders" data-id="${c.id}">${icon('list')}全部新订单与任务</button></div><p class="profile-note">新系统：潜在咨询 ${s.inquiry_count} · 已取消 / 拒收 ${s.closed_count}。旧记录只读，不重复计算业绩。</p>${legacy.review_count?`<p class="alert-note">另有 ${legacy.review_count} 条同电话旧资料待核对，暂不合并。</p>`:''}${legacy.unavailable?'<p class="profile-note">旧记录暂时无法读取。</p>':''}${historyRows.length?`<div class="table-scroll"><table><thead><tr><th>订单 / 日期</th><th>商品 / 平台</th><th>金额</th><th>状态</th></tr></thead><tbody>${historyRows.map(r=>r.html).join('')}</tbody></table></div>`:'<p class="profile-empty">暂无购买记录</p>'}</section>
      <section class="profile-section"><div class="profile-section-head"><h3>${icon('list-todo')}待处理任务 <span class="profile-count">${p.open_task_count}</span></h3></div>${p.tasks.length?`<div class="table-scroll"><table><thead><tr><th>订单</th><th>处理日期</th><th>标签</th><th>操作</th></tr></thead><tbody>${p.tasks.map(r=>`<tr><td>#${r.number}</td><td>${dateLabel(r.task.due_date)}</td><td>${safe(r.task.tag)}</td><td><div class="row-actions">${button('schedule',r.id,'安排后续处理','calendar')}${button('complete',r.id,'完成任务','check')}</div></td></tr>`).join('')}</tbody></table></div>`:'<p class="profile-empty">暂无待处理任务</p>'}</section>
      <section class="profile-section"><div class="profile-section-head"><h3>${icon('ticket')}优惠券</h3>${can('grant_coupon')?`<button type="button" class="secondary" data-action="cloud-gift" data-id="${c.id}">${icon('gift')}单独发券</button>`:''}</div>${window.DwellOrderPromotions.customerMarkup(p.coupons,p.legacy_coupons)}</section>
      ${window.DwellReferrals?.profileMarkup(p.referral_rewards)||''}
      <section class="profile-section">${window.DwellOrderPromotions.physicalMarkup(p.legacy_physical_rewards)}</section>
      </div>`,'Supabase · 有效购买不含咨询、取消或拒收');
    dialog.classList.add('cloud-profile-dialog');
    void window.DwellMessenger?.mount(c);
  }
  function refundHistory(r){return `<section class="profile-section"><h3>退款记录</h3>${r.refunds?.length?`<div class="table-scroll"><table><thead><tr><th>确认日期</th><th>退款金额</th><th>原因 / 经手人</th></tr></thead><tbody>${r.refunds.map(x=>`<tr><td>${dateLabel(x.confirmed_date)}</td><td>${safe(x.currency)} ${fmt(x.amount_minor)}<small>RM ${fmt(x.amount_myr_minor)}</small></td><td>${safe(x.reason)}<small>${safe(x.actor_name)}</small></td></tr>`).join('')}</tbody></table></div>`:'<p class="profile-empty">尚无退款记录</p>'}</section>`;}
  async function action(cmd,id){
    if(busy)return;
    if(cmd.startsWith('cloud-hr-')){await window.DwellCloudHR?.action(cmd,id);return;}
    try{
      if(!allowed())throw new Error('core_owner_required');
      const required=({'cloud-new':'save','cloud-edit':'save','cloud-schedule':'task','cloud-complete':'task','cloud-gift':'grant_coupon','cloud-cancel':'cancel','cloud-refund':'refund','cloud-refund-history':'get','cloud-audit':'audit','cloud-delivery':'delivery_save'})[cmd];
      if(required&&!can(required))throw new Error('core_owner_required');
      if(cmd==='cloud-delivery'){busy=true;await window.DwellDelivery.openManager(id);return;}
      if(cmd==='cloud-gift'){
        const choices=await catalog('pages');
        const c=id?(await rpc('customer',{id})).customer:null;
        pending=null;editing=null;
        showDialog('cloud-gift','', '单独发放优惠券',`<div class="form-grid">
          ${text('电话号码（含国家码）','phone',c?.phones?.[0]||'',true,30)}
          ${text('客户姓名','customer_name',c?.name||'',true,80)}
          <div class="field full"><div class="coupon-recipient-status"><span id="coupon-recipient-status" role="status"></span><button type="button" class="icon-button" data-coupon-search title="重新查询客户" aria-label="重新查询客户">${icon('search')}</button></div><div id="coupon-recipient-results"></div></div>
          ${selectField('所属主页','page_id',[['','请选择主页'],...choices.filter(p=>p.active).map(p=>[p.id,p.name])],'',true)}
          ${selectField('币种','currency',[['MYR','MYR'],['SGD','SGD']],'MYR',true)}
          ${optionField('客户平台','platform',['Facebook','Business Whatsapp','Manychat Whatsapp',"D'WELL 网站",'CALL','Instagram','WhatsApp','网站'],c?.channel||'')}
          ${text('优惠券名称','name','',true,100)}
          ${inputField('优惠券面额','amount','','number',true,'min="0.01" max="100000000" step="0.01"')}
          ${inputField('最低消费','minimum','0','number',true,'min="0" max="100000000" step="0.01"')}
          ${inputField('有效期至（留空为长期有效）','expires_on','','date',false,`min="${today}"`)}
          </div>`,'只发券，不建立订单；限所选主页及币种');
        window.DwellCouponRecipient.mount(c,()=>busy||Boolean(pending));
        return;
      }
      if(cmd==='cloud-coupons'){await window.DwellOrderPromotions.load();return;}
      if(cmd==='cloud-tab'){if(!['orders','tasks','hr'].includes(id))return;state.view=id;window.render();return;}
      if(cmd==='cloud-refresh'){await refresh();return;}
      if(cmd==='cloud-search'){query=$('#cloud-search').value.trim();pageId=$('#cloud-page').value;month=$('#cloud-month')?.value||'';taskStatus=$('#cloud-task-status')?.value||taskStatus;offset=0;await refresh();return;}
      if(cmd==='cloud-next'||cmd==='cloud-prev'){offset=Math.max(0,offset+(cmd==='cloud-next'?25:-25));await refresh();return;}
      if(cmd==='cloud-clear-customer'){customerId='';customerLabel='';offset=0;await refresh();return;}
      if(cmd==='cloud-customer'){busy=true;await profile(id);if(dialog.open&&dialogKind==='detail')$('#dialog-body').scrollTop=0;return;}
      if(cmd==='cloud-customer-orders'){dialog.close();customerId=id;customerLabel=rows?.find(r=>r.customer_id===id)?.customer_name||'客户';tab='orders';query='';pageId='';month='';offset=0;rows=null;state.view='orders';window.render();return;}
      busy=true;
      if(cmd==='cloud-new'||cmd==='cloud-edit'){await edit(id);return;}
      const token=generation,r=await rpc('get',{id});if(token!==generation||!allowed())return;editing=r;pending=null;
      if(cmd==='cloud-schedule')showDialog('cloud-task',id,'安排后续处理',`<div class="form-grid">${inputField('后续操作日期','due_date',r.task?.due_date>=today?r.task.due_date:today,'date',true,`min="${today}"`)}${selectField('订单标签','tag',tags.map(t=>[t,t]),r.task?.tag||'潜在客户跟进',true)}<label class="field full"><span>任务备注</span><textarea name="note" maxlength="2000">${safe(r.task?.note||'')}</textarea></label></div>`,'更新同一订单的任务');
      if(cmd==='cloud-complete')showDialog('cloud-complete',id,'完成待处理任务',`<p>${safe(r.customer_name||'未留姓名')} · #${r.number}</p><label class="field"><span>处理备注</span><textarea name="note" maxlength="2000"></textarea></label>`,'仅完成任务，不会改动销售额');
      if(cmd==='cloud-cancel')showDialog('cloud-cancel',id,'取消订单 / COD 拒收',`<div class="form-grid">${selectField('原因类型','kind',[['cancelled','取消订单'],['rejected','COD 拒收'],...(r.historical?[['cancelled_or_rejected','取消 / 拒收（旧记录未细分）']]:[])],'cancelled',true)}${r.historical?selectField('确认时间精度','date_precision',[['date','具体日期'],['month','只知道月份']],'date',true):''}<div id="cloud-cancel-time">${inputField('确认日期','confirmed_date',today,'date',true,`min="${r.order_date}" max="${today}"`)}</div>${text('原因','reason','',true,500)}</div><p>确认后扣减剩余 RM ${fmt(r.net_myr_minor??r.gmv_myr_minor)}，保留原订单和退款记录。已登记退款不会重复扣减；取消暂不支持撤销。</p>`,'扣减计入确认日期所在月份');
      if(cmd==='cloud-refund'||cmd==='cloud-refund-history'){
        const history=refundHistory(r);
        if(cmd==='cloud-refund-history')showDialog('detail',id,'退款记录',history,'原订单金额保留 · 按确认月份扣减');
        else showDialog('cloud-refund',id,'登记部分退款',`<dl class="detail-grid"><div><dt>原订单金额</dt><dd>${safe(r.currency)} ${fmt(r.gmv_minor)}</dd></div><div><dt>累计已退</dt><dd>${safe(r.currency)} ${fmt(r.refunded_minor||0)}</dd></div><div><dt>剩余净额</dt><dd>${safe(r.currency)} ${fmt(r.net_minor??r.gmv_minor)}</dd></div></dl><div class="form-grid">${inputField('本次退款金额 · '+r.currency,'refund_amount','','number',true,`min="0.01" max="${((r.net_minor??r.gmv_minor)-1)/100}" step="0.01"`)}${inputField('退款确认日期','confirmed_date',today,'date',true,`min="${r.refunds?.at(-1)?.confirmed_date||r.order_date}" max="${today}"`)}${text('退款原因','reason','',true,500)}</div><p class="notice">仅登记实际退款，不执行转账。部分退款不改变原奖励、购买次数和服用跟进；按确认月份扣减 HR。</p>${history}`,'保留原订单 · MYR / SGD 按原币登记');
      }
      if(cmd==='cloud-audit'){

        const logs=await rpc('audit',{id});if(token!==generation||!allowed())return;
        showDialog('detail',id,'订单与任务变更',`${r.items_snapshot?.length?`<h3 class="section-title">本单商品明细</h3>${window.DwellSkuForms.details(r.items_snapshot,r.quantity)}`:''}${window.DwellReferrals?.orderMarkup(r.referral_shipments)||''}<ol class="audit-list">${logs.map(l=>`<li><strong>${safe(l.actor_name)}</strong><small>${safe(new Date(l.occurred_at).toLocaleString('zh-CN',{timeZone:'Asia/Kuala_Lumpur'}))}</small><details><summary>变更详情</summary><pre style="white-space:pre-wrap;overflow-wrap:anywhere">${safe(JSON.stringify({before:l.before_data,after:l.after_data},null,2))}</pre></details></li>`).join('')}</ol>`,'最近 50 次变更');
        const delivery=r.delivery_snapshot;
        $('#dialog-body').insertAdjacentHTML('afterbegin',`<h3 class="section-title">本单收货资料</h3><p>${safe(delivery?.recipient_name||r.customer_name)} · ${safe(delivery?.recipient_phone||r.phone)}</p><p>${safe(delivery?.address||r.address)}</p>`);
        if(r.historical){const h=r.historical;$('#dialog-body').insertAdjacentHTML('afterbegin',`<h3>历史订单资料</h3><dl><dt>原订单编号</dt><dd>${safe(h.source.order_id)}</dd><dt>原客服 / 导入人</dt><dd>${safe(h.salesperson)} / ${safe(r.actor_name)}</dd><dt>原数量 / 核对后数量</dt><dd>${h.original_quantity} / ${h.sales_quantity}</dd><dt>数量更正依据</dt><dd>${safe(h.quantity_correction_reason||'无更正')}</dd><dt>金额依据</dt><dd>原最终 GMV；运费与折扣分项未记录</dd><dt>赠品明细</dt><dd>未记录，不采用现有配套补齐</dd>${h.task?`<dt>原任务</dt><dd>${safe(h.task.tag)} · ${safe(h.task.due_date||'原日期未记录')} · ${h.task.status==='completed'?'已完成（原完成时间未记录）':'待处理'}</dd>`:''}</dl>`);}
      }
    }catch(e){toast(failure(e));}finally{busy=false;}
  }
  async function submit(kind,id){
    if(kind==='cloud-delivery'){await window.DwellDelivery.saveManager();return;}
    if(busy)return;const token=generation;
    try{
      if(!allowed())throw new Error('core_owner_required');
      const required=({'cloud-order':'save','cloud-schedule':'task','cloud-complete':'task','cloud-gift':'grant_coupon','cloud-cancel':'cancel','cloud-refund':'refund','cloud-refund-history':'get','cloud-delivery':'delivery_save'})[kind];
      if(required&&!can(required))throw new Error('core_owner_required');
      if(!pending){
        const body={id:id||undefined,version:editing?.version,request_id:crypto.randomUUID()};let method;
        if(kind==='cloud-gift'){
          method='grant_coupon';
          for(const n of ['phone','customer_name','page_id','currency','name','platform'])body[n]=value(n);
          body.amount_minor=moneyInput('amount');body.minimum_minor=moneyInput('minimum');
          body.expires_on=value('expires_on')||null;
          Object.assign(body,window.DwellCouponRecipient.payload());
        }else if(kind==='cloud-order'){
          method='save';for(const n of ['order_date','nature','page_id','sku_id','currency','customer_name','phone','address','platform','source','payment','erp_id','tracking_number','note'])body[n]=value(n);
          body.quantity=Number(value('quantity'));body.customer_id=matched||'';
          body.market=value('market');body.choices=window.DwellSkuForms.choices();body.sku_version=skus.find(s=>s.id===body.sku_id)?.version;
          for(const n of ['goods_minor','shipping_minor','coupon_minor','discount_minor'])body[n]=body.nature==='inquiry'?0:moneyInput(n);
          if(window.DwellOrderLines?.isActive()){
            body.lines=window.DwellOrderLines.payload();body.sku_id=body.lines[0].sku_id;body.quantity=body.lines[0].quantity;
            body.choices=body.lines[0].choices;body.sku_version=body.lines[0].sku_version;
          }
          if(!id)for(const n of ['due_date','task_tag','task_note'])body[n]=value(n);
          Object.assign(body,window.DwellOrderPromotions.payload());
          Object.assign(body,window.DwellDelivery.payload());
        }else if(kind==='cloud-refund'){method='refund';body.amount_minor=moneyInput('refund_amount');body.currency=editing.currency;body.confirmed_date=value('confirmed_date');body.reason=value('reason');}
        else if(kind==='cloud-cancel'){method='cancel';body.date_precision=value('date_precision')||'date';for(const n of ['kind','reason',body.date_precision==='month'?'confirmed_month':'confirmed_date'])body[n]=value(n);}
        else{method='task';body.operation=kind==='cloud-complete'?'complete':'schedule';body.note=value('note');if(body.operation==='schedule'){body.due_date=value('due_date');body.tag=value('tag');}}
        pending={method,body};
      }
      busy=true;$('#save-button').disabled=true;
      await rpc(pending.method,pending.body);if(token!==generation||!allowed())return;
      pending=null;dialog.close();await refresh();toast(error?'已保存；列表刷新失败，请刷新核对':'已保存到 Supabase');
    }catch(e){
      if(token!==generation)return;
      const definite=/^[0-9A-Z]{5}$/.test(e?.code||'')&&!e.code.startsWith('08');if(definite)pending=null;
      if(pending)form.querySelectorAll('#dialog-body input,#dialog-body select,#dialog-body textarea').forEach(el=>el.disabled=true);
      $('#form-error').textContent=failure(e)+(pending?' 再点保存将重试同一份内容。':'');
    }finally{busy=false;$('#save-button').disabled=false;if(kind==='cloud-gift'&&!pending)window.DwellCouponRecipient.sync();}
  }
  form.addEventListener('change',e=>{
    if(dialogKind==='cloud-cancel'&&e.target.name==='date_precision'&&!pending){
      const monthOnly=e.target.value==='month';
      $('#cloud-cancel-time').innerHTML=monthOnly?inputField('确认月份','confirmed_month','','month',true,`min="${editing.order_date.slice(0,7)}" max="${today.slice(0,7)}"`):inputField('确认日期','confirmed_date',today,'date',true,`min="${editing.order_date}" max="${today}"`);
      return;
    }
    if(dialogKind!=='cloud-order'||pending)return;
    window.DwellDelivery.change(e);
    if(e.target.name==='saved_address')return;
    if(window.DwellOrderLines?.isActive()){
      if(e.target.name==='nature'&&editing?.nature==='inquiry'&&value('nature')==='inquiry')field('order_date').value=editing.order_date;
      window.DwellOrderLines.change(e);refreshForm();return;
    }
    // Inquiry totals are stored as zero, not as a quoted sale price.
    const initializeConversion=e.target.name==='nature'&&editing?.nature==='inquiry'&&value('nature')==='formal'&&!conversionPriced;
    if(e.target.name==='nature'&&editing?.nature==='inquiry'&&value('nature')==='inquiry')field('order_date').value=editing.order_date;
    if(e.target.name==='page_id'){updateSkuOptions();refreshItems();}
    if(['market','currency'].includes(e.target.name))updateSkuOptions(value('sku_id'));
    if(['sku_id','quantity','currency','market'].includes(e.target.name)||initializeConversion){
      const s=skus.find(s=>s.id===value('sku_id')),market=value('market');
      if(s){
        const same=editing?.nature==='formal'&&s.id===editing.sku_id&&market===(editing.market||(editing.currency==='SGD'?'SG':'MY'))&&value('currency')===editing.currency;
        const pricedCurrency=market==='SG'?'SGD':'MYR';
        const price=same?editing.goods_minor/editing.quantity:value('currency')!==pricedCurrency?null:market==='SG'?s.sgd_minor:market==='EM'?(s.em_minor??s.myr_minor):s.myr_minor;
        field('goods_minor').value=price==null?'':(price*Number(value('quantity'))/100).toFixed(2);
        if(e.target.name!=='quantity'||(!same&&s.shipping_tiers?.[market])){
          const shipping=same?editing.shipping_minor:value('currency')!==pricedCurrency?null:window.DwellSkuSales.shipping(s,market,Number(value('quantity')));
          field('shipping_minor').value=shipping==null?'':String(shipping/100);
        }
      }else{
        field('goods_minor').value='';field('shipping_minor').value='';
      }
      refreshItems(e.target.name!=='sku_id');
      if(initializeConversion)conversionPriced=true;
    }
    refreshForm();
  });
  form.addEventListener('input',e=>{if(dialogKind!=='cloud-order'||pending)return;window.DwellDelivery.editInput(e);if(e.target.name==='phone'){
    matched=null;phoneSerial++;clearTimeout(phoneTimer);window.DwellDelivery.identityInput();
    window.DwellOrderPromotions.clearPhone();
    for(const [name,previous] of Object.entries(autoFilled))if(value(name)===previous)field(name).value='';
    autoFilled={};window.DwellDelivery.syncIdentity();$('#cloud-match').textContent=value('phone')?'正在核对电话号码…':'尚未关联客户';
    phoneTimer=setTimeout(()=>void matchPhone(),300);
  }window.DwellOrderLines?.input(e);refreshForm();});
  dialog.addEventListener('cancel',e=>{if(busy&&dialogKind.startsWith('cloud-'))e.preventDefault();});
  document.addEventListener('click',e=>{if(busy&&dialogKind.startsWith('cloud-')&&(e.target===dialog||e.target.closest('[data-close]'))){e.preventDefault();e.stopImmediatePropagation();}},true);
  document.addEventListener('keydown',e=>{if(e.target.id==='cloud-search'&&e.key==='Enter'){e.preventDefault();void action('cloud-search');}});
  function checkDay(){if(allowed()&&state.view==='tasks'&&!loading&&!busy&&!dialog.open)void refresh();}
  window.addEventListener('focus',checkDay);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden)checkDay();});
  setInterval(()=>{if(localToday()!==today)checkDay();},60000);
  return {render,action,submit,clear,leave,nav,rpc,catalog,failure,currentTab:()=>tab};
})();
