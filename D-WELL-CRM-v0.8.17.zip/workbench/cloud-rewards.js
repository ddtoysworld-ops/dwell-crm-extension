"use strict";
window.DwellRewards=(()=>{
 const h=escapeHtml,allowed=()=>window.DwellPayments?.canCoreAction?.('rewards')??window.DwellPayments?.canManagePages();
 const statuses={available:'可使用',used:'已使用',expired:'已过期',not_started:'未到使用日期',void:'已作废',review:'待核对',unshipped:'未寄出',pending:'随原单待寄出',not_selected:'未安排寄送',hold:'留待下次订单',postage_pending:'待收邮费',ready:'待寄出',shipped:'已寄出',completed:'已完成'};
 const origins={manual:'单独发券',order:'订单附送',lucky:'幸运抽奖',referral:'好友推荐',crm:'旧 CRM'};
 const methods={with_friend:'随被推荐人订单',self_postage:'独立寄出',next_order:'随推荐人下次订单',current_order:'随抽奖来源订单'};
 const legacyStates={PENDING:'待寄出',DELIVERY_NOT_SELECTED:'尚未选择寄送安排',HOLD_FOR_NEXT_ORDER:'留待下次订单',POSTAGE_PENDING:'待收邮费',READY_TO_SHIP:'待寄出',SHIPPED:'已寄出',COMPLETED:'已完成',FULFILLED:'已寄出',VOID:'已作废'};
 const reasons={source_order_unresolved:'来源订单待核对',prize_snapshot_mismatch:'奖品快照不一致',legacy_test_record:'旧测试记录',unknown_status:'旧状态无法确认',shipment_audit_incomplete:'寄送时间或操作人缺失',shipment_status_conflict:'寄送状态与记录冲突',qualification_not_confirmed:'旧资格未确认',tracking_record_missing:'缺少寄送记录',phone_invalid:'电话号码待核对',issued_at_invalid:'获得时间待核对',shipped_at_invalid:'寄出时间待核对',updated_at_invalid:'更新时间待核对',grant_context_invalid:'来源订单资料待核对',prize_snapshot_invalid:'奖品资料待核对'};
 let source='supabase',kind='',status='',search='',offset=0,report=null,error='',loading=false,generation=0;
 const button=(a,label,ico)=>`<button type="button" class="secondary" data-reward="${a}">${icon(ico)}${label}</button>`;
 const date=v=>v?h(/^\d{4}-\d{2}-\d{2}$/.test(String(v))?String(v):new Date(v).toLocaleDateString('en-GB',{timeZone:'Asia/Kuala_Lumpur'})):'未记录';
 const order=r=>r.order_number?`#${h(r.order_number)}${r.order_ref?'<small>'+h(r.order_ref)+'</small>':''}`:r.order_ref?h(r.order_ref):r.source_order_refs?.length?`来源订单待核对<small>候选：${r.source_order_refs.map(h).join(' / ')}</small>`:'未关联订单';
 function leave(){generation++;loading=false;report=null;error='';}
 async function refresh(){if(!allowed()){leave();render(false);return;}const token=++generation;loading=true;report=null;error='';render(false);
  try{const data=await DwellPayments.rewardsRpc({source,kind,status,search,offset});if(token!==generation||!allowed())return;report=data;}
  catch(e){if(token===generation)error=e?.code==='PGRST202'?'奖励查询接口尚未更新，请稍后刷新。':'无法读取奖励记录，请检查登录与连接后重试。';}
  finally{if(token===generation){loading=false;render(false);}}
 }
 function render(fetch=true){if(state.view!=='rewards')return;
  if(!allowed()){$('#main').innerHTML=heading('优惠券与奖品','真实奖励记录')+'<div class="empty">请使用主管理员账号登录。</div>';return;}
  if(fetch){void refresh();return;}
  const legacy=source==='legacy';
  $('#main').innerHTML=heading('优惠券与奖品','客户奖励记录',button('refresh','刷新','refresh-cw'))+
   `<div class="payment-tabs" role="tablist" aria-label="奖励数据来源"><button type="button" data-reward="supabase" role="tab" aria-selected="${!legacy}">Supabase 记录</button><button type="button" data-reward="legacy" role="tab" aria-selected="${legacy}">旧系统 · 只读快照</button></div>
   <p class="notice">${legacy?'旧券与实物奖品仅供查看，不可在此核销或标记寄出。寄送状态以各条快照时间为准，不代表旧系统此刻状态。':'本页只读汇总已入库优惠券、抽奖实物和已审核推荐奖励。真实抽奖尚未开放，历史资料未完整迁入。'}</p>
   <div class="reward-filters"><label class="field"><span>顾客、电话、奖品或订单</span><input id="reward-search" type="search" maxlength="100" value="${h(search)}"></label>
   <label class="field"><span>类型</span><select id="reward-kind">${[['','全部'],['voucher','优惠券'],['product','实物奖品']].map(([v,l])=>`<option value="${v}" ${v===kind?'selected':''}>${l}</option>`).join('')}</select></label>
   <label class="field"><span>状态</span><select id="reward-status"><option value="">全部状态</option>${Object.entries(statuses).map(([v,l])=>`<option value="${v}" ${v===status?'selected':''}>${l}</option>`).join('')}</select></label>${button('search','查询','search')}</div>
   ${loading?'<div class="empty" role="status">正在读取奖励记录…</div>':error?`<div class="alert-note" role="alert">${h(error)}</div>`:report?table(report.items):''}`;icons();
 }
 function table(items){return `<div class="table-scroll"><table class="reward-records"><thead><tr>${['顾客','优惠券 / 奖品','来源 / 主页','状态','关联订单','日期 / 快照'].map(x=>`<th>${x}</th>`).join('')}</tr></thead><tbody>${items.map(r=>`<tr>
   <td>${h(r.customer_name||'尚未关联客户')}<small>${h(r.phone||'未记录电话')}</small></td>
   <td><strong>${h(r.name)}</strong><small>${r.kind==='voucher'?`${h(r.currency||'币种待核对')} ${r.amount_minor==null?'面额待核对':fmt(r.amount_minor)}`:`实物 × ${h(r.quantity)}`}</small>${r.kind==='voucher'?`<small>${r.minimum_minor==null?'使用门槛待核对':r.minimum_minor===0?'无最低消费':'最低消费 '+h(r.currency)+' '+fmt(r.minimum_minor)}</small><small>${r.expires_on?'有效期至 '+date(r.expires_on):'无到期日'}</small>`:''}</td>
   <td><span class="pill ${r.source==='legacy'?'neutral':'success'}">${r.source==='legacy'?'旧系统 · 只读':'Supabase'}</span><small>${h(origins[r.origin]||r.origin)}</small><small>${h(r.page_name||'主页未记录')}</small>${r.campaign_name?`<small>${h(r.campaign_name)}</small>`:''}</td>
   <td><span class="pill ${['available','shipped'].includes(r.status)?'success':['review','ready','pending','postage_pending','unshipped'].includes(r.status)?'warning':'neutral'}">${h(statuses[r.status]||r.status)}</span>${r.source==='legacy'?`<small>${r.kind==='product'?'快照状态 · 只读':'快照状态 · 不可核销'}</small>`:''}${r.delivery_method?`<small>${h(methods[r.delivery_method]||'未安排')}</small>`:''}${r.source==='legacy'&&r.kind==='product'?`<small>旧状态：${h(legacyStates[r.source_status]||r.source_status||'未记录')}</small>`:''}${r.tracking_number?`<small>运单 ${h(r.tracking_number)}</small>`:r.source==='legacy'&&r.kind==='product'?'<small>运单未记录</small>':''}${r.review_reasons?.length?`<small>待核对：${r.review_reasons.map(x=>h(reasons[x]||x)).join('；')}</small>`:''}</td>
   <td>${order(r)}${r.buyer_name?`<small>被推荐人：${h(r.buyer_name)}</small>`:''}${r.shipment_order_ref?`<small>寄送订单：${h(r.shipment_order_ref)}</small>`:''}${r.redeemed_order_number?`<small>使用于 #${h(r.redeemed_order_number)} · ${h(r.redeemed_order_ref||'')}</small>`:''}</td>
   <td>获得：${date(r.issued_at)}${r.used_at?`<small>使用：${date(r.used_at)}</small>`:''}${r.shipped_at?`<small>寄出：${date(r.shipped_at)}</small>`:r.kind==='product'&&r.status==='shipped'?'<small>寄出时间未记录</small>':''}${r.updated_at?`<small>旧表更新：${date(r.updated_at)}</small>`:''}${r.actor?`<small>记录人：${h(r.actor)}</small>`:''}${r.captured_at?`<small>快照：${h(new Date(r.captured_at).toLocaleString('en-GB',{timeZone:'Asia/Kuala_Lumpur'}))}</small><small>${h(r.source_sheet||'旧表')}第 ${h(r.source_row)} 行</small>`:''}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">此范围暂无快照或已入库奖励记录。</td></tr>'}</tbody></table></div>
   <div class="ref-pagination"><span>${report.total} 条 · 第 ${Math.floor(offset/25)+1} 页</span><div><button class="icon-button" data-reward="prev" title="上一页" aria-label="上一页" ${offset===0?'disabled':''}>${icon('chevron-left')}</button><button class="icon-button" data-reward="next" title="下一页" aria-label="下一页" ${offset+25>=report.total?'disabled':''}>${icon('chevron-right')}</button></div></div>`;}
 document.addEventListener('click',e=>{const b=e.target.closest('[data-reward]');if(!b||b.disabled||state.view!=='rewards'||!allowed())return;const a=b.dataset.reward;
  if(a==='supabase'||a==='legacy'){source=a;offset=0;kind='';status='';search='';}
  else if(a==='search'){search=$('#reward-search').value.trim();kind=$('#reward-kind').value;status=$('#reward-status').value;offset=0;}
  else if(a==='prev'||a==='next'){if(loading)return;offset+=a==='next'?25:-25;}
  else if(a!=='refresh')return;
  void refresh();
 });
 return {render,leave};
})();
