"use strict";
(() => {
  if(new URL(location.href).searchParams.get('surface')!=='sidepanel')return;
  const previous=window.DwellLucky;
  let generation=0,tab='results',campaign='',cfg=null,rows=null,query='',offset=0,error='',busy=false,pending=null;
  const h=escapeHtml;
  const labels={pending:'待寄出',shipped:'已寄出',available:'可使用',used:'已使用',void:'已作废',review:'待核对',expired:'已过期',active:'有效'};
  const rpc=(a,p={})=>DwellPayments.luckyRpc(a,p);
  function leave(){++generation;cfg=null;rows=null;error='';pending=null;previous.leave();}
  function draw(loading=false){
    if(state.view!=='draws')return;
    $('#main').innerHTML=heading('幸运抽奖','Supabase · 当前客户记录')+
      '<p class="notice">尚未正式切换：新抽奖链接与次数发放未开放。旧券和旧奖品在「优惠券与奖品」只读查看。</p>'+
      (cfg?`<label class="field"><span>活动</span><select id="plugin-lucky-campaign">${cfg.campaigns.map(c=>`<option value="${h(c.id)}" ${campaign===c.id?'selected':''}>${h(c.name)}</option>`).join('')}</select></label>`:'')+
      `<div class="payment-tabs" role="tablist">${[['orders','订单资格'],['grants','抽奖次数'],['results','中奖与寄送']].map(([id,label])=>`<button type="button" data-plugin-lucky="tab" data-id="${id}" aria-selected="${tab===id}" role="tab">${label}</button>`).join('')}</div>`+
      `<div class="plugin-lucky-search"><input aria-label="抽奖客户电话" id="plugin-lucky-search" value="${h(query)}" placeholder="客户电话"><button type="button" class="secondary" data-plugin-lucky="search">${icon('search')}查询</button></div>`+
      (loading?'<p class="empty" role="status">正在读取…</p>':error?`<p role="alert" class="alert-note">${h(error)}</p>`:records())+
      `<div class="ref-pagination"><span>${rows?.total||0} 条</span><div><button class="icon-button" data-plugin-lucky="prev" aria-label="上一页" ${!offset?'disabled':''}>${icon('chevron-left')}</button><button class="icon-button" data-plugin-lucky="next" aria-label="下一页" ${offset+25>=(rows?.total||0)?'disabled':''}>${icon('chevron-right')}</button></div></div>`;
    icons();
  }
  function records(){return (rows?.items||[]).map(r=>{
    const status=tab==='results'?(r.status==='void'?'void':r.coupon_id?r.coupon_status:r.status):r.status;
    const summary=tab==='results'?r.snapshot?.name:tab==='orders'?'订单 #'+r.number:'订单 #'+r.order_number;
    const canShip=tab==='results'&&r.status==='pending'&&r.snapshot?.kind==='product'&&!r.coupon_id&&DwellPayments.canCoreAction('lucky','ship');
    return `<article class="plugin-lucky-record"><div class="plugin-record-heading"><strong>${h(summary||'记录')}</strong><span class="pill ${status==='shipped'?'success':'neutral'}">${h(labels[status]||status||'资格预览')}</span></div><p>${h(r.customer_name)} · ${h(r.phone)}</p><small>${h(r.erp_id||'')}${r.order_number?' · #'+h(r.order_number):''}</small>${tab==='results'?`${r.tracking_number?`<p>运单：${h(r.tracking_number)}</p>`:''}${canShip?`<button type="button" class="secondary" data-plugin-lucky="ship" data-id="${h(r.id)}">${icon('truck')}登记寄出</button>`:''}`:tab==='grants'?`<p>已用 ${h(r.used)} / ${h(r.chances)} 次 · 剩余 ${r.status==='active'?Math.max(0,r.chances-r.used):0} 次</p>`:`<p>${h(r.currency)} ${fmt(r.gmv_minor)} · 预计 ${h(r.eligibility?.chances||0)} 次</p><small>${r.eligibility?.eligible?'符合金额与日期，尚须确认资格':'未满足活动规则'}</small>`}</article>`;
  }).join('')||'<p class="empty">当前范围暂无记录</p>';}
  async function refresh(){
    const serial=++generation;error='';draw(true);
    try{
      if(!cfg)cfg=await rpc('settings');if(serial!==generation)return;
      if(!cfg.campaigns.some(c=>c.id===campaign))campaign=cfg.campaigns[0]?.id||'';
      const result=campaign?await rpc('list',{campaign_id:campaign,kind:tab,search:query,offset}):{items:[],total:0};
      if(serial!==generation)return;rows=result;
    }catch(e){if(serial!==generation)return;error=e.message;rows=null;}
    if(serial===generation)draw();
  }
  function render(){query=window.DwellWorkbenchCustomer?.()?.phones?.[0]||window.DwellWorkbenchContext?.()?.phone||'';offset=0;void refresh();}
  async function submit(){
    if(dialogKind!=='plugin-lucky-ship'){return previous.submit();}
    if(busy||!pending)return;busy=true;$('#save-button').disabled=true;
    try{
      pending.body ||= {id:pending.record.id,version:pending.record.version,campaign_id:campaign,tracking_number:value('tracking_number'),request_id:crypto.randomUUID()};
      await rpc('ship',pending.body);dialog.close();pending=null;await refresh();
    }catch(e){$('#form-error').textContent=e.message||'登记失败，请刷新核对。';}
    finally{busy=false;$('#save-button').disabled=false;}
  }
  document.addEventListener('click',e=>{
    const b=e.target.closest('[data-plugin-lucky]');if(!b||b.disabled||busy||state.view!=='draws')return;
    const action=b.dataset.pluginLucky;
    if(action==='tab'){tab=b.dataset.id;offset=0;void refresh();}
    if(action==='search'){query=$('#plugin-lucky-search').value.trim();offset=0;void refresh();}
    if(action==='prev'||action==='next'){offset+=action==='next'?25:-25;void refresh();}
    if(action==='ship'){
      const r=rows?.items.find(r=>r.id===b.dataset.id);
      if(!r||r.status!=='pending'||r.coupon_id||r.snapshot?.kind!=='product')return;
      pending={record:r};
      showDialog('plugin-lucky-ship',r.id,'登记奖品寄出',`<p>${h(r.customer_name)} · ${h(r.phone)}</p><p>${h(r.snapshot.name)}</p>${inputField('运单号码','tracking_number','','text',true,'maxlength="100"')}<label class="ref-check"><input type="checkbox" required name="shipment_confirm">已核对奖品随这张订单寄出</label>`,'Supabase · 不发送消息');
    }
  });
  document.addEventListener('change',e=>{if(e.target.id==='plugin-lucky-campaign'){campaign=e.target.value;offset=0;void refresh();}});
  $('#edit-form').addEventListener('submit',e=>{if(dialogKind==='plugin-lucky-ship'){e.preventDefault();e.stopImmediatePropagation();if(e.target.reportValidity())void submit();}},true);
  window.DwellLucky={...previous,render,leave,submit};
})();
