"use strict";
window.DwellTasks=(()=>{
  const tags=['延迟寄出','潜在客户跟进','想要做复购的动作','已完成'];
  let filter='pending',query='',seenDay='';
  const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
  const actor=()=>window.DwellPayments?.actorName()||'管理员预览';
  const find=id=>state.orders.find(o=>o.id===id);
  const validDate=date=>/^\d{4}-\d{2}-\d{2}$/.test(date)&&!Number.isNaN(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date;
  const open=o=>!!o.followUp?.date&&o.followUp.tag!=='已完成'&&!['cancelled','rejected'].includes(o.status);
  const log=(action,before,after)=>({action,at:new Date().toISOString(),actor:actor(),from:before?.date||'',to:after.date||'',tag:after.tag,note:after.note||''});
  function updateCount(){const el=$('#task-count');if(el)el.textContent=state.orders.filter(o=>open(o)&&o.followUp.date<=today()).length;}
  function seed(){
    filter='pending';query='';
    for(const [id,date,tag] of [['DEMO-0015',TODAY,'潜在客户跟进'],['DEMO-0007','2026-10-10','延迟寄出'],['DEMO-0001','2026-10-08','想要做复购的动作']]){
      const o=find(id);if(o)o.followUp={date,tag,note:'模拟待处理事项',history:[],completedAt:null};
    }
    updateCount();
  }
  function orderFields(o){
    const f=o.followUp||{};
    return `<hr class="form-divider"><div class="form-section-title">待处理 / 后续跟进设置</div><div class="form-grid">${inputField('后续操作日期','followDate',f.date||'','date')}${selectField('订单标签','followTag',[['','不设置'],...tags.map(t=>[t,t])],f.tag||'')}<label class="field full"><span>详细备注</span><textarea name="followNote" rows="2" maxlength="500">${escapeHtml(f.note||'')}</textarea></label></div><hr class="form-divider"><div class="form-grid">${selectField('好友推荐订单','referral',[['no','否'],['yes','是']],o.referral?'yes':'no')}<div id="referrer-field">${inputField('推荐人电话号码','referrerPhone',o.referrerPhone||'','tel',false,'pattern="6[0-9]{7,15}" title="以 6 开头，支持马来西亚与新加坡号码"')}</div></div><p id="conversion-date-note" class="notice" hidden></p>`;
  }
  function refreshForm(){
    if(!field('referral'))return;
    const yes=value('referral')==='yes';
    $('#referrer-field').hidden=!yes;field('referrerPhone').disabled=!yes;field('referrerPhone').required=yes;
    const previous=find(dialogId),converting=previous?.nature==='inquiry'&&value('nature')==='formal';
    if(converting){
      if(!form.dataset.converting){form.dataset.converting='yes';form.dataset.originalDate=field('date').value;}
      field('date').value=today();field('date').readOnly=true;
      $('#conversion-date-note').hidden=false;
      $('#conversion-date-note').textContent=`最初咨询：${dateLabel(previous.inquiryDate||previous.date)}；成交日期：${dateLabel(today())}。销售额计入成交当天。`;
    }else{
      if(form.dataset.converting)field('date').value=form.dataset.originalDate;
      delete form.dataset.converting;delete form.dataset.originalDate;field('date').readOnly=false;
      $('#conversion-date-note').hidden=!previous?.inquiryDate;
      if(previous?.inquiryDate)$('#conversion-date-note').textContent=`最初咨询：${dateLabel(previous.inquiryDate)}；成交日期：${dateLabel(previous.convertedOn||previous.date)}`;
    }
    const tag=value('followTag'),date=value('followDate');
    field('followDate').required=!!tag&&tag!=='已完成';field('followTag').required=!!date;
  }
  function readOrder(previous,date){
    const referral=value('referral')==='yes',referrerPhone=referral?value('referrerPhone'):'';
    if(referral&&!/^6\d{7,15}$/.test(referrerPhone))throw new Error('请填写以 6 开头的推荐人电话号码');
    if(referral&&referrerPhone===value('phone'))throw new Error('推荐人电话不能与本单顾客相同');
    const converting=previous?.nature==='inquiry'&&value('nature')==='formal';
    if(converting&&date!==today())throw new Error('成交日期必须为实际处理当天');
    const before=previous?.followUp;
    let followUp={date:value('followDate'),tag:value('followTag'),note:value('followNote'),completedAt:before?.completedAt||null,history:[...(before?.history||[])]};
    if(followUp.date&&!validDate(followUp.date))throw new Error('后续操作日期无效');
    if((followUp.date&&!tags.includes(followUp.tag))||(followUp.tag&&followUp.tag!=='已完成'&&!followUp.date))throw new Error('请同时填写后续操作日期和订单标签');
    if(converting&&before?.date){followUp={...followUp,tag:'已完成',date:before.date,completedAt:new Date().toISOString()};followUp.history.push(log('成交并完成',before,followUp));}
    else if(['date','tag','note'].some(k=>(before?.[k]||'')!==followUp[k])){
      followUp.completedAt=followUp.tag==='已完成'?new Date().toISOString():null;
      followUp.history.push(log(followUp.tag==='已完成'?'标记完成':before?.date?'修改安排':'安排后续处理',before,followUp));
    }
    return {referral,referrerPhone,followUp,inquiryDate:previous?.inquiryDate||(previous?.nature==='inquiry'?previous.date:value('nature')==='inquiry'?date:''),convertedOn:converting?today():previous?.convertedOn||'',convertedBy:converting?actor():previous?.convertedBy||''};
  }
  function matches(o){
    if(!o.followUp?.date)return false;
    const isOpen=open(o),date=o.followUp.date,day=today();
    if(filter==='completed'?!(!isOpen&&o.followUp.tag==='已完成'):!isOpen)return false;
    if(filter==='overdue'&&date>=day||filter==='today'&&date!==day||filter==='future'&&date<=day)return false;
    return !query||[o.id,o.customerName,o.phone,o.erp,o.trackingNumber,o.channel,o.followUp.note,o.followUp.tag].join(' ').toLowerCase().includes(query.toLowerCase());
  }
  function render(){
    updateCount();const day=today();
    const selected=state.orders.filter(matches).sort((a,b)=>a.followUp.date.localeCompare(b.followUp.date)||a.id.localeCompare(b.id));
    const groups=[...new Set(selected.map(o=>o.followUp.date))];
    $('#main').innerHTML=heading('待处理任务清单',`${dateLabel(day)} · 马来西亚时间 · 模拟资料`)+`<div class="task-toolbar"><div class="task-tabs" role="tablist" aria-label="任务状态">${[['pending','全部待处理'],['overdue','逾期'],['today','今日'],['future','未来'],['completed','已完成']].map(([v,l])=>`<button role="tab" aria-selected="${filter===v}" data-action="task-filter" data-id="${v}">${l}</button>`).join('')}</div><label class="search-field">${icon('search')}<input id="task-search" aria-label="搜索待处理任务" placeholder="顾客、电话、订单或备注" value="${escapeHtml(query)}"></label></div><section class="task-list">${groups.map(date=>`<div class="task-date"><h3>${dateLabel(date)}</h3>${filter==='completed'?'':`<span class="pill ${date<day?'danger':date===day?'warning':'neutral'}">${date<day?'逾期':date===day?'今日':'未来'}</span>`}</div>${selected.filter(o=>o.followUp.date===date).map(o=>`<article class="task-row" data-task-id="${o.id}"><div class="task-person"><strong>${escapeHtml(o.customerName||'未留姓名')}</strong><span>${escapeHtml(o.channel)} · ${escapeHtml(o.phone||'未留电话')}</span><small>${escapeHtml(o.id)} · ${escapeHtml(o.skuName)}</small></div><div class="task-description"><span class="pill ${o.followUp.tag==='延迟寄出'?'danger':'neutral'}">${escapeHtml(o.followUp.tag)}</span><p>${escapeHtml(o.followUp.note||'')}</p>${o.inquiryDate?`<small>最初咨询 ${dateLabel(o.inquiryDate)}${o.convertedOn?` · 成交 ${dateLabel(o.convertedOn)}`:''}</small>`:''}</div><div class="task-actions">${open(o)?`<button class="secondary" data-action="task-process" data-id="${o.id}">${icon('calendar-clock')}处理 / 改期</button>${o.nature==='inquiry'?`<button class="primary" data-action="task-convert" data-id="${o.id}">${icon('check')}成交订单</button>`:''}`:''}<button class="icon-button" data-action="task-history" data-id="${o.id}" title="处理记录" aria-label="处理记录 ${o.id}">${icon('history')}</button><button class="icon-button" data-action="edit-order" data-id="${o.id}" title="查看订单" aria-label="查看订单 ${o.id}">${icon('square-pen')}</button></div></article>`).join('')}`).join('')||'<div class="empty">没有符合条件的任务</div>'}</section>`;icons();
  }
  function action(name,id){
    if(name==='task-filter'){filter=id;render();return;}
    const o=find(id);if(!o)throw new Error('找不到订单');
    if(name==='task-history'){
      showDialog('detail',id,'处理记录',o.followUp?.history?.length?`<ol class="audit-list">${o.followUp.history.map(h=>`<li><strong>${escapeHtml(h.action)}</strong> · ${escapeHtml(h.actor)}<small>${escapeHtml(new Date(h.at).toLocaleString('en-GB',{timeZone:'Asia/Kuala_Lumpur'}))}</small><p>${h.from?dateLabel(h.from):'未安排'} → ${h.to?dateLabel(h.to):'未安排'} · ${escapeHtml(h.tag)}<br>${escapeHtml(h.note)}</p></li>`).join('')}</ol>`:'<p>尚无处理记录</p>','模拟记录');return;
    }
    if(!open(o))throw new Error('此任务已完成或已关闭，请刷新核对');
    if(name==='task-convert'){if(o.nature!=='inquiry')throw new Error('这笔订单已经是正式订单');orderDialog(id,true);return;}
    if(name==='task-process'){
      showDialog('task-process',id,'处理待办任务',`<div class="summary-line"><span>${escapeHtml(o.customerName||'未留姓名')}</span><strong>${escapeHtml(o.id)}</strong></div><div class="form-grid task-process-fields">${selectField('处理结果','taskResult',[['reschedule','安排下次处理'],['complete','标记已完成']],'reschedule',true)}${inputField('下次处理日期','taskDate',o.followUp.date>=today()?o.followUp.date:today(),'date',true,`min="${today()}"`)}${selectField('订单标签','taskTag',tags.filter(t=>t!=='已完成').map(t=>[t,t]),o.followUp.tag,true)}<label class="field full"><span>详细备注</span><textarea name="taskNote" rows="3" maxlength="500">${escapeHtml(o.followUp.note||'')}</textarea></label><input type="hidden" name="taskRevision" value="${o.revision}"></div>`,'仅更新处理安排，不重复计算销售额');
    }
  }
  function refreshProcess(){const complete=value('taskResult')==='complete';for(const n of ['taskDate','taskTag']){field(n).disabled=complete;field(n).required=!complete;field(n).closest('label').hidden=complete;}}
  function submit(id){
    const o=find(id);if(!o||!open(o)||o.revision!==Number(value('taskRevision')))throw new Error('任务状态已改变，请重新打开');
    const complete=value('taskResult')==='complete',date=complete?o.followUp.date:value('taskDate');
    if(!complete&&(!validDate(date)||date<today()||!tags.includes(value('taskTag'))))throw new Error('请选择今天或之后的处理日期和有效标签');
    const f={...o.followUp,date,tag:complete?'已完成':value('taskTag'),note:value('taskNote'),completedAt:complete?new Date().toISOString():null};
    f.history=[...o.followUp.history,log(complete?'标记完成':'安排下次处理',o.followUp,f)];o.followUp=f;o.revision++;
    dialog.close();window.render();toast(complete?'任务已完成，销售金额未改变':'下次处理日期已更新');
  }
  function closeForCancellation(o){if(!o.followUp?.date||o.followUp.tag==='已完成')return;const f={...o.followUp,tag:'已完成',completedAt:new Date().toISOString()};f.history=[...f.history,log('订单取消 / 拒收，关闭任务',o.followUp,f)];o.followUp=f;}
  document.addEventListener('input',event=>{if(event.target.id!=='task-search')return;const pos=event.target.selectionStart;query=event.target.value;render();$('#task-search').focus();$('#task-search').setSelectionRange(pos,pos);});
  function refreshDay(){const day=today();if(day!==seenDay){seenDay=day;updateCount();}}
  window.addEventListener('focus',refreshDay);document.addEventListener('visibilitychange',refreshDay);
  setInterval(refreshDay,60000);
  seed();seenDay=today();
  return {today,seed,render,action,submit,refreshProcess,orderFields,refreshForm,readOrder,updateCount,closeForCancellation};
})();
