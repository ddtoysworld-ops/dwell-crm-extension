"use strict";
window.DwellOrderLines=(()=>{
  let rows=[],skus=[],editing=null,onChange=()=>{},active=false,converted=false;
  const safe=escapeHtml;
  const price=s=>value('currency')!==(value('market')==='SG'?'SGD':'MYR')?null:value('market')==='SG'?s?.sgd_minor:value('market')==='EM'?s?.em_minor:s?.myr_minor;
  const previous=r=>editing?.line_items?.find(l=>l.sku_id===r.sku_id&&Boolean(l.is_gift)===Boolean(r.is_gift));
  function available(s,r){return s.sku_kind!=='legacy'&&(!s.page_id||s.page_id===value('page_id'))&&((s.active&&(r.is_gift||window.DwellSkuSales.allowed(s,value('market'))))||Boolean(previous({...r,sku_id:s.id})));}
  function blank(){return {key:crypto.randomUUID(),sku_id:'',quantity:1,amount:'',is_gift:false,choices:{}};}
  function read(){
    for(const el of document.querySelectorAll('[data-cart-row]')){
      const r=rows.find(r=>r.key===el.dataset.cartRow);if(!r)continue;
      r.sku_id=el.querySelector('[data-cart-sku]').value;r.quantity=Number(el.querySelector('[data-cart-quantity]').value);
      r.is_gift=el.querySelector('[data-cart-kind]').value==='gift';
      r.amount=r.is_gift?'0.00':el.querySelector('[data-cart-amount]').value;
      r.choices=Object.fromEntries([...el.querySelectorAll('[data-order-choice]')].map(x=>[x.dataset.orderChoice,x.value]));
    }
  }
  function total(){
    const valid=rows.every(r=>r.sku_id&&r.amount!==''&&Number.isFinite(Number(r.amount)));
    field('goods_minor').value=valid?(rows.reduce((n,r)=>n+Math.round(Number(r.amount)*100),0)/100).toFixed(2):'';
  }
  function markup(r,i){
    const s=skus.find(s=>s.id===r.sku_id),old=previous(r),inquiry=value('nature')==='inquiry';
    const options=skus.filter(s=>available(s,r)&&(!rows.some(x=>x!==r&&x.sku_id===s.id&&Boolean(x.is_gift)===Boolean(r.is_gift))));
    return `<div class="cart-line" data-cart-row="${r.key}"><div class="cart-line-fields"><label class="field cart-kind"><span>类型 ${i+1}</span><select data-cart-kind><option value="sale" ${!r.is_gift?'selected':''}>正常销售</option><option value="gift" ${r.is_gift?'selected':''}>赠品（不收费）</option></select></label><label class="field cart-sku"><span>产品 / 配套 ${i+1} *</span><select data-cart-sku required><option value="">请选择 SKU</option>${options.map(s=>`<option value="${s.id}" ${r.sku_id===s.id?'selected':''}>${safe(s.code+' · '+s.name)}</option>`).join('')}</select></label><label class="field"><span>数量 ${i+1} *</span><input data-cart-quantity type="number" min="1" max="1000" step="1" value="${r.quantity}" required></label><label class="field"><span>商品小计 ${i+1} · ${safe(value('currency'))} *</span><input data-cart-amount type="number" min="0" max="100000000" step="0.01" value="${safe(r.amount)}" required ${r.is_gift?'readonly':''} ${inquiry?'disabled':''}></label><button type="button" class="icon-button" data-cart-remove title="移除商品 ${i+1}" aria-label="移除商品 ${i+1}" ${rows.length===1?'disabled':''}>${icon('trash-2')}</button></div><div data-cart-details>${window.DwellSkuForms.orderMarkup(s,old,r.quantity||1,r.is_gift)}</div></div>`;
  }
  function render(){
    $('#cloud-items').innerHTML='<h3 class="section-title">订单商品</h3>'+rows.map(markup).join('')+`<button type="button" class="secondary" data-cart-add ${rows.length>=30?'disabled':''}>${icon('plus')}添加产品 / 配套</button>`;
    for(const el of document.querySelectorAll('[data-cart-row]')){
      const r=rows.find(r=>r.key===el.dataset.cartRow);
      for(const choice of el.querySelectorAll('[data-order-choice]'))choice.value=r.choices[choice.dataset.orderChoice]||'';
    }
    total();icons();
  }
  function mount(order,options,change){
    editing=order;skus=options;onChange=change;converted=false;
    active=!order||Boolean(order.line_items?.length);
    if(!active)return false;
    rows=order?.line_items?.map(l=>({...l,key:crypto.randomUUID(),amount:(l.goods_minor/100).toFixed(2),choices:{}}))||[blank()];
    for(const name of ['sku_id','quantity']){field(name).required=false;field(name).closest('label').hidden=true;}
    field('goods_minor').readOnly=true;field('goods_minor').closest('label').querySelector('span').textContent='商品合计';
    field('shipping_minor').closest('label').querySelector('span').textContent='整单运费 *';
    if(!order)field('shipping_minor').value='';
    render();return true;
  }
  function reprice(r){
    if(r.is_gift){r.amount='0.00';return;}
    const s=skus.find(s=>s.id===r.sku_id),old=previous(r);
    const same=editing?.nature==='formal'&&editing.market===value('market')&&editing.currency===value('currency')&&old;
    const unit=same?old.goods_minor/old.quantity:price(s);
    r.amount=unit==null?'':(Math.round(unit*r.quantity)/100).toFixed(2);
  }
  function change(e){
    if(!active)return false;
    read();const el=e.target,row=rows.find(r=>r.key===el.closest('[data-cart-row]')?.dataset.cartRow);
    if(row&&(el.hasAttribute('data-cart-sku')||el.hasAttribute('data-cart-quantity')||el.hasAttribute('data-cart-kind'))){
      if(el.hasAttribute('data-cart-kind')){
        const s=skus.find(s=>s.id===row.sku_id);
        if(!s||!available(s,row)||rows.some(x=>x!==row&&x.sku_id===row.sku_id&&Boolean(x.is_gift)===Boolean(row.is_gift)))row.sku_id='';
      }
      if(el.hasAttribute('data-cart-sku')||el.hasAttribute('data-cart-kind'))row.choices={};reprice(row);render();
    }else if(['page_id','market','currency'].includes(el.name)){
      for(const r of rows){const s=skus.find(s=>s.id===r.sku_id);if(!s||!available(s,r)){r.sku_id='';r.choices={};}reprice(r);}
      if(['market','currency'].includes(el.name))field('shipping_minor').value='';render();
    }else if(el.name==='nature'){
      if(editing?.nature==='inquiry'&&value('nature')==='formal'&&!converted){rows.forEach(reprice);field('shipping_minor').value='';converted=true;}
      render();
    }else total();
    return true;
  }
  function input(e){
    const el=e.target.closest('[data-cart-row]');if(!active||!el)return;
    read();
    if(e.target.hasAttribute('data-cart-quantity')){
      const r=rows.find(r=>r.key===el.dataset.cartRow);reprice(r);el.querySelector('[data-cart-amount]').value=r.amount;
      el.querySelector('[data-cart-details]').innerHTML=window.DwellSkuForms.orderMarkup(skus.find(s=>s.id===r.sku_id),previous(r),r.quantity||1,r.is_gift);
      for(const choice of el.querySelectorAll('[data-order-choice]'))choice.value=r.choices[choice.dataset.orderChoice]||'';
    }
    total();
  }
  function payload(){
    read();return rows.map(r=>({sku_id:r.sku_id,is_gift:Boolean(r.is_gift),quantity:r.quantity,goods_minor:r.is_gift||value('nature')==='inquiry'?0:Math.round(Number(r.amount)*100),
      sku_version:skus.find(s=>s.id===r.sku_id)?.version,choices:previous(r)?{}:r.choices}));
  }
  function details(order){return order.line_items.map(l=>`<h3 class="section-title">${safe(l.sku_name)}${l.is_gift?' · 赠品':''} × ${l.quantity} · ${safe(order.currency)} ${fmt(l.goods_minor)}</h3>${window.DwellSkuForms.details(l.items_snapshot,l.quantity)}`).join('');}
  document.addEventListener('click',e=>{
    if(dialogKind!=='cloud-order'||!active||$('#save-button').disabled)return;
    const add=e.target.closest('[data-cart-add]'),remove=e.target.closest('[data-cart-remove]');if(!add&&!remove)return;
    if(field('phone').disabled)return;
    read();if(add&&rows.length<30)rows.push(blank());
    if(remove&&rows.length>1)rows=rows.filter(r=>r.key!==remove.closest('[data-cart-row]').dataset.cartRow);
    render();onChange();
  });
  return {mount,change,input,payload,details,isActive:()=>active};
})();
