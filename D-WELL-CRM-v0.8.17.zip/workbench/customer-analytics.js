"use strict";
window.DwellCRM=(()=>{
  const M=window.DwellCustomerMetrics,h=escapeHtml;
  const today=()=>window.DwellTasks?.today()||TODAY;
  const config=()=>state.crmView||(state.crmView={page:'all',sku:'all',channel:'all',period:'all',start:'',end:'',group:'all',sort:'amount',direction:'desc',query:'',drill:null,offset:0});
  const groupName=id=>M.groups.find(g=>g[0]===id)?.[1]||id;
  const badge=id=>`<span class="pill crm-group crm-${id}">${h(groupName(id))}</span>`;
  const percent=(n,d)=>d?`${(100*n/d).toFixed(1)}%`:'—';
  const select=(id,label,options,current)=>`<label class="field"><span>${label}</span><select id="${id}" aria-label="${label}">${options.map(([key,name])=>`<option value="${h(key)}" ${key===current?'selected':''}>${h(name)}</option>`).join('')}</select></label>`;
  const sortOptions=[['amount','有效消费金额'],['count','购买次数'],['average','平均每单金额'],['days','距最近购买天数'],['referrals','成功推荐人数']];
  function scope(){
    const c=config(),f={page:c.page,sku:c.sku,channel:c.channel,group:c.group};
    if(c.period==='custom'){f.start=c.start;f.end=c.end;}
    else if(c.period!=='all'){const date=new Date(today()+'T00:00:00Z');date.setUTCDate(date.getUTCDate()-Number(c.period)+1);f.start=date.toISOString().slice(0,10);}
    return f;
  }
  const report=()=>M.report(state,scope(),today());
  function definition(){return `<details class="crm-method"><summary>统计口径与分群规则</summary><p>演示订单按客户 ID 去重。仅计当前状态为正式有效的订单，排除潜在咨询、取消及 COD 拒收。有效 GMV 含运费，已扣优惠与折扣；SGD 固定 ×3 折合 MYR。独立退款资料尚未接入，此金额不代表实收或利润。</p><p>筛选期间决定金额、次数和参与客户；RFM 分群与距最近购买天数使用同一主页 / 产品 / 平台下、截至今天的全部有效历史。不是历史时点快照。跨主页、平台或产品的客户人数不可直接相加。HR 仍按取消／拒收确认月份扣减。</p><p>分群为互斥的试用规则：无有效购买 → 沉睡 → 需关注 → 忠实高价值 → 新成交 → 其余活跃客户；尚未用真实复购周期校准。顾客姓名、电话和地址不用于推断年龄、性别或健康状况。</p></details>`;}
  function reason(row,rules){
    const m=row.lifetime;
    if(!m.count)return '尚无有效购买记录';
    return `距上次 ${m.days} 天 · ${m.count} 次 · RM ${fmt(m.amount)}（全部历史）`;
  }
  function rowsTable(rows,{list=false,offset=0}={}){
    const slice=rows.slice(offset,offset+25);
    return `<div class="table-scroll"><table class="crm-table"><thead><tr><th>排名 / 客户</th><th>客户分类</th><th>有效消费 · MYR</th><th>购买次数</th><th>平均每单 · MYR</th><th>最近有效购买</th><th>成功推荐</th>${list?'<th>平台 / 电话</th><th></th>':''}</tr></thead><tbody>${slice.map((r,i)=>`<tr data-customer-id="${h(r.customer.id)}"><td><button class="customer-name" data-action="customer" data-id="${h(r.customer.id)}"><span class="crm-rank">${offset+i+1}</span><strong>${h(r.customer.name)}</strong></button><small>${h(r.customer.id)}</small></td><td>${badge(r.group)}<small>${h(reason(r))}</small></td><td class="money">RM ${fmt(r.amount)}</td><td>${r.count}</td><td class="money">${r.count?'RM '+fmt(r.average):'—'}</td><td>${r.lifetime.last?dateLabel(r.lifetime.last):'—'}<small>${r.lifetime.days===null?'未有效购买':`距今 ${r.lifetime.days} 天`}</small></td><td>${r.referrals}</td>${list?`<td>${platformTags(r.customer)}<small>${r.customer.phones.map(h).join('<br>')||'—'}</small></td><td><button class="icon-button" data-action="edit-customer" data-id="${h(r.customer.id)}" title="编辑客户" aria-label="编辑 ${h(r.customer.name)}">${icon('square-pen')}</button></td>`:''}</tr>`).join('')}</tbody></table>${rows.length?'':'<div class="empty">没有符合条件的客户</div>'}</div><div class="table-foot"><span>${rows.length?offset+1:0}–${Math.min(offset+25,rows.length)} / ${rows.length} 位客户</span><div class="row-actions"><button class="icon-button" data-crm-page="-1" data-list="${list}" aria-label="上一页" title="上一页" ${offset?'':'disabled'}>${icon('chevron-left')}</button><button class="icon-button" data-crm-page="1" data-list="${list}" aria-label="下一页" title="下一页" ${offset+25<rows.length?'':'disabled'}>${icon('chevron-right')}</button></div></div>`;
  }
  function chart(key,title,items,denominator,note){
    return `<section class="crm-chart" data-chart="${key}"><h2>${title}</h2><p class="crm-caption">${note} · ${denominator} 人</p><div class="crm-bars">${items.map((item,i)=>`<button class="crm-bar-row" data-crm-drill="${key}" data-bucket="${h(item.id)}" title="${h(item.label)}：${item.count} 人，${percent(item.count,denominator)}" aria-label="${h(title+'：'+item.label)}" ${item.count?'':'disabled'}><span class="crm-bar-label">${h(item.label)}</span><span class="crm-bar-track"><span class="crm-bar-fill tone-${i%5}" style="width:${denominator?item.count/denominator*100:0}%"></span></span><span class="crm-bar-value">${item.count} 人 <strong>${percent(item.count,denominator)}</strong></span></button>`).join('')}</div>${denominator?'':'<p class="crm-caption">当前范围无可分析资料</p>'}</section>`;
  }
  function rankRows(r){
    const c=config();let rows=r.rows;
    if(c.drill){const b=r[c.drill.key]?.find(item=>item.id===c.drill.id);rows=rows.filter(row=>b?.ids.includes(row.customer.id));}
    const q=c.query.trim().toLowerCase();if(q)rows=rows.filter(r=>[r.customer.name,r.customer.id,...r.customer.phones].some(x=>x.toLowerCase().includes(q)));
    return M.sorted(rows,c.sort,c.direction);
  }
  function renderRanking(r){
    const c=config(),rows=rankRows(r);c.offset=Math.min(c.offset,Math.max(0,Math.floor((rows.length-1)/25)*25));
    $('#crm-ranking-content').innerHTML=rowsTable(rows,{offset:c.offset});
    const b=c.drill?r[c.drill.key]?.find(x=>x.id===c.drill.id):null;
    $('#crm-drill-label').innerHTML=b?`<span>${h(b.label)} · ${b.count} 人</span><button class="icon-button" data-crm-clear title="清除图表筛选" aria-label="清除图表筛选">${icon('x')}</button>`:'';
    icons();
  }
  function render(){
    const c=config();let r;try{r=report();}catch(error){toast(error.message);return;}
    const pageChoices=[['all','全部主页'],...state.pages.map(p=>[p.id,p.name+(p.active===false?'（已停用）':'')]),['unassigned','未分配主页']];
    const channels=[...new Set(state.orders.map(o=>o.channel).filter(Boolean))];
    $('#main').innerHTML=heading('客户分析','演示资料 · '+dateLabel(today())+' · Asia/Kuala_Lumpur',`<button class="secondary" data-crm-rules>${icon('settings-2')}分群规则</button>`)+
      `<section class="crm-filters">${select('crm-period','统计期间',[['all','全部历史'],['90','最近 90 天'],['365','最近 365 天'],['custom','自选期间']],c.period)}${select('crm-homepage','主页',pageChoices,c.page)}${select('crm-sku','产品 / SKU',[['all','全部产品 / SKU'],...state.skus.map(s=>[s.id,s.name])],c.sku)}${select('crm-channel','本单下单平台',[['all','全部平台'],...channels.map(x=>[x,x])],c.channel)}${select('crm-group','客户分类',[['all','全部客户分类'],...M.groups],c.group)}${c.period==='custom'?`<label class="field"><span>开始日期</span><input type="date" id="crm-start" value="${h(c.start)}" max="${today()}" aria-label="分析开始日期"></label><label class="field"><span>结束日期</span><input type="date" id="crm-end" value="${h(c.end)}" max="${today()}" aria-label="分析结束日期"></label>`:''}</section>`+
      `<p class="crm-scope">${r.start?dateLabel(r.start):'全部历史'} 至 ${dateLabel(r.end)} · ${h(pageName(c.page))} · RFM 使用截至今天的同范围历史</p>`+
      `<div class="stats crm-stats">${stat('范围内客户',r.rows.length,'按客户 ID 去重','users')}${stat('期间有效买家',r.buyers.length,`${r.count} 笔有效购买`,'shopping-bag','blue')}${stat('期间有效 GMV',`RM ${fmt(r.amount)}`,'排除取消 / 拒收；退款未接入','wallet')}${stat('前 10% 买家销售贡献',r.topShare===null?'—':percent(r.topShare,1),`前 ${r.topCount} 位买家 · 人数向上取整`,'chart-no-axes-combined','blue')}</div>`+
      (r.unlinked?`<div class="alert-note">${r.unlinked} 笔订单尚未关联有效客户，不纳入客户统计。</div>`:'')+
      `<div class="crm-chart-grid">${chart('segments','客户类型占比',r.segments,r.rows.length,'分母：范围内全部客户')}${chart('spend','消费金额分布',r.spend,r.buyers.length,'分母：期间有效买家')}${chart('frequency','购买次数分布',r.frequency,r.buyers.length,'分母：期间有效买家')}${chart('recency','距离最近购买',r.recency,r.rows.filter(row=>row.lifetime.count).length,'分母：范围内历史有效买家')}</div>`+
      chart('products','购买产品分布',r.products,r.buyers.length,`分母：期间有效买家；一人可买多种产品，比例可重叠。跨产品买家 ${r.multiProduct} 人（${percent(r.multiProduct,r.buyers.length)}）`)+
      `<section class="crm-ranking"><div class="section-title"><h2>客户排行榜</h2><button class="secondary" data-crm-export>${icon('download')}导出名单</button></div><p class="crm-caption">金额、次数及推荐按筛选期间；分类与最近购买按同范围全部历史</p><div class="crm-rank-controls"><label class="search-field">${icon('search')}<input id="crm-search" aria-label="搜索排行榜客户" placeholder="姓名、电话或客户 ID" value="${h(c.query)}"></label>${select('crm-sort','排序指标',sortOptions,c.sort)}${select('crm-direction','排列顺序',[['desc','从高到低'],['asc','从低到高']],c.direction)}</div><div id="crm-drill-label" class="crm-drill" aria-live="polite"></div><div id="crm-ranking-content"></div></section>`+definition();
    renderRanking(r);
  }
  function renderCustomers(){
    const c=state.crmList||(state.crmList={sort:'amount',direction:'desc',group:'all',offset:0});
    const r=M.report(state,{group:c.group},today()),q=state.search.trim().toLowerCase();
    const rows=M.sorted(r.rows.filter(r=>[r.customer.name,r.customer.id,...r.customer.phones].some(x=>x.toLowerCase().includes(q))),c.sort,c.direction);
    c.offset=Math.min(c.offset,Math.max(0,Math.floor((rows.length-1)/25)*25));
    $('#main').innerHTML=heading('客户资料',`${state.customers.length} 位模拟客户 · 全部历史有效消费`,`<button class="primary" data-action="new-customer">${icon('user-plus')}新增客户</button>`)+`<section class="data-surface"><div class="crm-rank-controls"><label class="search-field">${icon('search')}<input id="customer-search" aria-label="搜索客户" placeholder="搜索姓名、电话或客户 ID" value="${h(state.search)}"></label>${select('crm-list-group','客户分类',[['all','全部客户分类'],...M.groups],c.group)}${select('crm-list-sort','客户排序',sortOptions,c.sort)}${select('crm-list-direction','排列顺序',[['desc','从高到低'],['asc','从低到高']],c.direction)}</div>${rowsTable(rows,{list:true,offset:c.offset})}</section>`+definition();
  }
  function customerSummary(id){
    const r=M.report(state,{},today()),row=r.rows.find(r=>r.customer.id===id);if(!row)return '';
    const orders=state.orders.filter(o=>o.customerId===id),rewards=(state.promotions?.rewards||[]).filter(r=>r.customerId===id);
    const available=rewards.filter(r=>r.status==='available'&&(!r.expires||r.expires>=today())&&(!r.validFrom||r.validFrom<=today()));
    const skuCounts=new Map();for(const o of row.orders){const item=skuCounts.get(o.skuId)||{name:o.skuName,count:0,quantity:0};item.count++;item.quantity+=o.units*o.quantity;skuCounts.set(o.skuId,item);}
    const favorites=[...skuCounts.values()].sort((a,b)=>b.count-a.count).slice(0,3);
    return `<section class="crm-customer-summary"><div class="section-title">${badge(row.group)}<small>试用 RFM 规则 · 全部历史</small></div><p class="crm-caption">${h(reason(row))}</p><dl class="crm-summary-grid"><div><dt>累计有效消费</dt><dd>RM ${fmt(row.amount)}</dd></div><div><dt>有效购买次数</dt><dd>${row.count} 次</dd></div><div><dt>平均每单</dt><dd>${row.count?'RM '+fmt(row.average):'—'}</dd></div><div><dt>首次有效购买</dt><dd>${row.first?dateLabel(row.first):'—'}</dd></div><div><dt>最近有效购买</dt><dd>${row.last?dateLabel(row.last):'—'}</dd></div><div><dt>距最近购买</dt><dd>${row.days===null?'—':row.days+' 天'}</dd></div><div><dt>可用券 / 待寄出礼品</dt><dd>${available.filter(r=>r.type==='voucher').length} 张 / ${available.filter(r=>r.type==='product').length} 份</dd></div><div><dt>成功推荐人数</dt><dd>${row.referrals} 人</dd></div><div><dt>取消 / COD 拒收</dt><dd>${orders.filter(o=>o.status==='cancelled').length} / ${orders.filter(o=>o.status==='rejected').length} 笔</dd></div></dl><p class="crm-caption">含运费及折扣，SGD ×3；不含取消 / 拒收，退款资料未接入。</p><div class="crm-favorites"><strong>常买配套</strong>${favorites.length?favorites.map(s=>`<span>${h(s.name)} · ${s.count} 次 · 累计 ${s.quantity} 件</span>`).join(''):'<span>暂无有效购买</span>'}</div></section>`;
  }
  function rulesDialog(){
    if(!window.DwellPayments?.isViewAllowed('analytics'))return;
    const r={...M.defaults,...state.crmRules};
    showDialog('crm-rules','','客户分群试用规则',`<div class="form-grid">${inputField('新客最近购买天数','newDays',r.newDays,'number',true,'min="1" max="3650" step="1"')}${inputField('活跃期天数','activeDays',r.activeDays,'number',true,'min="1" max="3650" step="1"')}${inputField('沉睡期超过天数','dormantDays',r.dormantDays,'number',true,'min="1" max="3650" step="1"')}${inputField('忠实客户最少购买次数','loyalCount',r.loyalCount,'number',true,'min="2" max="10000" step="1"')}${inputField('忠实客户最低消费 MYR','loyalAmount',(r.loyalAmount/100).toFixed(2),'number',true,'min="0.01" max="100000000" step="0.01"')}</div><div class="notice">新客天数 ≤ 活跃期天数 ＜ 沉睡期天数。需关注客户超过活跃期，但未超过沉睡期；忠实客户须在活跃期内，同时达到次数及金额门槛。仅作用于演示客户分类，不改变订单或 HR。</div>`,'试用阈值 · 尚未根据真实历史数据校准');
  }
  document.addEventListener('change',event=>{
    const bindings={'crm-homepage':'page','crm-sku':'sku','crm-channel':'channel','crm-group':'group','crm-period':'period','crm-start':'start','crm-end':'end','crm-sort':'sort','crm-direction':'direction'};
    const key=bindings[event.target.id];
    if(key&&state.view==='analytics'){
      const c=config(),old={...c};c[key]=event.target.value;c.offset=0;
      if(key==='period'&&c.period==='custom'){c.start=today().slice(0,7)+'-01';c.end=today();}
      if(!['sort','direction'].includes(key))c.drill=null;
      try{report();render();icons();}catch(error){state.crmView=old;event.target.value=old[key];toast(error.message);}
    }
    const listKey={'crm-list-sort':'sort','crm-list-direction':'direction','crm-list-group':'group'}[event.target.id];
    if(listKey){state.crmList[listKey]=event.target.value;state.crmList.offset=0;renderCustomers();icons();}
  });
  document.addEventListener('input',event=>{if(event.target.id==='crm-search'){config().query=event.target.value;config().offset=0;renderRanking(report());}});
  document.addEventListener('click',event=>{
    const drill=event.target.closest('[data-crm-drill]');
    if(drill){config().drill={key:drill.dataset.crmDrill,id:drill.dataset.bucket};config().offset=0;renderRanking(report());$('.crm-ranking').scrollIntoView({block:'start'});}
    if(event.target.closest('[data-crm-clear]')){config().drill=null;config().offset=0;renderRanking(report());}
    const pager=event.target.closest('[data-crm-page]');if(pager){const c=pager.dataset.list==='true'?state.crmList:config();c.offset=Math.max(0,c.offset+Number(pager.dataset.crmPage)*25);pager.dataset.list==='true'?renderCustomers():renderRanking(report());icons();}
    if(event.target.closest('[data-crm-rules]'))rulesDialog();
    if(event.target.closest('[data-crm-export]')){
      if(!window.DwellPayments?.isViewAllowed('analytics'))return;
      const c=config(),r=report(),rows=rankRows(r);
      const safe=text=>{const value=String(text??'');return '"'+(/^[=+@\-\t\r]/.test(value)?"'":'')+value.replace(/"/g,'""')+'"';};
      const data=[['客户 ID','姓名','类型','有效消费 MYR','购买次数','平均每单 MYR','最近购买','距最近购买天数','成功推荐人数','主页','期间开始','期间结束','分群截至'],...rows.map(x=>[x.customer.id,x.customer.name,groupName(x.group),(x.amount/100).toFixed(2),x.count,x.count?(x.average/100).toFixed(2):'',x.lifetime.last||'',x.lifetime.days??'',x.referrals,pageName(c.page),r.start||'全部历史',r.end,today()])];
      const url=URL.createObjectURL(new Blob(['\uFEFF'+data.map(row=>row.map(safe).join(',')).join('\r\n')],{type:'text/csv;charset=utf-8'}));const link=document.createElement('a');link.href=url;link.download=`DEMO-customers-${today()}.csv`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }
  });
  form.addEventListener('submit',event=>{
    if(dialogKind!=='crm-rules')return;event.preventDefault();
    try{
      if(!window.DwellPayments?.isViewAllowed('analytics'))throw new Error('没有修改分群规则的权限');
      const r=Object.fromEntries(['newDays','activeDays','dormantDays','loyalCount'].map(k=>[k,Number(value(k))]));r.loyalAmount=moneyInput('loyalAmount');
      if(!Object.values(r).every(Number.isFinite)||!['newDays','activeDays','dormantDays','loyalCount'].every(k=>Number.isInteger(r[k])&&r[k]>0)||r.newDays>r.activeDays||r.activeDays>=r.dormantDays||r.dormantDays>3650||r.loyalCount<2||r.loyalCount>10000||r.loyalAmount<=0)throw new Error('请核对天数顺序、次数及金额');
      state.crmRules=r;dialog.close();render();icons();toast('演示分群规则已更新');
    }catch(error){$('#form-error').textContent=error.message;}
  });
  return {render,renderCustomers,customerSummary,report,rankRows};
})();
