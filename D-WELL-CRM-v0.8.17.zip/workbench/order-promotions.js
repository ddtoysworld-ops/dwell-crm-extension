"use strict";
window.DwellOrderPromotions=(()=>{
  let editing=null,coupons=[],legacyCoupons=[],legacyPhysical=[],serial=0,ready=false,loading=false,onChange=()=>{};
  const normalize=v=>String(v||'').replace(/[+ ()-]/g,'').trim();
  const rpc=phone=>window.DwellPayments.operationsRpc('coupons',{phone});
  const label=c=>`${c.name} · ${c.currency} ${c.amount_minor==null?'待核对':fmt(c.amount_minor)} · ${c.minimum_minor==null?'门槛待核对':c.minimum_minor?'满 '+fmt(c.minimum_minor):'无最低消费'} · ${c.expires_on?'至 '+c.expires_on:'无到期日'}`;
  const legacyStatus=c=>({AVAILABLE:'快照未使用',USED:'已使用',EXPIRED:'已过期',VOID:'已作废',REVIEW:'待核对',NOT_STARTED:'未到使用日期'}[c.status]||'待核对');
  const legacyLabel=c=>`${c.source==='lucky'?'抽奖券':'CRM 券'} · ${label(c)} · ${legacyStatus(c)} · 旧系统只读`;
  function markup(r){
    const p=r?.promotions,g=p?.gift_coupon;
    return `<section id="cloud-promotions"><h3 class="section-title">好友推荐与优惠券</h3><div class="form-grid">
      ${selectField('好友推荐订单','referral_enabled',[['no','否'],['yes','是']],p?.referral_phone?'yes':'no')}
      ${inputField('推荐人电话号码（含国家码）','referral_phone',p?.referral_phone||'','text',false,'maxlength="30"')}
      <label class="field full"><span>使用客户现有优惠券</span><select name="redeem_coupon"><option value="">不使用优惠券</option></select></label>
      <div class="field full"><span id="cloud-coupon-status" role="status">请先填写客户电话号码</span><button type="button" class="icon-button" data-action="cloud-coupons" title="重新查询优惠券" aria-label="重新查询优惠券">${icon('refresh-cw')}</button><small>每单最多一张。旧券快照只读，不代表旧系统此刻的可用状态。推荐奖励需在「好友推荐」核对首购资格后确认。</small></div>
      <div id="cloud-legacy-coupon-status" class="field full" role="status" hidden></div>
      <div id="cloud-legacy-physical" class="field full" hidden></div>
      ${g?`<div class="field full"><strong>本单已附送优惠券</strong><span>${escapeHtml(label(g))}</span><small>${g.revoked_at?'已撤回':g.redeemed_order_id?'已使用':'已发放，不能重复赠送'}</small></div>`:(window.DwellPayments?.canCoreAction?.('orders','grant_coupon')??true)?selectField('本单附送优惠券','gift_enabled',[['no','否'],['yes','是']],'no'):''}
    </div>${g?'':`<div id="cloud-gift-fields" class="form-grid">
      ${inputField('赠券名称','gift_name','','text',false,'maxlength="100"')}
      ${inputField('赠券面额（本单币种）','gift_amount','','number',false,'min="0.01" max="100000000" step="0.01"')}
      ${inputField('最低消费（含运费，其他折扣后）','gift_minimum','0','number',false,'min="0" max="100000000" step="0.01"')}
      ${inputField('有效期至（留空为长期有效）','gift_expiry','','date',false)}
      <p class="field full">随正式订单发给本单客户，限本单主页及币种，下次消费使用。</p>
    </div>`}</section>`;
  }
  function mount(r,callback){
    serial++;editing=r;coupons=[];legacyCoupons=[];legacyPhysical=[];ready=false;loading=false;onChange=callback;
    $('#dialog-body').insertAdjacentHTML('beforeend',markup(r));
    field('coupon_minor').readOnly=true;
    field('coupon_minor').closest('label').querySelector('span').textContent=r?.coupon_minor&&!r.promotions?.coupon_id?'原记录优惠券折扣（保留）':'已选优惠券抵扣';
    refresh();icons();void load();
  }
  function clearPhone(){
    serial++;ready=false;loading=false;coupons=[];legacyCoupons=[];legacyPhysical=[];
    field('redeem_coupon').innerHTML='<option value="">不使用优惠券</option>';
    field('coupon_minor').value='0';
    $('#cloud-coupon-status').textContent='正在核对客户优惠券…';refresh();
  }
  function reason(c){
    if(c.source_order_id===editing?.id)return '本单附送，后续订单使用';
    if(editing?.promotions?.coupon&&normalize(value('phone'))!==normalize(editing.phone))return '原核销客户已变更';
    if(value('nature')!=='formal')return '潜在咨询暂不能核销';
    if(c.currency!==value('currency'))return '币种不同';
    if(c.page_id!==value('page_id'))return '不适用此主页';
    try{const total=moneyInput('goods_minor')+moneyInput('shipping_minor')-moneyInput('discount_minor');
      if(total<c.minimum_minor||total<c.amount_minor)return '未达到使用金额';
    }catch{return '请先填写订单金额';}
    return '';
  }
  function refresh(){
    if(!$('#cloud-promotions'))return;
    const inquiry=value('nature')==='inquiry',ref=value('referral_enabled')==='yes';
    field('referral_phone').closest('label').hidden=!ref;field('referral_phone').required=ref;field('referral_phone').disabled=!ref;
    const selection=field('redeem_coupon'),previous=selection.value,locked=editing?.promotions?.coupon;
    const items=locked?[locked]:coupons;
    selection.innerHTML='<option value="">不使用优惠券</option>'+items.map(c=>`<option value="${c.id}" ${reason(c)?'disabled':''}>${escapeHtml(label(c)+(reason(c)?' · '+reason(c):''))}</option>`).join('');
    if(legacyCoupons.length)selection.innerHTML+='<optgroup label="旧系统优惠券快照 · 只读">'+legacyCoupons.map(c=>`<option value="${escapeHtml(c.id)}" disabled>${escapeHtml(legacyLabel(c))}</option>`).join('')+'</optgroup>';
    const legacyStatusBox=$('#cloud-legacy-coupon-status');
    legacyStatusBox.hidden=!legacyCoupons.length;
    legacyStatusBox.textContent=legacyCoupons.length?`旧券 ${legacyCoupons.length} 张 · 快照日期 ${legacyCoupons.map(c=>String(c.captured_at).slice(0,10)).sort()[0]} · 尚未开放新后台核销`:'';
    const physicalBox=$('#cloud-legacy-physical');
    physicalBox.hidden=!ready||loading;
    physicalBox.innerHTML=ready&&!loading?physicalMarkup(legacyPhysical):'';
    const selected=items.find(c=>c.id===(locked?.id||previous));
    selection.value=selected&&!reason(selected)?selected.id:'';
    selection.disabled=!ready||loading||inquiry||!!locked;
    if(selected&&!reason(selected))field('coupon_minor').value=String(selected.amount_minor/100);
    else if(!editing?.coupon_minor||editing?.promotions?.coupon_id||normalize(value('phone'))!==normalize(editing?.phone))field('coupon_minor').value='0';
    const gift=field('gift_enabled');
    if(gift){
      gift.disabled=inquiry||!ready;
      const show=gift.value==='yes'&&!inquiry;
      $('#cloud-gift-fields').hidden=!show;
      for(const n of ['gift_name','gift_amount','gift_minimum','gift_expiry']){field(n).required=show&&n!=='gift_expiry';field(n).disabled=!show;}
    }
  }
  async function load(){
    const request=++serial,ph=value('phone');loading=true;ready=false;legacyCoupons=[];legacyPhysical=[];refresh();
    if(!ph){loading=false;coupons=[];$('#cloud-coupon-status').textContent='请先填写客户电话号码';refresh();return;}
    try{
      const data=await rpc(ph);
      if(request!==serial||!dialog.open||dialogKind!=='cloud-order')return;
      ready=true;coupons=data.items||[];legacyCoupons=data.legacy_coupons||[];legacyPhysical=data.legacy_physical_rewards||[];
      $('#cloud-coupon-status').textContent=editing?.promotions?.coupon?'本单已核销，保留原券记录':data.customer_id?(coupons.length?`找到 ${coupons.length} 张未使用且未过期的券`:'此客户在 Supabase 暂无可用券'):'尚未关联 Supabase 客户，旧记录按此号码查询';
      if(field('gift_expiry'))field('gift_expiry').min=data.today;
    }catch(e){
      if(request!==serial||!$('#cloud-coupon-status'))return;
      ready=false;coupons=[];legacyCoupons=[];legacyPhysical=[];$('#cloud-coupon-status').textContent='优惠券与旧奖品查询未成功，暂不能发券或选券；请重试。';
    }finally{if(request===serial&&dialog.open&&dialogKind==='cloud-order'){loading=false;refresh();onChange();}}
  }
  function payload(){
    const out={referral_phone:value('referral_enabled')==='yes'?value('referral_phone'):''};
    if(loading)throw new Error('coupon_loading');
    const locked=editing?.promotions?.coupon;
    if(locked&&(normalize(value('phone'))!==normalize(editing.phone)||reason(locked)))throw new Error('coupon_redemption_locked');
    out.coupon_id=locked?.id||value('redeem_coupon');
    if(out.coupon_id.startsWith('legacy:'))throw new Error('coupon_legacy_readonly');
    if(value('gift_enabled')==='yes'&&value('nature')==='formal'){
      if(!ready)throw new Error('coupon_loading');
      out.gift_coupon={name:value('gift_name'),amount_minor:moneyInput('gift_amount'),minimum_minor:moneyInput('gift_minimum'),expires_on:value('gift_expiry')||null};
    }
    return out;
  }
  function error(e){
    if(String(e?.message||e).includes('coupon_legacy_readonly'))return '旧系统优惠券目前只读，尚未开放在新后台核销。';
    const messages={coupon_loading:'优惠券资料尚未核对完成，请稍后重试。',referral_phone_invalid:'请核对推荐人电话号码及国家码。',referral_self:'顾客不能推荐自己，包括同一顾客的其他号码。',coupon_selection_required:'请选一张客户现有优惠券；额外人工优惠请填其他折扣。',coupon_not_eligible:'此券不属于该客户，或不适用于本单主页、币种。',coupon_already_used:'这张券已被使用，请重新打开订单核对。',coupon_expired:'这张券已过期，请重新选择。',coupon_minimum:'订单未达到该券的使用金额。',coupon_redemption_locked:'本单已核销优惠券，不能更换客户、券或不符合券条件的金额。',coupon_gift_locked:'本单已发券，不能重复发券或更换客户、主页及币种。',coupon_gift_invalid:'请核对赠券名称、面额、门槛及有效期。',coupon_gift_already_used:'本单附送的券已被使用，需先人工核对关联订单，暂不能直接取消。'};
    return Object.entries(messages).find(([code])=>String(e?.message||e).includes(code))?.[1];
  }
  function customerMarkup(items,legacy=[]){
    return `<h3 class="section-title">客户优惠券 · Supabase</h3>${items?.length?`<ul class="audit-list">${items.map(c=>`<li><strong>${escapeHtml(label(c))}</strong><small>${c.revoked_at?'已撤回':c.redeemed_order_id?'已使用':c.expires_on&&c.expires_on<new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur'}).format(new Date())?'已过期':'未使用'}</small></li>`).join('')}</ul>`:'<p>暂无新后台优惠券。</p>'}${legacy.length?`<h3 class="section-title">旧 CRM 与抽奖券 · 只读快照</h3><p>以旧系统最新状态为准，尚未开放新后台核销。</p><ul class="audit-list">${legacy.map(c=>`<li><strong>${escapeHtml(legacyLabel(c))}</strong><small>快照日期 ${escapeHtml(String(c.captured_at).slice(0,10))}${c.valid_from?' · 可用起始 '+escapeHtml(c.valid_from):''}${c.used_on?' · 使用日期 '+escapeHtml(c.used_on):''}</small></li>`).join('')}</ul>`:'<p>未载入该客户的旧系统券快照；不代表旧系统没有券。</p>'}`;
  }
  function physicalMarkup(items=[]){
    const date=v=>v?new Intl.DateTimeFormat('en-GB',{timeZone:'Asia/Kuala_Lumpur'}).format(new Date(v)):'未记录';
    const groups=[['unshipped','未寄出'],['shipped','已寄出'],['review','待核对'],['void','已作废']];
    return `<section class="legacy-physical-history"><h3 class="section-title">旧系统实物奖品 · 只读快照</h3><p class="profile-note">不自动加入本单或安排寄出，以旧系统最新记录为准。</p>${items.length?groups.map(([status,title])=>{
      const rows=items.filter(r=>(['unshipped','shipped','void'].includes(r.status)?r.status:'review')===status);
      return rows.length?`<h4>${title} · ${rows.length} 笔</h4><ul class="audit-list">${rows.map(r=>`<li><strong>${escapeHtml(r.name)} × ${escapeHtml(r.quantity)} <span class="pill ${status==='shipped'?'success':status==='unshipped'?'warning':'neutral'}">${title}</span></strong><small>${r.source==='referral'?'好友推荐':'幸运抽奖'} · ${escapeHtml(r.phone)} · 原状态 ${escapeHtml(r.source_status)}</small><small>来源订单 ${escapeHtml(r.order_ref||'待核对')}${r.source_order_refs?.length>1?' · 候选 '+r.source_order_refs.map(escapeHtml).join(' / '):''}</small>${r.review_reasons?.length?'<small>记录含待核对资料；不会据此更改寄送状态。</small>':''}${status==='shipped'?`<small>寄出日期 ${date(r.shipped_at)}</small>`:''}${r.tracking_number?`<small>运单 ${escapeHtml(r.tracking_number)}</small>`:''}<small>快照日期 ${date(r.captured_at)}</small></li>`).join('')}</ul>`:'';
    }).join(''):'<p class="profile-empty">此号码或已关联号码暂无旧实物快照，不代表旧系统没有记录。</p>'}</section>`;
  }
  return {mount,clearPhone,load,refresh,payload,error,customerMarkup,physicalMarkup};
})();
