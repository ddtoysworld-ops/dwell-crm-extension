"use strict";
function choiceKey(text){return String(text??'').normalize('NFKC').trim().replace(/\s+/g,' ').toLocaleLowerCase();}
function choiceField(label,name,current,source,required=false,extra=''){
  return `<label class="field ${extra.includes('data-full')?'full':''}"><span>${escapeHtml(label)}${required?' *':''}</span><div class="choice-control"><input name="${name}" value="${escapeHtml(current)}" data-choice="${source}" role="combobox" aria-label="${escapeHtml(label)}" aria-autocomplete="list" aria-haspopup="listbox" aria-expanded="false" autocomplete="off" ${required?'required':''} ${extra}><button type="button" class="choice-toggle" aria-label="显示已有${escapeHtml(label)}" title="显示已有${escapeHtml(label)}" tabindex="-1">${icon('chevron-down')}</button></div></label>`;
}
window.DwellChoices=(()=>{
  let active=null,popup=null,items=[],index=-1,sequence=0;
  function options(source){
    const product=state.lines.find(p=>choiceKey(p.name)===choiceKey(value('productName')));
    const rewards=[...(state.promotions?.prizes||[]),...(state.promotions?.rewards||[])];
    const sources={products:()=>state.lines.map(p=>p.name),packages:()=>state.skus.filter(s=>product&&s.line===product.id).map(s=>s.name),rewards:()=>rewards.filter(r=>r.type===(value('type')||'voucher')).map(r=>r.name),vouchers:()=>rewards.filter(r=>r.type==='voucher').map(r=>r.name),paymentLabels:()=>window.DwellPayments?.labelOptions()||[]};
    const seen=new Set();return (sources[source]?.()||[]).filter(text=>{const key=choiceKey(text);if(!key||seen.has(key))return false;seen.add(key);return true;});
  }
  function close(){
    if(active){active.setAttribute('aria-expanded','false');active.removeAttribute('aria-controls');active.removeAttribute('aria-activedescendant');}
    popup?.remove();active=null;popup=null;items=[];index=-1;
  }
  function position(){
    if(!active?.isConnected||!dialog.open){close();return;}
    const rect=active.closest('.choice-control').getBoundingClientRect(),bounds=dialog.getBoundingClientRect();
    const left=Math.max(8,Math.min(rect.left,innerWidth-rect.width-8));
    const below=Math.max(0,Math.min(innerHeight-8,bounds.bottom-8)-rect.bottom-4);
    const above=Math.max(0,rect.top-Math.max(8,bounds.top+8)-4);
    const up=below<160&&above>below,maxHeight=Math.max(60,Math.min(240,up?above:below));
    Object.assign(popup.style,{left:`${left}px`,width:`${Math.min(rect.width,innerWidth-16)}px`,maxHeight:`${maxHeight}px`,top:up?'auto':`${rect.bottom+4}px`,bottom:up?`${innerHeight-rect.top+4}px`:'auto'});
  }
  function highlight(next){
    if(!items.length)return;index=(next+items.length)%items.length;
    [...popup.querySelectorAll('[role=option]')].forEach((el,i)=>el.setAttribute('aria-selected',String(i===index)));
    const el=popup.querySelectorAll('[role=option]')[index];active.setAttribute('aria-activedescendant',el.id);el.scrollIntoView({block:'nearest'});
  }
  function open(input,all=false){
    if(input.disabled||input.readOnly)return;
    close();active=input;const choices=options(input.dataset.choice),query=choiceKey(input.value);
    items=(all?choices:choices.filter(text=>choiceKey(text).includes(query))).map(text=>({text,isNew:false}));
    if(query&&!choices.some(text=>choiceKey(text)===query))items.push({text:input.value.trim().replace(/\s+/g,' '),isNew:true});
    popup=document.createElement('div');popup.className='choice-popup';popup.id=`choice-options-${++sequence}`;popup.setAttribute('role','listbox');popup.setAttribute('aria-label',input.getAttribute('aria-label'));
    items.forEach((item,i)=>{const el=document.createElement('div');el.id=`${popup.id}-${i}`;el.dataset.choiceIndex=String(i);el.setAttribute('role','option');el.setAttribute('aria-selected','false');el.textContent=item.isNew?`新增：${item.text}`:item.text;popup.append(el);});
    if(!items.length){const empty=document.createElement('div');empty.className='choice-empty';empty.textContent='暂无已有选项';popup.append(empty);}
    dialog.append(popup);input.setAttribute('aria-controls',popup.id);input.setAttribute('aria-expanded','true');position();
  }
  function choose(i){
    if(!items[i]||!active)return;const input=active;input.value=items[i].text;
    close();input.focus();input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));close();
  }
  document.addEventListener('focusin',event=>{
    if(event.target.matches('input[data-choice]'))open(event.target,true);
    else if(active&&!popup?.contains(event.target))close();
  });
  document.addEventListener('input',event=>{if(event.target.matches('input[data-choice]')&&!event.isComposing)open(event.target);});
  document.addEventListener('compositionend',event=>{if(event.target.matches('input[data-choice]'))open(event.target);});
  document.addEventListener('pointerdown',event=>{
    const option=event.target.closest('[data-choice-index]');
    if(option&&popup?.contains(option)){event.preventDefault();choose(Number(option.dataset.choiceIndex));return;}
    const toggle=event.target.closest('.choice-toggle');
    if(toggle){event.preventDefault();const input=toggle.parentElement.querySelector('input');if(active===input){close();}else{input.focus({preventScroll:true});open(input,true);}return;}
    if(active&&event.target!==active&&!popup?.contains(event.target))close();
  });
  document.addEventListener('keydown',event=>{
    if(!event.target.matches('input[data-choice]')||event.isComposing)return;
    const input=event.target;
    if(event.key==='ArrowDown'||event.key==='ArrowUp'){event.preventDefault();if(active!==input)open(input,true);highlight(index+(event.key==='ArrowDown'?1:index<0?0:-1));}
    else if(event.key==='Enter'&&active===input){event.preventDefault();event.stopPropagation();if(index>=0)choose(index);else close();}
    else if(event.key==='Escape'&&active===input){event.preventDefault();event.stopPropagation();close();}
    else if(event.key==='Tab')close();
  },true);
  document.addEventListener('scroll',event=>{
    if(!active||popup?.contains(event.target))return;
    const rect=active.getBoundingClientRect(),body=document.querySelector('#dialog-body').getBoundingClientRect();
    if(rect.bottom<=body.top||rect.top>=body.bottom)close();else position();
  },true);
  window.addEventListener('resize',close);
  dialog.addEventListener('close',close);
  return {close};
})();
