"use strict";
window.DwellPerformanceMetrics=(()=>{
 const sum=(rows,key)=>rows.reduce((n,r)=>n+Number(r[key]??0),0);
 const ratio=(a,b)=>b>0?a/b:null;
 function aggregate(rows,monthOnly=0){
  const gross=sum(rows,'gross_minor'),deduction=sum(rows,'deduction_minor')+monthOnly,valid=sum(rows,'valid_count'),missing=sum(rows,'missing_cost_count');
  const input=key=>rows.length&&rows.every(r=>r.marketing?.[key]!=null)?rows.reduce((s,r)=>s+Number(r.marketing[key]),0):null;
  const spend=input('spend_minor'),messages=input('total_conversations'),fresh=input('new_conversations');
  const revenue=sum(rows,'product_revenue_minor'),cost=sum(rows,'known_cost_minor');
  const profit=missing===0&&deduction===0&&valid>0?revenue-cost:null;
  return {gross,deduction,net:gross-deduction,orders:sum(rows,'sales_count'),valid,repeat:sum(rows,'repeat_count'),unlinked:sum(rows,'unlinked_count'),missingCost:missing,cost,productRevenue:revenue,
   profit,margin:profit==null?null:ratio(profit,revenue),spend,messages,fresh,
   enteredSpend:rows.reduce((s,r)=>s+Number(r.marketing?.spend_minor??0),0),missingSpend:rows.filter(r=>r.marketing?.spend_minor==null).length,
   roi:spend==null?null:ratio(gross,spend),netRoi:spend==null?null:ratio(gross-deduction,spend),
   repeatRate:ratio(sum(rows,'repeat_count'),valid),newRate:messages==null||fresh==null?null:ratio(fresh,messages),
   average:ratio(gross,sum(rows,'sales_count')),costPerConversation:spend==null||messages==null?null:ratio(spend,messages),
   costPerNew:spend==null||fresh==null?null:ratio(spend,fresh),costPerOrder:spend==null?null:ratio(spend,sum(rows,'sales_count')),
   contribution:profit==null||spend==null?null:profit-spend};
 }
 function days(rows){const groups=new Map();for(const r of rows){if(!groups.has(r.date))groups.set(r.date,[]);groups.get(r.date).push(r);}return [...groups].sort(([a],[b])=>a.localeCompare(b)).map(([date,rows])=>({date,...aggregate(rows)}));}
 return {aggregate,days};
})();
