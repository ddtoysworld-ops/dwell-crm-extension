"use strict";
window.DwellCustomerMetrics=(()=>{
  const defaults={newDays:30,activeDays:60,dormantDays:90,loyalCount:3,loyalAmount:100000};
  const groups=[['new','新成交客户'],['active','活跃客户'],['loyal','忠实高价值客户'],['attention','需关注客户'],['dormant','沉睡客户'],['prospect','未有效购买']];
  const dayDiff=(later,earlier)=>Math.floor((Date.parse(later+'T00:00:00Z')-Date.parse(earlier+'T00:00:00Z'))/86400000);
  const validDate=date=>/^\d{4}-\d{2}-\d{2}$/.test(date)&&Number.isFinite(Date.parse(date))&&new Date(date).toISOString().slice(0,10)===date;
  const effective=o=>o.nature==='formal'&&o.status==='confirmed'&&Number.isFinite(o.total)&&o.total>0&&['MYR','SGD'].includes(o.currency);
  const amount=o=>Math.round(o.total*(o.currency==='SGD'?3:1));
  function classify(metric,rules=defaults){
    if(!metric.count)return 'prospect';
    if(metric.days>rules.dormantDays)return 'dormant';
    if(metric.days>rules.activeDays)return 'attention';
    if(metric.count>=rules.loyalCount&&metric.amount>=rules.loyalAmount)return 'loyal';
    if(metric.count===1&&metric.days<=rules.newDays)return 'new';
    return 'active';
  }
  function stats(orders,asOf){
    const dates=orders.map(o=>o.date).sort(),total=orders.reduce((n,o)=>n+amount(o),0);
    return {orders,count:orders.length,amount:total,average:orders.length?total/orders.length:0,first:dates[0]||null,last:dates.at(-1)||null,days:dates.length?dayDiff(asOf,dates.at(-1)):null};
  }
  function report(data,filters={},asOf){
    if(!validDate(asOf))throw new Error('分析日期无效');
    const start=filters.start||'',end=filters.end||asOf;
    if((start&&!validDate(start))||!validDate(end)||(start&&start>end)||end>asOf)throw new Error('请选择有效日期范围，结束日期不能晚于今天');
    const rules={...defaults,...data.crmRules};
    const customers=[...new Map(data.customers.map(c=>[c.id,c])).values()];
    const ids=new Set(customers.map(c=>c.id));
    const pageKey=id=>data.pages.some(p=>p.id===id)?id:'unassigned';
    const inDimensions=o=>(!filters.page||filters.page==='all'||pageKey(o.pageId)===filters.page)&&(!filters.sku||filters.sku==='all'||o.skuId===filters.sku)&&(!filters.channel||filters.channel==='all'||o.channel===filters.channel);
    const history=data.orders.filter(o=>validDate(o.date)&&o.date<=asOf&&inDimensions(o));
    const inPeriod=o=>(!start||o.date>=start)&&o.date<=end;
    const period=history.filter(inPeriod);
    const scoped=!!start||end!==asOf||['page','sku','channel'].some(key=>filters[key]&&filters[key]!=='all');
    const byCustomer=new Map();
    for(const o of history){if(!byCustomer.has(o.customerId))byCustomer.set(o.customerId,[]);byCustomer.get(o.customerId).push(o);}
    let rows=customers.map(customer=>{
      const all=byCustomer.get(customer.id)||[],current=all.filter(inPeriod);
      const lifetime=stats(all.filter(effective),asOf),metric=stats(current.filter(effective),asOf);
      const group=classify(lifetime,rules);
      const referred=new Set((data.promotions?.referrals||[]).filter(r=>r.referrerId===customer.id&&r.status==='approved'&&period.some(o=>o.id===r.orderId&&effective(o))).map(r=>r.customerId));
      return {customer,...metric,lifetime,group,referrals:referred.size,scopedOrders:current};
    }).filter(row=>!scoped||row.scopedOrders.length);
    if(filters.group&&filters.group!=='all')rows=rows.filter(r=>r.group===filters.group);
    const buyers=rows.filter(r=>r.count),sum=buyers.reduce((n,r)=>n+r.amount,0),count=buyers.reduce((n,r)=>n+r.count,0);
    const topCount=buyers.length?Math.ceil(buyers.length*.1):0;
    const topAmount=[...buyers].sort((a,b)=>b.amount-a.amount).slice(0,topCount).reduce((n,r)=>n+r.amount,0);
    const breakdown=(definitions,population)=>definitions.map(([id,label,predicate])=>({id,label,count:population.filter(predicate).length,ids:population.filter(predicate).map(r=>r.customer.id)}));
    const productMap=new Map();
    for(const row of buyers)for(const o of row.orders){if(!productMap.has(o.line))productMap.set(o.line,new Set());productMap.get(o.line).add(row.customer.id);}
    return {rows,buyers,amount:sum,count,average:count?sum/count:0,topCount,topShare:sum?topAmount/sum:null,asOf,start,end,rules,
      unlinked:period.filter(o=>!ids.has(o.customerId)).length,
      segments:breakdown(groups.map(([id,label])=>[id,label,r=>r.group===id]),rows),
      spend:breakdown([['low','低于 RM500',r=>r.amount<50000],['mid','RM500–999.99',r=>r.amount>=50000&&r.amount<100000],['high','RM1,000–2,999.99',r=>r.amount>=100000&&r.amount<300000],['top','RM3,000 及以上',r=>r.amount>=300000]],buyers),
      frequency:breakdown([['one','1 次',r=>r.count===1],['two','2 次',r=>r.count===2],['three','3–5 次',r=>r.count>=3&&r.count<=5],['six','6 次及以上',r=>r.count>=6]],buyers),
      recency:breakdown([['recent','0–30 天',r=>r.lifetime.days<=30],['month','31–60 天',r=>r.lifetime.days>30&&r.lifetime.days<=60],['quarter','61–90 天',r=>r.lifetime.days>60&&r.lifetime.days<=90],['old','超过 90 天',r=>r.lifetime.days>90]],rows.filter(r=>r.lifetime.count)),
      products:[...productMap].map(([id,customers])=>({id,label:data.lines.find(l=>l.id===id)?.name||id,count:customers.size,ids:[...customers]})).sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label)),
      multiProduct:buyers.filter(r=>new Set(r.orders.map(o=>o.line)).size>1).length};
  }
  function sorted(rows,key='amount',direction='desc'){
    const sign=direction==='asc'?1:-1;
    return [...rows].sort((a,b)=>{
      const x=key==='days'?a.lifetime.days:a[key],y=key==='days'?b.lifetime.days:b[key];
      if(x==null&&y!=null)return 1;if(y==null&&x!=null)return -1;
      return ((x??0)-(y??0))*sign||a.customer.id.localeCompare(b.customer.id);
    });
  }
  return {defaults,groups,report,sorted,effective,amount,validDate};
})();
