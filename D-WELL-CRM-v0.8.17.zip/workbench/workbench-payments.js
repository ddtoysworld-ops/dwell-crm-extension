"use strict";
window.DwellWorkbenchBridge = async (action, body = {}) => {
  const response = await chrome.runtime.sendMessage({ type: 'dwell-workbench', action, ...body,ticket:new URL(location.href).searchParams.get('ticket') });
  if(response?.code==='workbench_context_changed'||response?.code==='workbench_ticket_expired')window.DwellWorkbenchInvalidate?.(response.error);
  if (!response?.ok) throw Object.assign(new Error(response?.error || '读取失败，请重新打开 CRM 工作台。'), { code: response?.code });
  return response.value;
};
window.DwellPayments = (() => {
  let member = null;
  const views = new Set(['orders','customers','tasks','referrals','draws','rewards']);
  const permitted = p => !!member && member.active !== false && (member.is_owner || (member.core_access_enabled && member.permissions?.includes(p)));
  function canCoreAction(family, action, entity) {
    const customer = permitted('orders') || permitted('customers');
    if (family === 'catalog') return action === 'list' ? customer && ['pages','products','skus','customers'].includes(entity) : entity === 'customers' && permitted('customers');
    if (family === 'orders') return ['phone','customer','get','list','coupons'].includes(action) ? customer : permitted('orders');
    if (family === 'referrals') return ['list','get','settings'].includes(action) ? customer : ['approve','delivery','ship','complete'].includes(action) && permitted('orders');
    if (family === 'lucky') return ['list','settings'].includes(action) ? customer : action === 'ship' && permitted('orders');
    if (family === 'rewards') return customer;
    if (family === 'messenger') return customer && ['list','lookup'].includes(action);
    return false;
  }
  const rpc = (name, args) => DwellWorkbenchBridge('rpc', { name, args });
  function navigation() {
    document.querySelectorAll('[data-view]').forEach(n => { n.hidden = !views.has(n.dataset.view); });
    $('#ops-account').textContent = member?.display_name || '需要登录';
    $('.operator strong').textContent = member?.display_name || '未登录';
    $('.operator small').textContent = 'CRM 测试工作台';
    $('.connection span').textContent = 'Supabase';
    $('.connection .pill').textContent = member ? '已连接' : '未登录';
  }
  async function refresh() {
    member = await rpc('dwell_ops_payments', { p_action: 'self', p_payload: {} });
    navigation(); window.render(); return member;
  }
  async function action(cmd) {
    if (cmd === 'ops-account' || cmd === 'ops-login') {
      location.href='../panel.html';
    }
  }
  chrome.runtime.onMessage.addListener(message => {
    if (message?.type !== 'dwell-auth-changed') return;
    window.DwellWorkbenchInvalidate?.();
    member = null; window.DwellOperations?.clear(); window.DwellReferrals?.leave(); window.DwellLucky?.leave(); window.DwellRewards?.leave();
    if (dialog.open) dialog.close(); navigation(); window.render();
    void refresh().catch(() => { $('#workbench-status').textContent = '登录状态已改变，请从测试侧栏登录后重新打开工作台。'; });
  });
  return {
    configured: true, refresh, action, submit: async () => {}, render: () => {},
    isSignedIn: () => !!member, isViewAllowed: view => views.has(view) && (permitted('orders') || permitted('customers')),
    canCoreAction, canManagePages: () => false, actorName: () => member?.display_name || '', labelOptions: () => [],
    catalogRpc: (a,e,b={}) => rpc('dwell_ops_catalog',{p_action:a,p_entity:e,p_payload:b}),
    operationsRpc: (a,b={}) => a==='save'&&!b.id&&window.DwellWorkbenchContext?.()
      ? rpc('dwell_ops_sidebar_crm',{p_action:'save_order',p_payload:{order:b,identity:window.DwellWorkbenchContext()}})
      : rpc('dwell_ops_orders_api',{p_action:a,p_payload:b}),
    referralsRpc: (a,b={}) => rpc('dwell_ops_referrals_api',{p_action:a,p_payload:b}),
    luckyRpc: (a,b={}) => rpc('dwell_ops_lucky_api',{p_action:a,p_payload:b}),
    messengerRpc: (a,b={}) => rpc('dwell_ops_messenger_api',{p_action:a,p_payload:b}),
    legacyCustomerHistoryRpc: async id => {
      try{return await rpc('dwell_ops_legacy_customer_history',{p_customer_id:id});}
      catch(e){
        if(e.code!=='PGRST202')throw e;
        return rpc('dwell_ops_legacy_archive_api',{p_action:'profile',p_payload:{customer_id:id}});
      }
    },
    rewardsRpc: (b={}) => rpc('dwell_ops_rewards',{p_payload:b}),
    subscribeFollowups: () => () => {}
  };
})();
