"use strict";
window.DwellSkuSales=(()=>{
  const regions={MY:['西马','myr','myr_minor','shipping_myr'],EM:['东马','em','em_minor','shipping_em'],SG:['新加坡','sgd','sgd_minor','shipping_sgd']};
  const allowed=(s,market)=>(s?.sale_markets||['MY','EM','SG']).includes(market);
  const amount=(label,name,v,required)=>inputField(label,name,v==null?'':String(v/100),'number',required,'min="0" max="100000000" step="0.01"');
  const optionalMoney=name=>value(name)===''?null:moneyInput(name);
  function tierRow(market='MY',quantity='',minor=0){return `<div class="shipping-tier-row">${selectField('地区','tier_market',Object.entries(regions).map(([k,v])=>[k,v[0]]),market)}${inputField('份数（留空为其他数量）','tier_quantity',quantity==='default'?'':quantity,'number',false,'min="1" max="1000" step="1"')}${amount('运费（当地币种）','tier_amount',minor,true)}<button type="button" class="icon-button" data-tier-remove aria-label="移除运费规则" title="移除运费规则">${icon('trash-2')}</button></div>`;}
  function fields(r){
    return `<h3 class="section-title">直接销售地区</h3><div class="form-grid">${Object.entries(regions).map(([k,[label,name,key,ship]])=>`<label class="field full sale-market"><span><input type="checkbox" name="sale_market" value="${k}" ${allowed(r,k)?'checked':''}> ${label}</span></label>${amount(label+'售价 '+(k==='SG'?'SGD':'MYR'),name,r?r[key]:0,allowed(r,k))}${amount(label+'每单运费 '+(k==='SG'?'SGD':'MYR'),ship,r?r[ship+'_minor']:0,allowed(r,k))}`).join('')}</div><details class="shipping-rules"><summary>按购买份数设置运费</summary><div id="shipping-tiers">${Object.entries(r?.shipping_tiers||{}).flatMap(([k,rules])=>Object.entries(rules).map(([q,n])=>tierRow(k,q,n))).join('')}</div><button type="button" class="secondary" data-tier-add>${icon('plus')}添加运费规则</button></details>`;
  }
  function read(){
    const result={sale_markets:[...document.querySelectorAll('[name=sale_market]:checked')].map(el=>el.value),shipping_tiers:{}};
    for(const [,name,key,ship] of Object.values(regions)){result[key]=optionalMoney(name);result[ship+'_minor']=optionalMoney(ship);}
    for(const row of document.querySelectorAll('.shipping-tier-row')){
      const market=row.querySelector('[name=tier_market]').value,q=row.querySelector('[name=tier_quantity]').value||'default';
      if(result.shipping_tiers[market]?.[q]!==undefined)throw new Error('sku_shipping_invalid');
      const n=Number(row.querySelector('[name=tier_amount]').value),minor=Math.round(n*100);
      if(!Number.isFinite(n)||minor<0||Math.abs(n*100-minor)>0.00001)throw new Error('sku_shipping_invalid');
      (result.shipping_tiers[market]??={})[q]=minor;
    }
    return result;
  }
  function shipping(s,market,quantity){
    const rules=s.shipping_tiers?.[market];
    if(rules)return rules[String(quantity)]??rules.default??null;
    const key=regions[market]?.[3];return s[key+'_minor']??(s.sale_markets?null:0);
  }
  function summary(s){return Object.entries(regions).map(([k,[label,,key]])=>`${label} ${s[key]==null?'待定':(k==='SG'?'S$ ':'RM ')+fmt(s[key])}${allowed(s,k)?'':' · 暂不单卖'}`).join('<br>');}
  document.addEventListener('change',e=>{
    if(e.target.name!=='sale_market'||!dialogKind.startsWith('catalog-'))return;
    const [,name,,ship]=regions[e.target.value];for(const n of [name,ship]){field(n).required=e.target.checked;const span=field(n).closest('label').querySelector('span');span.textContent=span.textContent.replace(/\s*\*$/,'')+(e.target.checked?' *':'');}
  });
  document.addEventListener('click',e=>{
    if(!dialogKind.startsWith('catalog-')||$('#save-button').disabled)return;
    if(e.target.closest('[data-tier-add]')){$('#shipping-tiers').insertAdjacentHTML('beforeend',tierRow());icons();}
    e.target.closest('[data-tier-remove]')?.closest('.shipping-tier-row').remove();
  });
  return {fields,read,allowed,shipping,summary};
})();
