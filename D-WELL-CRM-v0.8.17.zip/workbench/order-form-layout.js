"use strict";
window.DwellOrderLayout=(()=>{
  function fold(heading,contents,open=false){
    const details=document.createElement('details');
    details.className='order-fold';details.open=open;
    const summary=document.createElement('summary');
    const title=document.createElement('span');title.textContent=heading.textContent;
    summary.append(title);summary.insertAdjacentHTML('beforeend',icon('chevron-down'));
    heading.before(details);heading.remove();details.append(summary,...contents);
    return details;
  }
  function mount(record){
    const taskGrid=field('due_date')?.closest('.form-grid');
    if(taskGrid&&taskGrid.previousElementSibling?.matches('h3.section-title')){
      fold(taskGrid.previousElementSibling,[taskGrid],Boolean(value('due_date')||value('task_note')));
    }
    const promotions=$('#cloud-promotions'),heading=promotions?.querySelector('h3.section-title');
    if(heading){
      const p=record?.promotions;
      fold(heading,Array.from(promotions.children).filter(el=>el!==heading),Boolean(p?.referral_phone||p?.coupon_id||p?.coupon||p?.gift_coupon));
    }
    icons();
  }
  // Native constraint validation runs before submit, including closed sections.
  form.addEventListener('invalid',event=>{
    if(dialogKind!=='cloud-order')return;
    const details=event.target.closest('details.order-fold');
    if(details)details.open=true;
  },true);
  return {mount};
})();
