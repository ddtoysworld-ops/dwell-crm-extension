"use strict";
const TODAY = "2026-10-09";
const DEMO_MONTH = "2026-10";
const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[character]));
const icon = (name) => `<i data-icon="${name}"></i>`;
const fmt = (minor) => (minor / 100).toLocaleString("en-MY", {minimumFractionDigits:2,maximumFractionDigits:2});
const dateLabel = (date) => `${date.slice(8,10)}/${date.slice(5,7)}/${date.slice(0,4)}`;
const currencyLabel = (currency) => currency === "SGD" ? "S$" : "RM";
function icons() { window.lucide?.createIcons({nameAttr:"data-icon", attrs:{"aria-hidden":"true"}}); }
let state;
function seed() {
  state = {
    view: "orders", month:DEMO_MONTH, search:"", status:"all", currency:"all", line:"all", hrMonth:DEMO_MONTH, paymentCurrency:"all", paymentStatus:"all",
    hrPage:'all',orderPage:'all',
    pages:[{id:'malaysia',name:"D'WELL Malaysia"},{id:'fibre-dtox',name:"D' WELL Fibre D'tox"}],
    lines:[{id:"gamat",name:"蓝藻海参精华"},{id:"tomato",name:"日本白番茄"}],
    skus:[
      {id:"s1",code:"GAMAT-03",name:"海参精华 · 3 支配套",line:"gamat",units:3,myr:26400,sgd:10500,active:true},
      {id:"s2",code:"GAMAT-A06",name:"配套 A · 6 支",line:"gamat",units:6,myr:44000,sgd:16500,active:true},
      {id:"s3",code:"GAMAT-B10",name:"配套 B · 10 支",line:"gamat",units:10,myr:61600,sgd:22500,active:true},
      {id:"s4",code:"GAMAT-C14",name:"配套 C · 14 支",line:"gamat",units:14,myr:88000,sgd:31500,active:true},
      {id:"s5",code:"TOMATO-01",name:"白番茄 · 单盒",line:"tomato",units:1,myr:16800,sgd:6000,active:true},
      {id:"s6",code:"TOMATO-03",name:"白番茄 · 3 盒配套",line:"tomato",units:3,myr:45000,sgd:16000,active:true}
    ],
    customers:Array.from({length:8},(_,i)=>({id:`DEMO-C${String(i+1).padStart(3,"0")}`,name:["示例客户 · 林","示例客户 · 陈","示例客户 · 王","示例客户 · 李","示例客户 · 黄","示例客户 · 张","示例客户 · 刘","示例客户 · 吴"][i],phones:[i%3===0?`65800000${String(i).padStart(2,"0")}`:`601200000${String(i).padStart(2,"0")}`],addresses:[i%3===0?"示例地址 · Singapore":"示例地址 · Kuala Lumpur"],channel:i%2===0?"Facebook":"WhatsApp",identity:i%2===0?`DEMO-PAGE / DEMO-PSID-${i+1}`:""})),
    orders:[],adjustments:[]
  };
  let n=1;
  for(let day=1;day<=9;day++) {
    for(let j=0;j<(day%3)+1;j++) {
      const sku=state.skus[(day+j)%6], customer=state.customers[(day*2+j)%8];
      const currency=(day+j)%4===0?"SGD":"MYR";
      const subtotal=currency==="SGD"?sku.sgd:sku.myr;
      const shipping=j===1?1000:0, voucher=day%3===0?1000:0;
      const inquiry=day===8&&j===0;
      state.orders.push({id:`DEMO-${String(n++).padStart(4,"0")}`,date:`2026-10-${String(day).padStart(2,"0")}`,nature:inquiry?"inquiry":"formal",customerId:customer.id,customerName:customer.name,phone:customer.phones[0],address:customer.addresses[0],channel:customer.channel,source:day%2===0?"广告":"repeat order",skuId:sku.id,skuName:sku.name,line:sku.line,quantity:1,units:sku.units,currency,subtotal,shipping,voucher,discount:0,total:inquiry?0:subtotal+shipping-voucher,rate:currency==="SGD"?3:1,payment:currency==="SGD"?"Bank Transfer":"COD",erp:`DEMO-ERP-${n}`,staff:["客服 A","客服 B","客服 C"][day%3],status:inquiry?"inquiry":"confirmed",note:"",revision:1});
    }
  }
  // One customer can order on multiple platforms; orders retain their own snapshot.
  state.orders.forEach((order,index)=>{order.pageId=index===17?'':state.pages[index%state.pages.length].id;});
  state.orders.find(order=>order.id==='DEMO-0007').channel='WhatsApp';
  const previous={...state.orders[0],id:"DEMO-0090",date:"2026-09-28",total:31500,subtotal:31500,shipping:0,voucher:0,currency:"MYR",rate:1,line:"gamat",status:"rejected",erp:"DEMO-ERP-0090"};
  state.orders.push(previous);
  state.adjustments.push({id:"adj-seed",orderId:previous.id,pageId:previous.pageId,line:"gamat",date:"2026-10-04",kind:"rejected",amount:31500,reason:"模拟 COD 拒收"});
  window.DwellTasks?.seed();
  window.DwellPromotions?.seed();
}
seed();
function toast(message) { const element=$("#toast");element.textContent=message;element.classList.add("visible");clearTimeout(toast.timer);toast.timer=setTimeout(()=>element.classList.remove("visible"),3200); }
function lineName(id) {return state.lines.find(line=>line.id===id)?.name||id;}
function pageKey(id) {return state.pages.some(page=>page.id===id)?id:'unassigned';}
function pageName(id) {return id==='all'?'全部主页':state.pages.find(page=>page.id===id)?.name||'未分配主页';}
function pageOptions(selected,report=false) {
  const available=state.pages.filter(p=>report||p.active!==false||p.id===selected);
  const options=report?[['all','全部主页（汇总）'],...available.map(p=>[p.id,p.name+(p.active===false?'（已停用）':'')]),['unassigned','未分配主页']]:[['','请选择主页'],...available.map(p=>[p.id,p.name+(p.active===false?'（已停用）':'')])];
  return options.map(([id,name])=>`<option value="${id}" ${id===selected?'selected':''}>${escapeHtml(name)}</option>`).join('');
}
function orderMyr(order) {return order.nature==="formal"?order.total*order.rate:0;}
function monthStats(month,line="all",page="all") {
  const matchesPage=id=>page==='all'||pageKey(id)===page;
  const orders=state.orders.filter(order=>order.date.startsWith(month)&&(line==="all"||order.line===line)&&matchesPage(order.pageId));
  const formal=orders.filter(order=>order.nature==="formal");
  const gross=formal.reduce((total,order)=>total+orderMyr(order),0);
  const cancelled=state.adjustments.filter(adj=>adj.date.startsWith(month)&&(line==="all"||adj.line===line)&&matchesPage(adj.pageId??state.orders.find(order=>order.id===adj.orderId)?.pageId)).reduce((total,adj)=>total+adj.amount,0);
  return {orders,formal,gross,cancelled,net:gross-cancelled,units:formal.reduce((sum,order)=>sum+order.units*order.quantity,0)};
}
function heading(title,subtitle,action="") {return `<div class="page-heading"><div><div class="eyebrow">D'WELL WORKSPACE</div><h1>${title}</h1><p>${subtitle}</p></div>${action}</div>`;}
function stat(label,value,foot,iconName,color="") {return `<div class="stat"><div class="stat-top"><span>${label}</span>${icon(iconName)}</div><div class="stat-value ${color}">${value}</div><div class="stat-foot">${foot}</div></div>`;}
function statusBadge(status) {const labels={confirmed:["success","正式订单"],inquiry:["warning","潜在咨询"],cancelled:["danger","已取消"],rejected:["danger","COD 拒收"]};const [tone,label]=labels[status]||labels.confirmed;return `<span class="pill ${tone}">${label}</span>`;}
function customerPlatforms(customer) {
  return [...new Set([customer.channel,...state.orders.filter(order=>order.customerId===customer.id).map(order=>order.channel)].filter(Boolean))];
}
function platformTags(customer) {return `<span class="platform-tags">${customerPlatforms(customer).map(channel=>`<span class="inline-tag">${escapeHtml(channel)}</span>`).join('')}</span>`;}
function orderLogistics(order) {
  return `<span>${escapeHtml(order.erp||'—')}</span><small>运单：${escapeHtml(order.trackingNumber||'未填写')}</small>`;
}
function orderOrigin(order) {return `${escapeHtml(order.channel||'—')}<small class="order-page">${escapeHtml(pageName(order.pageId))}</small><small>来源：${escapeHtml(order.source||'未记录')}</small>`;}
function orderRows(orders,customerView=false) {
  return orders.map(order=>`<tr><td><button class="id-link" data-action="edit-order" data-id="${order.id}">${escapeHtml(order.id)}</button><small>${dateLabel(order.date)}</small></td>${customerView?'':`<td><button class="customer-name" data-action="customer" data-id="${order.customerId||""}"><span class="avatar">${escapeHtml(order.customerName?.slice(-1)||"客")}</span><span>${escapeHtml(order.customerName||"未留姓名")}</span></button></td>`}<td class="order-channel">${orderOrigin(order)}</td><td>${escapeHtml(order.skuName)}<small>${order.units*order.quantity} ${order.line==="gamat"?"支":"盒"} · ${escapeHtml(lineName(order.line))}</small></td><td class="money">${order.nature==="formal"?`${currencyLabel(order.currency)} ${fmt(order.total)}`:"—"}<small>${order.currency}</small></td><td class="money"><strong>${order.nature==="formal"?`RM ${fmt(orderMyr(order))}`:"—"}</strong>${order.currency==="SGD"&&order.nature==="formal"?"<small>SGD ×3</small>":""}</td><td class="order-logistics">${orderLogistics(order)}</td><td>${statusBadge(order.status)}</td><td>${escapeHtml(order.staff)}</td><td><div class="row-actions"><button class="icon-button" title="查看或修改订单" aria-label="修改 ${order.id}" data-action="edit-order" data-id="${order.id}">${icon("square-pen")}</button>${order.status==="confirmed"?`<button class="icon-button danger-button" title="取消或 COD 拒收" aria-label="取消 ${order.id}" data-action="cancel-order" data-id="${order.id}">${icon("circle-slash")}</button>`:""}</div></td></tr>`).join("");
}
function orderTable(orders,customerView=false) {return `<div class="table-scroll"><table class="order-table"><thead><tr><th>订单 / 日期</th>${customerView?'':'<th>客户</th>'}<th>下单平台 / 来源</th><th>产品配套</th><th class="money">原币金额</th><th class="money">GMV · 马币</th><th>ERP Order ID / Tracking Number</th><th>状态</th><th>经手人</th><th></th></tr></thead><tbody>${orderRows(orders,customerView)}</tbody></table>${!orders.length?'<div class="empty">没有符合条件的订单</div>':""}</div>`;}
function lineOptions(selected,all=false) {return `${all?'<option value="all">全部产品线</option>':""}${state.lines.map(line=>`<option value="${line.id}" ${selected===line.id?"selected":""}>${escapeHtml(line.name)}</option>`).join("")}`;}
function renderOrders() {
  const stats=monthStats(state.month,'all',state.orderPage);
  const summaryPages=[...state.pages.map(page=>({id:page.id,name:page.name+(page.active===false?'（已停用）':'')})),{id:'unassigned',name:'未分配主页'}].filter(page=>state.orderPage==='all'||page.id===state.orderPage);
  let orders=stats.orders.filter(order=>(state.status==="all"||order.status===state.status)&&(state.currency==="all"||order.currency===state.currency));
  const query=state.search.toLowerCase().trim();
  if(query) orders=orders.filter(order=>[order.id,order.customerName,order.phone,order.erp,order.skuName,order.channel,order.source,order.trackingNumber,pageName(order.pageId)].some(value=>String(value||'').toLowerCase().includes(query)));
  orders.sort((a,b)=>b.date.localeCompare(a.date)||b.id.localeCompare(a.id));
  const [chartYear,chartMonth]=state.month.split("-").map(Number);
  const lastChartDay=state.month===DEMO_MONTH?9:new Date(Date.UTC(chartYear,chartMonth,0)).getUTCDate();
  const days=Array.from({length:9},(_,i)=>{const day=lastChartDay-8+i;return {day,amount:stats.formal.filter(order=>order.date===`${state.month}-${String(day).padStart(2,"0")}`).reduce((sum,order)=>sum+orderMyr(order),0)};});
  const max=Math.max(...days.map(day=>day.amount),1);
  $("#main").innerHTML=heading("销售订单",`${state.month.replace("-"," 年 ")} 月 · ${stats.formal.length} 笔正式订单`,`<button class="primary" data-action="new-order">${icon("plus")}新增订单</button>`)+
    `<div class="stats">${stat("订单 GMV",`<span class="currency">RM</span>${fmt(stats.gross)}`,"含运费，已扣优惠券与折扣","wallet")}${stat("正式订单",stats.formal.length,"不含潜在咨询","shopping-bag","blue")}${stat("产品数量",stats.units,"本月订单产品数量合计","package")}${stat("当月取消 / 拒收",`<span class="currency">RM</span>${fmt(stats.cancelled)}`,"按确认月份扣减","rotate-ccw","rose")}</div>`+
    `<section class="trend-section"><div><div class="section-title"><h3>每日销售</h3><small>GMV · MYR</small></div><div class="chart" aria-label="每日模拟销售柱状图">${days.map(day=>`<div class="bar-unit"><span class="chart-number">${Math.round(day.amount/100).toLocaleString()}</span><div class="bar" style="height:${Math.max(2,day.amount/max*64)}px" title="${day.day} 日 RM ${fmt(day.amount)}"></div><small>${String(day.day).padStart(2,"0")} 日</small></div>`).join("")}</div></div><div class="line-summary page-summary"><h3>主页销售</h3>${summaryPages.map((page,i)=>`<div class="line-row" data-page-id="${escapeHtml(page.id)}"><span class="legend ${i?"blue":""}">${escapeHtml(page.name)}</span><strong>RM ${fmt(monthStats(state.month,'all',page.id).gross)}</strong></div>`).join("")}</div></section>`+
    `<section class="data-surface"><div class="toolbar"><div class="filters"><label class="search-field">${icon("search")}<input id="order-search" value="${escapeHtml(state.search)}" placeholder="搜索客户、电话或订单" aria-label="搜索订单"></label><input type="month" id="order-month" value="${state.month}" max="2026-10" aria-label="销售月份"><select id="order-status" aria-label="订单状态">${[["all","全部状态"],["confirmed","正式订单"],["inquiry","潜在咨询"],["cancelled","已取消"],["rejected","COD 拒收"]].map(([value,label])=>`<option value="${value}" ${state.status===value?"selected":""}>${label}</option>`).join("")}</select><select id="order-currency" aria-label="订单币种">${["all","MYR","SGD"].map(value=>`<option value="${value}" ${state.currency===value?"selected":""}>${value==="all"?"全部币种":value}</option>`).join("")}</select><select id="order-page" aria-label="订单主页">${pageOptions(state.orderPage,true)}</select></div></div>${orderTable(orders)}<div class="table-foot"><span>显示 ${orders.length} 笔 · 模拟资料</span><span>日期 DD/MM/YYYY</span></div></section>`;
}
const viewNames={performance:"经营看板",orders:"销售订单",tasks:"待处理任务清单",customers:"客户资料",analytics:"客户分析",rewards:"优惠券与奖品",referrals:"好友推荐",draws:"幸运抽奖",products:"SKU 与配套",pages:"主页管理",payments:"信用卡付款链接",hr:"HR 销售导出",access:"账户与权限"};
const demoView=()=>false;
const canonicalView=view=>({operations:'orders',catalog:'products'}[view]|| (viewNames[view]?view:'orders'));
let renderedView='';
function render() {
  state.view=canonicalView(state.view);
  const denied=window.DwellPayments&&!window.DwellPayments.isViewAllowed(state.view);
  if(renderedView!==state.view){
    window.DwellCatalog?.leave();window.DwellOperations?.leave();window.DwellCloudHR?.leave();window.DwellFollowups?.leave();window.DwellPerformance?.leave();window.DwellReferrals?.leave();window.DwellLucky?.leave();window.DwellRewards?.leave();
    renderedView=state.view;
  }
  if(location.hash!=='#'+state.view)history.replaceState(null,'','#'+state.view);
  $("#breadcrumb").textContent=viewNames[state.view];
  const demo=demoView(state.view);
  $('#reset-demo').hidden=!demo;
  $('#data-source-banner').classList.toggle('demo-source',demo);
  $('#data-source-label').textContent=demo?'演示数据 · 仅本页模拟操作，不发放真实优惠券或奖品，不写入 Supabase。':`Supabase · ${(window.DwellPayments?.isSignedIn?.()||window.DwellPayments?.canManagePages())?'业务资料，历史资料尚未完整导入。':'需获授权账号登录后读取。'}旧系统未切换。`;
  $$("nav button").forEach(button=>{button.classList.toggle("active",button.dataset.view===state.view);button.setAttribute("aria-current",button.dataset.view===state.view?"page":"false");});
  if(denied){$('#main').innerHTML=heading(viewNames[state.view],'权限受限')+'<div class="empty">当前账号未获此功能权限，请联系管理员。</div>';icons();return;}
  if(['orders','tasks'].includes(state.view)) window.DwellOperations?.render();
  else if(['customers','products','pages'].includes(state.view)) window.DwellCatalog?.render();
  else if(state.view==="analytics") window.DwellCloudAnalytics?.render();
  else if(state.view==='rewards') window.DwellRewards?.render();
  else if(state.view==='draws')window.DwellLucky?.render();
  else if(state.view==='referrals')window.DwellReferrals?.render();
  else if(state.view==="payments"||state.view==="access") renderPayments();
  else if(state.view==='hr')window.DwellCloudHR?.render();
  else if(state.view==='performance')window.DwellPerformance?.render();
  icons();
}
document.addEventListener("click",event=>{
  const nav=event.target.closest("[data-view]");
  if(nav){state.view=nav.dataset.view;state.search="";render();return;}
  const action=event.target.closest("[data-action]");
  if(action) handleAction(action.dataset.action,action.dataset.id);
});
document.addEventListener("change",event=>{
  const bindings={"order-month":"month","order-status":"status","order-currency":"currency","order-page":"orderPage"};
  if(bindings[event.target.id]){state[bindings[event.target.id]]=event.target.value||DEMO_MONTH;render();}
});
document.addEventListener("input",event=>{
  if(event.target.id==="order-search") {const position=event.target.selectionStart;state.search=event.target.value;render();$("#order-search").focus();$("#order-search").setSelectionRange(position,position);}
});
function handleAction(action,id) { if(typeof window.previewAction==="function") window.previewAction(action,id); }

function renderPayments() {
  if(window.DwellPayments)window.DwellPayments.render();
  else $("#main").innerHTML='<div class="empty">付款模块正在载入，请稍候。</div>';
}
document.addEventListener("change",event=>{
  if(event.target.id==="payment-currency"){state.paymentCurrency=event.target.value;render();}
  if(event.target.id==="payment-status"){state.paymentStatus=event.target.value;render();}
});
document.addEventListener("input",event=>{
  if(event.target.id==="payment-search"){const position=event.target.selectionStart;state.search=event.target.value;render();$("#payment-search").focus();$("#payment-search").setSelectionRange(position,position);}
});

function renderCustomers() {
  window.DwellCRM?.renderCustomers();
}
function renderProducts() {
  const skus=state.skus.filter(sku=>state.line==="all"||sku.line===state.line);
  $("#main").innerHTML=heading("SKU 与配套",`${state.skus.length} 个 SKU · 模拟报价`,`<button class="primary" data-action="new-product">${icon("plus")}新增 SKU</button>`)+
    `<div class="toolbar catalog-filter"><select id="product-line" aria-label="SKU 产品线">${lineOptions(state.line,true)}</select><span class="table-filter-result">马币与新币独立定价</span></div><div class="product-grid">${skus.map(sku=>`<article class="product-card"><div class="product-head"><div class="product-symbol">${icon(sku.line==="gamat"?"package":"boxes")}</div><span class="pill ${sku.active?"success":"neutral"}">${sku.active?"启用":"停用"}</span></div><h3>${escapeHtml(sku.name)}</h3><div class="code">${escapeHtml(sku.code)}</div><div class="product-prices"><div><small>马来西亚价格</small><strong>RM ${fmt(sku.myr)}</strong></div><div><small>新加坡价格</small><strong>S$ ${fmt(sku.sgd)}</strong></div></div><div class="product-meta"><span>${escapeHtml(lineName(sku.line))} · ${sku.units} ${sku.line==="gamat"?"支":"盒"}</span><button class="icon-button" data-action="edit-product" data-id="${sku.id}" title="修改 SKU" aria-label="修改 ${escapeHtml(sku.code)}">${icon("square-pen")}</button></div></article>`).join("")}</div>`;
}
function getHrExport() {
  const month=state.hrMonth;
  if(!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)||month>DEMO_MONTH) throw new Error("请选择 2026 年 10 月或之前的月份");
  const [year,number]=month.split("-").map(Number);
  const businessDay=window.DwellTasks?.today()||TODAY;
  const length=month===businessDay.slice(0,7)?Number(businessDay.slice(8,10)):new Date(Date.UTC(year,number,0)).getUTCDate();
  if(!['all','unassigned',...state.pages.map(page=>page.id)].includes(state.hrPage))throw new Error('请选择有效主页');
  const stats=monthStats(month,'all',state.hrPage);
  const rows=Array.from({length},(_,i)=>{
    const date=`${month}-${String(i+1).padStart(2,"0")}`;
    return {date,amount:stats.formal.filter(order=>order.date===date).reduce((sum,order)=>sum+orderMyr(order),0)};
  });
  return {rows,...stats,pageId:state.hrPage,pageName:pageName(state.hrPage),text:rows.map(row=>`${dateLabel(row.date)}\t${(row.amount/100).toFixed(2)}`).join("\n")};
}
function requirePageAdmin() {
  if(!window.DwellPayments?.canManagePages())throw new Error('请使用管理员账号登录后管理主页');
}
function renderPages() {
  requirePageAdmin();
  $('#main').innerHTML=heading('主页管理',`${state.pages.length} 个主页 · 模拟设置`,`<button class="primary" data-action="new-page">${icon('plus')}新增主页</button>`)+
    `<section class="data-surface"><div class="table-scroll"><table class="page-table"><thead><tr><th>主页名称</th><th>状态</th><th>关联订单</th><th>操作</th></tr></thead><tbody>${state.pages.map(page=>`<tr><td>${escapeHtml(page.name)}</td><td><span class="pill ${page.active===false?'neutral':'success'}">${page.active===false?'已停用':'启用'}</span></td><td>${state.orders.filter(order=>order.pageId===page.id).length}</td><td><button class="icon-button" data-action="edit-page" data-id="${page.id}" aria-label="修改 ${escapeHtml(page.name)}" title="修改主页">${icon('square-pen')}</button></td></tr>`).join('')}</tbody></table></div></section><div class="notice">模拟设置仅保留在本次页面中，刷新或重置后清除。尚未绑定 Facebook mailbox_id。</div>`;
}
function pageDialog(id) {
  requirePageAdmin();
  const page=state.pages.find(row=>row.id===id);
  if(id&&!page)throw new Error('主页不存在');
  showDialog('page',id,page?'修改主页':'新增主页',`<div class="form-grid">${inputField('主页名称','name',page?.name||'','text',true,'data-full maxlength="80"')}${selectField('状态','active',[['yes','启用'],['no','停用']],page?.active===false?'no':'yes')}</div><div class="notice">停用不删除历史订单，仍可导出历史销售额。</div>`,'管理员 · 模拟主页设置');
}
function savePage() {
  requirePageAdmin();
  const name=value('name').replace(/\s+/g,' '),page=state.pages.find(row=>row.id===dialogId);
  if(!name||name.length>80)throw new Error('请填写 1 至 80 字的主页名称');
  if(state.pages.some(row=>row.id!==dialogId&&row.name.normalize('NFKC').toLowerCase()===name.normalize('NFKC').toLowerCase()))throw new Error('这个主页名称已存在');
  if(dialogId&&!page)throw new Error('主页不存在');
  const record={...page,id:page?.id||`page-${crypto.randomUUID()}`,name,active:value('active')==='yes'};
  if(page)state.pages[state.pages.indexOf(page)]=record;else state.pages.push(record);
  dialog.close();render();toast('模拟主页已保存');
}
function renderHr() {
  const data=getHrExport();
  $("#main").innerHTML=heading("HR 销售导出","按所属主页与月份汇总 · MYR",`<button class="secondary" data-action="open-hr">${icon("external-link")}打开现有 HR</button>`)+
    `<div class="toolbar hr-filters"><div class="filters"><label class="field"><span>所属主页</span><select id="hr-page">${pageOptions(state.hrPage,true)}</select></label><label class="field"><span>销售月份</span><input type="month" id="hr-month" value="${state.hrMonth}" max="2026-10" required></label></div><span class="table-filter-result">截至 ${dateLabel(data.rows.at(-1).date)}</span></div>
    ${state.hrPage==='unassigned'?'<div class="alert-note">这些记录尚未确认所属主页，不能直接归入任何主页佣金。</div>':''}
    <div class="hr-layout"><section class="hr-export"><div class="section-title"><h3>${escapeHtml(data.pageName)}</h3><span class="pill neutral">${data.rows.length} 天</span></div><p class="hr-export-scope">${state.hrMonth} · 每日 GMV · 取消扣减前</p><textarea id="hr-text" readonly aria-label="每日销售额复制内容" spellcheck="false">${data.text}</textarea><div class="hr-actions"><button class="primary" data-action="copy-hr">${icon("copy")}复制整月销售额</button><button class="secondary" data-action="download-hr">${icon("download")}下载 TSV</button></div></section>
    <aside class="hr-summary"><h3>${escapeHtml(data.pageName)}</h3><div class="summary-line"><span>GMV · 含运费及折扣</span><strong>RM ${fmt(data.gross)}</strong></div><div class="summary-line"><span>当月取消 / 拒收</span><strong class="stat-value rose" style="font-size:14px;margin:0">− RM ${fmt(data.cancelled)}</strong></div><div class="summary-line total"><span>扣减后金额</span><strong>RM ${fmt(data.net)}</strong></div>${data.net<0?'<div class="alert-note">当月扣减超过销售额，需核对 HR 的零下限处理。</div>':""}<button class="secondary" data-action="copy-cancelled">${icon("copy")}复制取消金额</button><div class="notice">GMV 已含运费，并已扣优惠券与其他折扣。<br>取消金额单独填写，避免重复扣减。</div><div class="notice">${state.hrPage==='all'?'当前包含全部主页，不是单独某个主页的销售额。<br>':''}本页为模拟资料，不是正式薪资数据。</div></aside></div>`;
}
const dialog=$("#editor"), form=$("#edit-form");
let dialogKind="", dialogId="";
function showDialog(kind,id,title,body,eyebrow="模拟数据") {
  window.DwellChoices?.close();
  dialog.dataset.kind=kind;
  dialog.classList.remove('customer-detail-dialog','cloud-profile-dialog');
  delete form.dataset.converting;delete form.dataset.originalDate;
  dialogKind=kind;dialogId=id||"";form.reset();
  $("#dialog-title").textContent=title;$("#dialog-eyebrow").textContent=eyebrow;
  if(demoView(state.view)&&!kind.startsWith('ops-'))$('#dialog-eyebrow').textContent='演示数据 · 不写入 Supabase，不发放真实奖励';
  $("#dialog-body").innerHTML=body;$("#form-error").textContent="";
  $("#save-button").hidden=kind==="detail";
  $("#save-button").innerHTML=`${icon("check")}${demoView(state.view)&&!kind.startsWith('ops-')?'保存演示':kind==="cancel"?"确认记录":"保存"}`;
  if(!dialog.open) dialog.showModal();icons();
}
function inputField(label,name,value="",type="text",required=false,extra="") {
  return `<label class="field ${extra.includes("data-full")?"full":""}"><span>${label}${required?" *":""}</span><input name="${name}" type="${type}" value="${escapeHtml(value)}" ${required?"required":""} ${extra}></label>`;
}
function selectField(label,name,options,value,required=false,extra="") {
  return `<label class="field"><span>${label}${required?" *":""}</span><select name="${name}" ${required?"required":""} ${extra}>${options.map(([v,t])=>`<option value="${escapeHtml(v)}" ${v===value?"selected":""}>${escapeHtml(t)}</option>`).join("")}</select></label>`;
}
function field(name) {return form.elements.namedItem(name);}
function value(name) {return field(name)?.value?.trim()||"";}
function moneyInput(name) {
  const raw=value(name)||"0";
  if(!/^\d+(\.\d{1,2})?$/.test(raw)) throw new Error("金额最多两位小数，且不能为负数");
  const [whole,fraction=""]=raw.split(".");
  const amount=Number(whole)*100+Number(fraction.padEnd(2,"0"));
  if(!Number.isSafeInteger(amount)||amount>10000000000) throw new Error("金额超出测试范围");
  return amount;
}
let orderCustomerMatch={manual:false,filled:{}};
function matchOrderCustomer() {
  const phone=value('phone'),valid=/^6\d{7,15}$/.test(phone);
  const matches=valid?state.customers.filter(customer=>customer.phones.includes(phone)):[];
  const status=$('#order-customer-match');
  let customer=state.customers.find(row=>row.id===value('customerId'));
  if(!orderCustomerMatch.manual) {
    const next=matches.length===1?matches[0]:null;
    if(customer?.id!==next?.id) {
      // Only remove values supplied by the previous automatic match, never user edits.
      for(const [name,filled] of Object.entries(orderCustomerMatch.filled))if(field(name).value===filled)field(name).value='';
      orderCustomerMatch.filled={};
    }
    field('customerId').value=next?.id||'';customer=next;
    if(customer)for(const [name,text] of Object.entries({customerName:customer.name,address:customer.addresses[0]||''})) {
      if(!value(name)&&text){field(name).value=text;orderCustomerMatch.filled[name]=text;}
    }
  }
  const conflict=matches.length>1||(customer&&matches.some(row=>row.id!==customer.id));
  const message=conflict?'此电话对应多个客户或与所选客户冲突，请核对关联客户。':
    !phone?(customer?`已选择：${customer.name}`:''):
    !valid?'号码格式待确认：请填写以 60 或 65 开头的完整号码。':
    customer?(matches.length===1?`已关联：${customer.name}`:`已选择：${customer.name}；此号码不在该客户已记录的电话中，请核对。`):
    '未找到已有客户，保存时将建立新客户。';
  status.textContent=message;status.hidden=!message;
  field('phone').setCustomValidity(conflict?'请先核对电话号码与关联客户':'');
}
function orderDialog(id,convert=false) {
  const order=state.orders.find(row=>row.id===id);
  if(order&&["cancelled","rejected"].includes(order.status)){toast("已取消订单保留原金额，不能直接覆盖");return;}
  const first=order?state.skus.find(sku=>sku.id===order.skuId):state.skus.find(sku=>sku.active);
  const entry=order||{date:window.DwellTasks?.today()||TODAY,nature:"formal",currency:"MYR",skuId:first?.id,quantity:1,subtotal:first?.myr||0,shipping:0,voucher:0,discount:0,customerId:"",customerName:"",phone:"",address:"",channel:"Facebook",source:"广告",payment:"Bank Transfer",erp:"",note:""};
  showDialog("order",id,order?"修改订单":"新增订单",`
    <div class="form-grid">${inputField("日期","date",entry.date,"date",true,`max="${window.DwellTasks?.today()||TODAY}"`)}${selectField("订单性质","nature",[["formal","正式订单"],["inquiry","潜在咨询"]],entry.nature,true)}
    <label class="field full"><span>所属主页 *</span><select name="pageId" required>${pageOptions(entry.pageId||'')}</select></label>
    ${selectField("产品配套","skuId",state.skus.filter(sku=>sku.active||sku.id===entry.skuId).map(sku=>[sku.id,sku.name]),entry.skuId,true)}${inputField("配套份数","quantity",entry.quantity,"number",true,'min="1" max="1000" step="1"')}
    </div><div id="order-money"><hr class="form-divider"><div class="form-section-title">订单金额</div><div class="form-grid">${selectField("币种","currency",[["MYR","马币 MYR"],["SGD","新币 SGD"]],entry.currency,true)}${inputField("商品 / 配套金额","subtotal",(entry.subtotal/100).toFixed(2),"number",true,'min="0" step="0.01"')}${inputField("收费运费","shipping",(entry.shipping/100).toFixed(2),"number",false,'min="0" step="0.01"')}${inputField("优惠券抵扣","voucher",(entry.voucher/100).toFixed(2),"number",false,'min="0" step="0.01"')}${inputField("其他折扣","discount",(entry.discount/100).toFixed(2),"number",false,'min="0" step="0.01"')}${selectField("支付方式","payment",[["","请选择"],["Bank Transfer","Bank Transfer"],["COD","COD"],["TNG","TNG"],["Cash","Cash"],["credit card","credit card"]],entry.payment,true)}</div><div class="computed-total"><div><span>订单 GMV</span><small id="conversion"></small></div><strong id="order-total"></strong></div></div>
    <hr class="form-divider"><div class="form-section-title">客户资料</div><div class="form-grid">${selectField("关联客户","customerId",[["","新客户 / 未关联"],...state.customers.map(customer=>[customer.id,customer.name])],entry.customerId)}${inputField("客户姓名","customerName",entry.customerName,"text",true,'maxlength="80"')}${inputField("电话号码","phone",entry.phone,"tel",true,'pattern="6[0-9]{7,15}" title="电话号码须以 6 开头，支持马来西亚 60 和新加坡 65"')}${selectField("平台渠道","channel",[["Facebook","Facebook"],["WhatsApp","WhatsApp"],["Instagram","Instagram"],["网站","网站"],["CALL","CALL"]],entry.channel,true)}${inputField("邮寄地址","address",entry.address,"text",true,'data-full maxlength="300"')}${selectField("来源","source",[["","请选择"],["广告","广告"],["朋友介绍","朋友介绍"],["自行询问","自行询问"],["repeat order","repeat order"]],entry.source,true)}${inputField("ERP 订单 ID","erp",entry.erp,"text",true,'maxlength="80"')}
    ${inputField('Tracking Number（运单号）','trackingNumber',entry.trackingNumber||'','text',false,'data-full maxlength="100"')}
    <label class="field full"><span>订单备注</span><textarea name="note" rows="2" maxlength="500">${escapeHtml(entry.note)}</textarea></label></div>`,order?`${order.id} · 版本 ${order.revision}`:"演示订单 · 不写入正式系统");
  $('#dialog-body').insertAdjacentHTML('beforeend',window.DwellTasks?.orderFields(entry)||'');
  $('#dialog-body').insertAdjacentHTML('beforeend',window.DwellPromotions?.orderFields(entry)||'');
  field('channel').closest('label').querySelector('span').textContent='本单下单平台 *';
  orderCustomerMatch={manual:!!entry.customerId,filled:{}};
  field('phone').setAttribute('aria-describedby','order-customer-match');
  field('phone').closest('label').insertAdjacentHTML('beforeend','<small id="order-customer-match" role="status" aria-live="polite" hidden></small>');
  matchOrderCustomer();
  if(convert&&order?.nature==='inquiry')field('nature').value='formal';
  refreshOrderForm();
}
function refreshOrderForm() {
  window.DwellTasks?.refreshForm();
  window.DwellPromotions?.refreshOrderForm();
  const inquiry=value("nature")==="inquiry";
  $("#order-money").hidden=inquiry;
  ["customerName","phone","address","erp","source","payment","subtotal","currency"].forEach(name=>{field(name).required=!inquiry;});
  $$("#order-money input,#order-money select").forEach(input=>input.disabled=inquiry);
  if(!inquiry) {
    try {const amount=moneyInput("subtotal")+moneyInput("shipping")-moneyInput("voucher")-moneyInput("discount");$("#order-total").textContent=`${currencyLabel(value("currency"))} ${fmt(amount)}`;$("#conversion").textContent=value("currency")==="SGD"?`佣金销售额 RM ${fmt(amount*3)} · SGD ×3`:`含运费 · 已扣优惠券和折扣`;}
    catch {$("#order-total").textContent="金额待确认";}
  }
  for(const name of ["customerName","phone","address","erp","source"]) {
    const label=field(name).closest("label").querySelector("span");
    label.textContent=label.textContent.replace(/ \*$/,"")+(!inquiry?" *":"");
  }
}
function saveOrder() {
  const previous=state.orders.find(order=>order.id===dialogId);
  if(previous?.nature==='formal'&&value('nature')==='inquiry')throw new Error('正式订单不能改回咨询，请使用取消流程');
  const pageId=value('pageId');if(!state.pages.some(page=>page.id===pageId&&(page.active!==false||previous?.pageId===pageId)))throw new Error('请选择启用中的订单所属主页');
  const nature=value("nature"), sku=state.skus.find(row=>row.id===value("skuId"));
  const quantity=Number(value("quantity"));
  if(!sku||!Number.isInteger(quantity)||quantity<1||quantity>1000) throw new Error("请选择产品及有效配套份数");
  const date=value("date");if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||date>(window.DwellTasks?.today()||TODAY))throw new Error("请选择有效订单日期");
  const phone=value("phone");if(phone&&!/^6\d{7,15}$/.test(phone))throw new Error("电话号码必须以 6 开头");
  const currency=value("currency")||"MYR";
  const subtotal=nature==="formal"?moneyInput("subtotal"):0,shipping=nature==="formal"?moneyInput("shipping"):0,voucher=nature==="formal"?moneyInput("voucher"):0,discount=nature==="formal"?moneyInput("discount"):0;
  const total=subtotal+shipping-voucher-discount;
  if(nature==="formal"&&total<=0)throw new Error("正式订单最终金额必须大于 0");
  if(value("erp")&&state.orders.some(order=>order.erp===value("erp")&&order.id!==dialogId))throw new Error("这个 ERP 订单 ID 已存在");
  const trackingNumber=value('trackingNumber');
  if(/\s|:\/\//.test(trackingNumber))throw new Error('Tracking 只填写运单号码，不填写链接或空格');
  const taskData=window.DwellTasks?.readOrder(previous,date)||{};
  const promotionData=window.DwellPromotions?.validateOrder(previous)||{};
  let customer=state.customers.find(row=>row.id===value("customerId"));
  const matches=phone?state.customers.filter(row=>row.phones.includes(phone)):[];
  if(!customer&&matches.length===1)customer=matches[0];
  if(matches.some(row=>customer&&row.id!==customer.id)||matches.length>1)throw new Error("此电话关联其他客户，请先核对客户身份");
  if(!customer&&phone) {customer={id:`DEMO-C${String(state.customers.length+1).padStart(3,"0")}`,name:value("customerName")||"未留姓名",phones:[phone],addresses:value("address")?[value("address")]:[],channel:value("channel"),identity:""};state.customers.push(customer);}
  const order={id:previous?.id||`DEMO-${String(100+state.orders.length).padStart(4,"0")}`,date,nature,skuId:sku.id,skuName:sku.name,line:sku.line,quantity,units:sku.units,currency,subtotal,shipping,voucher,discount,total,rate:currency==="SGD"?3:1,customerId:customer?.id||"",customerName:value("customerName"),phone,address:value("address").replace(/\s+/g," "),channel:value("channel"),source:value("source"),payment:nature==="formal"?value("payment"):"",erp:value("erp"),note:value("note"),staff:previous?.staff||"管理员预览",status:nature==="inquiry"?"inquiry":"confirmed",revision:(previous?.revision||0)+1};
  order.trackingNumber=trackingNumber;
  order.pageId=pageId;
  if(previous&&previous.skuId===order.skuId){order.skuName=previous.skuName;order.units=previous.units;order.line=previous.line;}
  Object.assign(order,taskData);
  order.staff=previous?.staff||window.DwellPayments?.actorName()||'管理员预览';
  order.mailbox_id=previous?.mailbox_id||'';order.psid=previous?.psid||'';
  if(previous)state.orders[state.orders.indexOf(previous)]=order;else state.orders.push(order);
  window.DwellPromotions?.commitOrder(order,previous,promotionData);
  state.month=date.slice(0,7);state.search="";state.status="all";state.currency="all";state.line="all";
  dialog.close();state.view="orders";render();toast(previous?"演示订单已更新，HR 汇总已重算":"演示订单已保存，客户资料已关联");
}
function cancelDialog(id) {
  const order=state.orders.find(row=>row.id===id);
  if(!order||order.status!=="confirmed")return;
  showDialog("cancel",id,"取消 / COD 拒收",`<div class="summary-line"><span>${escapeHtml(order.id)} · 原订单金额</span><strong>RM ${fmt(orderMyr(order))}</strong></div><div class="form-grid" style="margin-top:20px">${selectField("处理类型","kind",[["cancelled","取消订单"],["rejected","COD 拒收"]],"cancelled",true)}${inputField("确认日期","confirmedDate",TODAY,"date",true,`min="${order.date}" max="${TODAY}"`)}<label class="field full"><span>原因 *</span><textarea name="reason" required rows="3" maxlength="300"></textarea></label></div><div class="notice">扣减计入确认日期所在月份。原订单保留，不删除。</div>`,`${order.id} · 模拟扣减`);
  field('confirmedDate').value=window.DwellTasks?.today()||TODAY;field('confirmedDate').max=window.DwellTasks?.today()||TODAY;
}
function saveCancellation() {
  const order=state.orders.find(row=>row.id===dialogId);
  if(!order||order.status!=="confirmed")throw new Error("这笔订单已处理，不能重复扣减");
  const date=value("confirmedDate");if(date<order.date||date>(window.DwellTasks?.today()||TODAY))throw new Error("确认日期不在有效范围内");
  order.status=value("kind");order.revision++;
  window.DwellTasks?.closeForCancellation(order);
  window.DwellPromotions?.orderCancelled(order);
  state.adjustments.push({id:`adj-${order.id}`,orderId:order.id,pageId:order.pageId||'',line:order.line,date,kind:order.status,amount:orderMyr(order),reason:value("reason")});
  dialog.close();render();toast(`模拟扣减已计入 ${date.slice(0,7)}，原订单保留`);
}
function customerDialog(id,edit=false) {
  const customer=state.customers.find(row=>row.id===id);
  if(customer&&!edit) {
    const orders=state.orders.filter(order=>order.customerId===id).sort((a,b)=>b.date.localeCompare(a.date));
    showDialog("detail",id,customer.name,`<div class="customer-header"><span class="avatar">${escapeHtml(customer.name.slice(-1))}</span><div><strong>${escapeHtml(customer.id)}</strong><div style="margin-top:5px">${platformTags(customer)}</div></div></div><dl class="detail-grid"><div><dt>电话号码</dt><dd>${customer.phones.map(phone=>`<span class="inline-tag">${escapeHtml(phone)}</span>`).join("")||"—"}</dd></div><div><dt>平台身份</dt><dd>${escapeHtml(customer.identity||"未绑定")}</dd></div><div style="grid-column:1/-1"><dt>地址</dt><dd>${customer.addresses.map(address=>escapeHtml(address)).join("<br>")||"—"}</dd></div></dl><div class="section-title"><h3>订单记录</h3><button type="button" class="secondary" data-action="edit-customer" data-id="${customer.id}">${icon("square-pen")}编辑客户</button></div>${orderTable(orders,true)}`,"客户档案 · 模拟数据");
    dialog.classList.add('customer-detail-dialog');
    $('.customer-header').insertAdjacentHTML('afterend',window.DwellCRM?.customerSummary(id)||'');
    $('#dialog-body').insertAdjacentHTML('beforeend',window.DwellPromotions?.customerRewards(id)||'');
    return;
  }
  showDialog("customer",id,customer?"编辑客户":"新增客户",`<div class="form-grid">${inputField("客户姓名","name",customer?.name||"","text",true,'maxlength="80"')}${selectField("平台渠道","channel",[["Facebook","Facebook"],["WhatsApp","WhatsApp"],["Instagram","Instagram"],["网站","网站"]],customer?.channel||"Facebook",true)}${inputField("电话号码 1","phone1",customer?.phones[0]||"","tel",true,'pattern="6[0-9]{7,15}" title="以 6 开头的电话号码"')}${inputField("电话号码 2","phone2",customer?.phones[1]||"","tel",false,'pattern="6[0-9]{7,15}"')}${inputField("地址 1","address1",customer?.addresses[0]||"","text",false,'data-full maxlength="300"')}${inputField("地址 2","address2",customer?.addresses[1]||"","text",false,'data-full maxlength="300"')}</div>`,customer?.id||"独立客户 ID · 模拟数据");
}
function saveCustomer() {
  const customer=state.customers.find(row=>row.id===dialogId);
  const phones=[...new Set([value("phone1"),value("phone2")].filter(Boolean))];
  if(phones.some(phone=>!/^6\d{7,15}$/.test(phone)))throw new Error("电话号码必须以 6 开头");
  if(state.customers.some(row=>row.id!==dialogId&&row.phones.some(phone=>phones.includes(phone))))throw new Error("电话已关联其他客户，不能自动合并");
  const record={id:customer?.id||`DEMO-C${String(state.customers.length+1).padStart(3,"0")}`,name:value("name"),phones,addresses:[value("address1"),value("address2")].filter(Boolean).map(address=>address.replace(/\s+/g," ")),channel:value("channel"),identity:customer?.identity||""};
  if(customer)state.customers[state.customers.indexOf(customer)]=record;else state.customers.push(record);
  dialog.close();render();toast("演示客户资料已保存，旧订单快照保持不变");
}
function productDialog(id) {
  const sku=state.skus.find(row=>row.id===id);
  showDialog("product",id,sku?"修改 SKU":"新增 SKU",`<div class="form-grid">${inputField("SKU 编号","code",sku?.code||"","text",true,'maxlength="50"')}${choiceField('产品名称','productName',lineName(sku?.line||'gamat'),'products',true,'maxlength="80"')}${selectField('所属主页','skuPageId',[['','通用（下单时选择主页）'],...state.pages.filter(page=>page.active!==false||page.id===sku?.pageId).map(page=>[page.id,page.name])],sku?.pageId||'')}${choiceField("配套名称","name",sku?.name||"","packages",true,'data-full maxlength="100"')}${inputField("每份产品数量","units",sku?.units||1,"number",true,'min="1" max="1000" step="1"')}${selectField("状态","active",[["yes","启用"],["no","停用"]],sku?.active===false?"no":"yes")}${inputField("马币价格 MYR","myr",((sku?.myr||0)/100).toFixed(2),"number",true,'min="0.01" step="0.01"')}${inputField("新币价格 SGD","sgd",((sku?.sgd||0)/100).toFixed(2),"number",true,'min="0.01" step="0.01"')}</div><div class="notice">修改价格只影响之后的新订单，旧订单金额不变。</div>`,"演示 SKU · 价格为模拟值");
}
function saveProduct() {
  const sku=state.skus.find(row=>row.id===dialogId);
  const productName=value('productName').replace(/\s+/g,' '),skuPageId=value('skuPageId');
  if(!productName||productName.length>80)throw new Error('请填写产品名称');
  if(skuPageId&&!state.pages.some(page=>page.id===skuPageId&&(page.active!==false||sku?.pageId===skuPageId)))throw new Error('请选择启用中的主页');
  if(state.skus.some(row=>row.id!==dialogId&&row.code.toLowerCase()===value("code").toLowerCase()))throw new Error("SKU 编号已存在");
  const units=Number(value("units"));if(!Number.isInteger(units)||units<1||units>1000)throw new Error("数量须为 1 到 1000 的整数");
  const product=state.lines.find(line=>choiceKey(line.name)===choiceKey(productName))||{id:`product-${crypto.randomUUID()}`,name:productName};
  const record={id:sku?.id||`s${state.skus.length+1}`,code:value("code"),name:value("name"),line:product.id,pageId:skuPageId,units,myr:moneyInput("myr"),sgd:moneyInput("sgd"),active:value("active")==="yes"};
  if(record.myr<=0||record.sgd<=0)throw new Error("请填写正数价格");
  if(!state.lines.some(line=>line.id===product.id))state.lines.push(product);
  if(sku)state.skus[state.skus.indexOf(sku)]=record;else state.skus.push(record);
  dialog.close();render();toast("模拟 SKU 已保存，旧订单金额没有改变");
}
async function copyText(text,message,fallbackElement=null) {
  try {await navigator.clipboard.writeText(text);toast(message);}
  catch {const area=document.createElement("textarea");area.value=text;area.style.position="fixed";area.style.left="-9999px";(document.querySelector("dialog[open]")||document.body).append(area);area.select();let copied=false;try{copied=document.execCommand("copy");}catch{}finally{area.remove();}if(copied)toast(message);else {const target=fallbackElement||$("#hr-text");target?.focus();target?.select();toast(target?"浏览器未允许复制，请手动复制选中的文本":"浏览器未允许复制，请检查剪贴板权限");}}
}
window.previewAction=(action,id)=>{
  try {
    if(action.startsWith('catalog-')){void window.DwellCatalog?.action(action,id);return;}
    if(action.startsWith('follow-')){void window.DwellFollowups?.action(action,id);return;}
    if(action.startsWith('cloud-')){void window.DwellOperations?.action(action,id);return;}
    if(action.startsWith("ops-")){void window.DwellPayments?.action(action,id);return;}
    if(!demoView(state.view)&&action!=='open-hr')return;
    if(action.startsWith('promo-')){window.DwellPromotions?.action(action,id);return;}
    if(action.startsWith('task-')){window.DwellTasks?.action(action,id);return;}
    if(action==="new-order")orderDialog();
    else if(action==="edit-order")orderDialog(id);
    else if(action==="cancel-order")cancelDialog(id);
    else if(action==="customer"&&id)customerDialog(id);
    else if(action==="edit-customer")customerDialog(id,true);
    else if(action==="new-customer")customerDialog(null,true);
    else if(action==="edit-product")productDialog(id);
    else if(action==="new-product")productDialog();
    else if(action==="new-page")pageDialog();
    else if(action==="edit-page")pageDialog(id);
    else if(action==="copy-hr")void copyText(getHrExport().text,`${pageName(state.hrPage)} · 整月模拟销售额已复制`);
    else if(action==="copy-cancelled")void copyText((getHrExport().cancelled/100).toFixed(2),`${pageName(state.hrPage)} · 模拟取消金额已复制`);
    else if(action==="download-hr"){
      const url=URL.createObjectURL(new Blob(["\uFEFF"+getHrExport().text],{type:"text/tab-separated-values;charset=utf-8"}));
      const link=document.createElement("a");link.href=url;link.download=`DEMO-HR-${state.hrPage}-${state.hrMonth}.tsv`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
    }
    else if(action==="open-hr") window.open("https://production.d2br4xy4jidbhe.amplifyapp.com/","_blank","noopener,noreferrer");
  }catch(error){toast(error.message);}
};
document.addEventListener("click",event=>{if(event.target.closest("[data-close]"))dialog.close();});
dialog.addEventListener("click",event=>{if(event.target===dialog)dialog.close();});
form.addEventListener("submit",event=>{
  event.preventDefault();
  if(dialogKind.startsWith('catalog-')){void window.DwellCatalog?.submit(dialogKind,dialogId);return;}
  if(dialogKind==='follow-process'){void window.DwellFollowups?.submit();return;}
  if(dialogKind==='performance-entry'){void window.DwellPerformance?.submit();return;}
  if(dialogKind.startsWith('referral-')){void window.DwellReferrals?.submit();return;}
  if(dialogKind.startsWith('lucky-')){void window.DwellLucky?.submit();return;}
  if(dialogKind.startsWith('cloud-')){void window.DwellOperations?.submit(dialogKind,dialogId);return;}
  if(dialogKind.startsWith('promo-')){try{window.DwellPromotions.submit(dialogKind,dialogId);}catch(error){$('#form-error').textContent=error.message;}return;}
  try {if(dialogKind.startsWith("ops-")){void window.DwellPayments.submit(dialogKind,dialogId);return;}if(dialogKind==='task-process'){window.DwellTasks.submit(dialogId);return;}if(dialogKind==="order")saveOrder();else if(dialogKind==="customer")saveCustomer();else if(dialogKind==="product")saveProduct();else if(dialogKind==="page")savePage();else if(dialogKind==="cancel")saveCancellation();}
  catch(error){$("#form-error").textContent=error.message;}
});
form.addEventListener("change",event=>{
  if(dialogKind.startsWith('promo-')){window.DwellPromotions?.refreshForm();return;}
  if(dialogKind==='task-process'){window.DwellTasks?.refreshProcess();return;}
  if(dialogKind!=="order")return;
  if(event.target.name==="customerId") {
    orderCustomerMatch={manual:!!value('customerId'),filled:{}};
    const customer=state.customers.find(row=>row.id===value("customerId"));
    if(customer){field("customerName").value=customer.name;field("phone").value=customer.phones[0]||"";field("address").value=customer.addresses[0]||"";}
    matchOrderCustomer();
  }
  if(event.target.name==='phone')matchOrderCustomer();
  if(["skuId","quantity","currency"].includes(event.target.name)) {
    const sku=state.skus.find(row=>row.id===value("skuId"));
    if(event.target.name==='skuId'&&!value('pageId')&&state.pages.some(page=>page.id===sku?.pageId&&page.active!==false))field('pageId').value=sku.pageId;
    if(sku)field("subtotal").value=(((value("currency")==="SGD"?sku.sgd:sku.myr)*Number(value("quantity")||1))/100).toFixed(2);
  }
  refreshOrderForm();
});
form.addEventListener("input",event=>{if(dialogKind==="order"){if(event.target.name==='phone')matchOrderCustomer();refreshOrderForm();}});
document.addEventListener("change",event=>{
  if(event.target.id==="product-line"){state.line=event.target.value;render();}
  if(event.target.id==='hr-page'){state.hrPage=event.target.value;render();}
  if(event.target.id==="hr-month") {const month=event.target.value;if(!month||month>DEMO_MONTH){event.target.value=state.hrMonth;toast("请选择演示日期之前的月份");return;}state.hrMonth=month;render();}
});
document.addEventListener("input",event=>{
  if(event.target.id==="customer-search"){const position=event.target.selectionStart;state.search=event.target.value;render();$("#customer-search").focus();$("#customer-search").setSelectionRange(position,position);}
});
$("#reset-demo").addEventListener("click",()=>{
  if(!demoView(state.view))return;
  if(window.confirm("恢复活动演示资料？只清除活动模拟修改，不影响 Supabase 和旧系统。")){const view=state.view;dialog.close();seed();state.view=view;render();toast("已恢复模拟资料，云端资料未改动");}
});
window.addEventListener('hashchange',()=>{state.view=canonicalView(location.hash.slice(1));render();});
document.addEventListener('DOMContentLoaded',()=>{state.view=canonicalView(location.hash.slice(1));render();});

if(document.modelContext?.registerTool) {
  const lifecycle=new AbortController();
  window.addEventListener("pagehide",()=>lifecycle.abort(),{once:true});
  for(const tool of [
    {name:"open_preview_section",title:"打开后台页面",description:"Navigate to authenticated Supabase business pages. Navigation does not mutate records.",inputSchema:{type:"object",properties:{section:{type:"string",enum:["orders","customers","products","payments","hr"]}},required:["section"],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute(input){if(!input||!["orders","customers","products","payments","hr"].includes(input.section))throw new Error("Invalid section");state.view=input.section;render();return {section:state.view,simulated:false,cloudConfigured:!!window.DwellPayments?.configured};}}
  ])try {Promise.resolve(document.modelContext.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}
}
