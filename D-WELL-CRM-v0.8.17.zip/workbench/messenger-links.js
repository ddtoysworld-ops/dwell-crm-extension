"use strict";
window.DwellMessenger=(()=>{
  const id=v=>typeof v==='string'&&/^[0-9]{5,30}$/.test(v),safe=escapeHtml;
  // Same business account and legacy field mapping as the packing-photo system.
  const businessId='618894482700430';
  const rpc=(action,body)=>window.DwellPayments.messengerRpc(action,body);
  let generation=0;
  function url(link){
    if(!link||link.available===false||!id(link.mailbox_id)||!id(link.psid))return '';
    const u=new URL('https://business.facebook.com/latest/inbox/messenger');
    u.searchParams.set('asset_id',link.mailbox_id);u.searchParams.set('business_id',businessId);
    u.searchParams.set('thread_type','FB_MESSAGE');u.searchParams.set('mailbox_id',link.mailbox_id);u.searchParams.set('selected_item_id',link.psid);
    return u.href;
  }
  function button(link){
    const href=url(link);
    return href?`<a class="text-button" href="${safe(href)}" target="_blank" rel="noopener noreferrer">打开 Messenger</a>`:
      `<small>${link?.available===false?'Messenger 资料不一致或已停用，待核对':'尚未关联 Messenger 对话'}</small>`;
  }
  function clear(){generation++;}
  async function lookup(rows){
    const pairs=rows.filter(r=>['facebook','messenger'].includes(String(r.platform).toLowerCase())).map(r=>({customer_id:r.customer_id,page_id:r.page_id}));
    if(!pairs.length)return [];
    return (await rpc('lookup',{pairs})).items;
  }
  async function mount(c){
    const token=++generation;
    ($('#profile-messenger-slot')||$('#dialog-body')).insertAdjacentHTML('beforeend','<div id="messenger-profile"><h4>Messenger 对话</h4><p>读取中…</p></div>');
    try{
      const data=await rpc('list',{customer_id:c.id});
      if(token!==generation||!(window.DwellPayments?.canCoreAction?.('messenger','lookup')??window.DwellPayments?.canManagePages())||!dialog.open||dialogKind!=='detail'||dialogId!==c.id||!$('#messenger-profile'))return;
      $('#messenger-profile').innerHTML=`<h4>Messenger 对话</h4>${data.items.length?data.items.map(l=>`<p>${safe(l.page_name)} · ${button(l)}</p>`).join(''):'<p class="profile-note">尚未关联 Messenger 对话</p>'}`;
    }catch(e){if(token===generation&&$('#messenger-profile'))$('#messenger-profile').innerHTML='<p role="alert">Messenger 资料读取失败，请重新打开客户档案。</p>';}
  }
  return {url,button,lookup,mount,clear};
})();
