"use strict";
window.DwellSkuForms=(()=>{
  const safe=escapeHtml;
  let singles=[];
  function componentRow(c={}){
    return `<div class="component-row"><label class="field component-product"><span>单品 SKU</span><select data-component-sku required><option value="">请选择单品</option>${singles.map(s=>`<option value="${s.id}" ${s.id===c.sku_id?'selected':''}>${safe(s.code+' · '+s.name+(s.active?'':'（停用）'))}</option>`).join('')}</select></label><label class="field"><span>数量</span><input data-component-quantity type="number" min="1" max="1000" step="1" required value="${c.quantity||1}"></label><label class="field"><span>用途</span><select data-component-role><option value="main" ${c.role!=='gift'?'selected':''}>主商品</option><option value="gift" ${c.role==='gift'?'selected':''}>赠品</option></select></label><label class="field component-group"><span>任选赠品组（选填）</span><input data-component-group maxlength="40" value="${safe(c.choice_group||'')}" list="gift-group-options"></label><button type="button" class="icon-button" data-component-remove title="移除单品" aria-label="移除单品">${icon('trash-2')}</button></div>`;
  }
  function catalogFields(r,kind,options){
    singles=options.filter(s=>s.sku_kind==='single');
    return `<div class="form-grid">${kind==='single'?inputField('计量单位','unit_label',r?.unit_label||'瓶','text',true,'maxlength="12"'):''}</div>${window.DwellSkuSales.fields(r)}${kind==='bundle'?`<h3 class="section-title">配套商品</h3><div id="bundle-components">${(r?.components?.length?r.components:[{}]).map(componentRow).join('')}</div><datalist id="gift-group-options"><option value="任选赠品"></option></datalist><button type="button" class="secondary" data-component-add>${icon('plus')}添加单品</button>`:''}<hr class="form-divider"><h3 class="form-section-title">服用到期跟进</h3><div class="form-grid">${kind==='bundle'?window.DwellBundleConsumption.field(r?.components||[],singles):inputField('每份预计可服用天数（留空不启用）','consumption_days',r?.consumption_days??'','number',false,'min="1" max="3650" step="1"')}</div>`;
  }
  function read(kind){
    const components=kind==='bundle'?[...document.querySelectorAll('#bundle-components .component-row')].map(el=>({sku_id:el.querySelector('[data-component-sku]').value,quantity:Number(el.querySelector('[data-component-quantity]').value),role:el.querySelector('[data-component-role]').value,choice_group:el.querySelector('[data-component-group]').value.trim()})):[];
    return {sku_kind:kind,unit_label:kind==='single'?value('unit_label'):'份',units:kind==='single'?1:components.filter(c=>c.role==='main').reduce((sum,c)=>sum+c.quantity,0),...window.DwellSkuSales.read(),components,consumption_days:kind==='bundle'?null:(value('consumption_days')?Number(value('consumption_days')):null),followup_lead_days:0};
  }
  function details(lines,quantity=1){
    return `<ul class="component-details">${lines.map(c=>`<li><span>${safe(c.code+' · '+c.name)}</span><strong>${c.quantity*quantity} ${safe(c.unit_label||'件')}</strong><span class="pill ${c.role==='gift'?'warning':'neutral'}">${c.role==='gift'?'赠品':'主商品'}</span></li>`).join('')}</ul>`;
  }
  function orderMarkup(s,order,qty,isGift=false){
    if(isGift){
      s=s?{...s,components:s.components?.map(c=>({...c,role:'gift'}))}:s;
      if(order)order={...order,items_snapshot:order.items_snapshot?.map(c=>({...c,role:'gift'}))};
    }
    if(order&&s?.id===order.sku_id)return order.items_snapshot?.length?`<h3 class="section-title">本单商品明细</h3>${details(order.items_snapshot,qty)}`:'<div class="notice">旧版订单 · 未记录单品组成</div>';
    if(!s||s.sku_kind==='legacy')return '';
    if(s.sku_kind==='single')return `<h3 class="section-title">本单商品</h3>${details([{...s,quantity:1,role:isGift?'gift':'main'}],qty)}`;
    const groups=new Map();for(const c of s.components||[])if(c.choice_group){if(!groups.has(c.choice_group))groups.set(c.choice_group,[]);groups.get(c.choice_group).push(c);}
    return `<h3 class="section-title">配套商品明细</h3>${details((s.components||[]).filter(c=>!c.choice_group),qty)}<div class="form-grid">${[...groups].map(([g,items])=>`<label class="field full"><span>${safe(g)} *</span><select data-order-choice="${safe(g)}" required><option value="">请选择赠品</option>${items.map(c=>`<option value="${c.sku_id}" ${c.active?'':'disabled'}>${safe(c.name)} × ${c.quantity*qty} ${safe(c.unit_label)}${c.active?'':'（停用）'}</option>`).join('')}</select></label>`).join('')}</div>`;
  }
  function choices(){return Object.fromEntries([...document.querySelectorAll('[data-order-choice]')].map(el=>[el.dataset.orderChoice,el.value]));}
  document.addEventListener('click',e=>{
    const add=e.target.closest('[data-component-add]'),remove=e.target.closest('[data-component-remove]');
    if((!add&&!remove)||!dialogKind.startsWith('catalog-')||$('#save-button').disabled)return;
    if(add){$('#bundle-components').insertAdjacentHTML('beforeend',componentRow());icons();}
    if(remove)remove.closest('.component-row').remove();
  });
  return {catalogFields,read,orderMarkup,choices,details};
})();
