"use strict";
window.DwellSkuCost=(()=>{
 let singles=[];
 function calculate(components,options){
  if(!components.length)return {complete:false};
  const groups=new Map();
  for(const [i,c] of components.entries()){
   const s=options.find(s=>s.id===c.sku_id),q=Number(c.quantity);
   if(s?.cost_myr_minor==null||!Number.isInteger(q)||q<1)return {complete:false};
   const key=c.choice_group?.trim()||`fixed:${i}`;
   if(!groups.has(key))groups.set(key,[]);groups.get(key).push(s.cost_myr_minor*q);
  }
  return {complete:true,minimum_minor:[...groups.values()].reduce((s,v)=>s+Math.min(...v),0),maximum_minor:[...groups.values()].reduce((s,v)=>s+Math.max(...v),0)};
 }
 function label(c){return c?.complete?`RM ${fmt(c.minimum_minor)}${c.maximum_minor!==c.minimum_minor?' – RM '+fmt(c.maximum_minor):''}`:'成本未齐';}
 function fields(r,kind,options){
  singles=options;
  return `<h3 class="form-section-title">商品成本 · MYR</h3><div class="form-grid">${kind==='bundle'?`<div class="field full"><span>每份配套成本 · 含赠品</span><output id="bundle-cost-total">${label(calculate(r?.components||[],singles))}</output></div>`:inputField('每份商品成本 RM（留空为未设置）','cost_myr',r?.cost_myr_minor==null?'':r.cost_myr_minor/100,'number',false,'min="0" max="100000000" step="0.01"')}</div>`;
 }
 function read(kind){return {cost_myr_minor:kind==='bundle'||value('cost_myr')===''?null:moneyInput('cost_myr')};}
 function update(){const out=document.querySelector('#bundle-cost-total');if(!out)return;
  const parts=[...document.querySelectorAll('#bundle-components .component-row')].map(r=>({sku_id:r.querySelector('[data-component-sku]').value,quantity:r.querySelector('[data-component-quantity]').value,choice_group:r.querySelector('[data-component-group]').value}));
  out.textContent=label(calculate(parts,singles));
 }
 document.addEventListener('input',e=>{if(e.target.closest('#bundle-components'))update();});
 document.addEventListener('change',e=>{if(e.target.closest('#bundle-components'))update();});
 document.addEventListener('click',e=>{if(e.target.closest('[data-component-add],[data-component-remove]'))queueMicrotask(update);});
 return {fields,read,calculate,label};
})();
