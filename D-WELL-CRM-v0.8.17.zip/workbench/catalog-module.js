"use strict";
window.DwellCatalog=(()=>{
  const labels={pages:'主页',products:'产品分类',skus:'单品 SKU',bundles:'配套',legacy:'旧版 SKU',customers:'客户'};
  const isSku=k=>['skus','bundles','legacy'].includes(k);
  const skuKind=k=>({skus:'single',bundles:'bundle',legacy:'legacy'})[k];
  let entity='pages',rows=null,total=0,offset=0,query='',loading=false,busy=false,error='',generation=0;
  let editing=null,pending=null,options={pages:[],products:[],singles:[]};
  const can=action=>window.DwellPayments?.canCoreAction?.('catalog',action,isSku(entity)?'skus':entity)??window.DwellPayments?.canManagePages();
  const allowed=()=>can('list');
  const visible=()=>['pages','customers','products'].includes(state.view);
  const viewEntities=()=>state.view==='products'?['skus','bundles','products','legacy']:[state.view];
  function leave(){generation++;rows=null;loading=false;error='';}
  const rpc=(action,kind,payload)=>window.DwellPayments.catalogRpc(action,isSku(kind)?'skus':kind,{...payload,...(action==='list'&&isSku(kind)?{sku_kind:skuKind(kind)}:{})});
  const safe=escapeHtml;
  function clear(){generation++;rows=null;total=0;error='';loading=false;editing=null;pending=null;options={pages:[],products:[]};}
  function failure(e){
    const msg=String(e?.message||e);
    if(msg.includes('consumption_settings_invalid'))return '请检查单品服用天数（1 至 3650 天）及配套组成。';
    const saleErrors={sku_market_price_required:'开放销售的地区必须填写售价和运费。',sku_markets_invalid:'销售地区无效，请重新选择。',sku_shipping_invalid:'运费规则无效或同一地区份数重复，请核对。'};
    for(const [code,label] of Object.entries(saleErrors))if(msg.includes(code))return label;
    const codes={core_owner_required:'当前账号没有此操作权限，请联系管理员。',core_stale_version:'资料已被更新。请关闭此窗口并刷新后重新修改。',core_phone_conflict:'这个号码已属于另一位客户，请核对后再保存，不会自动合并。',core_contacts_invalid:'请核对电话号码和地址，不能重复；电话须含 60 / 65 国家码。',core_request_conflict:'本次保存内容已改变，请重新打开记录。',core_page_inactive:'主页已停用或不存在，请重新选择。',core_product_inactive:'产品已停用，请选择其他产品。',core_not_found:'记录不存在，请刷新。'};
    for(const [key,text] of Object.entries(codes))if(msg.includes(key))return text;
    const bundleErrors={bundle_components_invalid:'请填写有效单品、用途和数量。',bundle_main_required:'配套至少需要一个主商品，总数量不能超过 1000。',bundle_component_unavailable:'所选单品不存在、已停用或不是单品 SKU。',bundle_duplicate_component:'同一个单品、用途和赠品组不能重复添加。',bundle_choices_invalid:'任选赠品组至少需要两个选项，数量须一致，且用途须为赠品。',bundle_kind_immutable:'已有 SKU 的类型不能更换，请新建。'};
    for(const [code,msg] of Object.entries(bundleErrors))if(String(e?.message||e).includes(code))return msg;
    if(e?.code==='23505')return '名称、SKU 编号、主页编号或电话号码已存在，请核对。';
    if(['23514','23502','22P02','22003'].includes(e?.code))return '资料格式或数值不正确，请检查必填项、金额和数量。';
    if(e?.code==='PGRST202')return '云端资料接口尚未部署完成，暂时不能保存。';
    return '连接失败或操作结果尚未确认，请重试原请求，或刷新核对记录。';
  }
  async function refresh(){
    if(!allowed()){clear();return;}
    const token=++generation,kind=entity;loading=true;error='';if(visible())render();
    try{
      const data=await rpc('list',kind,{search:query,offset,limit:25});
      if(token!==generation||!allowed())return;
      rows=data.items;total=data.total;
    }catch(e){if(token===generation){rows=[];total=0;error=failure(e);}}
    finally{if(token===generation){loading=false;if(visible())render();}}
  }
  function rowMarkup(r){
    let fields='';
    if(entity==='pages')fields=`<td><strong>${safe(r.name)}</strong><small>${safe(r.id)}</small></td><td>${safe(r.mailbox_id||'未绑定')}</td>`;
    if(entity==='products')fields=`<td><strong>${safe(r.name)}</strong><small>${safe(r.id)}</small></td>`;
    if(isSku(entity))fields=`<td><strong>${safe(r.name)}</strong><small>${safe(r.code)}</small><small>${safe(window.DwellBundleConsumption.summary(r))}</small></td><td>${safe(r.product_name)}</td><td>${safe(r.page_name||'通用')}</td><td>${entity==='bundles'?`${r.components?.length||0} 个组成项`:safe(r.unit_label||'件')}</td><td>${window.DwellSkuSales.summary(r)}</td>`;
    if(entity==='customers')fields=`<td><strong>${safe(r.name)}</strong><small>${safe(r.id)}</small><div class="customer-row-actions"><button type="button" class="secondary" data-action="cloud-customer" data-id="${r.id}">${icon('contact')}查看客户档案</button>${can('save')?`<button type="button" class="secondary" data-action="cloud-delivery" data-id="${r.id}">${icon('map-pin')}管理收货资料</button>`:''}</div></td><td>${(r.phones||[]).map(safe).join('<br>')}</td><td>${safe(r.channel)}</td><td class="payment-note">${(r.addresses||[]).map(safe).join('<br>')||'—'}</td>`;
    return `<tr>${fields}<td><span class="pill ${r.active?'success':'neutral'}">${r.active?'启用':'已停用'}</span></td><td><div class="row-actions">${can('save')?`<button class="icon-button" data-action="catalog-edit" data-id="${r.id}" aria-label="修改 ${safe(r.name)}" title="修改">${icon('square-pen')}</button>`:''}${can('audit')?`<button class="icon-button" data-action="catalog-audit" data-id="${r.id}" aria-label="记录 ${safe(r.name)}" title="操作记录">${icon('history')}</button>`:''}</div></td></tr>`;
  }
  function render(){
    if(!visible())return;
    const skuView=state.view==='products',title={products:'SKU 与配套',pages:'主页管理',customers:'客户资料'}[state.view];
    if(!viewEntities().includes(entity)){entity=viewEntities()[0];query='';offset=0;clear();}
    if(!allowed()){$('#main').innerHTML=heading(title,'Supabase')+'<div class="empty">请使用获授权账号登录。<p><button class="primary" data-action="ops-account">后台账户</button></p></div>';return;}
    if(rows===null&&!loading){void refresh();return;}
    const columns=isSku(entity)?['名称 / SKU','产品分类','所属主页','组成 / 单位','价格']:{pages:['主页 / ID','mailbox_id'],products:['产品 / ID'],customers:['客户 / ID','电话号码','联系平台','地址']}[entity];
    $('#main').innerHTML=heading(title,'Supabase · 全部主页',`<div class="wide-actions"><button class="secondary" data-action="catalog-refresh" ${loading?'disabled':''}>${icon('refresh-cw')}刷新</button>${can('save')?`<button class="primary" data-action="catalog-new" ${loading||error?'disabled':''}>${icon('plus')}新增${labels[entity]}</button>`:''}</div>`)+
      (skuView?`<div class="payment-tabs" role="tablist" aria-label="SKU 资料类型">${viewEntities().map(key=>`<button role="tab" aria-selected="${key===entity}" data-action="catalog-tab" data-id="${key}">${labels[key]}</button>`).join('')}</div>`:'')+
      `<div class="notice">正式基础资料 · 与云端订单、客户分析共用。旧资料尚未完整导入；旧券及旧奖品只读，WordPress 抽奖未切换。</div>`+
      `${error?`<div class="alert-note" role="alert">${safe(error)}</div>`:''}<section class="data-surface"><div class="toolbar"><label class="search-field">${icon('search')}<input id="catalog-search" aria-label="搜索云端资料" placeholder="名称、SKU 或电话号码" maxlength="100" value="${safe(query)}"></label><button class="secondary" data-action="catalog-search">${icon('search')}搜索</button><span class="table-filter-result">${loading?'读取中…':`${total} 条`}</span></div><div class="table-scroll"><table><thead><tr>${[...columns,'状态','操作'].map(t=>`<th>${t}</th>`).join('')}</tr></thead><tbody>${(rows||[]).map(rowMarkup).join('')}</tbody></table>${!rows?.length?`<div class="empty">${loading?'正在读取…':error?'读取失败':'尚无记录'}</div>`:''}</div><div class="table-foot"><span>${total?offset+1:0}–${Math.min(offset+25,total)} / ${total}</span><div class="row-actions"><button class="icon-button" data-action="catalog-prev" ${offset===0||loading?'disabled':''} aria-label="上一页" title="上一页">${icon('chevron-left')}</button><button class="icon-button" data-action="catalog-next" ${offset+25>=total||loading?'disabled':''} aria-label="下一页" title="下一页">${icon('chevron-right')}</button></div></div></section>`;
    icons();
  }
  async function loadOptions(kind){
    const all=[];
    for(let start=0;;start+=100){
      const data=await rpc('list',kind,{offset:start,limit:100});all.push(...data.items);
      if(all.length>=data.total||data.items.length===0)return all;
    }
  }
  async function edit(id){
    if(!can('save'))throw new Error('core_owner_required');
    const r=id?rows.find(row=>row.id===id):null;
    if(id&&!r)throw new Error('core_not_found');
    const token=generation,kind=entity;
    if(isSku(kind)){
      options.pages=await loadOptions('pages');options.products=await loadOptions('products');
      options.singles=kind==='bundles'?await loadOptions('skus'):[];
      if(token!==generation||!allowed()||!visible())return;
    }
    editing=r;pending=null;
    let fields='';
    if(kind==='pages')fields=inputField('主页名称','name',r?.name||'','text',true,'data-full maxlength="80"')+inputField('Facebook mailbox_id','mailbox_id',r?.mailbox_id||'','text',false,'pattern="[0-9]{5,30}" maxlength="30"');
    if(kind==='products')fields=inputField('产品名称','name',r?.name||'','text',true,'data-full maxlength="80"');
    if(isSku(kind))fields=inputField('SKU 编号','code',r?.code||'','text',true,'maxlength="50"')+
      inputField('产品名称','product_name',r?.product_name||'','text',true,'list="catalog-products" maxlength="80"')+
      `<datalist id="catalog-products">${options.products.filter(p=>p.active||p.id===r?.product_id).map(p=>`<option value="${safe(p.name)}"></option>`).join('')}</datalist>`+
      inputField(kind==='skus'?'单品规格名称':'配套名称','name',r?.name||'','text',true,'data-full maxlength="100"')+
      selectField('所属主页','page_id',[['','通用'],...options.pages.filter(p=>p.active||p.id===r?.page_id).map(p=>[p.id,p.name])],r?.page_id||'')+
      (kind==='legacy'?inputField('每份产品数量','units',r?.units||1,'number',true,'min="1" max="1000" step="1"'):'');
    if(kind==='customers')fields=inputField('客户姓名','name',r?.name||'','text',true,'maxlength="80"')+
      selectField('主要联系平台','channel',[['Facebook','Facebook'],['WhatsApp','WhatsApp'],['Instagram','Instagram'],['网站','网站']],r?.channel||'Facebook',true)+
      `<label class="field full"><span>客户联系电话（每行一个，含国家码） *</span><textarea name="phones" required rows="3" maxlength="300">${safe((r?.phones||[]).join('\n'))}</textarea></label><label class="field full"><span>旧版未配对地址（每行一个）</span><textarea name="addresses" rows="3" maxlength="5010">${safe((r?.addresses||[]).join('\n'))}</textarea></label>`;
    fields+=selectField('状态','active',[['true','启用'],['false','停用']],String(r?.active??true));
    showDialog('catalog-'+kind,id,(r?'修改':'新增')+labels[kind],`<div class="form-grid">${fields}</div>${isSku(kind)?window.DwellSkuCost.fields(r,skuKind(kind),options.singles)+window.DwellSkuForms.catalogFields(r,skuKind(kind),options.singles):''}`,'正式资料 · 保存至 Supabase');
  }
  const auditLabels={name:'名称',code:'SKU',mailbox_id:'mailbox_id',product_id:'产品 ID',page_id:'主页 ID',sku_kind:'SKU 类型',unit_label:'单位',components:'配套组成',sale_markets:'开放销售地区',shipping_tiers:'数量运费规则',units:'每份数量',myr_minor:'MYR 金额（分）',em_minor:'东马金额（分）',sgd_minor:'SGD 金额（分）',shipping_myr_minor:'西马运费（分）',shipping_em_minor:'东马运费（分）',shipping_sgd_minor:'新加坡运费（分）',active:'启用',channel:'平台',phones:'电话',addresses:'地址'};
  async function action(cmd,id){
    Object.assign(auditLabels,{consumption_days:'每份服用天数',followup_lead_days:'提前跟进天数',cost_myr_minor:'每份商品成本 MYR（分）'});
    if(busy)return;
    try{
      if(!allowed())throw new Error('core_owner_required');
      if(cmd==='catalog-tab'){if(!viewEntities().includes(id))return;entity=id;query='';offset=0;rows=null;await refresh();}
      else if(cmd==='catalog-refresh')await refresh();
      else if(cmd==='catalog-search'){query=$('#catalog-search').value.trim();offset=0;await refresh();}
      else if(cmd==='catalog-next'||cmd==='catalog-prev'){offset=Math.max(0,offset+(cmd==='catalog-next'?25:-25));await refresh();}
      else if(cmd==='catalog-new'||cmd==='catalog-edit'){busy=true;await edit(id);}
      else if(cmd==='catalog-audit'){
        const token=generation,log=await rpc('audit',entity,{id});if(token!==generation||!allowed())return;
        showDialog('detail',id,'操作记录',log.length?`<ol class="audit-list">${log.map(entry=>`<li><strong>${safe(entry.actor_name)}</strong><small>${safe(new Date(entry.occurred_at).toLocaleString('zh-CN',{timeZone:'Asia/Kuala_Lumpur'}))}</small>${Object.entries(auditLabels).filter(([k])=>JSON.stringify(entry.before_data?.[k])!==JSON.stringify(entry.after_data?.[k])).map(([k,label])=>`<p>${label}：${safe(JSON.stringify(entry.before_data?.[k]??'—'))} → ${safe(JSON.stringify(entry.after_data?.[k]??'—'))}</p>`).join('')}</li>`).join('')}</ol>`:'<div class="empty">没有记录</div>','最近 50 次变更 · 马来西亚时间');
      }
    }catch(e){toast(failure(e));}finally{busy=false;}
  }
  async function submit(kind,id){
    if(busy||!kind.startsWith('catalog-'))return;
    const token=generation;
    try{
      if(!allowed())throw new Error('core_owner_required');
      if(!pending){
        const data={name:value('name'),active:value('active')==='true',id:id||undefined,version:editing?.version,request_id:crypto.randomUUID()};
        if(entity==='pages')data.mailbox_id=value('mailbox_id');
        if(isSku(entity))Object.assign(data,{code:value('code'),product_name:value('product_name'),page_id:value('page_id')},window.DwellSkuForms.read(skuKind(entity)),window.DwellSkuCost.read(skuKind(entity)),entity==='legacy'?{units:Number(value('units'))}:{});
        if(entity==='customers')Object.assign(data,{channel:value('channel'),phones:field('phones').value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean),addresses:field('addresses').value.split(/\r?\n/).map(s=>s.trim()).filter(Boolean)});
        pending={entity,body:data};
      }
      busy=true;$('#save-button').disabled=true;
      const saved=await rpc('save',pending.entity,pending.body);
      if(token!==generation||!allowed())return;
      pending=null;dialog.close();await refresh();toast(error?'资料已保存，但列表刷新失败，请再刷新核对':'已保存到 Supabase');
      return saved;
    }catch(e){
      if(token!==generation)return;
      const definite=/^[0-9A-Z]{5}$/.test(e?.code||'')&&!['PGRST','08006','08003'].some(prefix=>e.code.startsWith(prefix));
      if(definite)pending=null;
      if(pending)form.querySelectorAll('#dialog-body input,#dialog-body select,#dialog-body textarea').forEach(el=>{el.disabled=true;});
      $('#form-error').textContent=failure(e)+(pending?' 再点保存会重试同一份内容。':'');
    }finally{busy=false;$('#save-button').disabled=false;}
  }
  dialog.addEventListener('cancel',event=>{if(busy&&dialogKind.startsWith('catalog-'))event.preventDefault();});
  document.addEventListener('click',event=>{if(busy&&dialogKind.startsWith('catalog-')&&(event.target===dialog||event.target.closest('[data-close]'))){event.preventDefault();event.stopImmediatePropagation();}},true);
  document.addEventListener('keydown',event=>{if(event.target.id==='catalog-search'&&event.key==='Enter'){event.preventDefault();void action('catalog-search');}});
  return {render,action,submit,clear,leave};
})();
