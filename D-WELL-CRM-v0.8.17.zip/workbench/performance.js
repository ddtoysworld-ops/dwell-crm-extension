"use strict";
window.DwellPerformance=(()=>{
 const safe=escapeHtml,M=window.DwellPerformanceMetrics,allowed=()=>window.DwellPayments?.canManagePages();
 const today=()=>new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
 let month=today().slice(0,7),pageId='',tab='dashboard',pages=[],report=null,loading=false,error='',generation=0,busy=false,pending=null,editing=null;
 const money=n=>n==null?'—':'RM '+fmt(n),pct=n=>n==null?'—':(n*100).toFixed(1)+'%',multiple=n=>n==null?'—':n.toFixed(2)+'×';
 function leave(){generation++;loading=false;report=null;error='';pending=null;editing=null;pages=[];}
 function failure(e){const s=String(e?.message||e);
  if(s.includes('core_stale_version'))return '此日期资料已被更新，请关闭窗口并刷新后再修改。';
  if(s.includes('core_owner_required'))return '请使用主管理员账号登录。';
  if(e?.code==='PGRST202')return '经营看板接口尚未部署，暂不能读取或保存。';
  if(/performance_|23514|22P02/.test(s+' '+e?.code))return '请核对日期及数值：人数须为整数，新对话人数不能超过总对话人数。';
  return '连接失败，操作结果未确认，请刷新核对或重试。';
 }
 async function refresh(){
  if(!allowed()){leave();render(false);return;}const token=++generation;loading=true;error='';report=null;render(false);
  try{
   const ps=await DwellOperations.catalog('pages');
   const r=await DwellPayments.performanceRpc('report',{month,page_id:pageId});
   if(token!==generation||!allowed())return;pages=ps;report=r;
  }catch(e){if(token===generation)error=failure(e);}
  finally{if(token===generation){loading=false;render(false);}}
 }
 function render(fetch=true){
  if(state.view!=='performance')return;
  if(!allowed()){leave();$('#main').innerHTML=heading('经营看板','Supabase')+'<div class="empty">请使用主管理员账号登录。</div>';return;}
  if(fetch){void refresh();return;}
  $('#main').innerHTML=heading('经营看板','每日表现 · MYR',`<div class="wide-actions"><button class="secondary" data-perf="definitions">${icon('info')}统计口径</button><button class="secondary" data-perf="refresh" ${loading?'disabled':''}>${icon('refresh-cw')}刷新</button></div>`)+
   `<div class="payment-tabs" role="tablist" aria-label="经营看板视图"><button role="tab" data-perf="dashboard" aria-selected="${tab==='dashboard'}">业绩 Dashboard</button><button role="tab" data-perf="entry" aria-selected="${tab==='entry'}">每日录入</button></div>
   <div class="perf-filters"><label class="field"><span>月份</span><input type="month" id="perf-month" min="2000-01" max="${today().slice(0,7)}" value="${safe(month)}" ${loading?'disabled':''}></label><label class="field"><span>所属主页</span><select id="perf-page" ${loading?'disabled':''}><option value="">全部主页</option>${pages.map(p=>`<option value="${p.id}" ${p.id===pageId?'selected':''}>${safe(p.name)}${p.active?'':'（已停用）'}</option>`).join('')}</select></label></div>`+
   (loading?'<div class="empty" role="status">正在读取经营数据…</div>':error?`<div class="alert-note" role="alert">${safe(error)}</div>`:report?`<p class="perf-scope">试运行 · 仅已入库订单，历史尚不完整；ROI 为试算，首购与复购按已入库历史判断。<br>截至 ${dateLabel(report.through_date)} · 马来西亚时间</p>${tab==='entry'?entry():dashboard()}`:'');icons();
 }
 function dashboard(){
  const s=M.aggregate(report.daily,report.month_only_deductions),days=M.days(report.daily);
  return `<div class="stats perf-stats">${stat('销售额',money(s.gross),'正式订单 · 扣减前','wallet')}${stat('广告花费',money(s.spend),s.missingSpend?`${s.missingSpend} 个主页日待填，已录 ${money(s.enteredSpend)}`:'RM · 所选主页','megaphone','blue')}${stat('ROI · 试算',multiple(s.roi),'销售额 ÷ 广告费','chart-no-axes-combined')}${stat('复购订单',s.repeat,pct(s.repeatRate)+' · '+report.repeat_customers+' 位复购客户','repeat','rose')}</div>
   <div class="perf-secondary"><div><span>净销售额</span><strong>${money(s.net)}</strong><small>确认扣减 ${money(s.deduction)}</small></div><div><span>正式订单 / 当前有效</span><strong>${s.orders} / ${s.valid}</strong><small>平均客单 ${money(s.average)}</small></div><div><span>总对话 / 新对话</span><strong>${s.messages??'—'} / ${s.fresh??'—'}</strong><small>新对话占比 ${pct(s.newRate)}</small></div><div><span>每对话 / 每单广告成本</span><strong>${money(s.costPerConversation)} / ${money(s.costPerOrder)}</strong><small>每新对话 ${money(s.costPerNew)}</small></div></div>
   <section class="perf-profit"><h2>商品估算毛利</h2><div class="perf-secondary"><div><span>商品毛利额</span><strong>${money(s.profit)}</strong></div><div><span>商品毛利率</span><strong>${pct(s.margin)}</strong></div><div><span>扣广告后贡献</span><strong>${money(s.contribution)}</strong></div><div><span>成本完整订单</span><strong>${s.valid-s.missingCost} / ${s.valid}</strong></div></div><p class="crm-caption">商品净收入（不含收取运费）－商品成本，赠品计成本；未扣实际物流、手续费与税费，不是净利润。${s.missingCost?' '+s.missingCost+' 笔有效订单缺成本，暂不显示整体毛利。':''}${s.deduction?' 本月有确认扣减，商品收入与退货成本尚未分摊，暂不显示整体毛利。':''}</p></section>
   ${trend(days)}${dailyTable(days)}
   ${report.month_only_deductions?`<p class="alert-note">月度调整：${money(report.month_only_deductions)}，仅知道确认月份，未分配到任何一天。已计入上方净销售额。</p>`:''}
   <p class="crm-caption">扣减后 ROI ${multiple(s.netRoi)}${s.unlinked?' · '+s.unlinked+' 笔有效订单未关联客户，未计入复购':''} · 同一客户跨主页购买算复购；跨主页对话人数为各主页之和，未跨主页去重。</p>`;
 }
 function trend(days){
  const max=Math.max(1,...days.map(d=>Math.max(d.gross,d.spend??0)));
  return `<section class="perf-trend"><div class="section-title"><h2>每日销售与广告费</h2><div class="perf-legend"><span class="sales">销售额</span><span class="ads">广告费</span><small>RM · 最高 ${fmt(max)}</small></div></div><div class="perf-chart-scroll"><div class="perf-chart">${days.map(d=>`<button type="button" class="perf-day" data-perf="day" data-date="${d.date}" title="${dateLabel(d.date)} · 销售 ${money(d.gross)} · 广告 ${money(d.spend)}" aria-label="${dateLabel(d.date)}销售 ${money(d.gross)}，广告 ${money(d.spend)}，查看订单"><span class="perf-bars"><span class="sales" style="height:${d.gross/max*100}%"></span>${d.spend==null?'<span class="missing" aria-label="广告费未填">?</span>':`<span class="ads" style="height:${d.spend/max*100}%"></span>`}</span><small>${d.date.slice(-2)}</small></button>`).join('')}</div></div></section>`;
 }
 function dailyTable(days){return `<section class="perf-detail"><h2>每日明细</h2><div class="table-scroll"><table class="perf-table"><thead><tr>${['日期','销售额 RM','广告费 RM','ROI · 试算','正式 / 有效订单','复购订单 / 占比','总 / 新对话','新对话占比','平均客单 RM','每对话成本 RM','每单广告成本 RM','确认扣减 RM'].map(t=>`<th>${t}</th>`).join('')}</tr></thead><tbody>${days.map(d=>`<tr><td><button class="secondary" data-perf="day" data-date="${d.date}" title="查看当日订单">${icon('list')}${dateLabel(d.date)}</button></td><td>${fmt(d.gross)}</td><td>${d.spend==null?'待录入':fmt(d.spend)}</td><td>${multiple(d.roi)}</td><td>${d.orders} / ${d.valid}</td><td>${d.repeat} / ${pct(d.repeatRate)}</td><td>${d.messages??'—'} / ${d.fresh??'—'}</td><td>${pct(d.newRate)}</td><td>${d.average==null?'—':fmt(d.average)}</td><td>${d.costPerConversation==null?'—':fmt(d.costPerConversation)}</td><td>${d.costPerOrder==null?'—':fmt(d.costPerOrder)}</td><td>${fmt(d.deduction)}</td></tr>`).join('')}</tbody></table></div></section>`;}
 function entry(){return `<section class="data-surface"><div class="table-scroll"><table class="perf-entry-table"><thead><tr>${['日期 / 主页','广告费 RM','总对话人数','新对话人数','备注','修改人 / 时间','操作'].map(t=>`<th>${t}</th>`).join('')}</tr></thead><tbody>${report.daily.map((r,i)=>{const a=r.marketing;return `<tr><td>${dateLabel(r.date)}<small>${safe(r.page_name)}</small></td><td>${a?.spend_minor==null?'<span class="pill warning">待录入</span>':fmt(a.spend_minor)}</td><td>${a?.total_conversations??'—'}</td><td>${a?.new_conversations??'—'}</td><td class="perf-note">${safe(a?.note||'—')}</td><td>${safe(a?.actor_name||'—')}${a?`<small>${safe(new Date(a.updated_at).toLocaleString('zh-CN',{timeZone:'Asia/Kuala_Lumpur'}))}</small>`:''}</td><td><div class="row-actions"><button class="icon-button" data-perf="edit" data-index="${i}" title="${a?'修改':'录入'} ${dateLabel(r.date)}" aria-label="${a?'修改':'录入'} ${dateLabel(r.date)} ${safe(r.page_name)}">${icon('square-pen')}</button>${a?`<button class="icon-button" data-perf="audit" data-index="${i}" title="修改记录" aria-label="修改记录">${icon('history')}</button>`:''}</div></td></tr>`;}).join('')}</tbody></table></div></section>`;}
 function edit(index){
  editing=report.daily[index];if(!editing)return;pending=null;const a=editing.marketing;
  showDialog('performance-entry',null,'每日广告与对话',`<p class="perf-entry-context">${dateLabel(editing.date)} · ${safe(editing.page_name)}</p><div class="form-grid">${inputField('广告花费 RM','perf_spend',a?.spend_minor==null?'':a.spend_minor/100,'number',false,'min="0" max="100000000" step="0.01"')}${inputField('总对话人数 · Meta','perf_total',a?.total_conversations??'','number',false,'min="0" max="100000000" step="1"')}${inputField('新对话人数 · Meta','perf_new',a?.new_conversations??'','number',false,'min="0" max="100000000" step="1"')}<label class="field full"><span>备注</span><textarea name="perf_note" rows="3" maxlength="500">${safe(a?.note||'')}</textarea></label></div>`,'Supabase · 留空为未录入，0 为已确认无发生');
 }
 async function submit(){
  if(busy||!allowed())return;const token=generation;
  try{
   if(!pending){
    const optional=(name,scale=1)=>{const v=value(name);if(v==='')return null;const n=Number(v)*scale;if(!Number.isFinite(n)||n<0||n>100000000*scale||Math.abs(n-Math.round(n))>0.00001)throw new Error('performance_values_invalid');return Math.round(n);};
    const spend=optional('perf_spend',100),total=optional('perf_total'),fresh=optional('perf_new');
    if(fresh!=null&&(total==null||fresh>total))throw new Error('performance_values_invalid');
    pending={date:editing.date,page_id:editing.page_id,version:editing.marketing?.version||0,spend_minor:spend,total_conversations:total,new_conversations:fresh,note:value('perf_note'),request_id:crypto.randomUUID()};
   }
   busy=true;$('#save-button').disabled=true;
   await DwellPayments.performanceRpc('save',pending);
   if(token!==generation||!allowed())return;
   pending=null;dialog.close();await refresh();toast('每日资料已保存到 Supabase');
  }catch(e){
   if(token!==generation)return;
   if(/^[0-9A-Z]{5}$/.test(e?.code||'')&&!e.code.startsWith('08'))pending=null;
   if(String(e?.message).includes('performance_values_invalid'))pending=null;
   if(pending)form.querySelectorAll('#dialog-body input,#dialog-body textarea').forEach(el=>el.disabled=true);
   $('#form-error').textContent=failure(e)+(pending?' 再点保存会重试同一份内容。':'');
  }finally{busy=false;$('#save-button').disabled=false;}
 }
 function definitions(){showDialog('detail',null,'经营看板统计口径',`<dl class="detail-grid">
  <div><dt>数据范围</dt><dd>Supabase 已入库订单与每日手填广告记录。历史尚未完整导入，未查到旧订单不等于真正新客。首次已入库购买不直接标为新客。</dd></div>
  <div><dt>销售与 ROI</dt><dd>正式订单 GMV 包含收取运费、已减折扣；SGD 按订单现有 ×3 口径折算。取消订单保留原销售额，确认扣减另外列出，与 HR 对账一致。ROI 为总销售额 ÷ 总广告费，不平均每日比率；缺广告费或分母为 0 显示 —。</dd></div>
  <div><dt>复购</dt><dd>同一客户 ID 跨全部主页的有效正式订单按订单日期、订单编号排序。第二笔起算复购；取消、拒收、咨询不算有效购买。每月复购客户跨日及主页去重。历史变化会重新计算。</dd></div>
  <div><dt>对话人数</dt><dd>Meta 显示的 Total / New messaging 人数，不是消息条数。按主页日录入；月度及全部主页为每日人数相加，不能视作整月去重人数。</dd></div>
  <div><dt>成本与估算毛利</dt><dd>商品净收入 = GMV 减收取运费；估算毛利 = 商品净收入减下单时的商品成本，赠品照计成本。毛利率 = 估算毛利 ÷ 商品净收入。未扣实际物流、手续费、税费；扣广告后贡献也不是净利润。存在缺成本或确认扣减未分摊时，不显示整体毛利。旧订单不按现在 SKU 成本回填。</dd></div>
  <div><dt>部分退款</dt><dd>保留原销售额；实际退款按确认日期计入扣减，与 HR 对账一致。客户累计消费按退款后净额计算，购买次数与原奖励不变。退款未分摊到商品与运费，不据此推算退货成本。</dd></div>
  <div><dt>来源与权限</dt><dd>每日资料：dwell_ops_daily_marketing；订单：dwell_ops_orders；扣减：dwell_ops_sales_deductions（取消、拒收与部分退款）；客户身份：customer_id。仅主管理员可查看和修改，修改保留操作记录。</dd></div></dl>`,'实时云端查询 · Asia/Kuala_Lumpur');}
 async function showDay(date){
  const token=generation,r=await DwellPayments.performanceRpc('orders',{date,page_id:pageId});
  if(token!==generation||!allowed())return;
  showDialog('detail',null,dateLabel(date)+' · 正式订单',`<div class="table-scroll"><table><thead><tr><th>订单 / 客户</th><th>主页</th><th>GMV RM</th><th>状态</th></tr></thead><tbody>${r.items.map(o=>`<tr><td>#${o.number}<small>${safe(o.customer_name)}</small></td><td>${safe(o.page_name)}</td><td>${fmt(o.gmv_myr_minor)}</td><td>${{open:'正式订单',cancelled:'已取消',rejected:'COD 拒收'}[o.status]||safe(o.status)}</td></tr>`).join('')}</tbody></table></div><p class="crm-caption">${r.total} 笔${r.total>100?' · 此处显示前 100 笔，完整记录请在销售订单查看':''}</p>`,'Supabase · 只读明细');
 }
 document.addEventListener('change',e=>{if(state.view!=='performance'||loading||busy)return;if(e.target.id==='perf-month'){if(!e.target.value||e.target.value<'2000-01'||e.target.value>today().slice(0,7)){e.target.value=month;return;}month=e.target.value;void refresh();}if(e.target.id==='perf-page'){pageId=e.target.value;void refresh();}});
 document.addEventListener('click',async e=>{
  const b=e.target.closest('[data-perf]');if(!b||!allowed()||loading||busy||state.view!=='performance')return;
  const a=b.dataset.perf;try{
   if(a==='refresh')await refresh();
   else if(a==='dashboard'||a==='entry'){tab=a;render(false);}
   else if(a==='definitions')definitions();
   else if(a==='edit')edit(Number(b.dataset.index));
   else if(a==='day')await showDay(b.dataset.date);
   else if(a==='audit'){
    const row=report.daily[Number(b.dataset.index)],token=generation;
    const log=await DwellPayments.performanceRpc('audit',{id:row.marketing.id});
    if(token!==generation||!allowed())return;
    const show=d=>d?`广告 ${money(d.spend_minor)} · 总对话 ${d.total_conversations??'—'} · 新对话 ${d.new_conversations??'—'} · 备注 ${safe(d.note||'—')}`:'未录入';
    showDialog('detail',null,'每日资料修改记录',`<ol class="audit-list">${log.map(x=>`<li><strong>${safe(x.actor_name)}</strong><small>${safe(new Date(x.occurred_at).toLocaleString('zh-CN',{timeZone:'Asia/Kuala_Lumpur'}))}</small><p>之前：${show(x.before_data)}</p><p>之后：${show(x.after_data)}</p></li>`).join('')}</ol>`,'最近 50 次 · '+dateLabel(row.date));
   }
  }catch(e){toast(failure(e));}
 });
 dialog.addEventListener('cancel',e=>{if(busy&&dialogKind==='performance-entry')e.preventDefault();});
 document.addEventListener('click',e=>{if(busy&&dialogKind==='performance-entry'&&(e.target===dialog||e.target.closest('[data-close],[data-view]'))){e.preventDefault();e.stopImmediatePropagation();}},true);
 return {render,leave,submit};
})();
