// Ported legacy business methods; authentication and transport are supplied by the broker.
export class LegacyFlowApi {
  constructor({config,session,request,transport,accessToken}){Object.assign(this,{config,session,request,transport,accessToken});}
  async profile() {
    const id = this.session?.user?.id;
    if (!id) throw new Error("请重新登录");
    const rows = await this.request(`/rest/v1/profiles?id=eq.${encodeURIComponent(id)}&select=id,email,role&limit=1`);
    if (!rows?.[0]) throw new Error("找不到员工资料，请检查数据库脚本");
    return rows[0];
  }

  async flows(includeDrafts = false) {
    const filter = includeDrafts ? "" : "&status=eq.published";
    const flows = await this.request(`/rest/v1/flows?select=id,name,folder,status,updated_at${filter}&order=folder.asc,name.asc`);
    if (!flows.length) return [];
    const ids = flows.map((flow) => flow.id).join(",");
    const steps = await this.request(`/rest/v1/flow_steps?select=id,flow_id,position,kind,text_content,media_path,delay_ms&flow_id=in.(${ids})&order=position.asc`);
    const grouped = new Map();
    for (const step of steps) {
      if (!grouped.has(step.flow_id)) grouped.set(step.flow_id, []);
      grouped.get(step.flow_id).push(step);
    }
    return flows.map((flow) => ({ ...flow, steps: grouped.get(flow.id) || [] }));
  }

  async saveFlow(flow) {
    const flowBody = {
      name: flow.name.trim(),
      folder: String(flow.folder || "").trim() || "未分类",
      status: flow.status
    };
    let saved;
    if (flow.id) {
      const rows = await this.request(`/rest/v1/flows?id=eq.${encodeURIComponent(flow.id)}`, {
        method: "PATCH",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify(flowBody)
      });
      saved = rows[0];
    } else {
      const rows = await this.request("/rest/v1/flows", {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify(flowBody)
      });
      saved = rows[0];
    }

    await this.request(`/rest/v1/flow_steps?flow_id=eq.${encodeURIComponent(saved.id)}`, { method: "DELETE" });
    if (flow.steps.length) {
      const stepRows = [];
      for (let index = 0; index < flow.steps.length; index += 1) {
        const step = flow.steps[index];
        let mediaPath = step.media_path || null;
        if (step.file) mediaPath = await this.uploadMedia(step.file);
        stepRows.push({
          flow_id: saved.id,
          position: index,
          kind: step.kind,
          text_content: step.kind === "text" ? String(step.text_content || "").trim() : null,
          media_path: ["image", "video", "audio"].includes(step.kind) ? mediaPath : null,
          delay_ms: step.kind === "wait" ? Math.max(300, Number(step.delay_ms || 1000)) : 0
        });
      }
      await this.request("/rest/v1/flow_steps", {
        method: "POST",
        headers: { Prefer: "return=representation" },
        body: JSON.stringify(stepRows)
      });
    }
    return saved;
  }

  async deleteFlow(id) {
    await this.request(`/rest/v1/flows?id=eq.${encodeURIComponent(id)}`, { method: "DELETE" });
  }

  async sha256(blob) {
    const digest = await crypto.subtle.digest("SHA-256", await blob.arrayBuffer());
    return [...new Uint8Array(digest)].map((byte) => byte.toString(16).padStart(2, "0")).join("");
  }

  async registerMediaAsset(sha256, mediaPath, file) {
    await this.request("/rest/v1/media_assets?on_conflict=sha256", {
      method: "POST",
      headers: { Prefer: "resolution=ignore-duplicates,return=minimal" },
      body: JSON.stringify({
        sha256,
        media_path: mediaPath,
        original_name: file.name || mediaPath.split("/").pop() || "media",
        mime_type: file.type || null,
        size_bytes: Number(file.size || 0)
      })
    });
  }

  async mediaAssets() {
    return this.request("/rest/v1/media_assets?select=sha256,media_path,original_name,mime_type,size_bytes,created_at&order=created_at.desc");
  }

  async storageObjects(prefix = "") {
    const rows = await this.request("/storage/v1/object/list/flow-media", {
      method: "POST",
      body: JSON.stringify({ prefix, limit: 1000, offset: 0, sortBy: { column: "created_at", order: "desc" } })
    });
    const files = [];
    for (const row of rows || []) {
      const path = `${prefix}${row.name}`;
      if (!row.id && !row.metadata) {
        files.push(...await this.storageObjects(`${path}/`));
      } else {
        files.push({
          media_path: path,
          original_name: row.name,
          mime_type: row.metadata?.mimetype || row.metadata?.contentType || "",
          size_bytes: Number(row.metadata?.size || 0),
          created_at: row.created_at || row.updated_at || null
        });
      }
    }
    return files;
  }

  async mediaLibraryAssets() {
    const [indexed, stored] = await Promise.all([this.mediaAssets(), this.storageObjects()]);
    const indexedByPath = new Map(indexed.map((asset) => [asset.media_path, asset]));
    return stored.map((object) => ({ ...object, ...(indexedByPath.get(object.media_path) || {}) }));
  }

  async mediaPreviewUrl(path) {
    if (!path) return "";
    const encoded = path.split("/").map(encodeURIComponent).join("/");
    let response = await this.transport(this.mediaUrl(path), { cache: "no-store" });
    if (!response.ok) {
      const token = await this.accessToken();
      response = await this.transport(`${this.config.url}/storage/v1/object/authenticated/flow-media/${encoded}`, {
        cache: "no-store",
        headers: { apikey: this.config.anonKey, Authorization: `Bearer ${token}` }
      });
    }
    if (!response.ok) throw new Error(`媒体预览载入失败 (${response.status})`);
    return URL.createObjectURL(await response.blob());
  }

  async deleteMediaAsset(asset) {
    const references = await this.request(`/rest/v1/flow_steps?media_path=eq.${encodeURIComponent(asset.media_path)}&select=id&limit=1`);
    if (references.length) throw new Error("这个文件仍被 Flow 使用，请先从 Flow 移除或替换");
    const token = await this.accessToken();
    const encoded = asset.media_path.split("/").map(encodeURIComponent).join("/");
    const response = await this.transport(`${this.config.url}/storage/v1/object/flow-media/${encoded}`, {
      method: "DELETE",
      headers: { apikey: this.config.anonKey, Authorization: `Bearer ${token}` }
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.message || "文件删除失败");
    await this.request(`/rest/v1/media_assets?media_path=eq.${encodeURIComponent(asset.media_path)}`, { method: "DELETE" });
  }

  async indexExistingMedia(paths) {
    const uniquePaths = [...new Set((paths || []).filter(Boolean))];
    if (!uniquePaths.length) return;
    const indexed = await this.request("/rest/v1/media_assets?select=sha256,media_path");
    const indexedPaths = new Set(indexed.map((row) => row.media_path));
    const indexedHashes = new Set(indexed.map((row) => row.sha256));

    for (const mediaPath of uniquePaths) {
      if (indexedPaths.has(mediaPath)) continue;
      const response = await this.transport(this.mediaUrl(mediaPath));
      if (!response.ok) continue;
      const blob = await response.blob();
      const hash = await this.sha256(blob);
      if (indexedHashes.has(hash)) continue;
      const filename = mediaPath.split("/").pop() || "media";
      const file = new File([blob], filename, { type: blob.type || "application/octet-stream" });
      await this.registerMediaAsset(hash, mediaPath, file);
      indexedHashes.add(hash);
      indexedPaths.add(mediaPath);
    }
  }

  async uploadMedia(file) {
    const token = await this.accessToken();
    const hash = await this.sha256(file);
    const matches = await this.request(`/rest/v1/media_assets?sha256=eq.${encodeURIComponent(hash)}&select=media_path,original_name&limit=1`);
    if (matches?.[0]?.media_path) {
      const oldName = matches[0].original_name || matches[0].media_path.split("/").pop() || "";
      const generatedName = /^(?:[0-9a-f]{8}-[0-9a-f-]{27}|[0-9a-f]{64})(?:\.[a-z0-9]+)?$/i.test(oldName);
      if (file.name && generatedName) {
        await this.request(`/rest/v1/media_assets?media_path=eq.${encodeURIComponent(matches[0].media_path)}`, {
          method: "PATCH",
          body: JSON.stringify({ original_name: file.name })
        });
      }
      return matches[0].media_path;
    }

    const extension = (file.name.split(".").pop() || "jpg").replace(/[^a-z0-9]/gi, "").toLowerCase();
    const path = `sha256/${hash}.${extension}`;
    const exists = await this.transport(this.mediaUrl(path), { method: "HEAD" });
    if (!exists.ok) {
      const response = await this.transport(`${this.config.url}/storage/v1/object/flow-media/${path}`, {
        method: "POST",
        headers: {
          apikey: this.config.anonKey,
          Authorization: `Bearer ${token}`,
          "Content-Type": file.type || "application/octet-stream",
          "x-upsert": "false"
        },
        body: file
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.message || "媒体上传失败");
    }
    await this.registerMediaAsset(hash, path, file);
    return path;
  }

  mediaUrl(path) {
    if (!path) return "";
    const encoded = path.split("/").map(encodeURIComponent).join("/");
    return `${this.config.url}/storage/v1/object/public/flow-media/${encoded}`;
  }
}
