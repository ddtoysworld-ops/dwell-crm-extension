(() => {
  const errors={flow_login_required:'请先在独立侧栏登录。',flow_access_denied:'当前账号没有 Flow 读取权限。',flow_session_changed:'登录状态已改变，请重新读取。',flow_read_failed:'流程暂时无法读取，请重试。',flow_media_failed:'媒体暂时无法载入，请重试。',flow_media_invalid:'此媒体格式暂不支持预览。',flow_media_too_large:'媒体超过 20 MB，暂不载入预览。',flow_catalog_too_large:'流程数量超过本次读取上限，请联系管理员。'};
  const names={text:'文字',image:'照片',video:'视频',audio:'音频',wait:'等待',unsupported:'不支持的步骤'};
  function mount({container,send,documentId}) {
    let disposed=false,sequence=0,previewSequence=0,items=[],selected=null;
    const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
    const root=el('section',null,'flow-browser'),style=el('style',`
      .flow-browser{font:14px/1.6 Arial,"Microsoft YaHei",sans-serif;color:#263e38;min-width:0;letter-spacing:0;padding-top:16px}
      .flow-browser *{box-sizing:border-box}.flow-browser [hidden]{display:none!important}
      .flow-tools{display:flex;align-items:center;gap:8px;margin-bottom:14px}.flow-tools strong{flex:1;font-size:16px}.flow-tools small{font-size:12px;color:#637c75}
      .flow-browser button{font:inherit;min-height:38px;border:1px solid #cbd8d6;background:white;color:#23473d;border-radius:4px;padding:7px 10px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:6px}
      .flow-browser button:focus-visible{outline:2px solid #1b6bdc;outline-offset:2px}.flow-browser button:hover{background:#edf5f8}
      .flow-browser input,.flow-browser select{width:100%;min-width:0;font:inherit;background:white;border:1px solid #cbd8d6;border-radius:4px;min-height:40px;padding:8px 10px;color:inherit;margin-bottom:10px}
      .flow-browser label{display:block;font-size:13px}.flow-status{font-size:13px;color:#677a75;margin:8px 0;overflow-wrap:anywhere}
      .flow-list{display:flex;flex-direction:column;gap:8px}.flow-list button{display:flex;justify-content:space-between;gap:12px;text-align:left;padding:12px;min-height:58px;width:100%}.flow-list button span{min-width:0;overflow-wrap:anywhere}.flow-list small{display:block;color:#607780;font-size:12px}.flow-list .flow-count{flex-shrink:0;color:#28705a;font-size:12px}
      .flow-preview h3{font-size:16px;margin:14px 0 4px;overflow-wrap:anywhere}.flow-preview>p{font-size:13px;color:#677a75;margin:0 0 16px}
      .flow-step{padding:16px 0;border-bottom:1px solid #e1e8eb}.flow-step h4{font-size:13px;color:#466e83;margin:0 0 8px}.flow-step p{margin:0;white-space:pre-wrap;overflow-wrap:anywhere;font-size:14px}
      .flow-step img{display:block;width:100%;height:auto;max-height:320px;object-fit:contain;background:#f1f5f7;border-radius:4px}.flow-step video{display:block;width:100%;max-height:320px;background:#101a19}.flow-step audio{width:100%;display:block}.flow-media-state{font-size:13px;color:#677a75;margin:8px 0}
    `);
    const btn=(label,icon,action,iconOnly=false)=>{const n=el('button');n.type='button';n.title=label;n.setAttribute('aria-label',label);
      if(globalThis.lucide?.icons?.[icon])n.append(lucide.createElement(lucide.icons[icon],{width:17,height:17,'aria-hidden':'true'}));
      if(!iconOnly||!n.children.length)n.append(el('span',label));n.onclick=action;return n;};
    const tools=el('div',null,'flow-tools'),reload=btn('刷新流程','RefreshCw',()=>load(true),true);
    tools.append(el('strong','流程'),el('small','只读预览'),reload);
    const browse=el('div'),search=el('input'),folder=el('select'),list=el('div',null,'flow-list'),status=el('p','正在读取流程…','flow-status'),preview=el('div',null,'flow-preview');
    search.type='search';search.placeholder='搜索流程名称或内容';search.setAttribute('aria-label','搜索流程');folder.setAttribute('aria-label','流程分类');
    const category=el('label','分类');category.append(folder);browse.append(search,category,status,list);preview.hidden=true;status.setAttribute('role','status');if(location.protocol!=='chrome-extension:')root.append(style);root.append(tools,browse,preview);container.append(root);
    async function request(action,extra={}){const r=await send({type:'dwell-flow',action,documentId,...extra},45000);if(!r?.ok)throw Error(r?.code||'flow_read_failed');return r.value;}
    function stopMedia(){++previewSequence;for(const m of preview.querySelectorAll('audio,video')){m.pause();m.removeAttribute('src');m.load();}preview.replaceChildren();}
    function filter(){
      const query=search.value.trim().toLocaleLowerCase();
      const visible=items.filter(f=>(!folder.value||f.folder===folder.value)&&(f.name+' '+f.folder+' '+f.steps.map(s=>s.text).join(' ')).toLocaleLowerCase().includes(query));
      list.replaceChildren();status.textContent=items.length?`${visible.length} 个流程`:'暂无已发布流程';
      if(items.length&&!visible.length)status.textContent='没有符合条件的流程';
      for(const flow of visible){const b=btn(flow.name,'ChevronRight',()=>show(flow));b.replaceChildren();const label=el('span');label.append(el('strong',flow.name),el('small',flow.folder||'未分类'));b.append(label,el('span',`${flow.steps.length} 步`,'flow-count'));list.append(b);}
    }
    function show(flow){
      stopMedia();selected=flow.id;const ticket=previewSequence;browse.hidden=true;preview.hidden=false;
      preview.append(btn('返回流程列表','ArrowLeft',()=>{stopMedia();selected=null;browse.hidden=false;preview.hidden=true;}),el('h3',flow.name),el('p',`${flow.folder||'未分类'} · ${flow.steps.length} 步`));
      if(!flow.steps.length)preview.append(el('p','此流程尚无步骤'));
      flow.steps.forEach((step,index)=>{
        const section=el('section',null,'flow-step');section.append(el('h4',`${index+1}. ${names[step.kind]||names.unsupported}`));preview.append(section);
        if(step.kind==='text')section.append(el('p',step.text||'（空文字）'));
        else if(step.kind==='wait')section.append(el('p',`${step.delay_ms/1000} 秒`));
        else if(['image','video','audio'].includes(step.kind)){
          const target=el('div'),state=el('div',null,'flow-media-state');section.append(target,state);let busy=false;
          const button=btn(step.kind==='image'?'载入照片':step.kind==='video'?'载入视频':'载入音频','Eye',loadMedia);section.append(button);
          async function loadMedia(){
            if(busy)return;busy=true;button.disabled=true;state.textContent='正在载入…';
            try{const result=await request('media',{flowId:flow.id,stepId:step.id});if(disposed||ticket!==previewSequence)return;
              if(!new RegExp('^data:'+step.kind+'/(png|jpeg|webp|gif|mp4|webm|mpeg|ogg|wav|x-wav);base64,').test(result.data_url))throw Error('flow_media_invalid');
              const media=el(step.kind==='image'?'img':step.kind);if(step.kind==='image')media.alt=`${flow.name} 第 ${index+1} 步`;else{media.controls=true;media.preload='metadata';media.autoplay=false;}
              media.onerror=()=>{state.textContent='媒体无法播放或显示，请重试。';button.hidden=false;};media.src=result.data_url;target.replaceChildren(media);state.textContent='';button.hidden=true;
            }catch(error){if(!disposed&&ticket===previewSequence)state.textContent=errors[error.message]||'媒体暂时无法载入，请重试。';}
            finally{busy=false;button.disabled=false;}
          }
          if(step.kind==='image')void loadMedia();
          if(step.text)section.append(el('p',step.text));
        }else section.append(el('p','此步骤类型暂不支持预览。'));
      });
    }
    async function load(force=false){
      const ticket=++sequence;reload.disabled=true;status.textContent='正在读取流程…';
      if(force){stopMedia();items=[];selected=null;list.replaceChildren();browse.hidden=false;preview.hidden=true;}
      try{const result=await request('list',{force});if(disposed||ticket!==sequence)return;items=result.items;const prior=folder.value;folder.replaceChildren(new Option('全部分类',''));
        for(const f of [...new Set(items.map(f=>f.folder).filter(Boolean))])folder.append(new Option(f,f));folder.value=[...folder.options].some(o=>o.value===prior)?prior:'';filter();
      }catch(error){if(disposed||ticket!==sequence)return;items=[];list.replaceChildren();status.textContent=errors[error.message]||'流程暂时无法读取，请重试。';}
      finally{if(!disposed&&ticket===sequence)reload.disabled=false;}
    }
    search.oninput=filter;folder.onchange=filter;void load();
    return {refresh:()=>load(true),dispose(){disposed=true;++sequence;stopMedia();root.remove();}};
  }
  globalThis.DwellFlow=Object.freeze({mount});
})();
