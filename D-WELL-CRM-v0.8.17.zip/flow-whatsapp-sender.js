// Ported platform attachment/paste routines, with per-action guards.
(()=>{globalThis.DwellFlowAdapters ||= {};DwellFlowAdapters.whatsapp=({assertCurrent,delay,download})=>{const sleep=delay;

function visible(element) {
  if (!element) return false;
  const rect = element.getBoundingClientRect();
  const style = getComputedStyle(element);
  return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
}

function currentChatName() {
  // WhatsApp has more than one <header>. The first one belongs to the chat
  // list and can contain small counters such as "2". Only read the header of
  // the currently open conversation in #main.
  const header = document.querySelector("#main header")
    || document.querySelector('[data-testid="conversation-header"]');
  if (!header) return "尚未打开对话";

  const candidates = [...header.querySelectorAll("[title]")]
    .filter(visible)
    .map((node) => {
      const value = node.getAttribute("title")?.trim() || "";
      const phoneLike = /^\+?[\d ()-]{7,}$/.test(value);
      const shortCounter = /^\d{1,3}$/.test(value);
      const direction = node.getAttribute("dir");
      const style = getComputedStyle(node);
      const weight = Number.parseInt(style.fontWeight, 10) || 400;
      let score = 0;
      if (phoneLike) score += 100;
      if (direction === "auto") score += 30;
      if (weight >= 500) score += 20;
      if (value.length >= 4) score += 10;
      if (shortCounter) score -= 200;
      return { value, score };
    })
    .filter((item) => item.value && item.score > -100)
    .sort((left, right) => right.score - left.score);
  if (candidates[0]) return candidates[0].value;

  const text = header.innerText?.split("\n")
    .map((value) => value.trim())
    .find((value) => value && !/^\d{1,3}$/.test(value));
  return text || "当前对话";
}

function normalizedChatName(value) {
  return String(value || "").trim().replace(/\s+/g, " ").toLowerCase();
}

function assertExpectedChat(expectedChatName) {
  if (!expectedChatName) return;
  const actualChatName = currentChatName();
  if (normalizedChatName(actualChatName) !== normalizedChatName(expectedChatName)) {
    throw new Error(`检测到对话已切换，已停止后续发送。请回到 ${expectedChatName} 后重新开始`);
  }
}

function composer() {
  const candidates = [...document.querySelectorAll('[contenteditable="true"][role="textbox"], footer [contenteditable="true"]')];
  const found=candidates.filter(node=>visible(node)&&node.closest('#main footer'));return found.length===1?found[0]:null;
}

function sendButton(scope=document,media=false){const labels=/^(send|发送|傳送|hantar|kirim)$/i;const buttons=[...new Set([...scope.querySelectorAll('[data-icon*="send"]')].filter(visible).map(n=>n.closest("button,[role=button]")||n).concat([...scope.querySelectorAll('button[aria-label],[role=button][aria-label]')].filter(n=>labels.test(n.getAttribute('aria-label')?.trim()||''))))].filter(n=>visible(n)&&(!media||!n.closest('footer'))&&!n.disabled&&n.getAttribute('aria-disabled')!=='true');if(buttons.length>1)throw Error('存在多个发送按钮，未继续发送');return buttons[0]||null;}
async function waitFor(test, timeout = 8000, interval = 100) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const result = test();
    if (result) return result;
    await sleep(interval);
  }
  throw new Error("WhatsApp Web 等候超时");
}

async function sendText(text, expectedChatName) {
  const box = await waitFor(composer);
  assertCurrent();
  if(box.innerText?.trim())throw Error("回复框已有草稿，未覆盖。请先处理原草稿。");
  box.focus();
  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(box);
  selection.removeAllRanges();
  selection.addRange(range);
  if(box.innerText?.trim())throw Error("回复框已有草稿，未覆盖。请先处理原草稿。");

  // WhatsApp's editor collapses line breaks when a multiline value is inserted
  // with a single insertText command. A text/plain paste follows the same path
  // as a user paste and preserves intentional blank lines.
  const transfer = new DataTransfer();
  transfer.setData("text/plain", String(text || ""));
  let pasteEvent;
  try {
    pasteEvent = new ClipboardEvent("paste", {
      bubbles: true,
      cancelable: true,
      composed: true,
      clipboardData: transfer
    });
  } catch (_error) {
    pasteEvent = new Event("paste", { bubbles: true, cancelable: true, composed: true });
  }
  if (!pasteEvent.clipboardData) {
    Object.defineProperty(pasteEvent, "clipboardData", { value: transfer });
  }
  assertCurrent(); box.dispatchEvent(pasteEvent);

  // Fallback for WhatsApp builds that ignore synthetic text paste events.
  await sleep(80);
  if (!box.innerText?.trim()) {
    const escaped = String(text || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\r\n?/g, "\n")
      .replace(/\n/g, "<br>");
    document.execCommand("insertHTML", false, escaped);
  }
  await sleep(250);
  assertExpectedChat(expectedChatName);
  const button = sendButton(document.querySelector("#main footer"));
  if((box.innerText||" ").trim().replace(/\s+/g," ")!==String(text).trim().replace(/\s+/g," "))throw Error("回复草稿已改变，未发送");
  if (button) {
    assertCurrent(); button.click();
  } else {
    assertCurrent(); throw Error("无法确认发送按钮，未继续发送。请核对草稿。");
  }
  await sleep(550);
}

function attachButton() {
  const icons = [...document.querySelectorAll('#main footer [data-icon="plus"], #main footer [data-icon="plus-rounded"], #main footer [data-icon="clip"]')];
  const icon = icons.find(visible);
  if (icon) return icon.closest("button, [role='button']") || icon;
  return [...document.querySelectorAll("button[aria-label], [role='button'][aria-label]")]
    .find((node) => visible(node) && /(attach|附件|附加|lampir)/i.test(node.getAttribute("aria-label") || "")) || null;
}

function attachmentMenuItem(kind) {
  const patterns = {
    image: /^(photos?\s*(?:&|and)\s*videos?|照片和视频|相片和影片|相片與影片|foto dan video)$/i,
    video: /^(photos?\s*(?:&|and)\s*videos?|照片和视频|相片和影片|相片與影片|foto dan video)$/i,
    audio: /^(audio|音频|音訊|音效|audio file)$/i
  };
  const pattern = patterns[kind];
  if (!pattern) return null;
  return [...document.querySelectorAll('[role="menuitem"], button[aria-label]')]
    .find((node) => visible(node)
      && pattern.test(node.getAttribute("aria-label")?.trim() || node.textContent?.trim() || "")) || null;
}

function fileInput(kind) {
  const inputs = [...document.querySelectorAll('input[type="file"]')];
  if (kind === "image" || kind === "video") {
    return inputs.find((node) => {
      const accept = (node.accept || "").toLowerCase();
      return accept.includes(kind) && accept.includes("video") && !accept.includes("webp");
    }) || inputs.find((node) => {
      const accept = (node.accept || "").toLowerCase();
      return accept.includes(kind) && !accept.includes("webp") && !accept.includes("gif");
    }) || null;
  }
  return inputs.find((node) => (node.accept || "").toLowerCase().includes("audio"))
    || inputs.find((node) => {
      const accept = (node.accept || "").trim().toLowerCase();
      return !accept || accept === "*" || accept === "*/*" || accept.includes("application/");
    }) || null;
}

function mediaSendButton(){return sendButton(document,true);}
async function openImagePreview(file) {
  const box = await waitFor(composer);
  assertCurrent();
  if(box.innerText?.trim())throw Error("回复框已有草稿，未覆盖。请先处理原草稿。");
  box.focus();
  const transfer = new DataTransfer();
  transfer.items.add(file);
  let pasteEvent;
  try {
    pasteEvent = new ClipboardEvent("paste", {
      bubbles: true,
      cancelable: true,
      composed: true,
      clipboardData: transfer
    });
  } catch (_error) {
    pasteEvent = new Event("paste", { bubbles: true, cancelable: true, composed: true });
  }
  if (!pasteEvent.clipboardData) {
    Object.defineProperty(pasteEvent, "clipboardData", { value: transfer });
  }
  assertCurrent(); box.dispatchEvent(pasteEvent);
}

async function openAttachmentPreview(files, kind) {
  assertCurrent();if(composer()?.innerText?.trim())throw Error("回复框出现了新草稿，未发送附件");
  const fileList = Array.isArray(files) ? files : [files];
  const attach = await waitFor(attachButton);
  assertCurrent(); attach.click();
  const menuItem = await waitFor(() => attachmentMenuItem(kind));

  let intercepted = false;
  const interceptPicker = (event) => {
    const input = event.target;
    if (!(input instanceof HTMLInputElement) || input.type !== "file") return;

    // WhatsApp creates the real file input only after its attachment menu item
    // is clicked. Prevent the input's native picker, inject the Supabase-backed
    // File, then emit the same change event a manual selection would produce.
    event.preventDefault();
    const transfer = new DataTransfer();
    fileList.forEach((file) => transfer.items.add(file));
    input.files = transfer.files;
    intercepted = true;
    setTimeout(() => {
      try{assertCurrent(); input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));}catch{}
    }, 0);
  };

  document.addEventListener("click", interceptPicker, true);
  try {
    assertCurrent(); menuItem.click();
    await waitFor(() => intercepted, 3000, 50);
  } finally {
    document.removeEventListener("click", interceptPicker, true);
  }
}

async function downloadMediaFile(url, filename, kind) {
  const response = await download(url);
  const mediaLabel = { image: "照片", video: "视频", audio: "语音" }[kind] || "媒体";
  if (!response.ok) throw new Error(`无法读取 Flow ${mediaLabel}`);
  const blob = await response.blob();
  const fallbackType = kind === "image" ? "image/jpeg" : kind === "video" ? "video/mp4" : "audio/mpeg";
  const mimeType = kind === "image" && /\.jpe?g$/i.test(filename)
    ? "image/jpeg"
    : kind === "video" && /\.mp4$/i.test(filename)
      ? "video/mp4"
    : kind === "audio" && /\.mp3$/i.test(filename)
      ? "audio/mpeg"
      : (blob.type || fallbackType);
  return new File([blob], filename, { type: mimeType });
}

async function sendImageBatch(items, expectedChatName) {
  if (!Array.isArray(items) || !items.length) throw new Error("照片组没有内容");
  const files = await Promise.all(items.map((item, index) => downloadMediaFile(
    item.url,
    item.filename || `photo-${index + 1}.jpg`,
    "image"
  )));
  assertExpectedChat(expectedChatName);
  await openAttachmentPreview(files, "image");
  const button = await waitFor(mediaSendButton, 15000);
  await sleep(350);
  assertExpectedChat(expectedChatName);
  assertCurrent(); button.click();
  await sleep(1800);
}

async function sendFile(url, filename, kind, expectedChatName) {
  const file = await downloadMediaFile(url, filename, kind);
  assertCurrent();if(composer()?.innerText?.trim())throw Error("回复框出现了新草稿，未发送附件");
  assertExpectedChat(expectedChatName);

  if (kind === "image") {
    await openImagePreview(file);
  } else if (kind === "video") {
    await openAttachmentPreview(file, kind);
  } else {
    const attach = await waitFor(attachButton);
    assertCurrent(); attach.click();
    const menuItem = await waitFor(() => attachmentMenuItem(kind));
    assertCurrent(); menuItem.click();
    const input = await waitFor(() => fileInput(kind));
    const transfer = new DataTransfer();
    transfer.items.add(file);
    input.files = transfer.files;
    assertCurrent(); input.dispatchEvent(new Event("change", { bubbles: true, composed: true }));
  }

  const button = await waitFor(mediaSendButton, 12000);
  await sleep(300);
  assertExpectedChat(expectedChatName);
  assertCurrent(); button.click();
  await sleep(kind === "video" ? 2500 : kind === "image" ? 1600 : 1200);
}


return {chat:()=>({hasChat:!!composer(),chatName:currentChatName(),platformLabel:'WhatsApp'}),text:text=>sendText(text),images:items=>sendImageBatch(items),file:(url,name,kind)=>sendFile(url,name,kind)};};})();
