(() => {
  const visible=n=>n?.getBoundingClientRect().width>0&&n.getBoundingClientRect().height>0;
  function composer(platform){
    const selector=platform==='whatsapp'?'#main footer [contenteditable="true"][role="textbox"]':'[contenteditable="true"][aria-placeholder="Reply in Messenger…"], [contenteditable="true"][aria-placeholder="Reply in Messenger..."], [contenteditable="true"][aria-label="Reply in Messenger..."], [contenteditable="true"][aria-label="Reply in Messenger"], textarea[placeholder="Reply in Messenger"], [contenteditable="true"][aria-label="在 Messenger 中回复…"], [contenteditable="true"][aria-label="回复 Messenger…"]';
    const found=[...document.querySelectorAll(selector)].filter(visible);
    if(found.length!==1)throw Error('ai_composer_missing');return found[0];
  }
  function latest(platform){
    if(platform==='messenger')return latestMessenger();
    const nodes=[...document.querySelectorAll('#main .message-in')].filter(visible);
    const last=nodes.at(-1),parts=last?[...last.querySelectorAll('span.selectable-text')].filter(n=>!n.closest('[data-testid="quoted-message"]')):[];
    const value=parts.map(n=>n.innerText||n.textContent).join('\n').trim();if(!value||value.length>4000)throw Error('ai_message_missing');return value;
  }
  function latestMessenger(){
    const regions=[...document.querySelectorAll('[role="region"]')].filter(n=>visible(n)&&n.querySelector('[data-message-id]'));
    if(regions.length!==1)throw Error('ai_message_missing');
    const region=regions[0],names=new Set();
    for(const a of document.querySelectorAll('a')){
      if(!['View profile','查看个人主页','查看個人檔案','查看主页'].includes(a.textContent.trim()))continue;
      for(let p=a.parentElement,depth=0;p&&depth<4;p=p.parentElement,depth++){
        const h=p.querySelector('h3,[role="heading"]');if(h){names.add(h.textContent.trim());break;}
      }
    }
    if(names.size>1)throw Error('ai_message_missing');
    const name=[...names][0];
    const messages=[...region.querySelectorAll('[data-message-id]')].filter(visible);
    const sender=message=>{
      for(let row=message.parentElement,depth=0;row&&row!==region&&depth<7;row=row.parentElement,depth++){
        const content=[...row.children].find(child=>child.contains(message));
        if(!content)continue;
        const avatars=[...row.children].filter(child=>child!==content&&!child.querySelector('[data-message-id]'))
          .flatMap(child=>[...child.querySelectorAll('img[alt], [role="img"][aria-label]')]);
        const labels=avatars.filter(avatar=>{const rect=avatar.getBoundingClientRect();return rect.width>0&&rect.width<=64&&rect.height>0&&rect.height<=64;})
          .map(avatar=>(avatar.getAttribute('alt')||avatar.getAttribute('aria-label')||'').trim()).filter(Boolean);
        if(name&&labels.includes(name))return name;
        if(!name&&labels.length)return labels.length===1?labels[0]:'';
      }
      return '';
    };
    const senders=messages.map(sender).filter(Boolean);
    if(new Set(senders).size>1)throw Error('ai_message_missing');
    const identified=senders[0];
    const incoming=messages.filter(message=>{
      const avatarName=sender(message);
      if(avatarName)return avatarName===(name||identified);
      // Older Messenger layouts have no avatar beside every bubble. Use the old
      // plugin's left-side signal, but only inside the unique active message list.
      if(!name&&!identified)return false;
      const rect=message.querySelector('[dir="auto"]')?.getBoundingClientRect()||message.getBoundingClientRect();
      const bounds=region.getBoundingClientRect();
      return rect.width>0&&rect.width<bounds.width*.8&&rect.left<bounds.left+bounds.width*.55;
    });
    const last=incoming.at(-1);
    const parts=last?[...last.querySelectorAll('[dir="auto"]')].filter(n=>!n.querySelector('[dir="auto"]')&&!n.closest('button,[role="button"]')):[];
    const value=parts.map(n=>n.innerText||n.textContent).join('\n').trim();
    if(!value||value.length>4000)throw Error('ai_message_missing');return value;
  }
  function insert(platform,text){
    if(!text.trim())throw Error('ai_empty_reply');const box=composer(platform);
    if((box.value??box.innerText??box.textContent).trim())throw Error('ai_composer_not_empty');
    box.focus();
    if(box.tagName==='TEXTAREA'){const setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value').set;setter.call(box,text);box.dispatchEvent(new Event('input',{bubbles:true}));}
    else{const range=document.createRange();range.selectNodeContents(box);range.collapse(false);const selection=window.getSelection();selection.removeAllRanges();selection.addRange(range);if(!document.execCommand('insertText',false,text))throw Error('ai_insert_failed');}
    // Never dispatch Enter, click Send, or replace an existing draft.
  }
  globalThis.DwellAIChat=Object.freeze({latest,insert,composer});
})();
