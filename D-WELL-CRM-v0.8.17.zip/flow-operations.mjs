import {LegacyFlowApi} from './flow-legacy-api.mjs';
import {mediaPath} from './flow-service.mjs';
const uuid=/^[\da-f]{8}-[\da-f]{4}-[\da-f]{4}-[\da-f]{4}-[\da-f]{12}$/i;
const mediaTypes=/^(image\/(png|jpeg|gif|webp)|video\/(mp4|webm|quicktime)|audio\/(mpeg|mp4|ogg|wav|x-wav|webm))$/;
const maxFile=50*1024*1024,chunkSize=512*1024;
const encode=bytes=>{let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);};
function safeFlow(value){
 if(!value||typeof value.name!=='string'||!value.name.trim()||value.name.length>80||!['draft','published'].includes(value.status)||!Array.isArray(value.steps)||!value.steps.length||value.steps.length>500)throw Error('流程内容不完整或超过限制');
 if(value.id&&!uuid.test(value.id))throw Error('流程编号无效');
 const steps=value.steps.map((s,position)=>{
  if(!['text','image','video','audio','wait'].includes(s.kind))throw Error('不支持的步骤');
  if(s.kind==='text'&&(!String(s.text_content||'').trim()||String(s.text_content).length>20000))throw Error('文字内容不能为空或过长');
  if(['image','video','audio'].includes(s.kind))mediaPath(s.media_path);
  if(s.kind==='wait'&&(!Number.isFinite(Number(s.delay_ms))||Number(s.delay_ms)<300||Number(s.delay_ms)>600000))throw Error('等待时间须为 0.3 秒至 10 分钟');
  return {position,kind:s.kind,text_content:s.kind==='text'?s.text_content:null,media_path:['image','video','audio'].includes(s.kind)?s.media_path:null,delay_ms:s.kind==='wait'?Number(s.delay_ms):0};
 });return {id:value.id||null,name:value.name.trim(),folder:String(value.folder||'未分类').slice(0,60),status:value.status,updated_at:value.updated_at,steps};
}
export function createFlowOperations({config,getSession,transport=fetch,onChanged=()=>{}}){
 const transfers=new Map(),cache=new Map();let mutation=false,epoch=0;
 const clear=()=>{++epoch;transfers.clear();cache.clear();};
 const prune=()=>{for(const [key,t]of transfers)if(t.expires<Date.now())transfers.delete(key);};
 async function connection(assertCurrent=async()=>{}){
  await assertCurrent();const session=await getSession(),start=epoch;
  if(!session?.user?.id||!session.access_token)throw Error('请先登录客服账号');
  const check=async()=>{await assertCurrent();const next=await getSession();if(epoch!==start||next?.user?.id!==session.user.id)throw Error('登录状态已改变，请重新连接');return next;};
  const accessToken=async()=>(await check()).access_token;
  const network=async(input,options={})=>{
   await check();const url=new URL(input),method=(options.method||'GET').toUpperCase();
   if(url.origin!==config.url||!/^\/(rest\/v1\/(profiles|flows|flow_steps|media_assets)(\?|$)|storage\/v1\/object\/(?:list\/|public\/|authenticated\/)?flow-media(?:\/|\?|$))/.test(url.pathname+url.search)||!['GET','HEAD','POST','PATCH','DELETE'].includes(method))throw Error('Flow 操作被拒绝');
   const r=await transport(url.href,{...options,redirect:'error',credentials:'omit',signal:AbortSignal.timeout(60000)});await check();return r;
  };
  const request=async(path,options={})=>{
   const r=await network(config.url+path,{...options,headers:{apikey:config.anonKey,Authorization:'Bearer '+await accessToken(),...(options.body?{'Content-Type':'application/json'}:{}),...options.headers}});
   if(!r.ok)throw Error(r.status===403?'没有此 Flow 操作的权限':`Flow 请求失败 (${r.status})`);const body=await r.text();return body?JSON.parse(body):null;
  };
  const api=new LegacyFlowApi({config,session,request,transport:network,accessToken});
  const profile=await api.profile();if(!['admin','staff'].includes(profile.role))throw Error('没有 Flow 使用权限');
  // Paginate legacy tables and storage rather than silently stopping at server limits.
  const rows=async(table,params)=>{const result=[];for(let offset=0;offset<20000;offset+=200){const page=await request('/rest/v1/'+table+'?'+new URLSearchParams({...params,limit:'200',offset:String(offset)}));result.push(...page);if(page.length<200)return result;}throw Error('资料过多，请缩小范围');};
  api.flows=async(admin=false)=>{
   const flows=await rows('flows',{select:'id,name,folder,status,updated_at',...(!admin?{status:'eq.published'}:{}),order:'folder.asc,name.asc,id.asc'});
   const result=[];for(let i=0;i<flows.length;i+=30){const group=flows.slice(i,i+30);const steps=await rows('flow_steps',{select:'id,flow_id,position,kind,text_content,media_path,delay_ms',flow_id:'in.('+group.map(f=>f.id).join(',')+')',order:'position.asc,id.asc'});result.push(...group.map(f=>({...f,steps:steps.filter(s=>s.flow_id===f.id)})));}return result;
  };
  api.mediaAssets=()=>rows('media_assets',{select:'sha256,media_path,original_name,mime_type,size_bytes,created_at',order:'created_at.desc,media_path.asc'});
  api.storageObjects=async(prefix='',depth=0)=>{
   if(depth>10)throw Error('媒体目录层数过多');const files=[];
   for(let offset=0;offset<20000;offset+=200){const rows=await request('/storage/v1/object/list/flow-media',{method:'POST',body:JSON.stringify({prefix,limit:200,offset,sortBy:{column:'name',order:'asc'}})});
    for(const row of rows){const path=prefix+row.name;mediaPath(path);if(!row.id&&!row.metadata)files.push(...await api.storageObjects(path+'/',depth+1));else files.push({media_path:path,original_name:row.name,mime_type:row.metadata?.mimetype||row.metadata?.contentType||'',size_bytes:Number(row.metadata?.size||0),created_at:row.created_at});}
    if(rows.length<200)return files;
   }throw Error('媒体数量超过读取上限');
  };
  return {api,profile,session,check,request,network};
 }
 async function invoke(action,payload={},owner='',assertCurrent){
  prune();const c=await connection(assertCurrent),{api,profile,session,check,request,network}=c;
  const admin=['admin-list','library','save','delete','upload-begin','upload-chunk','upload-finish','delete-media'];
  if(admin.includes(action)&&profile.role!=='admin')throw Error('仅管理员可以管理 Flow 和媒体库');
  const transfer=id=>{const t=transfers.get(id);if(!t||t.owner!==owner||t.user!==session.user.id)throw Error('媒体传输已过期，请重新选择');t.expires=Date.now()+300000;return t;};
  if(action==='profile')return {email:profile.email||session.user.email||'当前账号',role:profile.role,url:config.url};
  if(action==='refresh'){cache.clear();return {};}
  if(['list','admin-list'].includes(action)){
   const key=session.user.id+':'+action;if(!cache.has(key))cache.set(key,api.flows(action==='admin-list').catch(e=>{cache.delete(key);throw e;}));const result=await cache.get(key);await check();return result;
  }
  if(action==='library')return api.mediaLibraryAssets();
  if(action==='upload-begin'){
   if(!Number.isInteger(payload.size)||payload.size<1||payload.size>maxFile||!mediaTypes.test(payload.mime))throw Error('支持照片、视频和音频，单个文件最多 50 MB');
   if(transfers.size>=4)throw Error('请等待当前媒体传输完成');const id=crypto.randomUUID();transfers.set(id,{owner,user:session.user.id,expires:Date.now()+300000,name:String(payload.name||'media').slice(0,200),mime:payload.mime,size:payload.size,bytes:0,chunks:[],upload:true});return {id};
  }
  if(action==='upload-chunk'){
   const t=transfer(payload.id);if(!t.upload||payload.index!==t.chunks.length||typeof payload.data!=='string'||payload.data.length>710000)throw Error('媒体分块无效');const bytes=Uint8Array.from(atob(payload.data),c=>c.charCodeAt(0));if(bytes.length>chunkSize||t.bytes+bytes.length>t.size)throw Error('媒体大小无效');t.chunks.push(bytes);t.bytes+=bytes.length;return {};
  }
  if(action==='preview-begin'){
   mediaPath(payload.path);
   const allowed=profile.role==='admin'?(await api.mediaLibraryAssets()).some(a=>a.media_path===payload.path):(await api.flows(false)).some(f=>f.steps.some(s=>s.media_path===payload.path));
   if(!allowed)throw Error('媒体不存在或无权读取');if(transfers.size>=4)throw Error('请等待当前媒体载入完成');
   const id=crypto.randomUUID();transfers.set(id,{owner,user:session.user.id,expires:Date.now()+300000});
   try{
   const r=await network(api.mediaUrl(payload.path));if(!r.ok)throw Error('媒体载入失败');const mime=(r.headers.get('content-type')||'').split(';')[0];if(!mediaTypes.test(mime)||Number(r.headers.get('content-length'))>maxFile){await r.body?.cancel();throw Error('不支持的媒体或超过 50 MB');}
   const reader=r.body.getReader(),chunks=[];let size=0;for(;;){const part=await reader.read();if(part.done)break;size+=part.value.length;if(size>maxFile){await reader.cancel();throw Error('媒体超过 50 MB');}chunks.push(part.value);}await check();
   transfer(id).blob=new Blob(chunks,{type:mime});return {id,size,mime,chunkSize};
   }catch(error){transfers.delete(id);throw error;}
  }
  if(action==='preview-chunk'){const t=transfer(payload.id);if(!t.blob||!Number.isInteger(payload.index)||payload.index<0||payload.index*chunkSize>=t.blob.size)throw Error('媒体分块无效');return {data:encode(new Uint8Array(await t.blob.slice(payload.index*chunkSize,(payload.index+1)*chunkSize).arrayBuffer()))};}
  if(action==='transfer-end'){transfer(payload.id);transfers.delete(payload.id);return {};}
  if(!['save','delete','upload-finish','delete-media'].includes(action))throw Error('未知 Flow 操作');
  if(mutation)throw Error('另一项 Flow 保存正在进行，请稍后重试');mutation=true;
  try{
   if(action==='upload-finish'){
    const t=transfer(payload.id);if(!t.upload||t.bytes!==t.size)throw Error('媒体上传不完整');const file=new File(t.chunks,t.name,{type:t.mime});transfers.delete(payload.id);
    const path=await api.uploadMedia(file);cache.clear();onChanged();return {path};
   }
   if(action==='delete-media'){mediaPath(payload.path);await api.deleteMediaAsset({media_path:payload.path});cache.clear();onChanged();return {};}
   if(action==='delete'){
    if(!uuid.test(payload.id))throw Error('流程编号无效');const result=await request('/rest/v1/flows?'+new URLSearchParams({id:'eq.'+payload.id,updated_at:'eq.'+payload.updated_at}),{method:'DELETE',headers:{Prefer:'return=representation'}});if(!result?.length)throw Error('Flow 已由其他人更新，请刷新后重试');cache.clear();onChanged();return {};
   }
   const flow=safeFlow(payload),before=flow.id?(await api.flows(true)).find(f=>f.id===flow.id):null;
   if(flow.id&&(!before||!flow.updated_at||before.updated_at!==flow.updated_at))throw Error('Flow 已由其他人更新，请刷新后重试');
   // Stage as draft before replacing steps. Failed saves restore the prior definition.
   const fields={name:flow.name,folder:flow.folder,status:'draft'};let saved,stepsTouched=false;
   try{
    const path=flow.id?'/rest/v1/flows?'+new URLSearchParams({id:'eq.'+flow.id,updated_at:'eq.'+flow.updated_at}):'/rest/v1/flows';
    const rows=await request(path,{method:flow.id?'PATCH':'POST',headers:{Prefer:'return=representation'},body:JSON.stringify(fields)});saved=rows?.[0];if(!saved)throw Error('Flow 已由其他人更新，请刷新后重试');
    stepsTouched=true;await request('/rest/v1/flow_steps?flow_id=eq.'+saved.id,{method:'DELETE'});
    await request('/rest/v1/flow_steps',{method:'POST',body:JSON.stringify(flow.steps.map(s=>({...s,flow_id:saved.id})))});
    const finished=await request('/rest/v1/flows?id=eq.'+saved.id,{method:'PATCH',headers:{Prefer:'return=representation'},body:JSON.stringify({status:flow.status})});return finished[0];
   }catch(error){
    if(saved&&stepsTouched){try{
      if(before){await request('/rest/v1/flow_steps?flow_id=eq.'+saved.id,{method:'DELETE'});if(before.steps.length)await request('/rest/v1/flow_steps',{method:'POST',body:JSON.stringify(before.steps)});await request('/rest/v1/flows?id=eq.'+saved.id,{method:'PATCH',body:JSON.stringify({name:before.name,folder:before.folder,status:before.status})});}
      else await request('/rest/v1/flows?id=eq.'+saved.id,{method:'DELETE'});
     }catch{throw Error('保存中断，自动恢复未完成。流程暂留草稿，请管理员核对，勿重复保存。');}}
    throw error;
   }finally{cache.clear();onChanged();}
  }finally{mutation=false;}
 }
 return {invoke,clear};
}
