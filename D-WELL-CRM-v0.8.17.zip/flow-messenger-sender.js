// Ported platform attachment/paste routines, with per-action guards.
(()=>{globalThis.DwellFlowAdapters ||= {};DwellFlowAdapters.messenger=({assertCurrent,delay,download})=>{const messengerSleep=delay;

function messengerVisible(element) {
  if (!element) return false;
  const rect = element.getBoundingClientRect();
  const style = getComputedStyle(element);
  return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
}

async function messengerWaitFor(test, timeout = 10000, interval = 100) {
  const started = Date.now();
  while (Date.now() - started < timeout) {
    const result = test();
    if (result) return result;
    await messengerSleep(interval);
  }
  throw new Error("Meta Business Suite 等候超时");
}

function messengerThreadSelected() {
  const threadType = new URL(location.href).searchParams.get("thread_type");
  return !threadType || threadType === "FB_MESSAGE";
}

function messengerComposer(){try{return DwellAIChat.composer('messenger');}catch{return null;}}
function messengerChatName() {
  const ignored = /^(Inbox|客户 CRM|About|Facebook profile|Outcomes|Data sharing|Activity|Order status|Lead stage|Labels|Notes|Shared photos|Reminder)$/i;
  const headings = [...document.querySelectorAll('h2, h3, [role="heading"][aria-level="2"], [role="heading"][aria-level="3"]')];
  const match = headings.find((node) => {
    const text = node.textContent?.trim() || "";
    return messengerVisible(node) && text && !ignored.test(text) && !node.closest("#flow-lite-floating-root");
  });
  return match?.textContent?.trim() || "当前 Messenger 对话";
}

function messengerSendButton(){const buttons=[...document.querySelectorAll('button[aria-label], [role="button"][aria-label]')].filter(n=>messengerVisible(n)&&/^(Send|发送|傳送|Hantar|Kirim)$/i.test(n.getAttribute('aria-label')?.trim()||'')&&n.getAttribute('aria-disabled')!=='true'&&!n.disabled);if(buttons.length>1)throw Error('存在多个发送按钮，未继续发送');return buttons[0]||null;}
function messengerListSignature() {
  const list = document.querySelector('[role="region"][aria-label*="Message list"], [aria-label*="Message list container"]');
  if (!list) return "";
  const text = list.innerText || "";
  return `${list.childElementCount}:${text.length}:${text.slice(-180)}`;
}

async function messengerSendText(text) {
  const box = await messengerWaitFor(messengerComposer);
  assertCurrent();
  if(box.innerText?.trim())throw Error("回复框已有草稿，未覆盖。请先处理原草稿。");
  box.focus();
  const selection = window.getSelection();
  const range = document.createRange();
  range.selectNodeContents(box);
  selection.removeAllRanges();
  selection.addRange(range);
  if(box.innerText?.trim())throw Error("回复框已有草稿，未覆盖。请先处理原草稿。");

  const value = String(text || "");
  const transfer = new DataTransfer();
  transfer.setData("text/plain", value);
  let pasteEvent;
  try {
    pasteEvent = new ClipboardEvent("paste", {
      bubbles: true,
      cancelable: true,
      composed: true,
      clipboardData: transfer
    });
  } catch (_error) {
    pasteEvent = new Event("paste", { bubbles: true, cancelable: true, composed: true });
  }
  if (!pasteEvent.clipboardData) Object.defineProperty(pasteEvent, "clipboardData", { value: transfer });
  assertCurrent(); box.dispatchEvent(pasteEvent);

  await messengerSleep(100);
  if (!box.innerText?.trim()) {
    const escaped = value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/\r\n?/g, "\n").replace(/\n/g, "<br>");
    document.execCommand("insertHTML", false, escaped);
    assertCurrent(); box.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType: "insertText", data: value }));
  }

  const button = await messengerWaitFor(messengerSendButton, 5000).catch(() => null);
  if((box.innerText||" ").trim().replace(/\s+/g," ")!==value.trim().replace(/\s+/g," "))throw Error("回复草稿已改变，未发送");
  if (button) {
    assertCurrent(); button.click();
  } else {
    assertCurrent(); throw Error("无法确认发送按钮，未继续发送。请核对草稿。");
  }
  await messengerSleep(700);
}

async function messengerDownloadFile(url, filename, kind) {
  const response = await download(url);
  const label = { image: "照片", video: "视频", audio: "语音" }[kind] || "媒体";
  if (!response.ok) throw new Error(`无法读取 Flow ${label}`);
  const blob = await response.blob();
  const fallbackType = kind === "image" ? "image/jpeg" : kind === "video" ? "video/mp4" : "audio/mpeg";
  const mimeType = kind === "image" && /\.jpe?g$/i.test(filename)
    ? "image/jpeg"
    : kind === "video" && /\.mp4$/i.test(filename)
      ? "video/mp4"
      : kind === "audio" && /\.mp3$/i.test(filename)
        ? "audio/mpeg"
        : (blob.type || fallbackType);
  return new File([blob], filename, { type: mimeType });
}

async function messengerInjectFiles(files) {
  const fileList = Array.isArray(files) ? files : [files];
  const box = await messengerWaitFor(messengerComposer);
  const before = messengerListSignature();
  const transfer = new DataTransfer();
  fileList.forEach((file) => transfer.items.add(file));
  assertCurrent();
  if(box.innerText?.trim())throw Error("回复框已有草稿，未覆盖。请先处理原草稿。");
  box.focus();

  if (fileList.every((file) => file.type.startsWith("image/"))) {
    let pasteEvent;
    try {
      pasteEvent = new ClipboardEvent("paste", {
        bubbles: true,
        cancelable: true,
        composed: true,
        clipboardData: transfer
      });
    } catch (_error) {
      pasteEvent = new Event("paste", { bubbles: true, cancelable: true, composed: true });
    }
    if (!pasteEvent.clipboardData) Object.defineProperty(pasteEvent, "clipboardData", { value: transfer });
    assertCurrent(); box.dispatchEvent(pasteEvent);
  } else {
    for (const type of ["dragenter", "dragover", "drop"]) {
      let dragEvent;
      try {
        dragEvent = new DragEvent(type, {
          bubbles: true,
          cancelable: true,
          composed: true,
          dataTransfer: transfer
        });
      } catch (_error) {
        dragEvent = new Event(type, { bubbles: true, cancelable: true, composed: true });
      }
      if (!dragEvent.dataTransfer) Object.defineProperty(dragEvent, "dataTransfer", { value: transfer });
      assertCurrent(); box.dispatchEvent(dragEvent);
      await messengerSleep(60);
    }
  }

  const send = await messengerWaitFor(() => {
    
    return messengerSendButton();
  }, 60000, 150);
  if (!send.alreadySent) {
    await messengerSleep(350);
    assertCurrent(); if(box.innerText?.trim())throw Error("回复框出现了新草稿，未发送附件"); send.click();
  }
  await messengerSleep(fileList.some((file) => file.type.startsWith("video/")) ? 2800 : 1700);
}

async function messengerSendImages(items) {
  if (!Array.isArray(items) || !items.length) throw new Error("照片组没有内容");
  const files = await Promise.all(items.map((item, index) => messengerDownloadFile(
    item.url,
    item.filename || `photo-${index + 1}.jpg`,
    "image"
  )));
  await messengerInjectFiles(files);
}

async function messengerSendFile(url, filename, kind) {
  const file = await messengerDownloadFile(url, filename, kind);
  await messengerInjectFiles(file);
}


return {chat:()=>({hasChat:!!messengerComposer(),chatName:messengerChatName(),platformLabel:'Messenger'}),text:messengerSendText,images:messengerSendImages,file:messengerSendFile};};})();
