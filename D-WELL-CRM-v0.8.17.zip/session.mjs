export class ContextSession {
  constructor(data, render, verify = async () => true) {
    this.data = data; this.render = render; this.verify = verify; this.version = 0;
    this.key = ''; this.authorized = false; this.context = null;
  }
  invalidate(status = 'transition') {
    ++this.version; this.key = ''; this.context = null;
    this.render({ status });
  }
  authorize(allowed) {
    this.authorized = allowed; this.invalidate(allowed ? 'transition' : 'signed_out');
  }
  async accept(tabId, snapshot) {
    const context = snapshot.context;
    const key = JSON.stringify([tabId, snapshot.documentId, snapshot.revision, context]);
    if (!this.authorized || key === this.key) return;
    const ticket = ++this.version; this.key = key; this.context = context;
    this.render({ status: context.status, context });
    if (context.status !== 'ready') return;
    this.render({ status: 'loading', context });
    try {
      const result = await this.data.resolve(context);
      if (ticket !== this.version || !this.authorized) return;
      if (result.status === 'conflict' || result.status === 'unavailable') { this.render({ status: result.status, context }); return; }
      if (result.items?.length !== 1) { this.render({ status: result.items?.length ? 'conflict' : 'not_found', context }); return; }
      const profile = await this.data.read('profile', { id: result.items[0].id });
      if (ticket !== this.version || !this.authorized) return;
      if (!await this.verify(tabId, snapshot)) { if (ticket === this.version) this.invalidate(); return; }
      if (ticket !== this.version || !this.authorized) return;
      this.render({ status: 'matched', context, profile });
    } catch (error) { if (ticket === this.version && this.authorized) this.render({ status: 'error', context, error }); }
  }
}
