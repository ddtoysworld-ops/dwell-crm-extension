// Narrow, conversation-scoped commands. No caller-supplied RPC names or auth tokens.
export function createInlineService({rpc,resolve,assertCurrent,writesEnabled=false}) {
  const can=feature=>writesEnabled===true||Boolean(writesEnabled?.[feature]);
  const liveLucky=Boolean(writesEnabled&&typeof writesEnabled==='object'&&writesEnabled.lucky_live);
  const run=(name,action,body={})=>rpc(name,{p_action:action,p_payload:body});
  const write=async(name,action,body)=>{await assertCurrent();return run(name,action,body);};
  async function all(name,action,body={},entity){
    const items=[];
    for(let offset=0;offset<10000;){
      const result=await rpc(name,{p_action:action,...(entity?{p_entity:entity}:{}),p_payload:{...body,offset,limit:100}});
      items.push(...(result.items||[]));offset+=(result.items||[]).length;
      if(offset>=result.total||!result.items?.length)return items;
    }
    throw new Error('inline_too_many_records');
  }
  return async function command(action,b={}){
    await assertCurrent();
    const current=await resolve(),c=current?.customer;
    const phone=c?.phones?.[0]||current?.context?.phone||'';
    const couponFields=['id','customer_id','name','page_id','currency','amount_minor','minimum_minor','expires_on','created_at','version','reserved_at','redeemed_order_id','status','source','source_order_id','read_only'];
    const cleanCoupon=x=>Object.fromEntries(couponFields.map(k=>[k,x[k]??null]));
    async function wallet(id){
      try{const result=await run('dwell_ops_coupon_wallet','list',{customer_id:id});return {...result,items:(result.items||[]).map(cleanCoupon),preview_only:!can('coupons'),can_redeem:can('coupon_redeem')};}
      catch(e){
        if(e.code!=='PGRST202'&&!/Could not find the function|function .*does not exist/.test(e.message||''))throw e;
        const old=await run('dwell_ops_orders_api','customer',{id});const today=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Kuala_Lumpur',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
        return {customer_id:id,can_manage:false,can_redeem:can('coupon_redeem'),preview_only:true,upgrade_required:true,legacy_coupons:old.legacy_coupons||[],items:(old.coupons||[]).map(x=>cleanCoupon({...x,source:x.source_order_id?'order':'unknown',status:x.manual_redeemed_at||x.redeemed_order_id?'used':x.revoked_at?'void':x.expires_on&&x.expires_on<today?'expired':'available'}))};
      }
    }
    const needCustomer=()=>{if(!c?.id)throw new Error('inline_customer_required');};
    const messengerIdentity=()=>{
      const context=current.context;
      if(context?.platform!=='messenger'||!/^\d+$/.test(context.page||'')||!/^\d+$/.test(context.uid||''))throw new Error('inline_messenger_required');
      return {mailbox_id:context.page,uid:context.uid};
    };
    const binding=async()=>{
      const identity=messengerIdentity(),found=await run('dwell_ops_sidebar_read','messenger',identity);
      if(!['found','not_found'].includes(found.status)||found.items?.length>1)throw new Error('sidebar_binding_conflict');
      return {identity,customer_id:found.items?.[0]?.id||null,version:found.binding_version??0,preview_only:!can('bindings')};
    };
    const orders=async()=>{needCustomer();return all('dwell_ops_orders_api','list',{scope:'orders',customer_id:c.id});};
    const referralSubject=async(searchPhone='')=>{
      const requested=String(searchPhone||'').replace(/[+ ()-]/g,'');
      if(!requested)return c;
      if(!/^(60|65)\d{7,12}$/.test(requested))throw new Error('inline_phone_invalid');
      if((c?.phones||[]).some(p=>String(p).replace(/[+ ()-]/g,'')===requested))return c;
      const result=await run('dwell_ops_sidebar_read','search',{search:requested,query:requested});
      const exact=(result.items||[]).filter(item=>(item.phones||[]).some(p=>String(p).replace(/[+ ()-]/g,'')===requested));
      if(exact.length>1)throw new Error('inline_phone_ambiguous');
      return exact[0]||null;
    };
    const referrals=async(searchPhone='')=>{
      const subject=await referralSubject(searchPhone),found=new Map();
      if(!subject)return {items:[],subject:null};
      for(const p of subject.phones||[]){
        for(const r of await all('dwell_ops_referrals_api','list',{search:p})){
          if(r.buyer_id===subject.id||r.referrer_id===subject.id||r.eligibility?.referrer_id===subject.id)found.set(r.id,r);
        }
      }
      return {items:[...found.values()],subject:{id:subject.id,name:subject.name,phones:subject.phones||[]}};
    };
    const lucky=async()=>{
      needCustomer();const cfg=await run('dwell_ops_lucky_api','settings');
      const campaign=cfg.campaigns?.find(x=>x.id===b.campaign_id)||cfg.campaigns?.[0];
      if(!campaign)return {campaigns:[],orders:[],results:[],grants:[],preview_only:!can('lucky')&&!can('lucky_live')};
      const own=new Set((await orders()).map(x=>x.id)),out={campaigns:cfg.campaigns,campaign,preview_only:!can('lucky')&&!can('lucky_live')};
      for(const kind of ['orders','results','grants']){
        const found=new Map();
        for(const p of c.phones||[]){
          for(const r of await all('dwell_ops_lucky_api','list',{campaign_id:campaign.id,kind,search:p})){
            if(own.has(kind==='orders'?r.id:r.order_id))found.set(r.id,r);
          }
        }
        out[kind]=[...found.values()];
      }
      return out;
    };
    let value;
    if(action==='current')value={customer:c||null,context:current.context};
    else if(action==='customer-history'){
      needCustomer();
      // Never pass the full order object (including owner-only costs) into the chat page.
      const fields=['id','number','order_date','nature','status','currency','gmv_minor','net_minor','gmv_myr_minor','net_myr_minor','payment','platform','page_name','sku_name','sku_code','product_name','quantity','tracking_number','erp_id'];
      value={items:(await orders()).filter(o=>o.customer_id===c.id).map(o=>({...Object.fromEntries(fields.map(k=>[k,o[k]??null])),
        historical:!!o.historical,
        consumption_snapshot:(o.consumption_snapshot||[]).map(x=>({days:x.days??null})),lines:(o.line_items||[]).map(l=>Object.fromEntries(['sku_name','sku_code','quantity','is_gift'].map(k=>[k,l[k]??null])))}))};
    }
    else if(action==='legacy-history'){
      needCustomer();
      try{value=await rpc('dwell_ops_legacy_customer_history',{p_customer_id:c.id});}
      catch(e){
        if(e.code!=='PGRST202'&&!/Could not find the function|function .*does not exist/.test(e.message||''))throw e;
        value=await run('dwell_ops_legacy_archive_api','profile',{customer_id:c.id});
      }
    }
    else if(action==='legacy-search'){
      const query=String(b.query||'').trim();
      if(query.length<3||query.length>100)throw new Error('inline_query_invalid');
      value=await run('dwell_ops_legacy_archive_api','search',{query});
    }
    else if(action==='legacy-crm-search'){
      const query=String(b.query||'').trim();
      if(query.length<3||query.length>100)throw new Error('inline_query_invalid');
      value=await run('dwell_ops_legacy_crm_api','search',{query});
    }
    else if(action==='legacy-crm-profile'){
      if(!b.customer_id)throw new Error('inline_customer_required');
      value=await run('dwell_ops_legacy_crm_api','profile',{customer_id:b.customer_id});
    }
    else if(action==='binding-status')value=await binding();
    else if(action==='coupon-wallet'){needCustomer();value=await wallet(c.id);}
    else if(action==='catalog'){
      value={pages:await all('dwell_ops_catalog','list',{},'pages'),skus:await all('dwell_ops_catalog','list',{},'skus'),preview_only:!can('orders'),order_promotions_enabled:!can('orders')||can('order_promotions')||(can('coupons')&&can('referrals'))};
    }else if(action==='lookup'){
      const query=String(b.query||'').trim();if(query.length<3||query.length>100)throw new Error('inline_query_invalid');
      value=await run('dwell_ops_sidebar_read','search',{search:query,query});
    }else if(action==='select'){
      if(!b.id)throw new Error('inline_customer_required');
      value=await run('dwell_ops_sidebar_read','profile',{id:b.id});
    }else if(action==='coupons'){
      const p=String(b.phone||phone).replace(/[+ ()-]/g,'');
      if(!/^(60|65)\d{7,12}$/.test(p))throw new Error('inline_phone_invalid');
      value=await run('dwell_ops_orders_api','coupons',{phone:p});
      if(value.customer_id){const info=await wallet(value.customer_id),eligible=new Set((value.items||[]).map(x=>x.id));value={...value,items:info.items.filter(x=>eligible.has(x.id)&&['available','reserved'].includes(x.status)),preview_only:info.preview_only};}
    }else if(action==='referral-next-orders'){
      const r=(await referrals(b.subject_phone)).items.find(x=>x.id===b.id);if(!r?.referrer_id)throw new Error('inline_record_scope');
      value={items:(await all('dwell_ops_orders_api','list',{scope:'orders',customer_id:r.referrer_id})).filter(o=>o.nature==='formal'&&o.status==='open'&&(o.order_date>r.order_date||(o.order_date===r.order_date&&Number(o.number)>Number(r.order_number))))};
    }else if(action==='referrals')value={...await referrals(b.subject_phone),settings:await run('dwell_ops_referrals_api','settings'),preview_only:!can('referrals')};
    else if(action==='referral-check'){
      if(!can('referralCheck'))throw new Error('inline_preview_only');
      const subject=await referralSubject(b.subject_phone);
      if(!subject?.phones?.length)throw new Error('inline_customer_required');
      value={qualified:0,held:0,scanned:0,mode:'off'};
      for(const subjectPhone of subject.phones){
        await assertCurrent();
        const checked=await rpc('dwell_ops_referral_check_new',{p_phone:subjectPhone});
        for(const key of ['qualified','held','scanned'])value[key]+=checked[key]||0;
        value.mode=checked.mode;
        value.reason=checked.reason||value.reason;
      }
    }
    else if(action==='lucky')value=await lucky();
    else {
      const feature=action==='save-order'?'orders':action==='bind-customer'||action==='unbind-customer'?'bindings':action==='coupon-redeem'?'coupon_redeem':action.startsWith('coupon-')?'coupons':action.startsWith('referral-')?'referrals':action.startsWith('lucky-')?(liveLucky?'lucky_live':'lucky'):null;
      if(feature&&!can(feature))throw new Error('inline_preview_only');
      if(!b.request_id)throw new Error('core_request_required');
      if(action==='coupon-redeem'){
        needCustomer();if(!can('coupon_redeem'))throw new Error('inline_preview_only');
        const item=(await wallet(c.id)).items.find(x=>x.id===b.id);
        if(!item)throw new Error('coupon_not_eligible');
        if(typeof b.reason!=='string'||!b.reason.trim()||b.reason.trim().length>300)throw new Error('coupon_redeem_invalid');
        value=await rpc('dwell_ops_coupon_manual_redeem',{p_customer_id:c.id,p_coupon_id:item.id,p_reason:b.reason.trim(),p_request_id:b.request_id});
      }else if(['coupon-grant','coupon-reserve','coupon-release'].includes(action)){
        if(!can('coupons'))throw new Error('inline_preview_only');
        needCustomer();value=await write('dwell_ops_coupon_wallet',action.slice(7),{...b,customer_id:c.id});
      }else if(action==='unbind-customer'){
        if(!can('bindings'))throw new Error('inline_preview_only');
        needCustomer();const state=await binding();if(state.customer_id!==c.id||state.version!==b.version)throw new Error('core_stale_version');
        value=await write('dwell_ops_sidebar_crm','unbind',{...state.identity,version:state.version,request_id:b.request_id});
      }else if(action==='bind-customer'){
        if(!can('bindings'))throw new Error('inline_preview_only');
        if(!b.customer_id||!Number.isInteger(b.version)||b.version<0)throw new Error('core_stale_version');
        const state=await binding();
        if(state.customer_id&&state.customer_id!==b.customer_id)throw new Error('sidebar_binding_conflict');
        if(state.customer_id===b.customer_id)value={customer_id:b.customer_id,version:state.version,status:'bound'};
        else{
          if(state.version!==b.version)throw new Error('core_stale_version');
          value=await write('dwell_ops_sidebar_crm','bind',{...state.identity,customer_id:b.customer_id,version:b.version,request_id:b.request_id});
        }
      }else if(action==='save-order'){
        if(!can('orders'))throw new Error('inline_preview_only');
        if(b.order?.id)throw new Error('inline_new_orders_only');
        if(!can('order_promotions')&&!can('coupons')&&(b.order?.coupon_id||b.order?.gift_coupon||Number(b.order?.coupon_minor||0)!==0))throw new Error('inline_order_promotions_disabled');
        if(!can('order_promotions')&&!can('referrals')&&b.order?.referral_phone)throw new Error('inline_order_promotions_disabled');
        const context=current.context;
        value=await write('dwell_ops_sidebar_crm','save_order',{order:{...b.order,request_id:b.request_id},identity:context.platform==='messenger'?{platform:'messenger',page:context.page,uid:context.uid}:{platform:'whatsapp',phone:context.phone}});
      }else if(['referral-approve','referral-delivery','referral-ship','referral-ship-self-postage'].includes(action)){
        if(!can('referrals'))throw new Error('inline_preview_only');
        const item=(await referrals(b.subject_phone)).items.find(r=>r.id===b.id);if(!item)throw new Error('inline_record_scope');
        value=await write('dwell_ops_referrals_api',action==='referral-ship-self-postage'?'ship_self_postage':action.slice(9),b);
      }else if(['lucky-grant','lucky-link','lucky-ship'].includes(action)){
        if(!can('lucky')&&!can('lucky_live'))throw new Error('inline_preview_only');
        const overview=await lucky();
        if(action==='lucky-grant'&&!overview.orders.some(o=>o.id===b.order_id))throw new Error('inline_record_scope');
        if(action==='lucky-ship'&&!overview.results.some(r=>r.id===b.id))throw new Error('inline_record_scope');
        value=await write(liveLucky?'dwell_ops_plugin_lucky_live':'dwell_ops_plugin_lucky',action.slice(6),{...b,customer_id:c.id,campaign_id:overview.campaign.id});
      }else throw new Error('inline_action_invalid');
    }
    await assertCurrent();return value;
  };
}
