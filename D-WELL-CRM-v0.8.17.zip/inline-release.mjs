export const inlineWritesEnabled = Object.freeze({ orders: true, order_promotions: true, bindings: true, coupons: true, coupon_redeem: true, referralCheck: true, referrals: true, lucky_live: true });
