const MAX_BYTES=8*1024*1024;
export function normalizeAIImage(value){
  try{
    const u=new URL(value);
    if(u.protocol!=='https:'||u.username||u.password||u.port)return '';
    if(u.hostname==='imgur.com'&&/^\/[a-zA-Z0-9]+\/?$/.test(u.pathname))return `https://i.imgur.com/${u.pathname.split('/')[1]}.jpeg`;
    if(u.hostname==='i.imgur.com'&&/^\/[a-zA-Z0-9]+\.(?:png|jpe?g|webp|gif)$/i.test(u.pathname))return u.origin+u.pathname;
  }catch{}
  return '';
}
export async function readAIImage({url,sources,assertCurrent,transport=fetch}){
  await assertCurrent();
  const normalized=normalizeAIImage(url);
  if(!normalized||!sources.has(normalized))throw Error('ai_image_denied');
  let bytes,type;
  try{
    const response=await transport(normalized,{credentials:'omit',referrerPolicy:'no-referrer',redirect:'error',signal:AbortSignal.timeout(20000)});
    if(!response.ok||Number(response.headers.get('content-length'))>MAX_BYTES)throw Error();
    type=(response.headers.get('content-type')||'').split(';')[0].toLowerCase();
    if(!['image/png','image/jpeg','image/webp','image/gif'].includes(type))throw Error();
    const reader=response.body.getReader(),chunks=[];let size=0;
    for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX_BYTES){await reader.cancel();throw Error();}chunks.push(value);}
    bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}
    const ascii=(start,end)=>String.fromCharCode(...bytes.slice(start,end));
    const valid=type==='image/png'?bytes[0]===137&&ascii(1,4)==='PNG':type==='image/jpeg'?bytes[0]===255&&bytes[1]===216&&bytes[2]===255:type==='image/webp'?ascii(0,4)==='RIFF'&&ascii(8,12)==='WEBP':/^GIF8[79]a$/.test(ascii(0,6));
    if(!valid)throw Error();
  }catch{throw Error('ai_image_failed');}
  await assertCurrent();
  let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));
  return {data_url:`data:${type};base64,${btoa(binary)}`};
}
