import {createAIService} from './ai-service.mjs';
import {normalizeAIImage} from './ai-images.mjs';

export const staticAIKey=(action,payload={})=>action==='prompts'||action==='media'?action:action==='listings'&&['my_cn','my_en','sg_cn','sg_en'].includes(payload.listing_key)?`listings:${payload.listing_key}`:null;

// Only fixed catalog data and bounded image previews. Never cache chat text or generation.
export function createAIStaticCache({transport=fetch}={}){
  const entries=new Map(),images=new Map(),sources=new Set();let revision=0;
  const clear=()=>{revision++;entries.clear();images.clear();sources.clear();};
  async function read(action,payload,assertAccess){
    await assertAccess();
    const key=staticAIKey(action,payload),image=action==='image';
    if(!key&&!image)throw Error('ai_action_denied');
    if(image&&!sources.has(normalizeAIImage(payload.url)))await preload(assertAccess);
    const map=image?images:entries,cacheKey=image?payload.url:key;
    if(payload.refresh===true)map.delete(cacheKey);
    let entry=map.get(cacheKey);
    if(!entry){
      const version=revision;entry={};map.set(cacheKey,entry);
      entry.pending=createAIService({transport,assertCurrent:assertAccess,imageSources:sources})(action,payload)
        .then(value=>{if(revision!==version)throw Error('sidebar_access_denied');return value;})
        .catch(error=>{if(map.get(cacheKey)===entry)map.delete(cacheKey);throw error;});
      if(image&&images.size>8)images.delete(images.keys().next().value);
    }
    const value=await entry.pending;await assertAccess();return value;
  }
  async function preload(assertAccess){
    const specs=[['prompts',{}],['media',{}],...['my_cn','my_en','sg_cn','sg_en'].map(listing_key=>['listings',{listing_key}])];
    const results=await Promise.allSettled(specs.map(async([action,payload])=>({key:staticAIKey(action,payload),value:await read(action,payload,assertAccess)})));
    await assertAccess();return {entries:results.filter(r=>r.status==='fulfilled').map(r=>r.value)};
  }
  return {read,preload,clear};
}
