(()=>{
 let running=null;
 const snapshot=()=>globalThis.DwellFlowContext?.read();
 const same=(a,b)=>a?.documentId===b?.documentId&&a?.revision===b?.revision&&a?.context?.key===b?.context?.key;
 function check(job){if(job.cancelled||!same(snapshot(),job.expected))throw Error('对话已切换或发送已停止；请核对聊天记录和输入框，未自动重试。');}
 async function guard(job){check(job);const r=await DwellTransport.send({type:'dwell-flow-job',action:'check',ticket:job.ticket});if(!r?.ok)throw Error(r?.error||'发送会话已失效');check(job);}
 function adapter(job){
  const assertCurrent=()=>check(job);
  const delay=async ms=>{const end=Date.now()+ms;do{await guard(job);await new Promise(r=>setTimeout(r,Math.min(250,Math.max(0,end-Date.now()))));check(job);}while(Date.now()<end);};
  const download=async url=>{
   await guard(job);if(!job.steps.some(s=>s.url===url))throw Error('媒体地址不在此流程');
   const r=await fetch(url,{credentials:'omit',redirect:'error',signal:job.abort.signal});if(!r.ok)throw Error('Flow 媒体下载失败');
   const mime=(r.headers.get('content-type')||'').split(';')[0];if(!/^(image\/(png|jpeg|webp|gif)|video\/(mp4|webm|quicktime)|audio\/(mpeg|mp4|ogg|wav|x-wav|webm))$/.test(mime))throw Error('不支持的媒体格式');
   const reader=r.body.getReader(),parts=[];let size=0;for(;;){check(job);const p=await reader.read();if(p.done)break;size+=p.value.length;job.mediaBytes+=p.value.length;if(size>50*1024*1024||job.mediaBytes>150*1024*1024){await reader.cancel();throw Error('单个媒体超过 50 MB 或此组媒体超过 150 MB');}parts.push(p.value);}await guard(job);
   return {ok:true,blob:async()=>new Blob(parts,{type:mime})};
  };
  return DwellFlowAdapters[job.expected.context.platform]({assertCurrent,delay,download});
 }
 async function execute(message){
  if(running)throw Error('这个对话正在发送 Flow');
  const job={...message,cancelled:false,abort:new AbortController()};running=job;
  try{
   await guard(job);const a=adapter(job);if(!a.chat().hasChat)throw Error('找不到当前聊天输入框');
   if([...document.querySelectorAll('[role=dialog],[aria-modal=true],[data-animate-modal-popup=true]')].some(n=>n.getBoundingClientRect().width>0&&n.getBoundingClientRect().height>0&&getComputedStyle(n).visibility!=='hidden'))throw Error('请先关闭聊天页面已有的弹窗或附件预览，再发送 Flow');
   const box=DwellAIChat.composer(job.expected.context.platform);if(!box)throw Error('找不到唯一的聊天输入框');if((box.value??box.innerText??'').trim())throw Error('回复框已有草稿，未覆盖。请先处理原草稿。');
   for(let i=0;i<job.steps.length;i++){
    await guard(job);job.mediaBytes=0;const step=job.steps[i];void DwellTransport.send({type:'dwell-flow-progress',ticket:job.ticket,message:`正在发送 ${i+1}/${job.steps.length}：${({text:'文字',image:'照片',video:'视频',audio:'音频',wait:'等待'})[step.kind]}`}).catch(()=>{});
    if(step.kind==='text')await a.text(step.text_content);
    else if(step.kind==='image'){const items=[];while(i<job.steps.length&&job.steps[i].kind==='image'&&items.length<30){const s=job.steps[i++];items.push({url:s.url,filename:s.media_path.split('/').pop()});}--i;await a.images(items);}
    else if(['audio','video'].includes(step.kind))await a.file(step.url,step.media_path.split('/').pop(),step.kind);
    else if(step.kind==='wait'){const until=Date.now()+Number(step.delay_ms);while(Date.now()<until){await guard(job);await new Promise(r=>setTimeout(r,Math.min(250,until-Date.now())));}}
    else throw Error('不支持的 Flow 步骤');await guard(job);
   }return {ok:true};
  }finally{job.abort.abort();if(running===job)running=null;}
 }
 chrome.runtime.onMessage.addListener((m,s,respond)=>{
  if(s.id!==chrome.runtime.id||s.tab||s.url&&!s.url.startsWith(chrome.runtime.getURL('')))return;
  if(m?.type==='dwell-flow-stop'){if(running?.ticket===m.ticket){running.cancelled=true;running.abort.abort();}respond({ok:true});return;}
  if(m?.type==='dwell-flow-chat'){const expected=snapshot();if(!expected||!['ready','phone_missing'].includes(expected.context.status)){respond({hasChat:false});return;}try{const a=adapter({expected,steps:[],cancelled:false});respond(a.chat());}catch{respond({hasChat:false});}return;}
  if(m?.type!=='dwell-flow-execute')return;
  execute(m).then(respond,e=>respond({ok:false,error:e.message}));return true;
 });
 globalThis.DwellFlowSender={cancel(){if(running){running.cancelled=true;running.abort.abort();}}};
})();
