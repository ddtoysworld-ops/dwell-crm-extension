(() => {
  const documentId = crypto.randomUUID();
  let revision = 0, lastSignature = '', current = { status: 'transition' }, header = null;
  let held = false;
  const headerObserver = new MutationObserver(() => sample());
  const notify = () => DwellTransport.send({ type: 'dwell-context-invalidated' }).catch(error => {
    if (DwellTransport.classify(error) === 'context_expired') DwellEmbed.expired();
  });
  function invalidate() {
    globalThis.DwellFlowSender?.cancel();
    ++revision; current = { status: 'transition' }; DwellEmbed.invalidate(); notify();
  }
  function sample() {
    const nextHeader = document.querySelector('#main header');
    if (nextHeader !== header) {
      headerObserver.disconnect(); header = nextHeader;
      if (header) headerObserver.observe(header, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ['title', 'data-testid', 'data-icon'] });
      invalidate();
    }
    const next = DwellReadContext.observe(document, location.href);
    const signature = JSON.stringify(next);
    if (signature !== lastSignature) {
      lastSignature = signature; held = false; invalidate();
    }
    current = held ? { status: 'transition' } : next;
    const snapshot = { documentId, revision, context: current };
    DwellEmbed.sync(snapshot);
    return snapshot;
  }
  // Clear on navigation intent, before React has replaced the previous chat header.
  // If a click leaves the identity unchanged, remain blank until explicit recheck.
  document.addEventListener('pointerdown', event => {
    if (event.target instanceof Element && event.target.closest('#pane-side, [role="navigation"]')) {
      held = true; invalidate();
    }
  }, { capture: true, passive: true });
  document.addEventListener('keydown', event => {
    if (event.target instanceof Element && event.target.closest('#pane-side') && ['Enter', 'ArrowUp', 'ArrowDown'].includes(event.key)) { held = true; invalidate(); }
  }, { capture: true, passive: true });
  addEventListener('pagehide', () => { held = true; invalidate(); });
  addEventListener('popstate', () => { held = true; invalidate(); sample(); });
  addEventListener('hashchange', () => { held = true; invalidate(); sample(); });
  globalThis.navigation?.addEventListener('navigate', () => { held = true; invalidate(); });
  chrome.runtime.onMessage.addListener((message, sender, respond) => {
    if (sender.id !== chrome.runtime.id || (sender.tab && !sender.url?.startsWith(chrome.runtime.getURL('panel.html')))) return;
    if (message?.type === 'dwell-auth-update') { if(message.resetCatalog!==false)DwellAI.resetCatalog();DwellEmbed.refresh();void DwellAI.preload(DwellTransport.send);return; }
    if (message?.type === 'dwell-open-ai') { DwellEmbed.showAI();respond({ok:true});return; }
    if (message?.type !== 'dwell-context-read') return;
    if (message.recheck === true) { held = false; ++revision; }
    respond(sample());
  });
  DwellEmbed.setRecheck(() => { held = false; ++revision; sample(); });
  globalThis.DwellFlowContext=Object.freeze({read:sample});
  setInterval(sample, 250);
  sample();
  void DwellAI.preload(DwellTransport.send);
})();
