import { guardedFetch } from './readonly-client.mjs';
import { allowedWorkbenchOperation } from './workbench-policy.mjs';
import { supabaseUrl } from './live-config.mjs';
export function guardedWorkbenchFetch(transport = fetch, writesEnabled = false, inlineEnabled = false) {
  const fallback = guardedFetch(transport);
  const can=feature=>inlineEnabled===true||Boolean(inlineEnabled?.[feature]);
  return (input, options = {}) => {
    const url = new URL(typeof input === 'string' ? input : input.url || String(input));
    if (url.origin === supabaseUrl && options.method?.toUpperCase() === 'POST' && url.pathname.startsWith('/rest/v1/rpc/')) {
      let args;
      try { args = JSON.parse(options.body); } catch { throw new Error('readonly_request_invalid'); }
      if (allowedWorkbenchOperation(url.pathname.slice('/rest/v1/rpc/'.length), args, writesEnabled)) return transport(input, { ...options, redirect: 'error', credentials: 'omit' });
      const name=url.pathname.slice('/rest/v1/rpc/'.length);
      if(can('coupons')&&name==='dwell_ops_coupon_wallet'&&['grant','reserve','release'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('coupon_redeem')&&name==='dwell_ops_coupon_manual_redeem'&&args&&typeof args==='object'&&!Array.isArray(args)&&Object.keys(args).sort().join(',')==='p_coupon_id,p_customer_id,p_reason,p_request_id'&&/^[0-9a-f-]{36}$/i.test(args.p_coupon_id)&&/^[0-9a-f-]{36}$/i.test(args.p_customer_id)&&/^[0-9a-f-]{36}$/i.test(args.p_request_id)&&typeof args.p_reason==='string'&&args.p_reason.trim().length>0&&args.p_reason.length<=300)return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('bindings')&&name==='dwell_ops_sidebar_crm'&&['bind','unbind'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('orders')&&name==='dwell_ops_sidebar_crm'&&args.p_action==='save_order')return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('referralCheck')&&name==='dwell_ops_referral_check_new'&&args&&typeof args==='object'&&!Array.isArray(args)&&Object.keys(args).length===1&&/^(60|65)\d{7,12}$/.test(args.p_phone))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('referrals')&&name==='dwell_ops_referrals_api'&&['approve','delivery','ship','ship_self_postage'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('lucky')&&name==='dwell_ops_plugin_lucky'&&['grant','link','ship'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
      if(can('lucky_live')&&name==='dwell_ops_plugin_lucky_live'&&['grant','link','ship'].includes(args.p_action))return transport(input,{...options,redirect:'error',credentials:'omit'});
    }
    return fallback(input, options);
  };
}
