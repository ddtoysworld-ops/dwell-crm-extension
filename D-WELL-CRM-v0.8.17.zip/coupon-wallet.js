(()=>{
 const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!=null)n.textContent=text;if(cls)n.className=cls;return n;};
 const sources={lucky:'抽奖获得',order:'下单附送',manual:'手动赠送',legacy:'旧券转入',unknown:'赠券（来源待核对）'};
 const statuses={available:'可使用',reserved:'已安排使用',used:'已使用',expired:'已过期',void:'已作废',not_started:'未生效',review:'待核对'};
 const money=n=>n==null?'待核对':(Number(n)/100).toFixed(2);
 function mount({container,send,expected,onChanged}){
  let alive=true,serial=0,busy=false,data=null;
  const root=el('details',null,'customer-coupons'),summary=el('summary'),badge=el('span',null,'coupon-badge'),count=el('span','正在读取…','coupon-count');badge.hidden=true;summary.append(el('strong','客户优惠券'),badge,count);root.append(summary);
  const content=el('div',null,'coupon-body'),actions=el('div',null,'coupon-actions'),note=el('p',null,'coupon-note'),list=el('div',null,'coupon-list'),form=el('form',null,'coupon-grant');form.hidden=true;
  const btn=(label,fn)=>{const b=el('button',label);b.type='button';b.addEventListener('click',fn);return b;};
  const call=async(action,payload={})=>{const r=await send({type:'dwell-inline',action,payload,expected});if(!alive)throw Error('对话已切换');if(!r?.ok)throw Error(r.error||'读取失败，请重试');return r.value;};
  const message=e=>({inline_preview_only:'此操作尚未接通正式库，优惠券没有改变。',core_stale_version:'优惠券刚被更新，请刷新核对。',coupon_not_eligible:'优惠券已使用、作废或不属于此客户。',coupon_expired:'优惠券已过期。'}[e.message]||e.message);
  const refresh=btn('刷新',()=>void load()),grant=btn('＋ 手动赠券',async()=>{
   form.hidden=!form.hidden;if(form.hidden)return;
   if(page.options.length)return;try{const catalog=await call('catalog');for(const p of catalog.pages.filter(x=>x.active!==false)){const op=el('option',p.name);op.value=p.id;page.append(op);}}catch(e){note.textContent=message(e);}
  });actions.append(grant,refresh);content.append(actions,note,form,list);root.append(content);container.append(root);
  function field(label,name,type,value){const w=el('label'),input=el(type==='select'?'select':'input');w.append(el('span',label),input);input.name=name;if(type!=='select')input.type=type;input.value=value??'';form.append(w);return input;}
  const name=field('优惠券名称','name','text',''),page=field('适用主页','page_id','select',''),currency=field('币种','currency','select','');for(const c of ['MYR','SGD'])currency.append(new Option(c,c));
  const amount=field('金额','amount','number',''),minimum=field('最低消费','minimum','number','0'),expiry=field('有效期（可留空）','expires_on','date','');name.required=true;name.maxLength=100;page.required=true;amount.required=true;amount.min='.01';minimum.min='0';amount.step=minimum.step='.01';
  const submit=el('button','确认赠送');submit.type='submit';form.append(submit);let request=null,lastPayload='';
  form.addEventListener('submit',async e=>{e.preventDefault();if(busy||!form.reportValidity())return;
   const payload={name:name.value.trim(),page_id:page.value,currency:currency.value,amount_minor:Math.round(Number(amount.value)*100),minimum_minor:Math.round(Number(minimum.value||0)*100),expires_on:expiry.value||null};
   if(!confirm(`确认赠送 ${payload.name} · ${payload.currency} ${money(payload.amount_minor)}？`))return;
   const signature=JSON.stringify(payload);if(signature!==lastPayload){request=crypto.randomUUID();lastPayload=signature;}
   busy=true;submit.disabled=true;try{await call('coupon-grant',{...payload,request_id:request});request=null;lastPayload='';form.reset();minimum.value='0';form.hidden=true;await load();onChanged?.();}catch(error){if(alive)note.textContent=message(error);}finally{busy=false;submit.disabled=false;}
  });
  function row(c,legacy=false){
   const status=String(c.status||'review').toLowerCase(),node=el('details',null,'coupon-row'),top=el('summary',null,'coupon-row-top'),heading=el('span',null,'coupon-row-heading'),body=el('div',null,'coupon-row-body');
   heading.append(el('strong',c.name||'优惠券'),el('small',`${c.currency||''} ${money(c.amount_minor)}`));top.append(heading,el('span',statuses[status]||'待核对','coupon-status'));node.append(top,body);
   const origin=legacy?'旧系统 · '+(c.source==='lucky'?'抽奖':'CRM'):
    c.source==='legacy'?`${sources.legacy} · ${c.legacy_source==='lucky'?'抽奖':'CRM'}`:sources[c.source]||'来源待核对';
   body.append(el('p',`最低消费 ${c.currency||''} ${money(c.minimum_minor)}`),el('p',`${origin} · ${c.expires_on?'有效至 '+c.expires_on:'无固定期限'}`,'coupon-note'));
   if(legacy)body.append(el('p','只读记录，未切换核销','coupon-note'));
   else if(data.can_manage&&['available','reserved'].includes(status)){
    const label=el('label',null,'coupon-reserve'),input=el('input');input.type='checkbox';input.checked=status==='reserved';input.disabled=data.preview_only||!data.can_manage;label.append(input,el('span','已安排使用'));body.append(label);
    const requestId=crypto.randomUUID();input.addEventListener('change',async()=>{
     const checked=input.checked;input.checked=!checked;if(busy||!confirm(checked?'确认安排使用此券？保存订单前不会核销。':'确认取消此券的使用安排？'))return;
     busy=true;input.disabled=true;try{await call(checked?'coupon-reserve':'coupon-release',{id:c.id,version:c.version,request_id:requestId});await load();onChanged?.();}catch(e){if(alive)note.textContent=message(e);}finally{busy=false;if(input.isConnected)input.disabled=data.preview_only||!data.can_manage;}
    });
   }
   if(!legacy){
    const label=el('label',null,'coupon-reserve'),input=el('input');input.type='checkbox';input.checked=status==='used';input.disabled=status!=='available'&&status!=='reserved'||!data.can_redeem;label.append(input,el('span','已使用'));body.append(label);
    input.addEventListener('change',()=>{input.checked=false;if(!data.can_redeem)return;reasonBox.hidden=false;reason.focus();});
    const reasonBox=el('div',null,'coupon-redeem');reasonBox.hidden=true;const reason=el('input');reason.placeholder='填写核销原因';reason.maxLength=300;reasonBox.append(reason,btn('确认核销',async()=>{
     if(busy||!reason.value.trim())return;const reasonText=reason.value.trim();if(!confirm(`确认手动核销「${c.name||'优惠券'}」？此操作不可撤销。`))return;
     busy=true;try{await call('coupon-redeem',{id:c.id,version:c.version,reason:reasonText,request_id:crypto.randomUUID()});await load();onChanged?.();}catch(e){if(alive)note.textContent=message(e);}finally{busy=false;}
    }));body.append(reasonBox);
   }
   return node;
  }
  async function load(){const token=++serial;refresh.disabled=true;try{
   const result=await call('coupon-wallet');if(token!==serial)return;data=result;list.replaceChildren();
   const items=data.items||[],legacy=data.legacy_coupons||[],available=items.filter(c=>c.status==='available').length,reserved=items.filter(c=>c.status==='reserved').length;
   badge.hidden=available===0;badge.textContent=String(available);
   count.textContent=`${available?'张可用':'0 张可用'}${reserved?' · '+reserved+' 张已安排':''}`;
   note.textContent=data.upgrade_required?'':data.preview_only?'赠券和安排使用尚未开放，真实优惠券不会改变。':'';grant.hidden=!data.can_manage;grant.disabled=data.preview_only||!data.can_manage;
   for(const c of items)list.append(row(c));for(const c of legacy)list.append(row(c,true));
   if(legacy.length)list.prepend(el('p',`另有 ${legacy.filter(c=>String(c.status).toUpperCase()==='AVAILABLE').length} 张旧系统可用记录（只读）`,'coupon-note'));
   if(!items.length&&!legacy.length)list.append(el('p','暂无优惠券记录','coupon-note'));
  }catch(e){if(alive&&token===serial){badge.hidden=true;count.textContent='未载入';note.textContent=message(e);list.replaceChildren();grant.disabled=true;}}finally{if(alive&&token===serial)refresh.disabled=false;}}
  void load();return {refresh:load,dispose(){alive=false;++serial;root.remove();}};
 }
 globalThis.DwellCoupons=Object.freeze({mount,sources});
})();
