import { ContextSession } from './session.mjs';
const $ = selector => document.querySelector(selector);
const el = (tag, text, className) => { const node = document.createElement(tag); node.textContent = text ?? ''; if (className) node.className = className; return node; };
const embedded = new URL(location.href).searchParams.get('embedded') === '1';
document.body.classList.toggle('embedded', embedded);
$('#login-form').hidden = embedded; $('#open-login').hidden = !embedded;
async function call(action, payload = {}) {
  const response = await chrome.runtime.sendMessage({ type: 'dwell-view', action, ...payload });
  if (!response?.ok) throw new Error(response?.error || '插件连接中断，请重新打开侧栏。');
  return response.value;
}
const data = {
  read: (readAction, payload) => call('read', { readAction, payload }),
  resolve: context => call('read', { readAction: context.platform === 'messenger' ? 'messenger' : 'phone', payload: context.platform === 'messenger' ? { mailbox_id: context.page, uid: context.uid } : { phone: context.phone } })
};
const money = value => value == null ? '未提供' : `RM ${(Number(value) / 100).toLocaleString('en-MY', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const messages = {
  signed_out: '尚未登录', transition: '正在确认当前对话…', unsupported: '请打开 Meta Business Suite 或 WhatsApp Web 对话。',
  missing_messenger: '此页面没有完整的主页 ID 与顾客 UID，暂不能自动匹配。', no_conversation: '尚未打开对话',
  group: '群组对话，不自动关联个人客户。', unverified_chat: '暂不能确认这是个人对话，已停止自动匹配。',
  phone_missing: '当前对话没有显示完整电话号码，不能仅凭姓名自动关联。',
  legacy_plugin: '检测到现用插件。请在独立 Chrome 测试配置文件使用本插件，现用插件未改动。',
  loading: '正在读取 Supabase 客户资料…', conflict: '关联存在冲突，请人工核对；未修改关联。',
  unavailable: '客户或主页已停用，或主页资料不一致。', not_found: '未找到已导入的客户，未创建新客户。',
  matched: '已匹配 · 正式库资料', disconnected: '对话连接已断开，请刷新聊天页面后重试。'
};
function render(state) {
  $('#profile').replaceChildren();
  $('#status').textContent = state.status === 'error' ? state.error.message : messages[state.status] || '';
  $('#channel').textContent = state.context?.platform === 'messenger' ? 'Messenger' : state.context?.platform === 'whatsapp' ? 'WhatsApp' : '当前对话';
  if (!state.profile) return;
  const { customer, summary, orders } = state.profile, root = $('#profile');
  root.append(el('h1', customer.name), el('p', (customer.phones || []).join(' / '), 'phone'));
  const metrics = el('dl', '', 'metrics');
  for (const [label, value] of [['有效购买', `${summary?.purchase_count ?? 0} 次`], ['累计有效金额', money(summary?.gmv_myr_minor)]]) { const part = el('div'); part.append(el('dt', label), el('dd', value)); metrics.append(part); }
  root.append(metrics);
  const delivery = el('section', '', 'detail'); delivery.append(el('h2', '收货资料'));
  const addresses = customer.delivery_profiles || [];
  for (const address of addresses) { const item = el('div', '', 'record'); item.append(el('strong', `${address.label || '地址'}${address.is_default ? ' · 默认' : ''}`), el('p', `${address.recipient_name || ''} · ${address.recipient_phone || ''}`), el('p', address.address)); delivery.append(item); }
  if (!addresses.length) {
    for (const address of customer.addresses || []) delivery.append(el('p', address, 'muted'));
    delivery.append(el('p', customer.addresses?.length ? '历史地址 · 尚未设置默认收货资料' : '尚无收货资料', 'muted'));
  }
  root.append(delivery);
  const recent = el('section', '', 'detail'); recent.append(el('h2', '最近订单'));
  for (const order of orders || []) {
    const item = el('div', '', 'order'), label = el('span', `#${order.number}`);
    label.append(el('small', order.order_date));
    const status = order.nature === 'inquiry' ? '潜在咨询' : ({ open: '正式订单', cancelled: '已取消', cod_rejected: 'COD 拒收' })[order.status] || order.status;
    const amount = el('span', order.nature === 'inquiry' ? '—' : money(order.status === 'open' ? order.net_myr_minor ?? order.gmv_myr_minor : 0)); amount.append(el('small', status));
    item.append(label, amount); recent.append(item);
  }
  if (!orders?.length) recent.append(el('p', '尚无已导入订单', 'muted'));
  root.append(recent, el('p', '优惠券与奖励尚未载入，不代表客户没有奖励。', 'muted'));
}
const session = new ContextSession(data, render, async (tabId, snapshot) => {
  const result = await call('context', { windowId });
  const fresh = result.snapshot;
  return result.tabId === tabId && fresh?.documentId === snapshot.documentId && fresh.revision === snapshot.revision && JSON.stringify(fresh.context) === JSON.stringify(snapshot.context);
});
let member = null, authVersion = 0, polling = false, pollVersion = 0, activeTab = null, windowId, authBusy = false, checkingAuth = false;
let flowView=null;
function resetFlow(){flowView?.dispose();flowView=null;}
function mountFlow(){if(!flowView&&!$('#flow').hidden)flowView=DwellFlow.mount({container:$('#flow'),send:message=>chrome.runtime.sendMessage(message)});}
function clear(status = 'transition') { ++pollVersion; session.invalidate(status); }
function reset() {
  resetFlow();
  ++authVersion; member = null; ++pollVersion; session.authorize(false);
  $('#login-section').hidden = false; $('#account-section').hidden = true; $('#account-name').textContent = ''; $('#refresh').disabled = true;
  $('#login-form').reset(); $('#login-button').disabled = false;
}
function signedIn(self) {
  const changed = !member; member = self;
  $('#account-name').textContent = self.display_name; $('#login-section').hidden = true; $('#account-section').hidden = false; $('#refresh').disabled = false; $('#auth-status').textContent = '';
  if (changed) { session.authorize(true); void poll(); resetFlow();mountFlow(); }
}
async function checkAuth() {
  if (authBusy || checkingAuth) return;
  checkingAuth = true; const ticket = authVersion;
  try { const result = await call('auth-state'); if (ticket !== authVersion) return; if (result.member) signedIn(result.member); else if (member) reset(); }
  catch (error) { if (ticket === authVersion) { if (member) reset(); $('#auth-status').textContent = error.message; } }
  finally { checkingAuth = false; }
}
$('#login-form').addEventListener('submit', async event => {
  event.preventDefault(); const ticket = ++authVersion; authBusy = true; $('#login-button').disabled = true; $('#auth-status').textContent = '正在登录…';
  let password = $('#login-form [name=password]').value; const email = $('#login-form [name=email]').value.trim(); $('#login-form [name=password]').value = '';
  try {
    const result = await call('login', { email, password, remember: $('#login-form [name=remember]').checked }); password = ''; if (ticket !== authVersion) return;
    signedIn(result.member); $('#login-form').reset();
  } catch (error) {
    if (ticket !== authVersion) return;
    reset(); $('#auth-status').textContent = error.message;
  } finally { password = ''; authBusy = false; $('#login-button').disabled = false; }
});
$('#logout').addEventListener('click', async () => { authBusy = true; reset(); try { await call('logout'); } catch (error) { $('#auth-status').textContent = error.message; } finally { authBusy = false; } });
$('#open-login').addEventListener('click', () => { void call('open-login').catch(error => { $('#auth-status').textContent = error.message; }); });
$('#open-ai').addEventListener('click',async()=>{try{await call('open-ai',{windowId});$('#ai-status').textContent='已打开对话侧栏。';}catch{$('#ai-status').textContent='请登录并打开一个可识别的顾客对话。';}});
async function poll(recheck = false) {
  if (polling || (!embedded && windowId === undefined)) return;
  polling = true; const ticket = pollVersion;
  try {
    const result = await call('context', { windowId, recheck });
    if (ticket !== pollVersion) return;
    if (!result.snapshot) { activeTab = null; session.invalidate(member ? result.status : 'signed_out'); return; }
    if (activeTab !== result.tabId) { activeTab = result.tabId; session.invalidate(member ? 'transition' : 'signed_out'); }
    const snapshot = result.snapshot;
    // Do not await a network lookup: context polling must continue during slow reads.
    if (member) void session.accept(result.tabId, snapshot);
    if (embedded) void call('embedded-ready', { documentId: snapshot.documentId, revision: snapshot.revision }).catch(() => {});
  } catch { if (ticket === pollVersion && member) session.invalidate('disconnected'); }
  finally { polling = false; }
}
chrome.runtime.onMessage.addListener((message, sender) => {
  if (sender.id !== chrome.runtime.id || sender.tab) return;
  if (message?.type === 'dwell-context-update' && message.tabId === activeTab) clear(member ? 'transition' : 'signed_out');
  if (!embedded && message?.type === 'dwell-tab-update' && message.windowId === windowId) { activeTab = null; clear(member ? 'transition' : 'signed_out'); }
  if (message?.type === 'dwell-auth-changed') { resetFlow();mountFlow();clear(member ? 'transition' : 'signed_out'); void checkAuth(); }
});
$('#refresh').addEventListener('click', () => { clear(); void poll(true); });
const tabs = [...document.querySelectorAll('[data-tab]')];
function activate(tab) { resetFlow();tabs.forEach(button => { const active = button === tab; button.setAttribute('aria-selected', String(active)); button.tabIndex = active ? 0 : -1; $(`#${button.dataset.tab}`).hidden = !active; });mountFlow(); }
tabs.forEach((tab, index) => { tab.addEventListener('click', () => activate(tab)); tab.addEventListener('keydown', event => { const offset = event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0; if (offset) { event.preventDefault(); const next = tabs[(index + offset + tabs.length) % tabs.length]; activate(next); next.focus(); } }); });
window.lucide?.createIcons();
if (!embedded) windowId = (await chrome.windows.getCurrent()).id;
await checkAuth();
setInterval(() => void checkAuth(), 2500);
setInterval(() => void poll(), 300);
