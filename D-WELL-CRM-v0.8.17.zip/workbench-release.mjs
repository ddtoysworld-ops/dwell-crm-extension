export const workbenchWritesEnabled = true;
