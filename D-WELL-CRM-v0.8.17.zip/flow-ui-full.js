(()=>{
 const chunkSize=512*1024;
 function base64(bytes){let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);}
 function mount({container,send,documentId}){
  let disposed=false,profile=null,progress=()=>{},activeTicket=null;const versions=new Map();
  let previews=0;const previewQueue=[];
  async function previewSlot(fn){if(previews>=2)await new Promise(r=>previewQueue.push(r));++previews;try{return await fn();}finally{--previews;previewQueue.shift()?.();}}
  async function call(type,action,payload={}){
   if(disposed&&action!=='stop'&&action!=='transfer-end')throw Error('面板已关闭');
   const result=await send({type,action,documentId,...(type==='dwell-flow-job'?payload:{payload})},120000);
   if(!result?.ok)throw Error(result?.error||'Flow 连接失败，请重试');
   if(disposed&&action!=='stop'&&action!=='transfer-end')throw Error('面板已关闭');return result.value;
  }
  const ops=(action,payload)=>call('dwell-flow-ops',action,payload);
  const job=(action,payload)=>call('dwell-flow-job',action,payload);
  const api={
   profile:async()=>profile=await ops('profile'),
   flows:async admin=>{const flows=await ops(admin?'admin-list':'list');for(const f of flows)versions.set(f.id,f.updated_at);return flows;},
   refresh:()=>ops('refresh'),
   logout:()=>ops('logout'),
   chat:async()=>{const windowId=!documentId?(await chrome.windows.getCurrent()).id:undefined;return job('chat',{windowId});},
   prepare:async id=>{const windowId=!documentId?(await chrome.windows.getCurrent()).id:undefined;const value=await job('prepare',{id,windowId});activeTicket=value.ticket;return value;},
   start:async ticket=>{await job('start',{ticket});while(!disposed){const status=await job('status',{ticket});progress({ticket,message:status.message});if(status.done)return status;await new Promise(r=>setTimeout(r,500));}throw Error('面板已关闭，后续发送已停止');},
   stop:ticket=>job('stop',{ticket}),
   onProgress:fn=>{progress=fn;return()=>{progress=()=>{};};},
   mediaUrl:path=>{if(!profile?.url||typeof path!=='string'||path.split('/').some(p=>!p||p==='.'||p==='..')||/[\\%?#:]/.test(path))return '';return profile.url+'/storage/v1/object/public/flow-media/'+path.split('/').map(encodeURIComponent).join('/');},
   mediaLibraryAssets:()=>ops('library'),
   indexExistingMedia:async()=>{},
   mediaPreviewUrl:path=>previewSlot(async()=>{
    const info=await ops('preview-begin',{path}),chunks=[];
    try{for(let i=0;i<Math.ceil(info.size/info.chunkSize);i++){const part=await ops('preview-chunk',{id:info.id,index:i});chunks.push(Uint8Array.from(atob(part.data),c=>c.charCodeAt(0)));}return URL.createObjectURL(new Blob(chunks,{type:info.mime}));}
    finally{await ops('transfer-end',{id:info.id}).catch(()=>{});}
   }),
   uploadMedia:async file=>{
    const {id}=await ops('upload-begin',{name:file.name,mime:file.type,size:file.size});
    try{for(let offset=0,index=0;offset<file.size;offset+=chunkSize,index++){const data=base64(new Uint8Array(await file.slice(offset,offset+chunkSize).arrayBuffer()));await ops('upload-chunk',{id,index,data});}return (await ops('upload-finish',{id})).path;}
    finally{await ops('transfer-end',{id}).catch(()=>{});}
   },
   saveFlow:async flow=>{
    const steps=[];for(const s of flow.steps){const path=s.file?await api.uploadMedia(s.file):s.media_path;steps.push({kind:s.kind,text_content:s.text_content,delay_ms:s.delay_ms,media_path:path});}
    return ops('save',{id:flow.id,name:flow.name,folder:flow.folder,status:flow.status,updated_at:flow.updated_at||versions.get(flow.id),steps});
   },
   deleteFlow:id=>ops('delete',{id,updated_at:versions.get(id)}),
   deleteMediaAsset:asset=>ops('delete-media',{path:asset.media_path})
  };
  const view=DwellFlowLegacy.mount({container,api});
  return {refresh:view.refresh,dispose(){view.dispose();disposed=true;if(activeTicket)void job('stop',{ticket:activeTicket}).catch(()=>{});}};
 }
 globalThis.DwellFlow=Object.freeze({mount});
})();
